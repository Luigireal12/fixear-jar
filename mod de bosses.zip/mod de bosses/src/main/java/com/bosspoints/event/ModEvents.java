package com.bosspoints.event;

import com.bosspoints.command.BossPointCommand;
import com.bosspoints.data.SpawnPointDefinition;
import com.bosspoints.data.SpawnPointSavedData;
import com.bosspoints.manager.BossBarManager;
import com.bosspoints.manager.DamageTracker;
import com.bosspoints.network.NetworkHandler;
import com.bosspoints.manager.MusicManager;
import com.bosspoints.manager.SpawnManager;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import com.bosspoints.client.FogColorManager;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ModEvents {

    private static final int PHASE_CHECK_INTERVAL = 40;
    private static final int BOSSBAR_UPDATE_INTERVAL = 20;
    private static final int AUTO_SPAWN_CHECK_INTERVAL = 20;

    private int tickCounter = 0;

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        BossPointCommand.register(event.getDispatcher());
    }

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = event.getServer();
        if (server == null) return;

        SpawnManager.tickTransforms(server);
        tickCounter++;

        if (tickCounter % PHASE_CHECK_INTERVAL == 0) {
            SpawnPointSavedData data = SpawnPointSavedData.get(server);
            SpawnManager.checkPhases(server, data);
        }

        if (tickCounter % BOSSBAR_UPDATE_INTERVAL == 0) {
            BossBarManager.update(server);
            MusicManager.updateAreas(server);
            SpawnManager.checkFightTimeouts(server);
            SpawnManager.checkPendingSpawns(server);
            SpawnManager.updateFogAreas(server);
        }
        SpawnManager.processPendingBroadcasts(server);
        com.bosspoints.manager.CinematicManager.tick(server);
        com.bosspoints.manager.ParticleAuraManager.tick(server);

        if (tickCounter % AUTO_SPAWN_CHECK_INTERVAL == 0) {
            checkAutoSpawn(server);
        }

        if (tickCounter >= 1200) tickCounter = 0;
    }

    private void checkAutoSpawn(MinecraftServer server) {
        SpawnPointSavedData data = SpawnPointSavedData.get(server);
        long now = server.overworld().getGameTime();
        for (SpawnPointDefinition def : data.getAll()) {
            if (def.autoSpawnIntervalTicks <= 0) continue;
            if (def.lastAutoSpawnTick < 0 || now - def.lastAutoSpawnTick >= def.autoSpawnIntervalTicks) {
                ResourceKey<net.minecraft.world.level.Level> dimKey = ResourceKey.create(
                    Registries.DIMENSION, ResourceLocation.parse(def.dimension));
                ServerLevel level = server.getLevel(dimKey);
                if (level != null) {
                    SpawnManager.trigger(def, level, null);
                    def.lastAutoSpawnTick = now;
                    data.markDirty();
                }
            }
        }
    }

    /** Rastrea daño de jugadores a bosses */
    @SubscribeEvent
    public void onLivingHurt(net.minecraftforge.event.entity.living.LivingDamageEvent event) {
        
        // Verificar si es un boss trackeado
        SpawnManager.TrackedEntity te = SpawnManager.getTracked(event.getEntity().getUUID());
        if (te == null) return;
        // Obtener el atacante (jugador)
        net.minecraft.world.entity.Entity attacker = event.getSource().getEntity();
        if (attacker instanceof net.minecraft.server.level.ServerPlayer sp) {
            DamageTracker.recordDamage(te.spawnPointName, sp.getUUID(), event.getAmount());
        }
    }

/** Limpieza cuando un jugador se desconecta del servidor */
    @SubscribeEvent
    public void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof net.minecraft.server.level.ServerPlayer sp) {
            MusicManager.onPlayerDisconnect(sp.getUUID());
            com.bosspoints.manager.CinematicManager.stopForPlayer(sp.getUUID(), sp.getServer());
        }
    }

    /** Limpiar música al conectarse (por si quedó algo de sesión anterior) */
    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof net.minecraft.server.level.ServerPlayer sp) {
            // Mandar stop-all al jugador que se conecta
            NetworkHandler.sendToPlayer(sp, new com.bosspoints.network.PacketStopMusic("__all__", 0));
        }
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        net.minecraftforge.fml.DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
            com.bosspoints.client.FogColorManager.tick();
            com.bosspoints.client.MusicPlayer.onGameTick();
            com.bosspoints.client.CinematicOverlay.tick();
            com.bosspoints.client.CustomTitleRenderer.tick();
            // Forzar primera persona durante cinematica - cada tick sin excepcion
            if (com.bosspoints.client.CinematicClientRunner.isRunning()) {
                net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
                if (mc.options.getCameraType() != net.minecraft.client.CameraType.FIRST_PERSON) {
                    mc.options.setCameraType(net.minecraft.client.CameraType.FIRST_PERSON);
                }
            }
        });
    }

    @SubscribeEvent
    public void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getLevel() instanceof ServerLevel serverLevel)) return;
        SpawnManager.onEntityJoinWorld(event.getEntity(), serverLevel);
    }

    @SubscribeEvent
    public void onLivingDrops(LivingDropsEvent event) {
        net.minecraft.nbt.CompoundTag pd = event.getEntity().getPersistentData();
        if (pd.contains(SpawnManager.NBT_SPAWN_POINT) && pd.getBoolean(SpawnManager.NBT_NO_LOOT)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onLivingDeath(LivingDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()) return;
        if (entity.getServer() == null) return;
        net.minecraft.world.entity.Entity killerEntity = event.getSource().getEntity();
        net.minecraft.server.level.ServerPlayer killer = killerEntity instanceof net.minecraft.server.level.ServerPlayer sp ? sp : null;
        SpawnManager.onEntityDeath(entity, entity.getServer(), killer);
    }
}
