package com.bosspoints.cinematic;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import team.creative.creativecore.common.util.math.vec.Vec3d;
import team.creative.creativecore.common.util.math.vec.VecNd;
import com.bosspoints.cinematic.CamAttribute;
import java.util.HashMap;
import java.util.Map.Entry;

public class CamPoint extends Vec3d {

    @net.minecraftforge.api.distmarker.OnlyIn(net.minecraftforge.api.distmarker.Dist.CLIENT)
    public static CamPoint createLocal() {
        Minecraft mc = Minecraft.getInstance();
        float pt = mc.getFrameTime();
        Vec3 vec = mc.player.getEyePosition(pt);
        return new CamPoint(vec.x, vec.y, vec.z, mc.player.getViewYRot(pt), mc.player.getViewXRot(pt), 0, 70);
    }

    public static CamPoint create(Entity entity) {
        Vec3 vec = entity.getEyePosition(1.0f);
        return new CamPoint(vec.x, vec.y, vec.z, entity.getYRot(), entity.getXRot(), 0, 70);
    }

    public double rotationYaw;
    public double rotationPitch;
    public double roll;
    public double zoom;

    public CamPoint(double x, double y, double z, double rotationYaw, double rotationPitch, double roll, double zoom) {
        super(x, y, z);
        this.rotationYaw = rotationYaw;
        this.rotationPitch = rotationPitch;
        this.roll = roll;
        this.zoom = zoom;
    }

    public CamPoint(HashMap<CamAttribute, VecNd> attributes) {
        super();
        for (Entry<CamAttribute, VecNd> entry : attributes.entrySet())
            entry.getKey().set(this, entry.getValue());
    }

    public CamPoint(CompoundTag nbt) {
        super(nbt.getDouble("x"), nbt.getDouble("y"), nbt.getDouble("z"));
        this.rotationYaw = nbt.getDouble("rotationYaw");
        this.rotationPitch = nbt.getDouble("rotationPitch");
        this.roll = nbt.getDouble("roll");
        this.zoom = nbt.getDouble("zoom");
    }

    public final Vec3d calculateViewVector() {
        float f = (float)(rotationPitch * (Math.PI / 180F));
        float f1 = (float)(-rotationYaw * (Math.PI / 180F));
        float f2 = Mth.cos(f1), f3 = Mth.sin(f1);
        float f4 = Mth.cos(f), f5 = Mth.sin(f);
        return new Vec3d(f3*f4, (-f5), f2*f4);
    }

    @Override
    public CamPoint copy() {
        return new CamPoint(x, y, z, rotationYaw, rotationPitch, roll, zoom);
    }

    public void set(CamPoint other) {
        x = other.x; y = other.y; z = other.z;
        rotationYaw = other.rotationYaw; rotationPitch = other.rotationPitch;
        roll = other.roll; zoom = other.zoom;
    }

    public void add(Vec3d vec) { x+=vec.x; y+=vec.y; z+=vec.z; }
    public void sub(Vec3d vec) { x-=vec.x; y-=vec.y; z-=vec.z; }

    public CompoundTag save() {
        CompoundTag nbt = new CompoundTag();
        nbt.putDouble("x", x); nbt.putDouble("y", y); nbt.putDouble("z", z);
        nbt.putDouble("rotationYaw", rotationYaw); nbt.putDouble("rotationPitch", rotationPitch);
        nbt.putDouble("roll", roll); nbt.putDouble("zoom", zoom);
        return nbt;
    }
}
