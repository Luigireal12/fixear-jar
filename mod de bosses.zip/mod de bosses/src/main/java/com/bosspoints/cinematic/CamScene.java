package com.bosspoints.cinematic;

import com.bosspoints.cinematic.interpolation.CamInterpolation;
import com.bosspoints.cinematic.interpolation.HermiteCamInterpolation;

import java.util.ArrayList;
import java.util.List;

/** Escena cinemática simplificada para SummonCore */
public class CamScene {
    public List<CamPoint> points = new ArrayList<>();
    public CamInterpolation interpolation = new HermiteCamInterpolation();
    public long duration; // total en ms
    public boolean loop = false;
    public boolean distanceBasedTiming = false;

    public CamScene(List<CamPoint> points, long durationMs) {
        this.points = points;
        this.duration = durationMs;
    }
}
