package com.bosspoints.network;

import com.bosspoints.BossPointsMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.List;
import java.util.Optional;

public class NetworkHandler {

    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        ResourceLocation.fromNamespaceAndPath(BossPointsMod.MOD_ID, "main"),
        () -> PROTOCOL,
        PROTOCOL::equals,
        PROTOCOL::equals
    );

    private static int id = 0;

    public static void register() {
        CHANNEL.registerMessage(id++, PacketPlayMusic.class,
            PacketPlayMusic::encode,
            PacketPlayMusic::new,
            PacketPlayMusic::handle,
            Optional.of(NetworkDirection.PLAY_TO_CLIENT));

        CHANNEL.registerMessage(id++, PacketStopMusic.class,
            PacketStopMusic::encode,
            PacketStopMusic::new,
            PacketStopMusic::handle,
            Optional.of(NetworkDirection.PLAY_TO_CLIENT));

        CHANNEL.registerMessage(id++, PacketFogColor.class,
            PacketFogColor::encode,
            PacketFogColor::new,
            PacketFogColor::handle,
            Optional.of(NetworkDirection.PLAY_TO_CLIENT));

        CHANNEL.registerMessage(id++, PacketOpenTitleEditor.class,
            PacketOpenTitleEditor::encode,
            PacketOpenTitleEditor::new,
            PacketOpenTitleEditor::handle,
            Optional.of(NetworkDirection.PLAY_TO_CLIENT));

        CHANNEL.registerMessage(id++, PacketSaveTitleEntry.class,
            PacketSaveTitleEntry::encode,
            PacketSaveTitleEntry::new,
            PacketSaveTitleEntry::handle,
            Optional.of(NetworkDirection.PLAY_TO_SERVER));

        CHANNEL.registerMessage(id++, PacketPlayCustomTitle.class,
            PacketPlayCustomTitle::encode,
            PacketPlayCustomTitle::new,
            PacketPlayCustomTitle::handle,
            Optional.of(NetworkDirection.PLAY_TO_CLIENT));

        CHANNEL.registerMessage(id++, PacketCinematicRestore.class,
            PacketCinematicRestore::encode,
            PacketCinematicRestore::new,
            PacketCinematicRestore::handle,
            Optional.of(NetworkDirection.PLAY_TO_CLIENT));

        CHANNEL.registerMessage(id++, PacketCinematicBars.class,
            PacketCinematicBars::encode,
            PacketCinematicBars::new,
            PacketCinematicBars::handle,
            Optional.of(NetworkDirection.PLAY_TO_CLIENT));

        CHANNEL.registerMessage(id++, PacketStartCinematic.class,
            PacketStartCinematic::encode,
            PacketStartCinematic::new,
            PacketStartCinematic::handle,
            Optional.of(NetworkDirection.PLAY_TO_CLIENT));

        CHANNEL.registerMessage(id++, PacketCinematicEnd.class,
            PacketCinematicEnd::encode,
            PacketCinematicEnd::new,
            PacketCinematicEnd::handle,
            Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }

    public static void sendToPlayer(ServerPlayer player, PacketPlayMusic packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }

    public static void sendToPlayer(ServerPlayer player, PacketStopMusic packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }

    public static void sendToPlayers(List<ServerPlayer> players, PacketPlayMusic packet) {
        for (ServerPlayer p : players) sendToPlayer(p, packet);
    }

    public static void sendToPlayers(List<ServerPlayer> players, PacketStopMusic packet) {
        for (ServerPlayer p : players) sendToPlayer(p, packet);
    }

    public static void sendToPlayer(ServerPlayer player, PacketFogColor packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
    public static void sendToPlayer(ServerPlayer player, PacketOpenTitleEditor packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
    public static void sendToServer(PacketSaveTitleEntry packet) {
        CHANNEL.sendToServer(packet);
    }
    public static void sendToPlayer(ServerPlayer player, PacketPlayCustomTitle packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
    public static void sendToPlayer(ServerPlayer player, PacketCinematicRestore packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
    public static void sendToPlayer(ServerPlayer player, PacketCinematicBars packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
    public static void sendToPlayer(ServerPlayer player, PacketStartCinematic packet) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
    public static void sendToServer(PacketCinematicEnd packet) {
        CHANNEL.sendToServer(packet);
    }

    public static void sendToAll(net.minecraft.server.MinecraftServer server, PacketFogColor packet) {
        CHANNEL.send(PacketDistributor.ALL.noArg(), packet);
    }
}
