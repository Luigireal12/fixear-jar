package com.bosspoints.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class PacketCinematicBars {
    public final boolean show;

    public PacketCinematicBars(boolean show) { this.show = show; }

    public PacketCinematicBars(FriendlyByteBuf buf) { this.show = buf.readBoolean(); }

    public void encode(FriendlyByteBuf buf) { buf.writeBoolean(show); }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            net.minecraftforge.fml.DistExecutor.unsafeRunWhenOn(
                net.minecraftforge.api.distmarker.Dist.CLIENT,
                () -> () -> com.bosspoints.client.CinematicOverlay.setActive(show)
            );
        });
        ctx.get().setPacketHandled(true);
    }
}
