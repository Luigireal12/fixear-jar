package com.bosspoints.network;

import com.bosspoints.data.CustomTitleConfig.TitleEntry;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

/** Servidor → Cliente: abre el editor de título */
public class PacketOpenTitleEditor {
    /** Registrado por el cliente en BossPointsMod - evita cargar Screen en el servidor */
    public static java.util.function.Consumer<PacketOpenTitleEditor> clientHandler = null;
    public final String sp;
    public final int eidx, tidx, entryIdx;
    public final TitleEntry entry;
    public final boolean isSpawn; // true = spawn, false = transform

    public PacketOpenTitleEditor(String sp, int eidx, int tidx, int entryIdx, TitleEntry entry, boolean isSpawn) {
        this.sp=sp; this.eidx=eidx; this.tidx=tidx; this.entryIdx=entryIdx;
        this.entry=entry; this.isSpawn=isSpawn;
    }

    public PacketOpenTitleEditor(FriendlyByteBuf buf) {
        sp=buf.readUtf(); eidx=buf.readInt(); tidx=buf.readInt(); entryIdx=buf.readInt();
        isSpawn=buf.readBoolean();
        entry = new TitleEntry();
        entry.text=buf.readUtf(); entry.color=buf.readUtf();
        entry.x=buf.readFloat(); entry.y=buf.readFloat();
        entry.scale=buf.readFloat();
        entry.startTick=buf.readInt(); entry.durationTicks=buf.readInt();
        entry.fadeInTicks=buf.readInt(); entry.fadeOutTicks=buf.readInt();
        entry.font=buf.readUtf();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(sp); buf.writeInt(eidx); buf.writeInt(tidx); buf.writeInt(entryIdx);
        buf.writeBoolean(isSpawn);
        buf.writeUtf(entry.text); buf.writeUtf(entry.color);
        buf.writeFloat(entry.x); buf.writeFloat(entry.y);
        buf.writeFloat(entry.scale);
        buf.writeInt(entry.startTick); buf.writeInt(entry.durationTicks);
        buf.writeInt(entry.fadeInTicks); buf.writeInt(entry.fadeOutTicks);
        buf.writeUtf(entry.font);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        PacketOpenTitleEditor self = this;
        ctx.get().enqueueWork(() -> {
            if (clientHandler != null) clientHandler.accept(self);
        });
        ctx.get().setPacketHandled(true);
    }
}
