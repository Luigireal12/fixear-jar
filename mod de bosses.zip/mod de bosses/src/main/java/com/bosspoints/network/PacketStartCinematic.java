package com.bosspoints.network;

import com.bosspoints.data.CinematicKeyframe;
import com.bosspoints.data.CinematicTake;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Enviado del servidor al cliente para iniciar una cinemática */
public class PacketStartCinematic {

    public final double spawnX, spawnY, spawnZ;
    public final List<CinematicTake> takes;
    public final int fadeStartTick, fadeBlackDurationTicks, fadeOutStartTick, fadeInDurationTicks, fadeOutDurationTicks;

    public PacketStartCinematic(double sx, double sy, double sz, List<CinematicTake> takes,
                                 int fadeStartTick, int fadeBlackDurationTicks, int fadeOutStartTick,
                                 int fadeInDurationTicks, int fadeOutDurationTicks) {
        spawnX=sx; spawnY=sy; spawnZ=sz; this.takes=takes;
        this.fadeStartTick=fadeStartTick; this.fadeBlackDurationTicks=fadeBlackDurationTicks;
        this.fadeOutStartTick=fadeOutStartTick; this.fadeInDurationTicks=fadeInDurationTicks;
        this.fadeOutDurationTicks=fadeOutDurationTicks;
    }

    public PacketStartCinematic(FriendlyByteBuf buf) {
        spawnX=buf.readDouble(); spawnY=buf.readDouble(); spawnZ=buf.readDouble();
        fadeStartTick=buf.readInt(); fadeBlackDurationTicks=buf.readInt(); fadeOutStartTick=buf.readInt();
        fadeInDurationTicks=buf.readInt(); fadeOutDurationTicks=buf.readInt();
        int numTakes=buf.readInt();
        takes=new ArrayList<>();
        for (int t=0; t<numTakes; t++) {
            CinematicTake take = new CinematicTake();
            take.fadeStartTick=buf.readInt(); take.fadeDurationTicks=buf.readInt(); take.fadeOutStartTick=buf.readInt();
            int numKf=buf.readInt();
            for (int k=0; k<numKf; k++) {
                CinematicKeyframe kf = new CinematicKeyframe();
                kf.dx=buf.readDouble(); kf.dy=buf.readDouble(); kf.dz=buf.readDouble();
                kf.yaw=buf.readFloat(); kf.pitch=buf.readFloat();
                kf.durationTicks=buf.readInt();
                take.keyframes.add(kf);
            }
            takes.add(take);
        }
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeDouble(spawnX); buf.writeDouble(spawnY); buf.writeDouble(spawnZ);
        buf.writeInt(fadeStartTick); buf.writeInt(fadeBlackDurationTicks); buf.writeInt(fadeOutStartTick);
        buf.writeInt(fadeInDurationTicks); buf.writeInt(fadeOutDurationTicks);
        buf.writeInt(takes.size());
        for (CinematicTake take : takes) {
            buf.writeInt(take.fadeStartTick); buf.writeInt(take.fadeDurationTicks); buf.writeInt(take.fadeOutStartTick);
            buf.writeInt(take.keyframes.size());
            for (CinematicKeyframe kf : take.keyframes) {
                buf.writeDouble(kf.dx); buf.writeDouble(kf.dy); buf.writeDouble(kf.dz);
                buf.writeFloat(kf.yaw); buf.writeFloat(kf.pitch);
                buf.writeInt(kf.durationTicks);
            }
        }
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
            net.minecraftforge.fml.DistExecutor.unsafeRunWhenOn(
                net.minecraftforge.api.distmarker.Dist.CLIENT,
                () -> () -> com.bosspoints.client.CinematicClientRunner.start(this))
        );
        ctx.get().setPacketHandled(true);
    }
}
