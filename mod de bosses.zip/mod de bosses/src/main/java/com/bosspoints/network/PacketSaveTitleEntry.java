package com.bosspoints.network;

import com.bosspoints.data.CustomTitleConfig.TitleEntry;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

/** Cliente → Servidor: guarda cambios del editor */
public class PacketSaveTitleEntry {
    public final String sp;
    public final int eidx, tidx, entryIdx;
    public final boolean isSpawn;
    public final TitleEntry entry;

    public PacketSaveTitleEntry(String sp, int eidx, int tidx, int entryIdx, boolean isSpawn, TitleEntry entry) {
        this.sp=sp; this.eidx=eidx; this.tidx=tidx; this.entryIdx=entryIdx;
        this.isSpawn=isSpawn; this.entry=entry;
    }

    public PacketSaveTitleEntry(FriendlyByteBuf buf) {
        sp=buf.readUtf(); eidx=buf.readInt(); tidx=buf.readInt(); entryIdx=buf.readInt();
        isSpawn=buf.readBoolean();
        entry = new TitleEntry();
        entry.text=buf.readUtf(); entry.color=buf.readUtf();
        entry.x=buf.readFloat(); entry.y=buf.readFloat();
        entry.scale=buf.readFloat();
        entry.startTick=buf.readInt(); entry.durationTicks=buf.readInt();
        entry.fadeInTicks=buf.readInt(); entry.fadeOutTicks=buf.readInt();
        entry.font=buf.readUtf();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(sp); buf.writeInt(eidx); buf.writeInt(tidx); buf.writeInt(entryIdx);
        buf.writeBoolean(isSpawn);
        buf.writeUtf(entry.text); buf.writeUtf(entry.color);
        buf.writeFloat(entry.x); buf.writeFloat(entry.y);
        buf.writeFloat(entry.scale);
        buf.writeInt(entry.startTick); buf.writeInt(entry.durationTicks);
        buf.writeInt(entry.fadeInTicks); buf.writeInt(entry.fadeOutTicks);
        buf.writeUtf(entry.font);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null || !player.hasPermissions(2)) return;
            com.bosspoints.data.SpawnPointSavedData data = com.bosspoints.data.SpawnPointSavedData.get(player.getServer());
            com.bosspoints.data.SpawnPointDefinition def = data.get(sp);
            if (def == null || eidx >= def.entities.size()) return;
            com.bosspoints.data.CustomTitleConfig cfg;
            if (isSpawn) {
                cfg = def.entities.get(eidx).customTitles;
            } else {
                if (tidx >= def.entities.get(eidx).transforms.size()) return;
                cfg = def.entities.get(eidx).transforms.get(tidx).customTitles;
            }
            if (entryIdx >= cfg.entries.size()) return;
            cfg.entries.set(entryIdx, entry);
            data.markDirty();
        });
        ctx.get().setPacketHandled(true);
    }
}
