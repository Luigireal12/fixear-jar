package com.bosspoints.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.GameType;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

/** Servidor → Cliente: cinemática terminada, restaurar estado */
public class PacketCinematicRestore {
    public final double x, y, z;
    public final float yaw, pitch;
    public final int gameTypeId;

    public PacketCinematicRestore(double x, double y, double z, float yaw, float pitch, GameType gt) {
        this.x=x; this.y=y; this.z=z; this.yaw=yaw; this.pitch=pitch;
        this.gameTypeId=gt.getId();
    }

    public PacketCinematicRestore(FriendlyByteBuf buf) {
        x=buf.readDouble(); y=buf.readDouble(); z=buf.readDouble();
        yaw=buf.readFloat(); pitch=buf.readFloat();
        gameTypeId=buf.readInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeDouble(x); buf.writeDouble(y); buf.writeDouble(z);
        buf.writeFloat(yaw); buf.writeFloat(pitch);
        buf.writeInt(gameTypeId);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
            net.minecraftforge.fml.DistExecutor.unsafeRunWhenOn(
                net.minecraftforge.api.distmarker.Dist.CLIENT,
                () -> () -> com.bosspoints.client.CinematicClientRunner.onServerRestore(this))
        );
        ctx.get().setPacketHandled(true);
    }
}
