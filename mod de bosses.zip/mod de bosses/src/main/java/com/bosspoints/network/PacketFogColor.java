package com.bosspoints.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Servidor → Cliente.
 * Activa/desactiva un tinte de fog color en el cliente.
 * r,g,b = -1 para restaurar el fog natural.
 */
public class PacketFogColor {

    public final float r, g, b;
    public final int fadeTicks;
    /** true = afecta el cielo, false = afecta el fog */
    public final boolean isSky;

    public PacketFogColor(float r, float g, float b, int fadeTicks) {
        this.r = r; this.g = g; this.b = b; this.fadeTicks = fadeTicks; this.isSky = false;
    }
    public PacketFogColor(float r, float g, float b, int fadeTicks, boolean isSky) {
        this.r = r; this.g = g; this.b = b; this.fadeTicks = fadeTicks; this.isSky = isSky;
    }

    public PacketFogColor(FriendlyByteBuf buf) {
        this.r = buf.readFloat(); this.g = buf.readFloat(); this.b = buf.readFloat();
        this.fadeTicks = buf.readInt(); this.isSky = buf.readBoolean();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeFloat(r); buf.writeFloat(g); buf.writeFloat(b);
        buf.writeInt(fadeTicks); buf.writeBoolean(isSky);
    }

    public void handle(Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> com.bosspoints.client.FogColorManager.receive(this));
        ctx.setPacketHandled(true);
    }

    public boolean isReset() { return r < 0; }
}
