package com.bosspoints.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Servidor → Cliente.
 * Envía el .ogg en chunks de 32KB — seguro para servidores dedicados en red.
 * El cliente ensambla los chunks antes de reproducir.
 */
public class PacketPlayMusic {

    public static final int CHUNK_SIZE = 32_768; // 32KB por chunk — seguro para servidores dedicados

    public final String musicId;
    public final String fileName;
    public final float volume;
    public final float pitch;
    public final boolean loop;
    /** Índice del chunk (0-based) */
    public final int chunkIndex;
    /** Total de chunks para este archivo */
    public final int totalChunks;
    /** Bytes de este chunk */
    public final byte[] data;

    public PacketPlayMusic(String musicId, String fileName, float volume, float pitch,
                           boolean loop, int chunkIndex, int totalChunks, byte[] data) {
        this.musicId     = musicId;
        this.fileName    = fileName;
        this.volume      = volume;
        this.pitch       = pitch;
        this.loop        = loop;
        this.chunkIndex  = chunkIndex;
        this.totalChunks = totalChunks;
        this.data        = data;
    }

    public PacketPlayMusic(FriendlyByteBuf buf) {
        this.musicId     = buf.readUtf();
        this.fileName    = buf.readUtf();
        this.volume      = buf.readFloat();
        this.pitch       = buf.readFloat();
        this.loop        = buf.readBoolean();
        this.chunkIndex  = buf.readInt();
        this.totalChunks = buf.readInt();
        int len = buf.readInt();
        this.data = new byte[len];
        buf.readBytes(this.data);
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(musicId);
        buf.writeUtf(fileName);
        buf.writeFloat(volume);
        buf.writeFloat(pitch);
        buf.writeBoolean(loop);
        buf.writeInt(chunkIndex);
        buf.writeInt(totalChunks);
        buf.writeInt(data.length);
        buf.writeBytes(data);
    }

    public void handle(Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> com.bosspoints.client.MusicPlayer.receiveChunk(this));
        ctx.setPacketHandled(true);
    }
}
