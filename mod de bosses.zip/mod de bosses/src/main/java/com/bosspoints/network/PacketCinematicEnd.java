package com.bosspoints.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Enviado del cliente al servidor cuando termina la cinemática */
public class PacketCinematicEnd {
    public PacketCinematicEnd() {}
    public PacketCinematicEnd(FriendlyByteBuf buf) {}
    public void encode(FriendlyByteBuf buf) {}

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                com.bosspoints.manager.CinematicManager.onClientFinished(player);
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
