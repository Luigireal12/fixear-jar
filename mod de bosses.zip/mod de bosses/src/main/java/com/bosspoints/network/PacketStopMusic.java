package com.bosspoints.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Servidor → Cliente.
 * Para o hace fade out de una canción específica o de todas.
 */
public class PacketStopMusic {

    /** ID del sonido a parar. "*" = para todo */
    public final String musicId;
    /** Ticks de fade out (0 = stop inmediato) */
    public final int fadeTicks;

    public PacketStopMusic(String musicId, int fadeTicks) {
        this.musicId   = musicId;
        this.fadeTicks = fadeTicks;
    }

    public PacketStopMusic(FriendlyByteBuf buf) {
        this.musicId   = buf.readUtf();
        this.fadeTicks = buf.readInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(musicId);
        buf.writeInt(fadeTicks);
    }

    public void handle(Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            if (musicId.equals("*")) {
                com.bosspoints.client.MusicPlayer.stopAll(fadeTicks);
            } else {
                com.bosspoints.client.MusicPlayer.receiveStop(musicId, fadeTicks);
            }
        });
        ctx.setPacketHandled(true);
    }
}
