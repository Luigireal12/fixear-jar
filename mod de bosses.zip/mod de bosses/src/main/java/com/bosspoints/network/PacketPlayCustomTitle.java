package com.bosspoints.network;

import com.bosspoints.data.CustomTitleConfig;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Servidor → Cliente: reproduce una lista de títulos custom */
public class PacketPlayCustomTitle {

    public final List<CustomTitleConfig.TitleEntry> entries;

    public PacketPlayCustomTitle(List<CustomTitleConfig.TitleEntry> entries) {
        this.entries = entries;
    }

    public PacketPlayCustomTitle(FriendlyByteBuf buf) {
        int size = buf.readInt();
        entries = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            CustomTitleConfig.TitleEntry e = new CustomTitleConfig.TitleEntry();
            e.text = buf.readUtf();
            e.color = buf.readUtf();
            e.x = buf.readFloat(); e.y = buf.readFloat();
            e.scale = buf.readFloat();
            e.startTick = buf.readInt();
            e.durationTicks = buf.readInt();
            e.fadeInTicks = buf.readInt();
            e.fadeOutTicks = buf.readInt();
            e.font = buf.readUtf();
            e.typewriter = buf.readBoolean();
            e.typewriterSpeed = buf.readInt();
            e.toX = buf.readFloat(); e.toY = buf.readFloat();
            e.shadowColor = buf.readUtf();
            entries.add(e);
        }
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(entries.size());
        for (CustomTitleConfig.TitleEntry e : entries) {
            buf.writeUtf(e.text); buf.writeUtf(e.color);
            buf.writeFloat(e.x); buf.writeFloat(e.y);
            buf.writeFloat(e.scale);
            buf.writeInt(e.startTick); buf.writeInt(e.durationTicks);
            buf.writeInt(e.fadeInTicks); buf.writeInt(e.fadeOutTicks);
            buf.writeUtf(e.font);
            buf.writeBoolean(e.typewriter);
            buf.writeInt(e.typewriterSpeed);
            buf.writeFloat(e.toX); buf.writeFloat(e.toY);
            buf.writeUtf(e.shadowColor);
        }
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
            net.minecraftforge.fml.DistExecutor.unsafeRunWhenOn(
                net.minecraftforge.api.distmarker.Dist.CLIENT,
                () -> () -> com.bosspoints.client.CustomTitleRenderer.play(entries)
            )
        );
        ctx.get().setPacketHandled(true);
    }
}
