package com.bosspoints.client;

import com.bosspoints.data.CustomTitleConfig.TitleEntry;
import com.bosspoints.network.NetworkHandler;
import com.bosspoints.network.PacketOpenTitleEditor;
import com.bosspoints.network.PacketSaveTitleEntry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class CustomTitleEditorScreen extends Screen {

    private final PacketOpenTitleEditor packet;
    private final TitleEntry working; // copia de trabajo

    // Estado del drag
    private boolean dragging = false;
    private double dragOffX, dragOffY;

    // Widgets
    private EditBox textBox, colorBox, fontBox;
    private EditBox scaleBox, startBox, durationBox, fadeInBox, fadeOutBox;

    private static final int PANEL_W = 220;

    @net.minecraftforge.api.distmarker.OnlyIn(net.minecraftforge.api.distmarker.Dist.CLIENT)
    public static void open(PacketOpenTitleEditor packet) {
        net.minecraft.client.Minecraft.getInstance().setScreen(new CustomTitleEditorScreen(packet));
    }

    public CustomTitleEditorScreen(PacketOpenTitleEditor packet) {
        super(Component.literal("Editor de Título"));
        this.packet = packet;
        this.working = cloneEntry(packet.entry);
    }

    @Override
    protected void init() {
        int px = width - PANEL_W - 5;
        int py = 10;
        int fw = PANEL_W - 10;

        // Text
        addLabel(px, py, "Texto (usa & para colores, &l negrita, &o cursiva):");
        textBox = new EditBox(font, px, py+12, fw, 16, Component.empty());
        textBox.setValue(working.text);
        textBox.setResponder(v -> working.text = v);
        addRenderableWidget(textBox);
        py += 35;

        // Color
        addLabel(px, py, "Color (#RRGGBB):");
        colorBox = new EditBox(font, px, py+12, fw, 16, Component.empty());
        colorBox.setValue(working.color);
        colorBox.setResponder(v -> working.color = v);
        addRenderableWidget(colorBox);
        py += 35;

        // Font
        addLabel(px, py, "Fuente:");
        fontBox = new EditBox(font, px, py+12, fw, 16, Component.empty());
        fontBox.setValue(working.font);
        fontBox.setResponder(v -> working.font = v);
        addRenderableWidget(fontBox);
        py += 35;

        // Scale
        addLabel(px, py, "Escala:");
        scaleBox = new EditBox(font, px, py+12, fw/2, 16, Component.empty());
        scaleBox.setValue(String.valueOf(working.scale));
        scaleBox.setResponder(v -> { try { working.scale = Float.parseFloat(v); } catch (Exception ignored) {} });
        addRenderableWidget(scaleBox);
        py += 35;

        // Timing
        addLabel(px, py, "Inicio (ticks) / Duración:");
        startBox = new EditBox(font, px, py+12, fw/2-2, 16, Component.empty());
        startBox.setValue(String.valueOf(working.startTick));
        startBox.setResponder(v -> { try { working.startTick = Integer.parseInt(v); } catch (Exception ignored) {} });
        addRenderableWidget(startBox);

        durationBox = new EditBox(font, px+fw/2+2, py+12, fw/2-2, 16, Component.empty());
        durationBox.setValue(String.valueOf(working.durationTicks));
        durationBox.setResponder(v -> { try { working.durationTicks = Integer.parseInt(v); } catch (Exception ignored) {} });
        addRenderableWidget(durationBox);
        py += 35;

        // Fade
        addLabel(px, py, "Fade In / Fade Out (ticks):");
        fadeInBox = new EditBox(font, px, py+12, fw/2-2, 16, Component.empty());
        fadeInBox.setValue(String.valueOf(working.fadeInTicks));
        fadeInBox.setResponder(v -> { try { working.fadeInTicks = Integer.parseInt(v); } catch (Exception ignored) {} });
        addRenderableWidget(fadeInBox);

        fadeOutBox = new EditBox(font, px+fw/2+2, py+12, fw/2-2, 16, Component.empty());
        fadeOutBox.setValue(String.valueOf(working.fadeOutTicks));
        fadeOutBox.setResponder(v -> { try { working.fadeOutTicks = Integer.parseInt(v); } catch (Exception ignored) {} });
        addRenderableWidget(fadeOutBox);
        py += 35;

        // Position display
        addLabel(px, py, "Posición (arrastrá el texto):");
        py += 10;
        addLabel(px, py, String.format("X: %.3f  Y: %.3f", working.x, working.y));
        py += 20;

        // Buttons
        addRenderableWidget(Button.builder(Component.literal("✔ Guardar"), btn -> save())
            .bounds(px, py, fw/2-2, 20).build());
        addRenderableWidget(Button.builder(Component.literal("✘ Cancelar"), btn -> onClose())
            .bounds(px+fw/2+2, py, fw/2-2, 20).build());
    }

    private void addLabel(int x, int y, String text) {
        // Labels are drawn in render
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        // Fondo semi-transparente del panel
        int px = width - PANEL_W - 5;
        g.fill(px-5, 0, width, height, 0xCC000000);

        // Labels
        int lx = px, ly = 10;
        g.drawString(font, "Texto (&l negrita, &o cursiva, &c rojo...):", lx, ly, 0xFFFFFF);
        ly += 35;
        g.drawString(font, "Color (#RRGGBB):", lx, ly, 0xFFFFFF);
        ly += 35;
        g.drawString(font, "Fuente:", lx, ly, 0xFFFFFF);
        ly += 35;
        g.drawString(font, "Escala:", lx, ly, 0xFFFFFF);
        ly += 35;
        g.drawString(font, "Inicio / Duración (ticks):", lx, ly, 0xFFFFFF);
        ly += 35;
        g.drawString(font, "Fade In / Fade Out (ticks):", lx, ly, 0xFFFFFF);
        ly += 35;
        g.drawString(font, "Posición (arrastrá el texto):", lx, ly, 0xFFFFFF);
        ly += 10;
        g.drawString(font, String.format("X: %.3f  Y: %.3f", working.x, working.y), lx, ly, 0xAAFFFF);

        super.render(g, mx, my, pt);

        // Preview del título en su posición
        int tw = font.width(working.text);
        int th = font.lineHeight;
        int tx = (int)(width * working.x - (tw * working.scale) / 2f);
        int ty = (int)(height * working.y - (th * working.scale) / 2f);

        g.pose().pushPose();
        g.pose().translate(tx, ty, 200);
        g.pose().scale(working.scale, working.scale, 1f);

        int color = 0xFFFFFFFF;
        try {
            String clean = working.color.startsWith("#") ? working.color.substring(1) : working.color;
            color = 0xFF000000 | Integer.parseInt(clean, 16);
        } catch (Exception ignored) {}

        g.drawString(font, working.text, 0, 0, color, true);
        g.pose().popPose();

        // Indicador de drag (borde alrededor del texto)
        g.renderOutline(tx-2, ty-2, (int)(tw*working.scale)+4, (int)(th*working.scale)+4, 0x88FFFFFF);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (super.mouseClicked(mx, my, btn)) return true;
        if (btn == 0 && isOverText(mx, my)) {
            dragging = true;
            int tw = font.width(working.text);
            int th = font.lineHeight;
            int tx = (int)(width * working.x - (tw * working.scale) / 2f);
            int ty = (int)(height * working.y - (th * working.scale) / 2f);
            dragOffX = mx - tx;
            dragOffY = my - ty;
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging) {
            int tw = font.width(working.text);
            int th = font.lineHeight;
            double newTx = mx - dragOffX + (tw * working.scale) / 2.0;
            double newTy = my - dragOffY + (th * working.scale) / 2.0;
            working.x = (float) Math.max(0, Math.min(1, newTx / width));
            working.y = (float) Math.max(0, Math.min(1, newTy / height));
            return true;
        }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        dragging = false;
        return super.mouseReleased(mx, my, btn);
    }

    private boolean isOverText(double mx, double my) {
        int tw = font.width(working.text);
        int th = font.lineHeight;
        int tx = (int)(width * working.x - (tw * working.scale) / 2f);
        int ty = (int)(height * working.y - (th * working.scale) / 2f);
        return mx >= tx-5 && mx <= tx + tw*working.scale+5
            && my >= ty-5 && my <= ty + th*working.scale+5;
    }

    private void save() {
        NetworkHandler.sendToServer(new PacketSaveTitleEntry(
            packet.sp, packet.eidx, packet.tidx, packet.entryIdx,
            packet.isSpawn, working));
        onClose();
    }

    private static TitleEntry cloneEntry(TitleEntry src) {
        TitleEntry e = new TitleEntry();
        e.text=src.text; e.color=src.color; e.font=src.font;
        e.x=src.x; e.y=src.y; e.scale=src.scale;
        e.startTick=src.startTick; e.durationTicks=src.durationTicks;
        e.fadeInTicks=src.fadeInTicks; e.fadeOutTicks=src.fadeOutTicks;
        return e;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
