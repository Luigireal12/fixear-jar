package com.bosspoints.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

@OnlyIn(Dist.CLIENT)
public class CinematicOverlay {

    private static boolean active = false;
    private static float blend = 0f;
    private static final float SPEED = 0.05f;
    private static final float BAR_RATIO = 0.12f;

    public static void setActive(boolean show) {
        active = show;
        if (show && blend <= 0f) blend = 0.01f;
    }

    public static boolean isActive() { return blend > 0f; }

    public static void tick() {
        if (active && blend < 1f) blend = Math.min(1f, blend + SPEED);
        else if (!active && blend > 0f) blend = Math.max(0f, blend - SPEED);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onRenderOverlayPre(RenderGuiOverlayEvent.Pre event) {
        if (blend > 0f) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onRenderGui(RenderGuiEvent.Post event) {
        if (blend <= 0f && !CinematicClientRunner.isFading()) return;

        Minecraft mc = Minecraft.getInstance();
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        GuiGraphics g = event.getGuiGraphics();

        // Barras negras
        if (blend > 0f) {
            int barH = (int)(sh * BAR_RATIO * blend);
            if (barH > 0) {
                int color = ((int)(255 * blend) << 24);
                g.fill(0, 0, sw, barH, color);
                g.fill(0, sh - barH, sw, sh, color);
            }
        }

        // Fade entre tomas
        if (CinematicClientRunner.isFading()) {
            float fadeAlpha = CinematicClientRunner.getFadeAlpha();
            if (fadeAlpha > 0f) {
                int fadeColor = ((int)(fadeAlpha * 255) << 24);
                g.fill(0, 0, sw, sh, fadeColor);
            }
        }
    }
}
