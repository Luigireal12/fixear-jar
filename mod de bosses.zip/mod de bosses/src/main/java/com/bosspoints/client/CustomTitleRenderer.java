package com.bosspoints.client;

import com.bosspoints.data.CustomTitleConfig.TitleEntry;
import com.bosspoints.network.NetworkHandler;
import com.bosspoints.network.PacketPlayCustomTitle;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

@OnlyIn(Dist.CLIENT)
public class CustomTitleRenderer {

    private static class ActiveTitle {
        final TitleEntry entry;
        int ticksAlive = 0;

        ActiveTitle(TitleEntry e) { entry = e; }

        float getAlpha() {
            int remaining = entry.durationTicks - ticksAlive;
            if (ticksAlive < entry.fadeInTicks)
                return (float) ticksAlive / Math.max(1, entry.fadeInTicks);
            if (remaining < entry.fadeOutTicks)
                return (float) remaining / Math.max(1, entry.fadeOutTicks);
            return 1.0f;
        }

        /** Texto visible según typewriter */
        String getVisibleText() {
            if (!entry.typewriter) return entry.text;
            int chars = Math.max(0, ticksAlive - entry.fadeInTicks) / Math.max(1, entry.typewriterSpeed);
            return entry.text.substring(0, Math.min(chars, entry.text.length()));
        }

        /** Posición X actual (con movimiento) */
        float getCurrentX() {
            if (entry.toX < 0) return entry.x;
            float t = (float) ticksAlive / Math.max(1, entry.durationTicks);
            return entry.x + (entry.toX - entry.x) * t;
        }

        /** Posición Y actual (con movimiento) */
        float getCurrentY() {
            if (entry.toY < 0) return entry.y;
            float t = (float) ticksAlive / Math.max(1, entry.durationTicks);
            return entry.y + (entry.toY - entry.y) * t;
        }

        boolean isDone() { return ticksAlive >= entry.durationTicks; }
    }

    private static final List<TitleEntry> pending = new ArrayList<>();
    private static final List<ActiveTitle> active = new ArrayList<>();
    private static int globalTick = 0;

    public static void play(List<TitleEntry> entries) {
        pending.clear();
        active.clear();
        globalTick = 0;
        pending.addAll(entries);
    }

    public static void tick() {
        pending.removeIf(e -> {
            if (globalTick >= e.startTick) {
                active.add(new ActiveTitle(e));
                return true;
            }
            return false;
        });

        active.removeIf(t -> {
            t.ticksAlive++;
            return t.isDone();
        });

        globalTick++;
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onRenderGui(RenderGuiEvent.Post event) {
        if (active.isEmpty()) return;

        Minecraft mc = Minecraft.getInstance();
        int sw = mc.getWindow().getGuiScaledWidth();
        int sh = mc.getWindow().getGuiScaledHeight();
        GuiGraphics g = event.getGuiGraphics();

        for (ActiveTitle at : active) {
            TitleEntry e = at.entry;
            float alpha = at.getAlpha();
            if (alpha <= 0) continue;

            String visibleText = at.getVisibleText();
            if (visibleText.isEmpty()) continue;

            // Parsear color
            int argb = parseColor(e.color, alpha);

            // Parsear color de sombra
            boolean hasShadow = !e.shadowColor.isEmpty();

            // Posición actual
            float cx = at.getCurrentX();
            float cy = at.getCurrentY();

            // Soportar multilinea con \n
            String[] lines = visibleText.replace("\\n", "\n").split("\n");

            g.pose().pushPose();

            float totalH = lines.length * mc.font.lineHeight * e.scale;
            float startY = sh * cy - totalH / 2f;

            for (String line : lines) {
                // Convertir & a §
                String rendered = line.replace("&", "\u00a7");
                int textWidth = mc.font.width(rendered);
                float tx = sw * cx - (textWidth * e.scale) / 2f;

                g.pose().pushPose();
                g.pose().translate(tx, startY, 0);
                g.pose().scale(e.scale, e.scale, 1f);

                if (hasShadow) {
                    int shadowArgb = parseColor(e.shadowColor, alpha * 0.5f);
                    g.drawString(mc.font, rendered, 2, 2, shadowArgb, false);
                }
                g.drawString(mc.font, rendered, 0, 0, argb, true);
                g.pose().popPose();

                startY += mc.font.lineHeight * e.scale;
            }

            g.pose().popPose();
        }
    }

    private static int parseColor(String hex, float alpha) {
        try {
            String clean = hex.startsWith("#") ? hex.substring(1) : hex;
            int rgb = Integer.parseInt(clean, 16);
            int a = (int)(alpha * 255) & 0xFF;
            return (a << 24) | (rgb & 0xFFFFFF);
        } catch (Exception e) {
            return (int)(alpha * 255) << 24 | 0xFFFFFF;
        }
    }
}
