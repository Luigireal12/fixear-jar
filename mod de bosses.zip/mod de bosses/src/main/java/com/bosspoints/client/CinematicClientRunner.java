package com.bosspoints.client;

import com.bosspoints.BossPointsMod;
import com.bosspoints.cinematic.interpolation.HermiteCamInterpolation;
import com.bosspoints.cinematic.interpolation.LinearCamInterpolation;
import com.bosspoints.data.CinematicKeyframe;
import com.bosspoints.network.NetworkHandler;
import com.bosspoints.network.PacketCinematicEnd;
import com.bosspoints.network.PacketCinematicRestore;
import com.bosspoints.network.PacketStartCinematic;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import team.creative.creativecore.common.util.math.vec.Vec3d;
import team.creative.creativecore.common.util.math.interpolation.Interpolation;

import java.util.*;

@OnlyIn(Dist.CLIENT)
public class CinematicClientRunner {

    private static boolean running = false;
    private static CameraType savedCameraType = null;
    private static long startTimeMs = 0;
    private static long totalDurationMs = 0;
    private static Interpolation<Vec3d> posInterp = null;
    private static Interpolation<Vec3d> rotInterp = null;
    private static double[] times = null;

    private static java.util.List<com.bosspoints.data.CinematicTake> allTakes;
    private static int currentTakeIdx = 0;
    private static int takeTick = 0;         // tick actual dentro de la toma
    private static float fadeAlpha = 0f;     // alpha actual del fade (0=transparente, 1=negro)
    private static com.bosspoints.data.CinematicTake currentTake = null;

    private static double mobSpawnX, mobSpawnY, mobSpawnZ;
    private static int globalTick = 0;
    private static int gFadeStart, gFadeBlackDur, gFadeOutStart, gFadeInDur, gFadeOutDur;

    public static void start(PacketStartCinematic packet) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || packet.takes.isEmpty()) return;

        allTakes = packet.takes;
        mobSpawnX = packet.spawnX; mobSpawnY = packet.spawnY; mobSpawnZ = packet.spawnZ;
        gFadeStart = packet.fadeStartTick; gFadeBlackDur = packet.fadeBlackDurationTicks;
        gFadeOutStart = packet.fadeOutStartTick; gFadeInDur = packet.fadeInDurationTicks;
        gFadeOutDur = packet.fadeOutDurationTicks;
        globalTick = 0;
        currentTakeIdx = 0;

        savedCameraType = mc.options.getCameraType();
        mc.options.setCameraType(CameraType.FIRST_PERSON);
        running = true;

        startTake(0);
        CinematicOverlay.setActive(true);
        BossPointsMod.LOGGER.info("[SummonCore|Cinematic] START takes:{} take0kf:{} take1kf:{}", 
            packet.takes.size(),
            packet.takes.size() > 0 ? packet.takes.get(0).keyframes.size() : -1,
            packet.takes.size() > 1 ? packet.takes.get(1).keyframes.size() : -1);
    }

    private static void startTake(int idx) {
        if (idx >= allTakes.size()) { stop(); return; }
        com.bosspoints.data.CinematicTake take = allTakes.get(idx);
        if (take.keyframes.size() < 2) { stop(); return; }
        currentTakeIdx = idx;
        currentTake = take;
        takeTick = 0;

        List<CinematicKeyframe> kfs = take.keyframes;
        totalDurationMs = 0;
        for (int i = 1; i < kfs.size(); i++) totalDurationMs += kfs.get(i).durationTicks * 50L;

        times = new double[kfs.size()];
        times[0] = 0;
        long acc = 0;
        for (int i = 1; i < kfs.size(); i++) {
            acc += kfs.get(i).durationTicks * 50L;
            times[i] = (double) acc / totalDurationMs;
        }

        List<Vec3d> posList = new ArrayList<>();
        List<Vec3d> rotList = new ArrayList<>();
        for (CinematicKeyframe kf : kfs) {
            posList.add(new Vec3d(mobSpawnX + kf.dx, mobSpawnY + kf.dy, mobSpawnZ + kf.dz));
            rotList.add(new Vec3d(kf.yaw, kf.pitch, 0));
        }

        posInterp = new HermiteCamInterpolation().create(times, null, null, posList, null, null);
        rotInterp = new LinearCamInterpolation().create(times, null, null, rotList, null, null);
        startTimeMs = System.currentTimeMillis();

        Minecraft mc = Minecraft.getInstance();
        Vec3d firstPos = (Vec3d) posInterp.valueAt(0);
        Vec3d firstRot = (Vec3d) rotInterp.valueAt(0);
        moveCamera(mc.player, firstPos.x, firstPos.y, firstPos.z, (float)firstRot.x, (float)firstRot.y);
        BossPointsMod.LOGGER.info("[SummonCore|Cinematic] Starting take {} keyframes:{} fadeStart:{}", idx, kfs.size(), take.fadeStartTick);
    }

    public static boolean isFading() { return fadeAlpha > 0f; }
    public static float getFadeAlpha() { return fadeAlpha; }

    public static void renderTick() {
        if (!running || posInterp == null) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) { stop(); return; }

        long elapsed = System.currentTimeMillis() - startTimeMs;

        // Avanzar tick global
        globalTick++;
        takeTick++;

        // Calcular fade alpha usando tick global
        if (gFadeStart >= 0 && globalTick >= gFadeStart && gFadeInDur > 0) {
            int t = globalTick - gFadeStart;
            if (t <= gFadeInDur) fadeAlpha = Math.min(1f, (float) t / gFadeInDur);
        }
        if (gFadeOutStart >= 0 && globalTick >= gFadeOutStart && gFadeOutDur > 0) {
            int t = globalTick - gFadeOutStart;
            fadeAlpha = Math.max(0f, 1f - (float) t / gFadeOutDur);
        }

        if (elapsed >= totalDurationMs) {
            int nextIdx = currentTakeIdx + 1;
            if (allTakes != null && nextIdx < allTakes.size()) {
                startTake(nextIdx);
            } else {
                BossPointsMod.LOGGER.info("[SummonCore|Cinematic] END all takes, allTakes size:{}", allTakes != null ? allTakes.size() : -1);
                stop();
            }
            return;
        }

        double t = Math.min(1.0, (double) elapsed / totalDurationMs);
        Vec3d pos = (Vec3d) posInterp.valueAt(t);
        Vec3d rot = (Vec3d) rotInterp.valueAt(t);
        moveCamera(mc.player, pos.x, pos.y, pos.z, (float)rot.x, (float)rot.y);
    }

    private static void moveCamera(LocalPlayer player, double x, double y, double z, float yaw, float pitch) {
        player.absMoveTo(x, y, z, yaw, pitch);
        player.yRotO = yaw;
        player.xRotO = pitch;
        player.moveTo(x, y, z, yaw, pitch);
    }

    /** Llamado por el servidor cuando confirma el fin de la cinemática */
    public static void onServerRestore(com.bosspoints.network.PacketCinematicRestore packet) {
        Minecraft mc = Minecraft.getInstance();
        mc.options.hideGui = false;
        if (savedCameraType != null) {
            mc.options.setCameraType(savedCameraType);
            savedCameraType = null;
        }
        CinematicOverlay.setActive(false);
        BossPointsMod.LOGGER.info("[SummonCore|Cinematic] Client restored by server");
    }

    private static void stop() {
        running = false;
        fadeAlpha = 0f;
        currentTake = null;
        globalTick = 0;
        posInterp = null;
        rotInterp = null;
        // NO restaurar perspectiva aquí — esperar confirmación del servidor
        NetworkHandler.sendToServer(new PacketCinematicEnd());
    }

    public static boolean isRunning() { return running; }

    public static void forceStop() {
        running = false;
        posInterp = null;
        rotInterp = null;
        Minecraft mc = Minecraft.getInstance();
        mc.options.hideGui = false;
        if (savedCameraType != null) {
            mc.options.setCameraType(savedCameraType);
            savedCameraType = null;
        }
        CinematicOverlay.setActive(false);
    }
}
