package com.bosspoints.client;

import com.bosspoints.network.PacketFogColor;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Gestiona el tinte de fog en el cliente.
 * Se registra en el event bus de Forge para interceptar el cálculo del fog color.
 */
@OnlyIn(Dist.CLIENT)
public class FogColorManager {

    // ── Fog color ─────────────────────────────────────────────────────────────
    private static float fogTargetR = -1, fogTargetG = -1, fogTargetB = -1;
    private static float fogCurrentBlend = 0f;
    private static float fogTargetBlend  = 0f;
    private static float fogBlendSpeed   = 0.05f;

    // Sky color delegado a SkyColorManager

    // ── Recibir paquete del servidor ──────────────────────────────────────────

    public static void receive(PacketFogColor packet) {
        float speed = packet.fadeTicks > 0 ? 1f / packet.fadeTicks : 1f;
        if (packet.isSky) {
            // Delegar al SkyColorManager que usa DimensionSpecialEffects
            SkyColorManager.receive(packet.isReset() ? -1 : packet.r,
                                    packet.isReset() ? -1 : packet.g,
                                    packet.isReset() ? -1 : packet.b,
                                    packet.fadeTicks);
        } else {
            if (packet.isReset()) { fogTargetBlend = 0f; fogBlendSpeed = speed; }
            else { fogTargetR = packet.r; fogTargetG = packet.g; fogTargetB = packet.b; fogTargetBlend = 1f; fogBlendSpeed = speed; }
        }
    }

    // ── Tick cliente (actualiza la animación) ─────────────────────────────────

    public static void tick() {
        if (fogCurrentBlend < fogTargetBlend) fogCurrentBlend = Math.min(fogTargetBlend, fogCurrentBlend + fogBlendSpeed);
        else if (fogCurrentBlend > fogTargetBlend) fogCurrentBlend = Math.max(fogTargetBlend, fogCurrentBlend - fogBlendSpeed);
        SkyColorManager.tick(); // tick del sky color
        com.bosspoints.client.CinematicClientRunner.renderTick(); // animación cinemática
    }

    // ── Evento de fog color (cliente) ─────────────────────────────────────────

    @SubscribeEvent
    public void onComputeFogColor(ViewportEvent.ComputeFogColor event) {
        if (fogCurrentBlend <= 0f && fogTargetR < 0) return;

        // Interpolar entre el fog natural y el color objetivo
        float blend = fogCurrentBlend;
        event.setRed  (Mth.lerp(blend, event.getRed(),   fogTargetR));
        event.setGreen(Mth.lerp(blend, event.getGreen(), fogTargetG));
        event.setBlue (Mth.lerp(blend, event.getBlue(),  fogTargetB));
    }

    @SubscribeEvent
    public void onClientDisconnect(net.minecraftforge.client.event.ClientPlayerNetworkEvent.LoggingOut event) {
        MusicPlayer.stopAll(0);
        reset();
        SkyColorManager.reset();
        com.bosspoints.client.CinematicClientRunner.forceStop();
    }

    public static boolean isActive() { return fogCurrentBlend > 0f || fogTargetBlend > 0f; }

    public static void reset() {
        fogTargetBlend = fogCurrentBlend = 0f; fogTargetR = fogTargetG = fogTargetB = -1;
        SkyColorManager.reset();
    }
}
