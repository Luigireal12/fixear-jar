package com.bosspoints.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import org.lwjgl.opengl.GL11;

@OnlyIn(Dist.CLIENT)
public class SkyColorManager {

    private static float targetR = -1, targetG = -1, targetB = -1;
    private static float currentBlend = 0f, targetBlend = 0f, blendSpeed = 0.05f;

    public static void receive(float r, float g, float b, int fadeTicks) {
        float speed = fadeTicks > 0 ? 1f / fadeTicks : 1f;
        if (r < 0) { targetBlend = 0f; blendSpeed = speed; }
        else { targetR = r; targetG = g; targetB = b; targetBlend = 1f; blendSpeed = speed; }
    }

    public static void tick() {
        if (currentBlend < targetBlend) currentBlend = Math.min(targetBlend, currentBlend + blendSpeed);
        else if (currentBlend > targetBlend) currentBlend = Math.max(targetBlend, currentBlend - blendSpeed);
    }

    public static void reset() {
        targetBlend = 0f; currentBlend = 0f;
        targetR = targetG = targetB = -1;
    }

    @SubscribeEvent
    public void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) return;
        if (currentBlend <= 0.01f || targetR < 0) return;

        float r = Mth.lerp(currentBlend, 0f, targetR);
        float g = Mth.lerp(currentBlend, 0f, targetG);
        float b = Mth.lerp(currentBlend, 0f, targetB);
        int ri = (int)(r * 255), gi = (int)(g * 255), bi = (int)(b * 255);
        int ai = (int)(currentBlend * 180); // semi-transparente para que sol/luna se vean

        PoseStack pose = event.getPoseStack();
        pose.pushPose();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        GL11.glDepthFunc(GL11.GL_ALWAYS);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder buf = tess.getBuilder();

        // Disco superior — mismo que el sky dome de vanilla, GL_ALWAYS garantiza que pasa
        buf.begin(VertexFormat.Mode.TRIANGLE_FAN, DefaultVertexFormat.POSITION_COLOR);
        buf.vertex(pose.last().pose(), 0f, 16f, 0f).color(ri, gi, bi, ai).endVertex();
        for (int i = 0; i <= 16; i++) {
            float angle = (float)(i * Math.PI * 2.0 / 16);
            buf.vertex(pose.last().pose(), Mth.sin(angle) * 512f, 16f, Mth.cos(angle) * 512f)
               .color(ri, gi, bi, ai).endVertex();
        }
        tess.end();

        // Anillo lateral — conecta el disco superior con el horizonte
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        for (int i = 0; i < 16; i++) {
            float a1 = (float)(i * Math.PI * 2.0 / 16);
            float a2 = (float)((i + 1) * Math.PI * 2.0 / 16);
            float x1 = Mth.sin(a1) * 512f, z1 = Mth.cos(a1) * 512f;
            float x2 = Mth.sin(a2) * 512f, z2 = Mth.cos(a2) * 512f;
            buf.vertex(pose.last().pose(), x1, 16f, z1).color(ri, gi, bi, ai).endVertex();
            buf.vertex(pose.last().pose(), x2, 16f, z2).color(ri, gi, bi, ai).endVertex();
            buf.vertex(pose.last().pose(), x2, -16f, z2).color(ri, gi, bi, ai).endVertex();
            buf.vertex(pose.last().pose(), x1, -16f, z1).color(ri, gi, bi, ai).endVertex();
        }
        tess.end();

        // Disco inferior
        buf.begin(VertexFormat.Mode.TRIANGLE_FAN, DefaultVertexFormat.POSITION_COLOR);
        buf.vertex(pose.last().pose(), 0f, -16f, 0f).color(ri, gi, bi, ai).endVertex();
        for (int i = 0; i <= 16; i++) {
            float angle = (float)(i * Math.PI * 2.0 / 16);
            buf.vertex(pose.last().pose(), Mth.sin(angle) * 512f, -16f, Mth.cos(angle) * 512f)
               .color(ri, gi, bi, ai).endVertex();
        }
        tess.end();

        GL11.glDepthFunc(GL11.GL_LEQUAL);
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        pose.popPose();
    }
}
