package com.bosspoints.client;

import com.bosspoints.BossPointsMod;
import com.bosspoints.network.PacketPlayMusic;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.BufferUtils;
import org.lwjgl.stb.STBVorbis;

import javax.sound.sampled.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@OnlyIn(Dist.CLIENT)
public class MusicPlayer {

    private static final Map<String, ActiveTrack> activeTracks  = new ConcurrentHashMap<>();
    private static final Map<String, ChunkBuffer>  pendingChunks = new ConcurrentHashMap<>();
    private static boolean wasPaused = false;

    // ── Recibir chunk ─────────────────────────────────────────────────────────

    public static void receiveChunk(PacketPlayMusic packet) {
        if (packet.totalChunks == 1) {
            playBytes(packet.musicId, packet.fileName, packet.data,
                      packet.volume, packet.pitch, packet.loop);
            return;
        }
        ChunkBuffer buf = pendingChunks.computeIfAbsent(packet.musicId,
            k -> new ChunkBuffer(packet.totalChunks, packet.fileName,
                                 packet.volume, packet.pitch, packet.loop));
        buf.addChunk(packet.chunkIndex, packet.data);
        if (buf.isComplete()) {
            pendingChunks.remove(packet.musicId);
            playBytes(packet.musicId, buf.fileName, buf.assemble(),
                      buf.volume, buf.pitch, buf.loop);
        }
    }

    // ── Reproducir ────────────────────────────────────────────────────────────

    private static float getGameVolume() {
        try {
            return net.minecraft.client.Minecraft.getInstance()
                .options.getSoundSourceVolume(net.minecraft.sounds.SoundSource.RECORDS);
        } catch (Exception e) { return 1.0f; }
    }

    private static void playBytes(String musicId, String fileName, byte[] data,
                                  float volume, float pitch, boolean loop) {
        // Parar cualquier instancia previa con la misma ID (sin tocar stoppedIds)
        stopClean(musicId);

        Thread thread = new Thread(() -> {
            try {
                ByteBuffer raw = BufferUtils.createByteBuffer(data.length);
                raw.put(data).flip();

                IntBuffer channels   = BufferUtils.createIntBuffer(1);
                IntBuffer sampleRate = BufferUtils.createIntBuffer(1);
                ShortBuffer pcm      = STBVorbis.stb_vorbis_decode_memory(raw, channels, sampleRate);

                if (pcm == null) {
                    BossPointsMod.LOGGER.error("[SummonCore] STBVorbis no pudo decodificar '{}'", fileName);
                    return;
                }

                int ch   = channels.get(0);
                int rate = sampleRate.get(0);

                byte[] pcmBytes = new byte[pcm.remaining() * 2];
                for (int i = 0; i < pcm.remaining(); i++) {
                    short s = pcm.get(i);
                    pcmBytes[i * 2]     = (byte)(s & 0xff);
                    pcmBytes[i * 2 + 1] = (byte)((s >> 8) & 0xff);
                }

                BossPointsMod.LOGGER.info("[SummonCore] OGG decodificado: {} bytes PCM, {}Hz, {} canales",
                    pcmBytes.length, rate, ch);

                AudioFormat format = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    rate, 16, ch, ch * 2, rate, false
                );

                AudioInputStream stream = new AudioInputStream(
                    new ByteArrayInputStream(pcmBytes), format,
                    pcmBytes.length / format.getFrameSize()
                );

                Clip clip = AudioSystem.getClip();
                clip.open(stream);

                FloatControl gain = null;
                if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                    // Aplicar volumen del juego (categoría bloques musicales) × volumen configurado
                    gain.setValue(toDb(volume * getGameVolume()));
                }

                // Verificar si fue detenida mientras se decodificaba
                if (!activeTracks.containsKey(musicId) && pendingChunks.containsKey(musicId)) {
                    clip.close();
                    return;
                }

                ActiveTrack track = new ActiveTrack(clip, gain, volume, loop);
                activeTracks.put(musicId, track);

                BossPointsMod.LOGGER.info("[SummonCore] Iniciando reproducción: {}", musicId);

                if (loop) {
                    clip.loop(Clip.LOOP_CONTINUOUSLY);
                } else {
                    clip.start();
                    while (clip.isRunning() && activeTracks.containsKey(musicId))
                        Thread.sleep(100);
                    activeTracks.remove(musicId);
                    clip.close();
                }

            } catch (Exception e) {
                BossPointsMod.LOGGER.error("[SummonCore] Error reproduciendo '{}': {}", fileName, e.getMessage());
            }
        }, "SummonCore-Music-" + musicId);

        thread.setDaemon(true);
        thread.start();
    }

    // ── Stop limpio (interno, para reemplazar una pista) ──────────────────────

    private static void stopClean(String musicId) {
        pendingChunks.remove(musicId);
        ActiveTrack track = activeTracks.remove(musicId);
        if (track != null) {
            track.clip.stop();
            track.clip.close();
        }
    }

    // ── Stop público (con fade, llamado por paquetes del servidor) ────────────

    public static void receiveStop(String musicId, int fadeTicks) {
        if ("__all__".equals(musicId)) { stopAll(fadeTicks); return; }
        stop(musicId, fadeTicks);
    }

    public static void stop(String musicId, int fadeTicks) {
        pendingChunks.remove(musicId);
        ActiveTrack track = activeTracks.get(musicId);
        if (track == null) return;

        if (fadeTicks <= 0 || track.gain == null) {
            activeTracks.remove(musicId);
            track.clip.stop();
            track.clip.close();
        } else {
            track.fading = true;
            Thread t = new Thread(() -> {
                try {
                    float start  = track.gain.getValue();
                    float end    = track.gain.getMinimum();
                    long  fadeMs = fadeTicks * 50L;
                    long  steps  = 40;
                    long  stepMs = Math.max(1, fadeMs / steps);
                    float db     = (end - start) / steps;
                    for (int i = 0; i < steps; i++) {
                        if (!activeTracks.containsKey(musicId)) break;
                        track.gain.setValue(Math.max(end, start + db * (i + 1)));
                        Thread.sleep(stepMs);
                    }
                } catch (InterruptedException ignored) {
                } finally {
                    activeTracks.remove(musicId);
                    track.clip.stop();
                    track.clip.close();
                }
            }, "SummonCore-Fade-" + musicId);
            t.setDaemon(true);
            t.start();
        }
    }

    public static void stopAll(int fadeTicks) {
        pendingChunks.clear();
        new HashMap<>(activeTracks).keySet().forEach(id -> stop(id, fadeTicks));
    }

    /** Pausar/reanudar al pausar el juego (single player) */
    public static void onGameTick() {
        // Actualizar volumen según configuración actual del juego
        float gameVol = getGameVolume();
        activeTracks.values().forEach(t -> {
            if (t.gain != null && !t.fading) {
                try { t.gain.setValue(toDb(t.vol * gameVol)); } catch (Exception ignored) {}
            }
        });

        boolean paused = net.minecraft.client.Minecraft.getInstance().isPaused();
        if (paused == wasPaused) return;
        wasPaused = paused;
        activeTracks.values().forEach(t -> {
            if (paused) {
                t.clip.stop();
            } else {
                if (t.loop) t.clip.loop(Clip.LOOP_CONTINUOUSLY);
                else t.clip.start();
            }
        });
    }

    private static float toDb(float v) {
        if (v <= 0f) return -80f;
        return 20f * (float) Math.log10(Math.max(v, 0.0001f));
    }

    // ── Clases internas ───────────────────────────────────────────────────────

    private static class ActiveTrack {
        final Clip clip; final FloatControl gain;
        final float vol; final boolean loop;
        volatile boolean fading = false;
        ActiveTrack(Clip c, FloatControl g, float v, boolean l) {
            clip=c; gain=g; vol=v; loop=l;
        }
    }

    private static class ChunkBuffer {
        final int totalChunks; final String fileName;
        final float volume, pitch; final boolean loop;
        final byte[][] chunks; int received = 0;
        ChunkBuffer(int t, String f, float v, float p, boolean l) {
            totalChunks=t; fileName=f; volume=v; pitch=p; loop=l;
            chunks = new byte[t][];
        }
        void addChunk(int i, byte[] d) { if (chunks[i]==null) { chunks[i]=d; received++; } }
        boolean isComplete() { return received >= totalChunks; }
        byte[] assemble() {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            try { for (byte[] c : chunks) if (c != null) o.write(c); }
            catch (Exception e) { BossPointsMod.LOGGER.error("[SummonCore] Error ensamblando chunks", e); }
            return o.toByteArray();
        }
    }
}
