package com.bosspoints.config;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

public class BossConfig {

    public static ForgeConfigSpec.BooleanValue DEFAULT_BROADCAST;
    public static ForgeConfigSpec.IntValue DEFAULT_COOLDOWN;
    public static ForgeConfigSpec.ConfigValue<String> CHAT_PREFIX;
    public static ForgeConfigSpec.ConfigValue<String> DEFAULT_SPAWN_FORMAT;
    public static ForgeConfigSpec.ConfigValue<String> DEFAULT_PHASE_FORMAT;
    public static ForgeConfigSpec.ConfigValue<String> DEFAULT_TRANSFORM_FORMAT;

    // Top daño
    public static ForgeConfigSpec.ConfigValue<String> TOP_DAMAGE_HEADER;
    public static ForgeConfigSpec.ConfigValue<String> TOP_DAMAGE_MEDAL_1;
    public static ForgeConfigSpec.ConfigValue<String> TOP_DAMAGE_MEDAL_2;
    public static ForgeConfigSpec.ConfigValue<String> TOP_DAMAGE_MEDAL_3;
    public static ForgeConfigSpec.ConfigValue<String> TOP_DAMAGE_MEDAL_4;
    public static ForgeConfigSpec.ConfigValue<String> TOP_DAMAGE_MEDAL_5;
    public static ForgeConfigSpec.ConfigValue<String> TOP_DAMAGE_LINE_FORMAT;

    private static final ForgeConfigSpec SPEC;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("SummonCore - General Settings").push("general");

        CHAT_PREFIX = b
            .comment("Prefijo del chat para mensajes del mod")
            .define("chatPrefix", "&6[SummonCore]&r");

        DEFAULT_BROADCAST = b
            .comment("Broadcast messages globally by default when a boss spawns")
            .define("defaultBroadcast", true);

        DEFAULT_COOLDOWN = b
            .comment("Default cooldown in ticks between spawns (0 = no cooldown)")
            .defineInRange("defaultCooldown", 0, 0, Integer.MAX_VALUE);

        DEFAULT_SPAWN_FORMAT = b
            .comment("Spawn broadcast format. Placeholders: {player}, {entity}, {x}, {y}, {z}, {spawnpoint}")
            .define("defaultSpawnFormat", "{prefix} &f{player} invocó &e{entity} &fen &b{x}, {y}, {z}");

        DEFAULT_PHASE_FORMAT = b
            .comment("Phase message format. Placeholders: {entity}, {percent}, {health}, {maxhealth}")
            .define("defaultPhaseFormat", "{prefix} &e{entity} &fal &c{percent}% &fde vida!");

        DEFAULT_TRANSFORM_FORMAT = b
            .comment("Transform message format. Placeholders: {entity}, {newentity}, {x}, {y}, {z}")
            .define("defaultTransformFormat", "{prefix} &e{entity} &fse transforma en &e{newentity}&f!");

        b.pop();

        b.comment("Top Daño").push("topDamage");

        TOP_DAMAGE_HEADER = b
            .comment("Encabezado del top daño")
            .define("header", "&6&l⚔ Top Daño");

        TOP_DAMAGE_MEDAL_1 = b.define("medal1", "🥇");
        TOP_DAMAGE_MEDAL_2 = b.define("medal2", "🥈");
        TOP_DAMAGE_MEDAL_3 = b.define("medal3", "🥉");
        TOP_DAMAGE_MEDAL_4 = b.define("medal4", "④");
        TOP_DAMAGE_MEDAL_5 = b.define("medal5", "⑤");

        TOP_DAMAGE_LINE_FORMAT = b
            .comment("Formato de cada línea. Placeholders: {medal}, {name}, {damage}, {percent}")
            .define("lineFormat", "{medal} &f{name} &7— &e{damage} &7dmg (&a{percent}%&7)");

        b.pop();

        SPEC = b.build();
    }

    public static void register(FMLJavaModLoadingContext ctx) {
        ctx.registerConfig(ModConfig.Type.COMMON, SPEC);
    }

    public static String prefix() {
        try {
            return CHAT_PREFIX.get().replace("&", "§");
        } catch (Exception e) {
            return "§6[SummonCore]§r";
        }
    }

    public static String[] medals() {
        try {
            return new String[]{
                TOP_DAMAGE_MEDAL_1.get(),
                TOP_DAMAGE_MEDAL_2.get(),
                TOP_DAMAGE_MEDAL_3.get(),
                TOP_DAMAGE_MEDAL_4.get(),
                TOP_DAMAGE_MEDAL_5.get()
            };
        } catch (Exception e) {
            return new String[]{"🥇","🥈","🥉","④","⑤"};
        }
    }

    public static String topDamageHeader() {
        try { return TOP_DAMAGE_HEADER.get().replace("&", "§"); }
        catch (Exception e) { return "§6§l⚔ Top Daño"; }
    }

    public static String topDamageLineFormat() {
        try { return TOP_DAMAGE_LINE_FORMAT.get().replace("&", "§"); }
        catch (Exception e) { return "{medal} §f{name} §7— §e{damage} §7dmg (§a{percent}%§7)"; }
    }
}
