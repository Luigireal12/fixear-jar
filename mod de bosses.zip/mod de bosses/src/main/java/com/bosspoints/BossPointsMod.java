package com.bosspoints;

import com.bosspoints.config.BossConfig;
import com.bosspoints.event.ModEvents;
import com.bosspoints.client.FogColorManager;
import com.bosspoints.manager.ConfigFileManager;
import com.bosspoints.manager.MusicManager;
import com.bosspoints.network.NetworkHandler;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(BossPointsMod.MOD_ID)
public class BossPointsMod {

    public static final String MOD_ID = "summoncore";
    public static final Logger LOGGER = LogManager.getLogger();

    public BossPointsMod(FMLJavaModLoadingContext ctx) {
        BossConfig.register(ctx);
        ctx.getModEventBus().addListener(this::setup);
        MinecraftForge.EVENT_BUS.register(new ModEvents());
        // FogColorManager solo en cliente
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
            MinecraftForge.EVENT_BUS.register(new FogColorManager());
            MinecraftForge.EVENT_BUS.register(new com.bosspoints.client.SkyColorManager());
            MinecraftForge.EVENT_BUS.register(new com.bosspoints.client.CinematicOverlay());
            MinecraftForge.EVENT_BUS.register(new com.bosspoints.client.CustomTitleRenderer());
            com.bosspoints.network.PacketOpenTitleEditor.clientHandler = pkt -> {
                try {
                    Class.forName("com.bosspoints.client.CustomTitleEditorScreen")
                        .getMethod("open", com.bosspoints.network.PacketOpenTitleEditor.class)
                        .invoke(null, pkt);
                } catch (Exception ex) { ex.printStackTrace(); }
            };
        });
    }

    private void setup(FMLCommonSetupEvent event) {
        NetworkHandler.register();
        MusicManager.init();
        ConfigFileManager.init();
    }
}
