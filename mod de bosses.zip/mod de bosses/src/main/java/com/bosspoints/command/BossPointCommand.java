package com.bosspoints.command;

import com.bosspoints.data.*;
import com.bosspoints.manager.ConfigFileManager;
import com.bosspoints.manager.MusicManager;
import com.bosspoints.manager.SpawnManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.*;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.commands.synchronization.SuggestionProviders;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Collection;

public class BossPointCommand {

    // ── Suggestion providers ──────────────────────────────────────────────────

    private static final SuggestionProvider<CommandSourceStack> SPAWN_POINTS =
        (ctx, builder) -> {
            try {
                SpawnPointSavedData data = SpawnPointSavedData.get(ctx.getSource().getServer());
                data.getAll().forEach(def -> builder.suggest(def.name));
            } catch (Exception ignored) {}
            return builder.buildFuture();
        };

    private static final SuggestionProvider<CommandSourceStack> ATTRIBUTES =
        (ctx, builder) -> {
            // Suggest from the attribute registry (includes modded attributes)
            net.minecraftforge.registries.ForgeRegistries.ATTRIBUTES.getKeys().forEach(
                rl -> builder.suggest(rl.toString()));
            return builder.buildFuture();
        };

    private static final SuggestionProvider<CommandSourceStack> BOSSBAR_COLORS =
        (ctx, builder) -> SharedSuggestionProvider.suggest(
            new String[]{"PINK","BLUE","RED","GREEN","YELLOW","PURPLE","WHITE"}, builder);

    private static final SuggestionProvider<CommandSourceStack> BOSSBAR_STYLES =
        (ctx, builder) -> SharedSuggestionProvider.suggest(
            new String[]{"PROGRESS","NOTCHED_6","NOTCHED_10","NOTCHED_12","NOTCHED_20"}, builder);

    private static final SuggestionProvider<CommandSourceStack> CINEMATIC_STYLES =
        (ctx, builder) -> SharedSuggestionProvider.suggest(
            new String[]{"explosion","portal","smoke","ender"}, builder);

    private static final SuggestionProvider<CommandSourceStack> EFFECTS =
        (ctx, builder) -> {
            net.minecraftforge.registries.ForgeRegistries.MOB_EFFECTS.getKeys()
                .forEach(rl -> builder.suggest(rl.toString()));
            return builder.buildFuture();
        };

    private static final SuggestionProvider<CommandSourceStack> FOG_PRESETS =
        (ctx, builder) -> SharedSuggestionProvider.suggest(
            new String[]{"red","blue","purple","green","orange","dark","white","yellow","pink","cyan","none"}, builder);

    /** Resuelve nombre de preset o "r,g,b" a float[3]. null = none/reset */
    private static float[] resolveFog(String input) {
        return switch (input.toLowerCase()) {
            case "red"    -> new float[]{1.0f, 0.05f, 0.05f};
            case "blue"   -> new float[]{0.05f, 0.15f, 1.0f};
            case "purple" -> new float[]{0.5f, 0.0f, 0.8f};
            case "green"  -> new float[]{0.05f, 0.8f, 0.05f};
            case "orange" -> new float[]{1.0f, 0.4f, 0.0f};
            case "dark"   -> new float[]{0.02f, 0.02f, 0.02f};
            case "white"  -> new float[]{1.0f, 1.0f, 1.0f};
            case "yellow" -> new float[]{1.0f, 0.9f, 0.0f};
            case "pink"   -> new float[]{1.0f, 0.2f, 0.6f};
            case "cyan"   -> new float[]{0.0f, 0.8f, 0.9f};
            case "none"   -> null;
            default -> null;
        };
    }

    private static final SuggestionProvider<CommandSourceStack> MUSIC_FILES =
        (ctx, builder) -> SharedSuggestionProvider.suggest(
            com.bosspoints.manager.MusicManager.listSounds(), builder);

    // ── Register ──────────────────────────────────────────────────────────────

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
            Commands.literal("smc")
                .requires(src -> src.hasPermission(2))

                .then(Commands.literal("create")
                    .then(Commands.argument("name", StringArgumentType.word())
                        .then(Commands.argument("pos", BlockPosArgument.blockPos())
                            .executes(ctx -> create(ctx, str(ctx,"name"), BlockPosArgument.getBlockPos(ctx,"pos"))))))

                .then(Commands.literal("delete")
                    .then(Commands.argument("name", StringArgumentType.word()).suggests(SPAWN_POINTS)
                        .executes(ctx -> delete(ctx, str(ctx,"name")))))

                .then(Commands.literal("list")
                    .executes(BossPointCommand::list))

                .then(Commands.literal("info")
                    .then(Commands.argument("name", StringArgumentType.word()).suggests(SPAWN_POINTS)
                        .executes(ctx -> info(ctx, str(ctx,"name")))))

                .then(Commands.literal("trigger")
                    .then(Commands.argument("name", StringArgumentType.word()).suggests(SPAWN_POINTS)
                        .executes(ctx -> trigger(ctx, str(ctx,"name")))))

                .then(Commands.literal("tp")
                    .then(Commands.argument("name", StringArgumentType.word()).suggests(SPAWN_POINTS)
                        .executes(ctx -> tp(ctx, str(ctx,"name")))))

                .then(Commands.literal("kill")
                    .then(Commands.argument("name", StringArgumentType.word()).suggests(SPAWN_POINTS)
                        .executes(ctx -> kill(ctx, str(ctx,"name")))))

                // entity
                .then(Commands.literal("entity")

                    .then(Commands.literal("add")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("entityType", ResourceLocationArgument.id()).suggests(SuggestionProviders.SUMMONABLE_ENTITIES)
                                .executes(ctx -> entityAdd(ctx, str(ctx,"sp"), rl(ctx,"entityType"), 1))
                                .then(Commands.argument("count", IntegerArgumentType.integer(1,100))
                                    .executes(ctx -> entityAdd(ctx, str(ctx,"sp"), rl(ctx,"entityType"), IntegerArgumentType.getInteger(ctx,"count")))))))

                    .then(Commands.literal("remove")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("index", IntegerArgumentType.integer(0))
                                .executes(ctx -> entityRemove(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"index"))))))

                    .then(Commands.literal("count")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("index", IntegerArgumentType.integer(0))
                                .then(Commands.argument("count", IntegerArgumentType.integer(1,100))
                                    .executes(ctx -> entityCount(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"index"), IntegerArgumentType.getInteger(ctx,"count")))))))

                    .then(Commands.literal("name")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("index", IntegerArgumentType.integer(0))
                                .then(Commands.argument("name", StringArgumentType.greedyString())
                                    .executes(ctx -> entityName(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"index"), str(ctx,"name")))))))

                    .then(Commands.literal("attr")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("index", IntegerArgumentType.integer(0))
                                .then(Commands.argument("attribute", StringArgumentType.string()).suggests(ATTRIBUTES)
                                    .then(Commands.argument("value", DoubleArgumentType.doubleArg(0))
                                        .executes(ctx -> entityAttr(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"index"), str(ctx,"attribute"), DoubleArgumentType.getDouble(ctx,"value"))))))))

                    .then(Commands.literal("attrremove")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("index", IntegerArgumentType.integer(0))
                                .then(Commands.argument("attribute", StringArgumentType.string()).suggests(ATTRIBUTES)
                                    .executes(ctx -> entityAttrRemove(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"index"), str(ctx,"attribute")))))))

                    // entity phase
                    .then(Commands.literal("phase")

                        .then(Commands.literal("add")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("hp", DoubleArgumentType.doubleArg(1,99))
                                        .executes(ctx -> phaseAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), DoubleArgumentType.getDouble(ctx,"hp"), ""))
                                        .then(Commands.argument("message", StringArgumentType.greedyString())
                                            .executes(ctx -> phaseAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), DoubleArgumentType.getDouble(ctx,"hp"), str(ctx,"message"))))))))

                        .then(Commands.literal("remove")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("pidx", IntegerArgumentType.integer(0))
                                        .executes(ctx -> phaseRemove(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"pidx")))))))

                        .then(Commands.literal("msg")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("pidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("message", StringArgumentType.greedyString())
                                            .executes(ctx -> phaseMsg(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"pidx"), str(ctx,"message"))))))))

                        .then(Commands.literal("cmd")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("pidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("command", StringArgumentType.greedyString())
                                            .executes(ctx -> phaseCmd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"pidx"), str(ctx,"command"))))))))

                        .then(Commands.literal("attr")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("pidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("attribute", StringArgumentType.string()).suggests(ATTRIBUTES)
                                            .then(Commands.argument("value", DoubleArgumentType.doubleArg(0))
                                                .executes(ctx -> phaseAttr(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"pidx"), str(ctx,"attribute"), DoubleArgumentType.getDouble(ctx,"value")))))))))

                        .then(Commands.literal("attrremove")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("pidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("attribute", StringArgumentType.string()).suggests(ATTRIBUTES)
                                            .executes(ctx -> phaseAttrRemove(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"pidx"), str(ctx,"attribute"))))))))

                        .then(Commands.literal("title")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("pidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("title", StringArgumentType.greedyString())
                                            .executes(ctx -> phaseTitleSet(ctx, str(ctx,"sp"),
                                                IntegerArgumentType.getInteger(ctx,"eidx"),
                                                IntegerArgumentType.getInteger(ctx,"pidx"),
                                                str(ctx,"title"), "")))))))

                        .then(Commands.literal("subtitle")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("pidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("subtitle", StringArgumentType.greedyString())
                                            .executes(ctx -> phaseTitleSetSub(ctx, str(ctx,"sp"),
                                                IntegerArgumentType.getInteger(ctx,"eidx"),
                                                IntegerArgumentType.getInteger(ctx,"pidx"),
                                                str(ctx,"subtitle"))))))))

                        .then(Commands.literal("fog")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("pidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("color", StringArgumentType.word()).suggests(FOG_PRESETS)
                                            .executes(ctx -> phaseFog(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"pidx"), str(ctx,"color"), 40))
                                            .then(Commands.argument("fadeTicks", IntegerArgumentType.integer(0,200))
                                                .executes(ctx -> phaseFog(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"pidx"), str(ctx,"color"), IntegerArgumentType.getInteger(ctx,"fadeTicks"))))))))))

                    // entity transform
                    .then(Commands.literal("transform")

                        .then(Commands.literal("add")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("entityType", ResourceLocationArgument.id()).suggests(SuggestionProviders.SUMMONABLE_ENTITIES)
                                        .executes(ctx -> transformAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), rl(ctx,"entityType"), 60, "explosion"))
                                        .then(Commands.argument("delay", IntegerArgumentType.integer(20,600))
                                            .executes(ctx -> transformAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), rl(ctx,"entityType"), IntegerArgumentType.getInteger(ctx,"delay"), "explosion"))
                                            .then(Commands.argument("style", StringArgumentType.word()).suggests(CINEMATIC_STYLES)
                                                .executes(ctx -> transformAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), rl(ctx,"entityType"), IntegerArgumentType.getInteger(ctx,"delay"), str(ctx,"style")))))))))

                        .then(Commands.literal("remove")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .executes(ctx -> transformRemove(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx")))))))

                        .then(Commands.literal("name")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("name", StringArgumentType.greedyString())
                                            .executes(ctx -> transformName(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"name"))))))))

                        .then(Commands.literal("broadcast")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("value", BoolArgumentType.bool())
                                            .executes(ctx -> transformBroadcast(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), BoolArgumentType.getBool(ctx,"value"), ""))
                                            .then(Commands.argument("format", StringArgumentType.greedyString())
                                                .executes(ctx -> transformBroadcast(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), BoolArgumentType.getBool(ctx,"value"), str(ctx,"format")))))))))

                        .then(Commands.literal("attr")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("attribute", StringArgumentType.string()).suggests(ATTRIBUTES)
                                            .then(Commands.argument("value", DoubleArgumentType.doubleArg(0))
                                                .executes(ctx -> transformAttr(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"attribute"), DoubleArgumentType.getDouble(ctx,"value")))))))))

                        .then(Commands.literal("attrremove")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("attribute", StringArgumentType.string()).suggests(ATTRIBUTES)
                                            .executes(ctx -> transformAttrRemove(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"attribute"))))))))

                        .then(Commands.literal("noloot")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("value", BoolArgumentType.bool())
                                            .executes(ctx -> transformNoLoot(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), BoolArgumentType.getBool(ctx,"value"))))))))

                        .then(Commands.literal("title")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("title", StringArgumentType.greedyString())
                                            .executes(ctx -> transformTitleSet(ctx, str(ctx,"sp"),
                                                IntegerArgumentType.getInteger(ctx,"eidx"),
                                                IntegerArgumentType.getInteger(ctx,"tidx"),
                                                str(ctx,"title"), "")))))))

                        .then(Commands.literal("subtitle")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("subtitle", StringArgumentType.greedyString())
                                            .executes(ctx -> transformTitleSetSub(ctx, str(ctx,"sp"),
                                                IntegerArgumentType.getInteger(ctx,"eidx"),
                                                IntegerArgumentType.getInteger(ctx,"tidx"),
                                                str(ctx,"subtitle"))))))))

                        .then(Commands.literal("fog")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("color", StringArgumentType.word()).suggests(FOG_PRESETS)
                                            .executes(ctx -> transformFog(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"color"), 40))
                                            .then(Commands.argument("fadeTicks", IntegerArgumentType.integer(0,200))
                                                .executes(ctx -> transformFog(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"color"), IntegerArgumentType.getInteger(ctx,"fadeTicks")))))))))

                        .then(Commands.literal("sky")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("color", StringArgumentType.word()).suggests(FOG_PRESETS)
                                            .executes(ctx -> transformSky(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"color"), 40))
                                            .then(Commands.argument("fadeTicks", IntegerArgumentType.integer(0,200))
                                                .executes(ctx -> transformSky(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"color"), IntegerArgumentType.getInteger(ctx,"fadeTicks")))))))))

                        .then(Commands.literal("invul")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("ticks", IntegerArgumentType.integer(0))
                                            .executes(ctx -> transformInvul(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), IntegerArgumentType.getInteger(ctx,"ticks"))))))))

                        .then(Commands.literal("aura")
                            .then(Commands.literal("add")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("particle", StringArgumentType.word())
                                                .then(Commands.argument("shape", StringArgumentType.word())
                                                    .then(Commands.argument("duration", IntegerArgumentType.integer(1))
                                                        .executes(ctx -> auraAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"particle"), str(ctx,"shape"), IntegerArgumentType.getInteger(ctx,"duration"))))))))))
                            .then(Commands.literal("clear")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> auraClear(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx")))))))
                            .then(Commands.literal("list")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> auraList(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"))))))))

                        .then(Commands.literal("ctitle")
                            .then(Commands.literal("add")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("text", StringArgumentType.greedyString())
                                                .executes(ctx -> ctitleAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"text"), "transform")))))))
                            .then(Commands.literal("clear")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> ctitleClear(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), "transform"))))))
                            .then(Commands.literal("list")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> ctitleList(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), "transform"))))))
                            .then(Commands.literal("edit")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("idx", IntegerArgumentType.integer(0))
                                                .executes(ctx -> ctitleEdit(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), IntegerArgumentType.getInteger(ctx,"idx"), "transform"))))))))

                        .then(Commands.literal("cinematicfade")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("fadeStart", IntegerArgumentType.integer(-1))
                                            .then(Commands.argument("fadeInDur", IntegerArgumentType.integer(1))
                                                .then(Commands.argument("blackDur", IntegerArgumentType.integer(0))
                                                    .then(Commands.argument("fadeOutStart", IntegerArgumentType.integer(-1))
                                                        .then(Commands.argument("fadeOutDur", IntegerArgumentType.integer(1))
                                                            .executes(ctx -> setCinematicFade(ctx, str(ctx,"sp"),
                                                                IntegerArgumentType.getInteger(ctx,"eidx"),
                                                                IntegerArgumentType.getInteger(ctx,"tidx"),
                                                                IntegerArgumentType.getInteger(ctx,"fadeStart"),
                                                                IntegerArgumentType.getInteger(ctx,"fadeInDur"),
                                                                IntegerArgumentType.getInteger(ctx,"blackDur"),
                                                                IntegerArgumentType.getInteger(ctx,"fadeOutStart"),
                                                                IntegerArgumentType.getInteger(ctx,"fadeOutDur"))))))))))))

                        .then(Commands.literal("take")
                            .then(Commands.literal("add")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> takeAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx")))))))
                            .then(Commands.literal("remove")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("takeIdx", IntegerArgumentType.integer(0))
                                                .executes(ctx -> takeRemove(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), IntegerArgumentType.getInteger(ctx,"takeIdx"))))))))
                            .then(Commands.literal("list")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> takeList(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx")))))))
                            .then(Commands.literal("fade")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("takeIdx", IntegerArgumentType.integer(0))
                                                .then(Commands.argument("fadeStart", IntegerArgumentType.integer(0))
                                                    .then(Commands.argument("fadeDuration", IntegerArgumentType.integer(1))
                                                        .then(Commands.argument("fadeOutStart", IntegerArgumentType.integer(0))
                                                            .executes(ctx -> takeFade(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), IntegerArgumentType.getInteger(ctx,"takeIdx"), IntegerArgumentType.getInteger(ctx,"fadeStart"), IntegerArgumentType.getInteger(ctx,"fadeDuration"), IntegerArgumentType.getInteger(ctx,"fadeOutStart"))))))))))))

                        .then(Commands.literal("camkf")
                            .then(Commands.literal("setref")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> camKfSetRef(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), -1))
                                            .then(Commands.argument("takeIdx", IntegerArgumentType.integer(0))
                                                .executes(ctx -> camKfSetRef(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), IntegerArgumentType.getInteger(ctx,"takeIdx"))))))))
                            .then(Commands.literal("add")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("duration", IntegerArgumentType.integer(1))
                                                .executes(ctx -> camKfAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), IntegerArgumentType.getInteger(ctx,"duration"), -1))
                                                .then(Commands.argument("takeIdx", IntegerArgumentType.integer(0))
                                                    .executes(ctx -> camKfAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), IntegerArgumentType.getInteger(ctx,"duration"), IntegerArgumentType.getInteger(ctx,"takeIdx")))))))))
                            .then(Commands.literal("clear")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> camKfClear(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx")))))))
                            .then(Commands.literal("list")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> camKfList(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx")))))))
                            .then(Commands.literal("radius")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("radius", DoubleArgumentType.doubleArg(10, 200))
                                                .executes(ctx -> camKfRadius(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), (float)DoubleArgumentType.getDouble(ctx,"radius"))))))))
                            .then(Commands.literal("preview")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> camKfPreview(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"))))))))

                        .then(Commands.literal("effect")
                            .then(Commands.literal("add")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("effect", ResourceLocationArgument.id()).suggests(EFFECTS)
                                                .then(Commands.argument("amplifier", IntegerArgumentType.integer(0,255))
                                                    .executes(ctx -> transformEffectAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), rl(ctx,"effect"), IntegerArgumentType.getInteger(ctx,"amplifier"), 0))
                                                    .then(Commands.argument("duration", IntegerArgumentType.integer(0))
                                                        .executes(ctx -> transformEffectAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), rl(ctx,"effect"), IntegerArgumentType.getInteger(ctx,"amplifier"), IntegerArgumentType.getInteger(ctx,"duration"))))))))))
                            .then(Commands.literal("remove")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("effectIdx", IntegerArgumentType.integer(0))
                                                .executes(ctx -> transformEffectRemove(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), IntegerArgumentType.getInteger(ctx,"effectIdx")))))))))

                        .then(Commands.literal("aura")
                            .then(Commands.literal("add")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("particle", StringArgumentType.word())
                                                .then(Commands.argument("shape", StringArgumentType.word())
                                                    .then(Commands.argument("duration", IntegerArgumentType.integer(1))
                                                        .executes(ctx -> auraAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"particle"), str(ctx,"shape"), IntegerArgumentType.getInteger(ctx,"duration"))))))))))
                            .then(Commands.literal("clear")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> auraClear(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx")))))))
                            .then(Commands.literal("list")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> auraList(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"))))))))

                        .then(Commands.literal("ctitle")
                        .then(Commands.literal("add")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("text", StringArgumentType.greedyString())
                                        .executes(ctx -> ctitleAdd(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), -1, str(ctx,"text"), "spawn"))))))
                        .then(Commands.literal("clear")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .executes(ctx -> ctitleClear(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), -1, "spawn")))))
                        .then(Commands.literal("list")
                            .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                    .executes(ctx -> ctitleList(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), -1, "spawn"))))))
                    .then(Commands.literal("bossbar")
                            .then(Commands.literal("enable")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("color", StringArgumentType.word()).suggests(BOSSBAR_COLORS)
                                                .then(Commands.argument("style", StringArgumentType.word()).suggests(BOSSBAR_STYLES)
                                                    .executes(ctx -> transformBossbarEnable(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"color"), str(ctx,"style")))))))))
                            .then(Commands.literal("title")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .then(Commands.argument("title", StringArgumentType.greedyString())
                                                .executes(ctx -> transformBossbarTitle(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"title"))))))))
                            .then(Commands.literal("disable")
                                .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                                    .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                        .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                            .executes(ctx -> transformBossbarDisable(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"))))))))

                    ) // end transform

                    .then(Commands.literal("noloot")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                .then(Commands.argument("value", BoolArgumentType.bool())
                                    .executes(ctx -> entityNoLoot(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), BoolArgumentType.getBool(ctx,"value")))))))

                ) // end entity

                // bossbar
                .then(Commands.literal("bossbar")
                    .then(Commands.literal("enable")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("index", IntegerArgumentType.integer(0))
                                .then(Commands.argument("color", StringArgumentType.word()).suggests(BOSSBAR_COLORS)
                                    .then(Commands.argument("style", StringArgumentType.word()).suggests(BOSSBAR_STYLES)
                                        .executes(ctx -> bossbarEnable(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"index"), str(ctx,"color"), str(ctx,"style"))))))))
                    .then(Commands.literal("title")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("index", IntegerArgumentType.integer(0))
                                .then(Commands.argument("title", StringArgumentType.greedyString())
                                    .executes(ctx -> bossbarTitle(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"index"), str(ctx,"title")))))))
                    .then(Commands.literal("disable")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("index", IntegerArgumentType.integer(0))
                                .executes(ctx -> bossbarDisable(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"index")))))))

                // timer
                .then(Commands.literal("timer")
                    .then(Commands.literal("set")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("ticks", IntegerArgumentType.integer(200))
                                .executes(ctx -> timerSet(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"ticks"))))))
                    .then(Commands.literal("remove")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .executes(ctx -> timerRemove(ctx, str(ctx,"sp"))))))

                // config
                .then(Commands.literal("config")
                    .then(Commands.literal("broadcast")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("value", BoolArgumentType.bool())
                                .executes(ctx -> configBroadcast(ctx, str(ctx,"sp"), BoolArgumentType.getBool(ctx,"value"))))))
                    .then(Commands.literal("message")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("format", StringArgumentType.greedyString())
                                .executes(ctx -> configMessage(ctx, str(ctx,"sp"), str(ctx,"format"))))))
                    .then(Commands.literal("cooldown")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("ticks", IntegerArgumentType.integer(0))
                                .executes(ctx -> configCooldown(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"ticks"))))))
                    .then(Commands.literal("export")
                        .executes(BossPointCommand::configExport))
                    .then(Commands.literal("reload")
                        .executes(BossPointCommand::configReload))
                    .then(Commands.literal("defeatmsg")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("message", StringArgumentType.greedyString())
                                .executes(ctx -> configDefeatMsg(ctx, str(ctx,"sp"), str(ctx,"message"))))))
                    .then(Commands.literal("prefix")
                        .then(Commands.argument("prefix", StringArgumentType.greedyString())
                            .executes(ctx -> configPrefix(ctx, str(ctx,"prefix"))))))

                // music
                .then(Commands.literal("music")
                    .then(Commands.literal("list")
                        .executes(BossPointCommand::musicList))
                    .then(Commands.literal("spawn")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                .then(Commands.argument("file", StringArgumentType.word()).suggests(MUSIC_FILES)
                                    .executes(ctx -> musicSetSpawn(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), str(ctx,"file"), 64f, 1.0f))
                                    .then(Commands.argument("radius", DoubleArgumentType.doubleArg(1,512))
                                        .executes(ctx -> musicSetSpawn(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), str(ctx,"file"), (float)DoubleArgumentType.getDouble(ctx,"radius"), 1.0f))
                                        .then(Commands.argument("volume", DoubleArgumentType.doubleArg(0,1))
                                            .executes(ctx -> musicSetSpawn(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), str(ctx,"file"), (float)DoubleArgumentType.getDouble(ctx,"radius"), (float)DoubleArgumentType.getDouble(ctx,"volume")))))))))
                    .then(Commands.literal("spawnremove")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                .executes(ctx -> musicRemoveSpawn(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"))))))
                    .then(Commands.literal("phase")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                .then(Commands.argument("pidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("file", StringArgumentType.word()).suggests(MUSIC_FILES)
                                        .executes(ctx -> musicSetPhase(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"pidx"), str(ctx,"file"), 64f, 1.0f))
                                        .then(Commands.argument("radius", DoubleArgumentType.doubleArg(1,512))
                                            .executes(ctx -> musicSetPhase(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"pidx"), str(ctx,"file"), (float)DoubleArgumentType.getDouble(ctx,"radius"), 1.0f))
                                            .then(Commands.argument("volume", DoubleArgumentType.doubleArg(0,1))
                                                .executes(ctx -> musicSetPhase(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"pidx"), str(ctx,"file"), (float)DoubleArgumentType.getDouble(ctx,"radius"), (float)DoubleArgumentType.getDouble(ctx,"volume"))))))))))
                    .then(Commands.literal("phaseremove")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                .then(Commands.argument("pidx", IntegerArgumentType.integer(0))
                                    .executes(ctx -> musicRemovePhase(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"pidx")))))))
                    .then(Commands.literal("transform")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                    .then(Commands.argument("file", StringArgumentType.word()).suggests(MUSIC_FILES)
                                        .executes(ctx -> musicSetTransform(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"file"), 64f, 1.0f))
                                        .then(Commands.argument("radius", DoubleArgumentType.doubleArg(1,512))
                                            .executes(ctx -> musicSetTransform(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"file"), (float)DoubleArgumentType.getDouble(ctx,"radius"), 1.0f))
                                            .then(Commands.argument("volume", DoubleArgumentType.doubleArg(0,1))
                                                .executes(ctx -> musicSetTransform(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx"), str(ctx,"file"), (float)DoubleArgumentType.getDouble(ctx,"radius"), (float)DoubleArgumentType.getDouble(ctx,"volume"))))))))))
                    .then(Commands.literal("transformremove")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("eidx", IntegerArgumentType.integer(0))
                                .then(Commands.argument("tidx", IntegerArgumentType.integer(0))
                                    .executes(ctx -> musicRemoveTransform(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"eidx"), IntegerArgumentType.getInteger(ctx,"tidx")))))))
                    .then(Commands.literal("stop")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .executes(ctx -> musicStop(ctx, str(ctx,"sp"))))))

                // victory title
                .then(Commands.literal("victory")
                    .then(Commands.literal("title")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("title", StringArgumentType.greedyString())
                                .executes(ctx -> victoryTitle(ctx, str(ctx,"sp"), str(ctx,"title"))))))
                    .then(Commands.literal("subtitle")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("subtitle", StringArgumentType.greedyString())
                                .executes(ctx -> victorySubtitle(ctx, str(ctx,"sp"), str(ctx,"subtitle"))))))
                    .then(Commands.literal("disable")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .executes(ctx -> victoryDisable(ctx, str(ctx,"sp"))))))

                // reward
                .then(Commands.literal("reward")
                    .then(Commands.literal("exp")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("amount", IntegerArgumentType.integer(0))
                                .executes(ctx -> rewardExp(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"amount"))))))
                    .then(Commands.literal("item")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("itemId", ResourceLocationArgument.id())
                                .executes(ctx -> rewardItem(ctx, str(ctx,"sp"), rl(ctx,"itemId"), 1, 1.0, true))
                                .then(Commands.argument("count", IntegerArgumentType.integer(1))
                                    .executes(ctx -> rewardItem(ctx, str(ctx,"sp"), rl(ctx,"itemId"), IntegerArgumentType.getInteger(ctx,"count"), 1.0, true))
                                    .then(Commands.argument("prob", DoubleArgumentType.doubleArg(0.01,1.0))
                                        .executes(ctx -> rewardItem(ctx, str(ctx,"sp"), rl(ctx,"itemId"), IntegerArgumentType.getInteger(ctx,"count"), DoubleArgumentType.getDouble(ctx,"prob"), true))
                                        .then(Commands.argument("allPlayers", BoolArgumentType.bool())
                                            .executes(ctx -> rewardItem(ctx, str(ctx,"sp"), rl(ctx,"itemId"), IntegerArgumentType.getInteger(ctx,"count"), DoubleArgumentType.getDouble(ctx,"prob"), BoolArgumentType.getBool(ctx,"allPlayers")))))))))
                    .then(Commands.literal("cmd")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("command", StringArgumentType.greedyString())
                                .executes(ctx -> rewardCmd(ctx, str(ctx,"sp"), str(ctx,"command"))))))
                    .then(Commands.literal("loot")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("lootTable", ResourceLocationArgument.id())
                                .executes(ctx -> rewardLoot(ctx, str(ctx,"sp"), rl(ctx,"lootTable"))))))
                    .then(Commands.literal("radius")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("radius", DoubleArgumentType.doubleArg(1,512))
                                .executes(ctx -> rewardRadius(ctx, str(ctx,"sp"), (float)DoubleArgumentType.getDouble(ctx,"radius"))))))

                    .then(Commands.literal("message")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("message", StringArgumentType.greedyString())
                                .executes(ctx -> rewardMessage(ctx, str(ctx,"sp"), str(ctx,"message"))))))
                    .then(Commands.literal("clear")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .executes(ctx -> rewardClear(ctx, str(ctx,"sp")))))
                    .then(Commands.literal("info")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .executes(ctx -> rewardInfo(ctx, str(ctx,"sp")))))
                    .then(Commands.literal("mindamage")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("percent", DoubleArgumentType.doubleArg(0,100))
                                .executes(ctx -> rewardMinDamage(ctx, str(ctx,"sp"), DoubleArgumentType.getDouble(ctx,"percent"))))))
                    .then(Commands.literal("topreward")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .executes(ctx -> rewardTopItemHand(ctx, str(ctx,"sp"), 0, 1.0))
                            .then(Commands.argument("count", IntegerArgumentType.integer(1))
                                .executes(ctx -> rewardTopItemHand(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"count"), 1.0))
                                .then(Commands.argument("prob", DoubleArgumentType.doubleArg(0.01,1.0))
                                    .executes(ctx -> rewardTopItemHand(ctx, str(ctx,"sp"), IntegerArgumentType.getInteger(ctx,"count"), DoubleArgumentType.getDouble(ctx,"prob")))))))
                    .then(Commands.literal("topclear")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .executes(ctx -> rewardTopClear(ctx, str(ctx,"sp")))))
                    .then(Commands.literal("topmessage")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .then(Commands.argument("message", StringArgumentType.greedyString())
                                .executes(ctx -> rewardTopMessage(ctx, str(ctx,"sp"), str(ctx,"message"))))))
                    .then(Commands.literal("itemhand")
                        .then(Commands.argument("sp", StringArgumentType.word()).suggests(SPAWN_POINTS)
                            .executes(ctx -> rewardItemHand(ctx, str(ctx,"sp"), 1.0, true))
                            .then(Commands.argument("prob", DoubleArgumentType.doubleArg(0.01,1.0))
                                .executes(ctx -> rewardItemHand(ctx, str(ctx,"sp"), DoubleArgumentType.getDouble(ctx,"prob"), true))
                                .then(Commands.argument("allPlayers", BoolArgumentType.bool())
                                    .executes(ctx -> rewardItemHand(ctx, str(ctx,"sp"), DoubleArgumentType.getDouble(ctx,"prob"), BoolArgumentType.getBool(ctx,"allPlayers"))))))))

                .then(Commands.literal("help")
                    .executes(BossPointCommand::help))
        );
    }

    // ── Implementations ───────────────────────────────────────────────────────

    private static int create(CommandContext<CommandSourceStack> ctx, String name, BlockPos pos) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        if (data.exists(name)) return fail(src, "Ya existe un spawn point llamado §e" + name);

        SpawnPointDefinition def = new SpawnPointDefinition();
        def.name = name;
        def.x = pos.getX() + 0.5; def.y = pos.getY(); def.z = pos.getZ() + 0.5;
        def.dimension = src.getLevel().dimension().location().toString();
        data.add(def);
        return ok(src, "Spawn point §e" + name + " §acreado en §f" + pos.getX() + ", " + pos.getY() + ", " + pos.getZ());
    }

    private static int delete(CommandContext<CommandSourceStack> ctx, String name) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnManager.killSpawnPoint(name, src.getServer());
        if (data.remove(name)) return ok(src, "Spawn point §e" + name + " §aeliminado.");
        return fail(src, "Spawn point §e" + name + " §cno encontrado.");
    }

    private static int list(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        Collection<SpawnPointDefinition> all = data.getAll();
        if (all.isEmpty()) return ok(src, "§7No hay spawn points.");
        StringBuilder sb = new StringBuilder("§6=== Spawn Points ===\n");
        for (SpawnPointDefinition def : all) {
            sb.append("§e").append(def.name)
              .append(" §7@ §f").append((int)def.x).append(",").append((int)def.y).append(",").append((int)def.z)
              .append(" §8[").append(def.dimension).append("] §7entidades:§f").append(def.entities.size());
            if (def.autoSpawnIntervalTicks > 0)
                sb.append(" §7timer:§f").append(def.autoSpawnIntervalTicks/20).append("s");
            sb.append("\n");
        }
        src.sendSuccess(() -> Component.literal(sb.toString().trim()), false);
        return 1;
    }

    private static int info(CommandContext<CommandSourceStack> ctx, String name) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointDefinition def = requireDef(src, name);
        if (def == null) return 0;
        src.sendSuccess(() -> Component.literal(def.describe()), false);
        return 1;
    }

    private static int trigger(CommandContext<CommandSourceStack> ctx, String name) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, name);
        if (def == null) return 0;
        long now = src.getServer().overworld().getGameTime();
        if (def.isOnCooldown(now)) return fail(src, "En cooldown. Listo en §e" + def.ticksUntilReady(now)/20 + "s§c.");
        ServerPlayer player = null;
        try { player = src.getPlayerOrException(); } catch (Exception ignored) {}
        String result = SpawnManager.trigger(def, src.getLevel(), player);
        data.markDirty();
        src.sendSuccess(() -> Component.literal(result), false);
        return 1;
    }

    private static int tp(CommandContext<CommandSourceStack> ctx, String name) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointDefinition def = requireDef(src, name);
        if (def == null) return 0;
        try {
            ServerPlayer player = src.getPlayerOrException();
            net.minecraft.core.registries.Registries r = null;
            var dimKey = net.minecraft.resources.ResourceKey.create(
                net.minecraft.core.registries.Registries.DIMENSION,
                net.minecraft.resources.ResourceLocation.parse(def.dimension));
            var level = src.getServer().getLevel(dimKey);
            if (level == null) return fail(src, "Dimensión no encontrada: " + def.dimension);
            player.teleportTo(level, def.x, def.y, def.z, player.getYRot(), player.getXRot());
            return ok(src, "Teletransportado a §e" + name + " §a(" + (int)def.x + ", " + (int)def.y + ", " + (int)def.z + ")§a.");
        } catch (Exception e) {
            return fail(src, "Solo jugadores pueden usar /smc tp.");
        }
    }

    private static int kill(CommandContext<CommandSourceStack> ctx, String name) {
        CommandSourceStack src = ctx.getSource();
        if (!SpawnPointSavedData.get(src.getServer()).exists(name))
            return fail(src, "Spawn point §e" + name + " §cno encontrado.");
        int killed = SpawnManager.killSpawnPoint(name, src.getServer());
        return ok(src, "§e" + killed + " §aentidad(es) eliminadas del spawn point §e" + name + "§a.");
    }

    // ── Entity ────────────────────────────────────────────────────────────────

    private static int entityAdd(CommandContext<CommandSourceStack> ctx, String sp, String entityType, int count) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp);
        if (def == null) return 0;
        EntitySpawnConfig cfg = new EntitySpawnConfig();
        cfg.entityType = entityType;
        cfg.count = count;
        def.entities.add(cfg);
        data.markDirty();
        return ok(src, "§e" + entityType + " §a(x" + count + ") añadido al índice §e" + (def.entities.size()-1) + "§a.");
    }

    private static int entityRemove(CommandContext<CommandSourceStack> ctx, String sp, int idx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, idx)) return 0;
        EntitySpawnConfig r = def.entities.remove(idx);
        data.markDirty();
        return ok(src, "Entidad §e" + r.entityType + " §aeliminada.");
    }

    private static int entityCount(CommandContext<CommandSourceStack> ctx, String sp, int idx, int count) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, idx)) return 0;
        def.entities.get(idx).count = count;
        data.markDirty();
        return ok(src, "Cantidad de [" + idx + "] → §e" + count + "§a.");
    }

    private static int entityName(CommandContext<CommandSourceStack> ctx, String sp, int idx, String name) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, idx)) return 0;
        def.entities.get(idx).displayName = name;
        data.markDirty();
        return ok(src, "Nombre de [" + idx + "] → §b" + name + "§a.");
    }

    private static int entityAttr(CommandContext<CommandSourceStack> ctx, String sp, int idx, String attr, double value) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, idx)) return 0;
        String fullAttr = attr.contains(":") ? attr : "minecraft:" + attr;
        def.entities.get(idx).attributes.put(fullAttr, value);
        data.markDirty();
        return ok(src, "Atributo §e" + fullAttr + " §a= §e" + value + "§a.");
    }

    private static int entityAttrRemove(CommandContext<CommandSourceStack> ctx, String sp, int idx, String attr) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, idx)) return 0;
        String fullAttr = attr.contains(":") ? attr : "minecraft:" + attr;
        def.entities.get(idx).attributes.remove(fullAttr);
        data.markDirty();
        return ok(src, "Atributo §e" + fullAttr + " §aqitado.");
    }

    // ── Phase ─────────────────────────────────────────────────────────────────

    private static int phaseAdd(CommandContext<CommandSourceStack> ctx, String sp, int eidx, double hp, String msg) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        PhaseConfig phase = new PhaseConfig(hp / 100.0, msg);
        def.entities.get(eidx).phases.add(phase);
        def.entities.get(eidx).phases.sort((a, b) -> Double.compare(b.healthPercent, a.healthPercent));
        data.markDirty();
        int pidx = def.entities.get(eidx).phases.indexOf(phase);
        return ok(src, "Fase [" + pidx + "] añadida: HP ≤ §e" + (int)hp + "%§a.");
    }

    private static int phaseRemove(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        phases.remove(pidx);
        data.markDirty();
        return ok(src, "Fase §e" + pidx + " §aeliminada.");
    }

    private static int phaseMsg(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx, String msg) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        phases.get(pidx).message = msg;
        data.markDirty();
        return ok(src, "Mensaje de fase [" + pidx + "] actualizado.");
    }

    private static int phaseCmd(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx, String cmd) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        phases.get(pidx).commands.add(cmd);
        data.markDirty();
        return ok(src, "Comando añadido a fase [" + pidx + "].");
    }

    private static int phaseAttr(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx, String attr, double value) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        String fullAttr = attr.contains(":") ? attr : "minecraft:" + attr;
        phases.get(pidx).attributeChanges.put(fullAttr, value);
        data.markDirty();
        return ok(src, "Atributo de fase [" + pidx + "]: §e" + fullAttr + " §a→ §e" + value + "§a.");
    }

    private static int phaseAttrRemove(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx, String attr) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        String fullAttr = attr.contains(":") ? attr : "minecraft:" + attr;
        phases.get(pidx).attributeChanges.remove(fullAttr);
        data.markDirty();
        return ok(src, "Atributo de fase eliminado.");
    }

    // ── Transform ─────────────────────────────────────────────────────────────

    private static int transformAdd(CommandContext<CommandSourceStack> ctx, String sp, int eidx, String newType, int delay, String style) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        TransformConfig tc = new TransformConfig();
        tc.entityType = newType; tc.delayTicks = delay; tc.cinematicStyle = style;
        def.entities.get(eidx).transforms.add(tc);
        data.markDirty();
        int tidx = def.entities.get(eidx).transforms.size() - 1;
        return ok(src, "Transformación [" + tidx + "] añadida: §e" + newType + " §a(" + delay + "t, " + style + ").");
    }

    private static int transformRemove(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        transforms.remove(tidx);
        data.markDirty();
        return ok(src, "Transformación [" + tidx + "] eliminada.");
    }

    private static int transformName(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String name) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        transforms.get(tidx).displayName = name;
        data.markDirty();
        return ok(src, "Nombre de transformación [" + tidx + "] → §b" + name + "§a.");
    }

    private static int transformBroadcast(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, boolean enabled, String format) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        transforms.get(tidx).broadcastMessage = enabled;
        if (!format.isEmpty()) transforms.get(tidx).message = format;
        data.markDirty();
        return ok(src, "Broadcast de transformación [" + tidx + "] → §e" + enabled + "§a.");
    }

    private static int transformAttr(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String attr, double value) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        String fullAttr = attr.contains(":") ? attr : "minecraft:" + attr;
        transforms.get(tidx).attributes.put(fullAttr, value);
        data.markDirty();
        return ok(src, "Atributo de transformación [" + tidx + "]: §e" + fullAttr + " §a→ §e" + value + "§a.");
    }

    private static int transformAttrRemove(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String attr) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        String fullAttr = attr.contains(":") ? attr : "minecraft:" + attr;
        transforms.get(tidx).attributes.remove(fullAttr);
        data.markDirty();
        return ok(src, "Atributo de transformación [" + tidx + "] eliminado.");
    }

    private static int transformNoLoot(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, boolean value) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        transforms.get(tidx).noLoot = value;
        data.markDirty();
        return ok(src, "No loot de transformación [" + tidx + "] → §e" + value + "§a.");
    }

    private static int entityNoLoot(CommandContext<CommandSourceStack> ctx, String sp, int eidx, boolean value) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        def.entities.get(eidx).noLoot = value;
        data.markDirty();
        return ok(src, "No loot de entidad [" + eidx + "] → §e" + value + "§a.");
    }

    private static int phaseFog(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx, String color, int fadeTicks) {
        return phaseFogFull(ctx, sp, eidx, pidx, color, fadeTicks, 128f);
    }

    private static int phaseSky(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx, String color, int fadeTicks) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        float[] rgb = resolveFog(color);
        com.bosspoints.data.PhaseConfig phase = phases.get(pidx);
        if (rgb == null) { phase.skyR = phase.skyG = phase.skyB = -1; data.markDirty(); return ok(src, "Sky de fase [" + pidx + "] desactivado."); }
        phase.skyR = rgb[0]; phase.skyG = rgb[1]; phase.skyB = rgb[2]; phase.skyFadeTicks = fadeTicks;
        data.markDirty();
        return ok(src, "Sky de fase [" + pidx + "] → §e" + color + " §afade:§e" + fadeTicks + "t§a.");
    }

    private static int setCinematicFade(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx,
            int fadeStart, int fadeInDur, int blackDur, int fadeOutStart, int fadeOutDur) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var tc = def.entities.get(eidx).transforms.get(tidx);
        tc.fadeStartTick = fadeStart;
        tc.fadeInDurationTicks = fadeInDur;
        tc.fadeBlackDurationTicks = blackDur;
        tc.fadeOutStartTick = fadeOutStart;
        tc.fadeOutDurationTicks = fadeOutDur;
        data.markDirty();
        return ok(src, "Fade cinematico seteado: inicio §e" + fadeStart + "t§a, fadeIn §e" + fadeInDur +
            "t§a, negro §e" + blackDur + "t§a, fadeOut desde §e" + fadeOutStart + "t§a dur §e" + fadeOutDur + "t");
    }

    private static java.util.List<com.bosspoints.data.CinematicTake> getTakes(SpawnPointDefinition def, int eidx, int tidx) {
        return def.entities.get(eidx).transforms.get(tidx).cinematicTakes;
    }

    private static int takeAdd(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx) || tidx >= def.entities.get(eidx).transforms.size()) return fail(src, "Índice inválido.");
        getTakes(def, eidx, tidx).add(new com.bosspoints.data.CinematicTake());
        data.markDirty();
        return ok(src, "Toma [" + (getTakes(def, eidx, tidx).size()-1) + "] añadida.");
    }

    private static int takeRemove(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, int takeIdx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        var takes = getTakes(def, eidx, tidx);
        if (takeIdx >= takes.size()) return fail(src, "Índice de toma inválido.");
        takes.remove(takeIdx);
        data.markDirty();
        return ok(src, "Toma [" + takeIdx + "] eliminada.");
    }

    private static int takeList(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        var takes = getTakes(def, eidx, tidx);
        if (takes.isEmpty()) return ok(src, "Sin tomas configuradas. Usá §e/smc entity transform take add§a.");
        for (int i = 0; i < takes.size(); i++) {
            var t = takes.get(i);
            ok(src, "[" + i + "] §ekf:" + t.keyframes.size() + " §7fadeStart:§e" + t.fadeStartTick + "§t dur:§e" + t.fadeDurationTicks + "§t fadeOut:§e" + t.fadeOutStartTick + "t");
        }
        return 1;
    }

    private static int takeFade(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, int takeIdx, int fadeStart, int fadeDuration, int fadeOutStart) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        var takes = getTakes(def, eidx, tidx);
        if (takeIdx >= takes.size()) return fail(src, "Índice de toma inválido.");
        var take = takes.get(takeIdx);
        take.fadeStartTick = fadeStart;
        take.fadeDurationTicks = fadeDuration;
        take.fadeOutStartTick = fadeOutStart;
        data.markDirty();
        return ok(src, "Fade de toma [" + takeIdx + "]: inicio §e" + fadeStart + "t§a, dur §e" + fadeDuration + "t§a, fadeOut §e" + fadeOutStart + "t");
    }

    private static int auraAdd(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String particle, String shape, int duration) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        if (tidx >= def.entities.get(eidx).transforms.size()) return fail(src, "Índice de transformación inválido.");
        var aura = def.entities.get(eidx).transforms.get(tidx).particleAura;
        com.bosspoints.data.ParticleAuraConfig.AuraEntry e = new com.bosspoints.data.ParticleAuraConfig.AuraEntry();
        e.particleType = particle;
        try { e.shape = com.bosspoints.data.ParticleAuraConfig.AuraShape.valueOf(shape.toUpperCase()); } catch (Exception ex) { return fail(src, "Forma inválida. Usar: ORBIT, RAIN, EXPLODE, SPIRAL"); }
        e.durationTicks = duration;
        aura.entries.add(e);
        data.markDirty();
        return ok(src, "Aura añadida [" + (aura.entries.size()-1) + "]: §e" + particle + " §a(" + shape + ") §edur:" + duration + "t");
    }

    private static int auraClear(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        def.entities.get(eidx).transforms.get(tidx).particleAura.entries.clear();
        data.markDirty();
        return ok(src, "Auras de transformación [" + tidx + "] limpiadas.");
    }

    private static int auraList(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var entries = def.entities.get(eidx).transforms.get(tidx).particleAura.entries;
        if (entries.isEmpty()) return ok(src, "Sin auras configuradas.");
        for (int i = 0; i < entries.size(); i++) {
            var e = entries.get(i);
            ok(src, "[" + i + "] §e" + e.particleType + " §7shape:§e" + e.shape + " §7dur:§e" + e.durationTicks + "t §7radius:§e" + e.radius + " §7count:§e" + e.countPerTick + "/t");
        }
        return 1;
    }

    private static int ctitleEdit(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, int idx, String type) {
        CommandSourceStack src = ctx.getSource();
        try {
            net.minecraft.server.level.ServerPlayer player = src.getPlayerOrException();
            SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
            if (!checkIdx(src, def, eidx)) return 0;
            com.bosspoints.data.CustomTitleConfig cfg = getCtitleConfig(def, eidx, tidx >= 0 ? tidx : -1);
            if (idx >= cfg.entries.size()) return fail(src, "Índice inválido.");
            boolean isSpawn = tidx < 0;
            com.bosspoints.network.NetworkHandler.sendToPlayer(player,
                new com.bosspoints.network.PacketOpenTitleEditor(sp, eidx, tidx, idx, cfg.entries.get(idx), isSpawn));
            return 1;
        } catch (Exception e) { return fail(src, "Error: " + e.getMessage()); }
    }

    private static com.bosspoints.data.CustomTitleConfig getCtitleConfig(SpawnPointDefinition def, int eidx, int tidx) {
        if (tidx < 0) return def.entities.get(eidx).customTitles;
        return def.entities.get(eidx).transforms.get(tidx).customTitles;
    }

    private static int ctitleAdd(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String text, String type) {
        CommandSourceStack src = ctx.getSource();
        try {
            SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
            SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
            if (!checkIdx(src, def, eidx)) return 0;
            if (tidx >= 0 && tidx >= def.entities.get(eidx).transforms.size()) return fail(src, "Índice de transformación inválido.");
            com.bosspoints.data.CustomTitleConfig cfg = getCtitleConfig(def, eidx, tidx);
            com.bosspoints.data.CustomTitleConfig.TitleEntry e = new com.bosspoints.data.CustomTitleConfig.TitleEntry();
            e.text = text;
            cfg.entries.add(e);
            data.markDirty();
            return ok(src, "§aTítulo añadido [§e" + (cfg.entries.size()-1) + "§a]. Editá sus propiedades con §e/smc entity transform ctitle edit§a.");
        } catch (Exception e) { return fail(src, "Error: " + e.getMessage()); }
    }

    private static int ctitleClear(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String type) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        getCtitleConfig(def, eidx, tidx).entries.clear();
        data.markDirty();
        return ok(src, "Títulos custom limpiados.");
    }

    private static int ctitleList(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String type) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var entries = getCtitleConfig(def, eidx, tidx).entries;
        if (entries.isEmpty()) return ok(src, "Sin títulos custom.");
        for (int i = 0; i < entries.size(); i++) {
            var e = entries.get(i);
            ok(src, "[" + i + "] §r" + e.text + " §7pos:§e" + e.x + "," + e.y + " §7scale:§e" + e.scale + " §7start:§e" + e.startTick + "t §7dur:§e" + e.durationTicks + "t §7fade:§e" + e.fadeInTicks + "/" + e.fadeOutTicks + " §7color:§e" + e.color);
        }
        return 1;
    }

     private static int camKfSetRef(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, int takeIdx) {
        CommandSourceStack src = ctx.getSource();
        try {
            net.minecraft.server.level.ServerPlayer player = src.getPlayerOrException();
            SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
            SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
            if (!checkIdx(src, def, eidx)) return 0;
            var tc = def.entities.get(eidx).transforms.get(tidx);
            {
                tc.refX = player.getX(); tc.refY = player.getY(); tc.refZ = player.getZ();
                data.markDirty();
                return ok(src, "Punto de referencia seteado a §e" + String.format("%.2f, %.2f, %.2f", tc.refX, tc.refY, tc.refZ));
            }
        } catch (Exception e) { return fail(src, "Error: " + e.getMessage()); }
    }


    private static int camKfAdd(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, int duration, int takeIdx) {
        CommandSourceStack src = ctx.getSource();
        try {
            net.minecraft.server.level.ServerPlayer player = src.getPlayerOrException();
            SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
            SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
            if (!checkIdx(src, def, eidx)) return 0;
            var tc = def.entities.get(eidx).transforms.get(tidx);
            com.bosspoints.data.CinematicKeyframe kf = new com.bosspoints.data.CinematicKeyframe();
            kf.yaw = player.getYRot(); kf.pitch = player.getXRot();
            kf.durationTicks = duration;
            if (takeIdx >= 0) {
                if (takeIdx >= tc.cinematicTakes.size()) return fail(src, "Toma [" + takeIdx + "] no existe.");
                if (tc.refX == 0 && tc.refY == 0 && tc.refZ == 0) return fail(src, "Primero seteá el ref global: §e/smc entity transform camkf setref " + sp + " " + eidx + " " + tidx);
                var take = tc.cinematicTakes.get(takeIdx);
                kf.dx = player.getX()-tc.refX; kf.dy = player.getY()-tc.refY; kf.dz = player.getZ()-tc.refZ;
                take.keyframes.add(kf);
                data.markDirty();
                return ok(src, "Keyframe [" + (take.keyframes.size()-1) + "] añadido a toma [" + takeIdx + "] §e" + duration + "t");
            } else {
                if (tc.refX == 0 && tc.refY == 0 && tc.refZ == 0) return fail(src, "Primero seteá el ref con §e/smc entity transform camkf setref§c.");
                kf.dx = player.getX()-tc.refX; kf.dy = player.getY()-tc.refY; kf.dz = player.getZ()-tc.refZ;
                tc.cinematicKeyframes.add(kf);
                data.markDirty();
                return ok(src, "Keyframe [" + (tc.cinematicKeyframes.size()-1) + "] añadido §e" + duration + "t");
            }
        } catch (Exception e) { return fail(src, "Error: " + e.getMessage()); }
    }

    private static int camKfRadius(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, float radius) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        transforms.get(tidx).cinematicRadius = radius;
        data.markDirty();
        return ok(src, "Radio de cinemática de transformación [" + tidx + "] → §e" + radius + " bloques§a.");
    }

    private static int camKfPreview(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx) {
        CommandSourceStack src = ctx.getSource();
        try {
            net.minecraft.server.level.ServerPlayer player = src.getPlayerOrException();
            SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
            if (!checkIdx(src, def, eidx)) return 0;
            var transforms = def.entities.get(eidx).transforms;
            if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
            var tc = transforms.get(tidx);
            if (tc.cinematicKeyframes.size() < 2) return fail(src, "Necesitás al menos 2 keyframes para previsualizar.");
            if (!(player.level() instanceof net.minecraft.server.level.ServerLevel sl))
                return fail(src, "Solo en servidor.");
            // Usar el punto de referencia como spawn para el preview
            com.bosspoints.manager.CinematicManager.start(
                java.util.Collections.singletonList(player), sl,
                tc.cinematicKeyframes, tc.refX, tc.refY, tc.refZ);
            return ok(src, "Previsualizando cinemática...");
        } catch (Exception e) { return fail(src, "Error: " + e.getMessage()); }
    }

    private static int camKfClear(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        transforms.get(tidx).cinematicKeyframes.clear();
        data.markDirty();
        return ok(src, "Keyframes de cinemática de transformación [" + tidx + "] limpiados.");
    }

    private static int camKfList(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        var kfs = transforms.get(tidx).cinematicKeyframes;
        if (kfs.isEmpty()) return ok(src, "Sin keyframes en transformación [" + tidx + "].");
        for (int i = 0; i < kfs.size(); i++) {
            var kf = kfs.get(i);
            ok(src, String.format("[%d] §e%.1f, %.1f, %.1f §7yaw:%.1f pitch:%.1f §a%dt", i, kf.dx, kf.dy, kf.dz, kf.yaw, kf.pitch, kf.durationTicks));
        }
        return 1;
    }

    private static int transformInvul(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, int ticks) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        transforms.get(tidx).invulnerabilityTicks = ticks;
        data.markDirty();
        if (ticks <= 0) return ok(src, "Invulnerabilidad de transformación [" + tidx + "] desactivada.");
        return ok(src, "Invulnerabilidad de transformación [" + tidx + "] → §e" + ticks + "t §7(≈" + ticks/20 + "s).");
    }

    private static int transformSky(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String color, int fadeTicks) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        float[] rgb = resolveFog(color);
        com.bosspoints.data.TransformConfig tc = transforms.get(tidx);
        if (rgb == null) { tc.skyR = tc.skyG = tc.skyB = -1; data.markDirty(); return ok(src, "Sky de transformación [" + tidx + "] desactivado."); }
        tc.skyR = rgb[0]; tc.skyG = rgb[1]; tc.skyB = rgb[2]; tc.skyFadeTicks = fadeTicks;
        data.markDirty();
        return ok(src, "Sky de transformación [" + tidx + "] → §e" + color + " §afade:§e" + fadeTicks + "t§a.");
    }

    private static int phaseFogFull(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx, String color, int fadeTicks, float radius) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        float[] rgb = resolveFog(color);
        com.bosspoints.data.PhaseConfig phase = phases.get(pidx);
        if (rgb == null) {
            phase.fogR = phase.fogG = phase.fogB = -1;
            data.markDirty();
            return ok(src, "Fog de fase [" + pidx + "] desactivado.");
        }
        phase.fogR = rgb[0]; phase.fogG = rgb[1]; phase.fogB = rgb[2];
        phase.fogFadeTicks = fadeTicks; phase.fogRadius = radius;
        data.markDirty();
        return ok(src, "Fog de fase [" + pidx + "] → §e" + color + " §aradio:§e" + (int)radius + " §afade:§e" + fadeTicks + "t§a.");
    }

    private static int transformFog(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String color, int fadeTicks) {
        return transformFogFull(ctx, sp, eidx, tidx, color, fadeTicks, 128f);
    }

    private static int transformFogFull(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String color, int fadeTicks, float radius) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        float[] rgb = resolveFog(color);
        com.bosspoints.data.TransformConfig tc = transforms.get(tidx);
        if (rgb == null) {
            tc.fogR = tc.fogG = tc.fogB = -1;
            data.markDirty();
            return ok(src, "Fog de transformación [" + tidx + "] desactivado.");
        }
        tc.fogR = rgb[0]; tc.fogG = rgb[1]; tc.fogB = rgb[2];
        tc.fogFadeTicks = fadeTicks; tc.fogRadius = radius;
        data.markDirty();
        return ok(src, "Fog de transformación [" + tidx + "] → §e" + color + " §aradio:§e" + (int)radius + " §afade:§e" + fadeTicks + "t§a.");
    }

    private static int transformBossbarEnable(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String color, String style) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        BossBarConfig bb = transforms.get(tidx).bossBar;
        bb.enabled = true; bb.color = color.toUpperCase(); bb.style = style.toUpperCase();
        data.markDirty();
        return ok(src, "BossBar de transformación [" + tidx + "] activada: §e" + color + "/" + style + "§a.");
    }

    private static int transformBossbarTitle(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String title) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        transforms.get(tidx).bossBar.title = title;
        data.markDirty();
        return ok(src, "Título de BossBar de transformación [" + tidx + "] → §b" + title + "§a.");
    }

    private static int transformBossbarDisable(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        transforms.get(tidx).bossBar.enabled = false;
        data.markDirty();
        return ok(src, "BossBar de transformación [" + tidx + "] desactivada.");
    }


    // ── BossBar ───────────────────────────────────────────────────────────────

    private static int bossbarEnable(CommandContext<CommandSourceStack> ctx, String sp, int idx, String color, String style) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, idx)) return 0;
        BossBarConfig bb = def.entities.get(idx).bossBar;
        bb.enabled = true; bb.color = color.toUpperCase(); bb.style = style.toUpperCase();
        data.markDirty();
        return ok(src, "BossBar activada: §e" + color + " / " + style + "§a.");
    }

    private static int bossbarTitle(CommandContext<CommandSourceStack> ctx, String sp, int idx, String title) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, idx)) return 0;
        def.entities.get(idx).bossBar.title = title;
        data.markDirty();
        return ok(src, "Título de BossBar → §b" + title + "§a.");
    }

    private static int bossbarDisable(CommandContext<CommandSourceStack> ctx, String sp, int idx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, idx)) return 0;
        def.entities.get(idx).bossBar.enabled = false;
        data.markDirty();
        return ok(src, "BossBar desactivada.");
    }

    // ── Timer ─────────────────────────────────────────────────────────────────

    private static int timerSet(CommandContext<CommandSourceStack> ctx, String sp, int ticks) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.autoSpawnIntervalTicks = ticks;
        data.markDirty();
        return ok(src, "Timer de §e" + sp + " §a→ §e" + ticks + " ticks §7(≈" + ticks/20 + "s)§a.");
    }

    private static int timerRemove(CommandContext<CommandSourceStack> ctx, String sp) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.autoSpawnIntervalTicks = 0;
        data.markDirty();
        return ok(src, "Timer de §e" + sp + " §adesactivado.");
    }

    // ── Config ────────────────────────────────────────────────────────────────

    private static int configBroadcast(CommandContext<CommandSourceStack> ctx, String sp, boolean value) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.broadcastSpawn = value; data.markDirty();
        return ok(src, "Broadcast de §e" + sp + " §a→ §e" + value + "§a.");
    }

    private static int configMessage(CommandContext<CommandSourceStack> ctx, String sp, String format) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.spawnMessageFormat = format; data.markDirty();
        return ok(src, "Formato de mensaje actualizado.");
    }

    private static int configCooldown(CommandContext<CommandSourceStack> ctx, String sp, int ticks) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.cooldownTicks = ticks; data.markDirty();
        return ok(src, "Cooldown de §e" + sp + " §a→ §e" + ticks + "t §7(≈" + ticks/20 + "s)§a.");
    }

    // ── Help ──────────────────────────────────────────────────────────────────

    private static int configReload(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        // Recargar TOML de Forge leyendo el archivo directamente
        try {
            for (net.minecraftforge.fml.config.ModConfig modConfig :
                    net.minecraftforge.fml.config.ConfigTracker.INSTANCE.configSets()
                        .get(net.minecraftforge.fml.config.ModConfig.Type.SERVER)) {
                if (modConfig.getModId().equals("summoncore")) {
                    ((com.electronwill.nightconfig.core.file.FileConfig) modConfig.getConfigData()).load();
                    break;
                }
            }
        } catch (Exception ignored) {}

        java.util.List<com.bosspoints.data.SpawnPointDefinition> loaded = ConfigFileManager.load();
        if (loaded == null)
            return fail(src, "No se encontró bosses.json en config/summoncore/. Usá §e/smc config export §cprimero.");
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        for (String name : new java.util.ArrayList<>(data.getAll().stream()
                .map(d -> d.name).toList()))
            data.remove(name);
        for (com.bosspoints.data.SpawnPointDefinition def : loaded)
            data.add(def);
        src.sendSuccess(() -> Component.literal("§aBosses y config recargados. §e" + loaded.size() + " §aspawn points cargados."), true);
        return 1;
    }

    private static int configExport(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        ConfigFileManager.save(data.getAll());
        return ok(src, "bosses.json exportado a §econfig/summoncore/bosses.json§a.");
    }

    // ── Music ────────────────────────────────────────────────────────────────

    private static int musicList(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        java.util.List<String> sounds = MusicManager.listSounds();
        if (sounds.isEmpty()) {
            return ok(src, "No hay archivos en config/summoncore/sounds/ — ponés tus .ogg ahí.");
        }
        StringBuilder sb = new StringBuilder("§6Sonidos disponibles:\n");
        sounds.forEach(s -> sb.append("  §e").append(s).append("\n"));
        src.sendSuccess(() -> Component.literal(sb.toString().trim()), false);
        return 1;
    }

    private static int musicSetSpawn(CommandContext<CommandSourceStack> ctx, String sp, int eidx,
                                     String file, float radius, float volume) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        com.bosspoints.data.MusicConfig mc = def.entities.get(eidx).spawnMusic;
        mc.enabled = true; mc.soundEvent = file; mc.radius = radius; mc.volume = volume;
        data.markDirty();
        return ok(src, "Música de spawn [" + eidx + "] → §e" + file + " §aradio:§e" + (int)radius + "§a.");
    }

    private static int musicRemoveSpawn(CommandContext<CommandSourceStack> ctx, String sp, int eidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        def.entities.get(eidx).spawnMusic.enabled = false;
        data.markDirty();
        return ok(src, "Música de spawn [" + eidx + "] desactivada.");
    }

    private static int musicSetPhase(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx,
                                     String file, float radius, float volume) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        com.bosspoints.data.MusicConfig mc = phases.get(pidx).music;
        mc.enabled = true; mc.soundEvent = file; mc.radius = radius; mc.volume = volume;
        data.markDirty();
        return ok(src, "Música de fase [" + pidx + "] → §e" + file + " §aradio:§e" + (int)radius + "§a.");
    }

    private static int musicRemovePhase(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        phases.get(pidx).music.enabled = false;
        data.markDirty();
        return ok(src, "Música de fase [" + pidx + "] desactivada.");
    }

    private static int musicSetTransform(CommandContext<CommandSourceStack> ctx, String sp,
                                         int eidx, int tidx, String file, float radius, float volume) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        com.bosspoints.data.MusicConfig mc = transforms.get(tidx).spawnMusic;
        mc.enabled = true; mc.soundEvent = file; mc.radius = radius; mc.volume = volume;
        data.markDirty();
        return ok(src, "Música de transformación [" + tidx + "] → §e" + file + " §aradio:§e" + (int)radius + "§a.");
    }

    private static int musicRemoveTransform(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        transforms.get(tidx).spawnMusic.enabled = false;
        data.markDirty();
        return ok(src, "Música de transformación [" + tidx + "] desactivada.");
    }

    private static int musicStop(CommandContext<CommandSourceStack> ctx, String sp) {
        CommandSourceStack src = ctx.getSource();
        MusicManager.stopForSpawnPoint(sp, 40, src.getServer());
        return ok(src, "Música de §e" + sp + " §adetenida.");
    }

    // ── Titles ───────────────────────────────────────────────────────────────────

    private static int phaseTitleSet(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx, String title, String sub) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        com.bosspoints.data.TitleConfig tc = phases.get(pidx).titleConfig;
        tc.enabled = true; tc.title = title;
        if (!sub.isEmpty()) tc.subtitle = sub;
        data.markDirty();
        return ok(src, "Título de fase [" + pidx + "] → §b" + title + "§a.");
    }

    private static int phaseTitleSetSub(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx, String sub) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        phases.get(pidx).titleConfig.subtitle = sub;
        data.markDirty();
        return ok(src, "Subtítulo de fase [" + pidx + "] → §b" + sub + "§a.");
    }

    private static int transformTitleSet(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String title, String sub) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        com.bosspoints.data.TitleConfig tc = transforms.get(tidx).titleConfig;
        tc.enabled = true; tc.title = title;
        if (!sub.isEmpty()) tc.subtitle = sub;
        data.markDirty();
        return ok(src, "Título de transformación [" + tidx + "] → §b" + title + "§a.");
    }

    private static int transformTitleSetSub(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String sub) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        transforms.get(tidx).titleConfig.subtitle = sub;
        data.markDirty();
        return ok(src, "Subtítulo de transformación [" + tidx + "] → §b" + sub + "§a.");
    }

    // ── Potion Effects ───────────────────────────────────────────────────────────

    private static int phaseEffectAdd(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx, String effect, int amplifier, int duration) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        com.bosspoints.data.PotionEffectConfig pec = new com.bosspoints.data.PotionEffectConfig();
        pec.effectId = effect; pec.amplifier = amplifier; pec.durationSeconds = duration;
        phases.get(pidx).potionEffects.add(pec);
        data.markDirty();
        String dur = duration <= 0 ? "permanente" : duration + "s";
        return ok(src, "Efecto §e" + effect + " §aNivel §e" + (amplifier+1) + " §a(" + dur + ") añadido a fase [" + pidx + "].");
    }

    private static int phaseEffectRemove(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int pidx, int effectIdx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var phases = def.entities.get(eidx).phases;
        if (pidx < 0 || pidx >= phases.size()) return fail(src, "Índice de fase inválido: " + pidx);
        var effects = phases.get(pidx).potionEffects;
        if (effectIdx < 0 || effectIdx >= effects.size()) return fail(src, "Índice de efecto inválido: " + effectIdx);
        effects.remove(effectIdx);
        data.markDirty();
        return ok(src, "Efecto [" + effectIdx + "] eliminado de fase [" + pidx + "].");
    }

    private static int transformEffectAdd(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, String effect, int amplifier, int duration) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        com.bosspoints.data.PotionEffectConfig pec = new com.bosspoints.data.PotionEffectConfig();
        pec.effectId = effect; pec.amplifier = amplifier; pec.durationSeconds = duration;
        transforms.get(tidx).potionEffects.add(pec);
        data.markDirty();
        String dur = duration <= 0 ? "permanente" : duration + "s";
        return ok(src, "Efecto §e" + effect + " §aNivel §e" + (amplifier+1) + " §a(" + dur + ") añadido a transformación [" + tidx + "].");
    }

    private static int transformEffectRemove(CommandContext<CommandSourceStack> ctx, String sp, int eidx, int tidx, int effectIdx) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        if (!checkIdx(src, def, eidx)) return 0;
        var transforms = def.entities.get(eidx).transforms;
        if (tidx < 0 || tidx >= transforms.size()) return fail(src, "Índice de transformación inválido: " + tidx);
        var effects = transforms.get(tidx).potionEffects;
        if (effectIdx < 0 || effectIdx >= effects.size()) return fail(src, "Índice de efecto inválido: " + effectIdx);
        effects.remove(effectIdx);
        data.markDirty();
        return ok(src, "Efecto [" + effectIdx + "] eliminado de transformación [" + tidx + "].");
    }

    // ── Victory Title ───────────────────────────────────────────────────────────

    private static int timerTimeout(CommandContext<CommandSourceStack> ctx, String sp, int ticks) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.fightTimeoutTicks = ticks;
        data.markDirty();
        if (ticks <= 0) return ok(src, "Tiempo límite de §e" + sp + "§a desactivado.");
        return ok(src, "Tiempo límite de §e" + sp + "§a → §e" + ticks + "t §7(≈" + ticks/20 + "s).");
    }

    private static int timerRemaining(CommandContext<CommandSourceStack> ctx, String sp) {
        CommandSourceStack src = ctx.getSource();
        long remaining = SpawnManager.getFightTimeRemaining(sp, src.getServer());
        if (remaining < 0) return fail(src, "No hay pelea activa en §e" + sp + "§c o sin límite configurado.");
        return ok(src, "Tiempo restante en §e" + sp + "§a: §e" + remaining + "t §7(≈" + remaining/20 + "s).");
    }

    private static int timerTimeoutMsg(CommandContext<CommandSourceStack> ctx, String sp, String msg) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.timeoutMessage = msg;
        data.markDirty();
        return ok(src, "Mensaje de timeout de §e" + sp + "§a configurado. Vars: {boss} {spawnpoint}");
    }

    private static int configPrefix(CommandContext<CommandSourceStack> ctx, String prefix) {
        com.bosspoints.config.BossConfig.CHAT_PREFIX.set(prefix);
        return ok(ctx.getSource(), "Prefijo del mod cambiado a: " + prefix.replace("&", "§"));
    }

    private static int configDefeatMsg(CommandContext<CommandSourceStack> ctx, String sp, String msg) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.defeatMessage = msg;
        data.markDirty();
        return ok(src, "Mensaje de derrota de §e" + sp + "§a configurado.");
    }

    private static int rewardItemHand(CommandContext<CommandSourceStack> ctx, String sp, double prob, boolean allPlayers) {
        CommandSourceStack src = ctx.getSource();
        try {
            net.minecraft.server.level.ServerPlayer player = src.getPlayerOrException();
            net.minecraft.world.item.ItemStack stack = player.getMainHandItem();
            if (stack.isEmpty()) return fail(src, "No tenés ningún item en la mano.");
            SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
            SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
            com.bosspoints.data.ItemRewardConfig ir = new com.bosspoints.data.ItemRewardConfig();
            ir.itemId = net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(stack.getItem()).toString();
            ir.count = 1;
            ir.probability = prob;
            ir.allPlayers = allPlayers;
            ir.displayName = stack.getHoverName().getString();
            // Guardar NBT completo si tiene
            if (stack.hasTag()) ir.nbt = stack.getTag().toString();
            def.rewardConfig.items.add(ir);
            data.markDirty();
            String dist = allPlayers ? "todos" : "sorteado";
            return ok(src, "Item §e" + ir.displayName + " §a(" + Math.round(prob*100) + "% · " + dist + ") añadido a rewards de §e" + sp + "§a.");
        } catch (Exception e) {
            return fail(src, "Error: " + e.getMessage());
        }
    }

    private static int rewardMinDamage(CommandContext<CommandSourceStack> ctx, String sp, double percent) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.rewardConfig.minDamagePercent = percent;
        data.markDirty();
        if (percent <= 0) return ok(src, "Daño mínimo desactivado para §e" + sp + "§a.");
        return ok(src, "Daño mínimo para §e" + sp + "§a: §e" + percent + "%§a de la vida total del boss.");
    }

    private static int rewardTopClear(CommandContext<CommandSourceStack> ctx, String sp) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.rewardConfig.topDamageRewards.clear();
        data.markDirty();
        return ok(src, "Recompensas top daño de §e" + sp + "§a limpiadas.");
    }

    private static int rewardTopItemHand(CommandContext<CommandSourceStack> ctx, String sp, int count, double prob) {
        CommandSourceStack src = ctx.getSource();
        try {
            net.minecraft.server.level.ServerPlayer player = src.getPlayerOrException();
            net.minecraft.world.item.ItemStack stack = player.getMainHandItem();
            if (stack.isEmpty()) return fail(src, "No tenés ningún item en la mano.");
            SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
            SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
            com.bosspoints.data.ItemRewardConfig ir = new com.bosspoints.data.ItemRewardConfig();
            ir.itemId = net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(stack.getItem()).toString();
            ir.count = count > 0 ? count : 1;
            ir.probability = prob;
            ir.displayName = stack.getHoverName().getString();
            if (stack.hasTag()) ir.nbt = stack.getTag().toString();
            def.rewardConfig.topDamageRewards.add(ir);
            def.rewardConfig.topDamageProbability = prob;
            data.markDirty();
            return ok(src, "Recompensa top daño de §e" + sp + "§a → §e" + ir.displayName + " §a(" + Math.round(prob*100) + "%).");
        } catch (Exception e) {
            return fail(src, "Error: " + e.getMessage());
        }
    }


    private static int rewardTopMessage(CommandContext<CommandSourceStack> ctx, String sp, String msg) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.rewardConfig.topDamageMessage = msg;
        data.markDirty();
        return ok(src, "Mensaje top daño de §e" + sp + "§a configurado. Vars: {player} {damage} {percent} {spawnpoint}");
    }

    private static int victoryTitle(CommandContext<CommandSourceStack> ctx, String sp, String title) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.victoryTitleConfig.enabled = true;
        def.victoryTitleConfig.title = title;
        data.markDirty();
        return ok(src, "Victory title de §e" + sp + "§a → §b" + title + "§a.");
    }

    private static int victorySubtitle(CommandContext<CommandSourceStack> ctx, String sp, String subtitle) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.victoryTitleConfig.subtitle = subtitle;
        data.markDirty();
        return ok(src, "Victory subtitle de §e" + sp + "§a → §b" + subtitle + "§a.");
    }

    private static int victoryDisable(CommandContext<CommandSourceStack> ctx, String sp) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.victoryTitleConfig.enabled = false;
        data.markDirty();
        return ok(src, "Victory title desactivado para §e" + sp + "§a.");
    }

    // ── Rewards ──────────────────────────────────────────────────────────────────

    private static int rewardExp(CommandContext<CommandSourceStack> ctx, String sp, int amount) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.rewardConfig.experience = amount;
        data.markDirty();
        return ok(src, "Recompensa de §e" + sp + "§a: §e" + amount + "§a XP.");
    }

    private static int rewardItem(CommandContext<CommandSourceStack> ctx, String sp, String itemId, int count, double prob, boolean allPlayers) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        com.bosspoints.data.ItemRewardConfig ir = new com.bosspoints.data.ItemRewardConfig();
        ir.itemId = itemId; ir.count = count; ir.probability = prob; ir.allPlayers = allPlayers;
        def.rewardConfig.items.add(ir);
        data.markDirty();
        String dist = allPlayers ? "todos" : "sorteado";
        return ok(src, "Item reward §e" + itemId + " ×" + count + " §a(" + Math.round(prob*100) + "% · " + dist + ") añadido a §e" + sp + "§a.");
    }

    private static int rewardCmd(CommandContext<CommandSourceStack> ctx, String sp, String command) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.rewardConfig.commands.add(command);
        data.markDirty();
        return ok(src, "Comando reward añadido a §e" + sp + "§a: §7" + command);
    }

    private static int rewardLoot(CommandContext<CommandSourceStack> ctx, String sp, String loot) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.rewardConfig.lootTable = loot;
        data.markDirty();
        return ok(src, "Loot table de §e" + sp + "§a → §e" + loot + "§a.");
    }

    private static int rewardRadius(CommandContext<CommandSourceStack> ctx, String sp, float radius) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.rewardConfig.rewardRadius = radius;
        data.markDirty();
        return ok(src, "Radio de recompensa de §e" + sp + "§a → §e" + (int)radius + " §abloques.");
    }

    private static int rewardPerPlayer(CommandContext<CommandSourceStack> ctx, String sp, boolean val) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.rewardConfig.perPlayer = val;
        data.markDirty();
        return ok(src, "PerPlayer de §e" + sp + "§a → §e" + val + "§a.");
    }

    private static int rewardMessage(CommandContext<CommandSourceStack> ctx, String sp, String msg) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.rewardConfig.rewardMessage = msg;
        data.markDirty();
        return ok(src, "Mensaje de recompensa de §e" + sp + "§a → §b" + msg + "§a.");
    }

    private static int rewardClear(CommandContext<CommandSourceStack> ctx, String sp) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointSavedData data = SpawnPointSavedData.get(src.getServer());
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        def.rewardConfig = new com.bosspoints.data.RewardConfig();
        data.markDirty();
        return ok(src, "Recompensas de §e" + sp + "§a limpiadas.");
    }

    private static int rewardInfo(CommandContext<CommandSourceStack> ctx, String sp) {
        CommandSourceStack src = ctx.getSource();
        SpawnPointDefinition def = requireDef(src, sp); if (def == null) return 0;
        com.bosspoints.data.RewardConfig r = def.rewardConfig;
        StringBuilder sb = new StringBuilder("§6[Rewards: " + sp + "]§r\n");
        sb.append("§7XP: §f").append(r.experience).append("  §7PerPlayer: §f").append(r.perPlayer);
        sb.append("  §7Radio: §f").append((int)r.rewardRadius).append("b\n");
        if (r.lootTable != null) sb.append("§7LootTable: §f").append(r.lootTable).append("\n");
        for (int i=0; i<r.items.size(); i++) {
            com.bosspoints.data.ItemRewardConfig ir = r.items.get(i);
            sb.append("§7[").append(i).append("] §f").append(ir.itemId).append(" x").append(ir.count)
              .append(" §7(").append(Math.round(ir.probability*100)).append("% - ").append(ir.allPlayers?"todos":"sorteado").append(")\n");
        }
        for (int i=0; i<r.commands.size(); i++) sb.append("§7cmd[").append(i).append("]: §f").append(r.commands.get(i)).append("\n");
        return ok(src, sb.toString().trim());
    }

    private static int help(CommandContext<CommandSourceStack> ctx) {
        String help = "§6=== SummonCore - Ayuda ===\n" +
            "§e/smc create §7<nombre> <pos>\n" +
            "§e/smc delete/list/info/trigger §7<nombre>\n" +
            "§e/smc tp §7<nombre> §8- Teletransportarse al spawn point\n" +
            "§e/smc kill §7<nombre> §8- Matar todos los bosses activos\n" +
            "§6-- Entidad --\n" +
            "§e/smc entity add §7<sp> <tipo> [cantidad]\n" +
            "§e/smc entity remove/count/name §7<sp> <idx> ...\n" +
            "§e/smc entity attr §7<sp> <idx> <atributo> <valor>\n" +
            "§e/smc entity attrremove §7<sp> <idx> <atributo>\n" +
            "§6-- Fases --\n" +
            "§e/smc entity phase add §7<sp> <eidx> <hp%> [msg]\n" +
            "§e/smc entity phase remove/msg/cmd §7<sp> <eidx> <pidx> ...\n" +
            "§e/smc entity phase attr §7<sp> <eidx> <pidx> <attr> <val>\n" +
            "§e/smc entity phase attrremove §7<sp> <eidx> <pidx> <attr>\n" +
            "§6-- Transformación --\n" +
            "§e/smc entity transform set §7<sp> <idx> <tipo> [delay] [estilo]\n" +
            "§e/smc entity transform remove/name/msg/attr/attrremove §7...\n" +
            "§6-- BossBar --\n" +
            "§e/smc bossbar enable §7<sp> <idx> <COLOR> <STYLE>\n" +
            "§e/smc bossbar title/disable §7<sp> <idx> ...\n" +
            "§6-- Timer/Config --\n" +
            "§e/smc timer set §7<sp> <ticks> §8| §e/smc timer remove §7<sp>\n" +
            "§e/smc config broadcast/message/cooldown §7<sp> ...";
        ctx.getSource().sendSuccess(() -> Component.literal(help), false);
        return 1;
    }

    // ── Util ──────────────────────────────────────────────────────────────────

    private static String str(CommandContext<CommandSourceStack> ctx, String name) {
        return StringArgumentType.getString(ctx, name);
    }

    private static String rl(CommandContext<CommandSourceStack> ctx, String name) {
        return ResourceLocationArgument.getId(ctx, name).toString();
    }

    private static SpawnPointDefinition requireDef(CommandSourceStack src, String name) {
        SpawnPointDefinition def = SpawnPointSavedData.get(src.getServer()).get(name);
        if (def == null) fail(src, "Spawn point §e" + name + " §cno encontrado.");
        return def;
    }

    private static boolean checkIdx(CommandSourceStack src, SpawnPointDefinition def, int idx) {
        if (idx >= 0 && idx < def.entities.size()) return true;
        fail(src, "Índice §e" + idx + " §cinválido. Rango: 0-" + (def.entities.size()-1));
        return false;
    }

    private static int ok(CommandSourceStack src, String msg) {
        src.sendSuccess(() -> Component.literal("§a" + msg), false);
        return 1;
    }

    private static int fail(CommandSourceStack src, String msg) {
        src.sendFailure(Component.literal("§c" + msg));
        return 0;
    }

    // ===== /smc cine implementations =====

    private static int cineCreate(CommandContext<CommandSourceStack> ctx, String name) {
        CommandSourceStack src = ctx.getSource();
        com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
        if (data.get(name) != null) return fail(src, "Ya existe una cinemática llamada §e" + name);
        com.bosspoints.data.CinematicDefinition def = new com.bosspoints.data.CinematicDefinition();
        def.name = name;
        data.add(def);
        return ok(src, "Cinemática §e" + name + "§a creada.");
    }

    private static int cineDelete(CommandContext<CommandSourceStack> ctx, String name) {
        CommandSourceStack src = ctx.getSource();
        com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
        if (data.get(name) == null) return fail(src, "No existe §e" + name);
        data.remove(name);
        return ok(src, "Cinemática §e" + name + "§a eliminada.");
    }

    private static int cineList(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
        if (data.cinematics.isEmpty()) return ok(src, "No hay cinemáticas. Usá §e/smc cine create <nombre>§a.");
        for (com.bosspoints.data.CinematicDefinition def : data.cinematics)
            ok(src, "§e" + def.name + " §7— §e" + def.takes.size() + " §7tomas");
        return 1;
    }

    private static int cineTakeAdd(CommandContext<CommandSourceStack> ctx, String name) {
        CommandSourceStack src = ctx.getSource();
        com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
        com.bosspoints.data.CinematicDefinition def = data.get(name);
        if (def == null) return fail(src, "No existe §e" + name);
        def.takes.add(new com.bosspoints.data.CinematicTake());
        data.setDirty();
        return ok(src, "Toma [" + (def.takes.size()-1) + "] añadida a §e" + name);
    }

    private static int cineTakeRemove(CommandContext<CommandSourceStack> ctx, String name, int takeIdx) {
        CommandSourceStack src = ctx.getSource();
        com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
        com.bosspoints.data.CinematicDefinition def = data.get(name);
        if (def == null || takeIdx >= def.takes.size()) return fail(src, "Índice inválido.");
        def.takes.remove(takeIdx);
        data.setDirty();
        return ok(src, "Toma [" + takeIdx + "] eliminada.");
    }

    private static int cineTakeList(CommandContext<CommandSourceStack> ctx, String name) {
        CommandSourceStack src = ctx.getSource();
        com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
        com.bosspoints.data.CinematicDefinition def = data.get(name);
        if (def == null) return fail(src, "No existe §e" + name);
        if (def.takes.isEmpty()) return ok(src, "Sin tomas. Usá §e/smc cine take add " + name);
        for (int i = 0; i < def.takes.size(); i++) {
            var t = def.takes.get(i);
            ok(src, "[" + i + "] §ekf:" + t.keyframes.size() + " fadeStart:" + t.fadeStartTick + "t dur:" + t.fadeDurationTicks + "t fadeOut:" + t.fadeOutStartTick + "t");
        }
        return 1;
    }

    private static int cineTakeFade(CommandContext<CommandSourceStack> ctx, String name, int takeIdx, int ticks) {
        CommandSourceStack src = ctx.getSource();
        com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
        com.bosspoints.data.CinematicDefinition def = data.get(name);
        if (def == null || takeIdx >= def.takes.size()) return fail(src, "Índice inválido.");
        // handled by new signature
        data.setDirty();
        return ok(src, "Fade de toma [" + takeIdx + "] = §e" + ticks + "§a ticks.");
    }

    private static int cineCamKfSetRef(CommandContext<CommandSourceStack> ctx, String name, int takeIdx) {
        CommandSourceStack src = ctx.getSource();
        try {
            net.minecraft.server.level.ServerPlayer player = src.getPlayerOrException();
            com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
            com.bosspoints.data.CinematicDefinition def = data.get(name);
            if (def == null || takeIdx >= def.takes.size()) return fail(src, "Índice inválido.");
            def.refX = player.getX(); def.refY = player.getY(); def.refZ = player.getZ();
            data.setDirty();
            return ok(src, "Ref global seteado a §e" + String.format("%.2f,%.2f,%.2f", def.refX, def.refY, def.refZ));
        } catch (Exception e) { return fail(src, e.getMessage()); }
    }

    private static int cineCamKfAdd(CommandContext<CommandSourceStack> ctx, String name, int takeIdx, int duration) {
        CommandSourceStack src = ctx.getSource();
        try {
            net.minecraft.server.level.ServerPlayer player = src.getPlayerOrException();
            com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
            com.bosspoints.data.CinematicDefinition def = data.get(name);
            if (def == null || takeIdx >= def.takes.size()) return fail(src, "Índice inválido.");
            com.bosspoints.data.CinematicTake take = def.takes.get(takeIdx);
            com.bosspoints.data.CinematicKeyframe kf = new com.bosspoints.data.CinematicKeyframe();
            kf.dx = player.getX()-def.refX; kf.dy = player.getY()-def.refY; kf.dz = player.getZ()-def.refZ;
            kf.yaw = player.getYRot(); kf.pitch = player.getXRot();
            kf.durationTicks = duration;
            take.keyframes.add(kf);
            data.setDirty();
            return ok(src, "Keyframe [" + (take.keyframes.size()-1) + "] añadido a toma [" + takeIdx + "] dur:§e" + duration + "t");
        } catch (Exception e) { return fail(src, e.getMessage()); }
    }

    private static int cineCamKfClear(CommandContext<CommandSourceStack> ctx, String name, int takeIdx) {
        CommandSourceStack src = ctx.getSource();
        com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
        com.bosspoints.data.CinematicDefinition def = data.get(name);
        if (def == null || takeIdx >= def.takes.size()) return fail(src, "Índice inválido.");
        def.takes.get(takeIdx).keyframes.clear();
        data.setDirty();
        return ok(src, "Keyframes de toma [" + takeIdx + "] limpiados.");
    }

    private static int cineCamKfList(CommandContext<CommandSourceStack> ctx, String name, int takeIdx) {
        CommandSourceStack src = ctx.getSource();
        com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
        com.bosspoints.data.CinematicDefinition def = data.get(name);
        if (def == null || takeIdx >= def.takes.size()) return fail(src, "Índice inválido.");
        var kfs = def.takes.get(takeIdx).keyframes;
        if (kfs.isEmpty()) return ok(src, "Sin keyframes en toma [" + takeIdx + "].");
        for (int i = 0; i < kfs.size(); i++) {
            var k = kfs.get(i);
            ok(src, "[" + i + "] dx:§e" + String.format("%.2f", k.dx) + " §7dz:§e" + String.format("%.2f", k.dz) + " §7dur:§e" + k.durationTicks + "t");
        }
        return 1;
    }

    private static int cinePlay(CommandContext<CommandSourceStack> ctx, String name, int radio) {
        CommandSourceStack src = ctx.getSource();
        try {
            net.minecraft.server.level.ServerPlayer player = src.getPlayerOrException();
            com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
            com.bosspoints.data.CinematicDefinition def = data.get(name);
            if (def == null) return fail(src, "No existe §e" + name);
            if (def.takes.isEmpty()) return fail(src, "Sin tomas configuradas.");
            java.util.List<net.minecraft.server.level.ServerPlayer> targets = new java.util.ArrayList<>();
            for (net.minecraft.server.level.ServerPlayer p : player.getServer().getPlayerList().getPlayers()) {
                double dx = p.getX()-player.getX(), dz = p.getZ()-player.getZ();
                if (Math.sqrt(dx*dx+dz*dz) <= radio) targets.add(p);
            }
            com.bosspoints.manager.CinematicManager.startTakes(targets, def.takes, player.getX(), player.getY(), player.getZ(), -1, 10, -1, 10, 10);
            return ok(src, "Reproduciendo §e" + name + "§a para §e" + targets.size() + "§a jugadores.");
        } catch (Exception e) { return fail(src, e.getMessage()); }
    }

    private static int cinePreview(CommandContext<CommandSourceStack> ctx, String name) {
        CommandSourceStack src = ctx.getSource();
        try {
            net.minecraft.server.level.ServerPlayer player = src.getPlayerOrException();
            com.bosspoints.data.CinematicSavedData data = com.bosspoints.data.CinematicSavedData.get(src.getServer());
            com.bosspoints.data.CinematicDefinition def = data.get(name);
            if (def == null) return fail(src, "No existe §e" + name);
            if (def.takes.isEmpty()) return fail(src, "Sin tomas configuradas.");
            com.bosspoints.manager.CinematicManager.startTakes(java.util.List.of(player), def.takes, player.getX(), player.getY(), player.getZ(), -1, 10, -1, 10, 10);
            return ok(src, "Preview de §e" + name);
        } catch (Exception e) { return fail(src, e.getMessage()); }
    }

}