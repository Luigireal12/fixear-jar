package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import java.util.ArrayList;
import java.util.List;

public class ParticleAuraConfig {

    public enum AuraShape { ORBIT, RAIN, EXPLODE, SPIRAL, AURA }

    public static class AuraEntry {
        public String particleType = "minecraft:flame";
        public float radius = 2.0f;
        public int countPerTick = 3;
        public int durationTicks = 60;
        public int startTick = 0;
        public AuraShape shape = AuraShape.ORBIT;
        public float speedX = 0f, speedY = 0.1f, speedZ = 0f;

        public CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putString("particleType", particleType);
            t.putFloat("radius", radius);
            t.putInt("countPerTick", countPerTick);
            t.putInt("durationTicks", durationTicks);
            t.putInt("startTick", startTick);
            t.putString("shape", shape.name());
            t.putFloat("speedX", speedX); t.putFloat("speedY", speedY); t.putFloat("speedZ", speedZ);
            return t;
        }

        public static AuraEntry load(CompoundTag t) {
            AuraEntry e = new AuraEntry();
            e.particleType = t.getString("particleType");
            e.radius = t.contains("radius") ? t.getFloat("radius") : 2f;
            e.countPerTick = t.contains("countPerTick") ? t.getInt("countPerTick") : 3;
            e.durationTicks = t.contains("durationTicks") ? t.getInt("durationTicks") : 60;
            e.startTick = t.contains("startTick") ? t.getInt("startTick") : 0;
            try { e.shape = AuraShape.valueOf(t.getString("shape")); } catch (Exception ignored) {}
            e.speedX = t.contains("speedX") ? t.getFloat("speedX") : 0f;
            e.speedY = t.contains("speedY") ? t.getFloat("speedY") : 0.1f;
            e.speedZ = t.contains("speedZ") ? t.getFloat("speedZ") : 0f;
            return e;
        }
    }

    public List<AuraEntry> entries = new ArrayList<>();

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        ListTag list = new ListTag();
        for (AuraEntry e : entries) list.add(e.save());
        t.put("entries", list);
        return t;
    }

    public static ParticleAuraConfig load(CompoundTag t) {
        ParticleAuraConfig c = new ParticleAuraConfig();
        if (t.contains("entries")) {
            ListTag list = t.getList("entries", 10);
            for (int i = 0; i < list.size(); i++)
                c.entries.add(AuraEntry.load(list.getCompound(i)));
        }
        return c;
    }
}
