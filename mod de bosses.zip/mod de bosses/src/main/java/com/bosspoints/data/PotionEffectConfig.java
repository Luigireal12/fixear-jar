package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;

public class PotionEffectConfig {
    /** Resource location del efecto. Ej: "minecraft:resistance", "minecraft:strength" */
    public String effectId;
    /** Nivel del efecto (0 = nivel I, 1 = nivel II, etc.) */
    public int amplifier;
    /** Duración en segundos. 0 = permanente (Integer.MAX_VALUE ticks) */
    public int durationSeconds;
    /** true = partículas tenues (como efecto de baliza) */
    public boolean ambient;
    /** false = sin partículas */
    public boolean visible;

    public PotionEffectConfig() {
        this.effectId = "minecraft:resistance";
        this.amplifier = 0;
        this.durationSeconds = 0;
        this.ambient = false;
        this.visible = true;
    }

    public int getDurationTicks() {
        return durationSeconds <= 0 ? Integer.MAX_VALUE : durationSeconds * 20;
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("effectId", effectId);
        t.putInt("amplifier", amplifier);
        t.putInt("durationSeconds", durationSeconds);
        t.putBoolean("ambient", ambient);
        t.putBoolean("visible", visible);
        return t;
    }

    public static PotionEffectConfig load(CompoundTag t) {
        PotionEffectConfig c = new PotionEffectConfig();
        c.effectId = t.getString("effectId");
        c.amplifier = t.getInt("amplifier");
        c.durationSeconds = t.getInt("durationSeconds");
        c.ambient = t.contains("ambient") && t.getBoolean("ambient");
        c.visible = !t.contains("visible") || t.getBoolean("visible");
        return c;
    }

    public static List<PotionEffectConfig> loadList(ListTag list) {
        List<PotionEffectConfig> result = new ArrayList<>();
        for (int i = 0; i < list.size(); i++)
            result.add(load(list.getCompound(i)));
        return result;
    }
}
