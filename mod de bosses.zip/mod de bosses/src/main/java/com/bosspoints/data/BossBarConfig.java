package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.BossEvent;

public class BossBarConfig {
    public boolean enabled = false;
    public String color = "RED";
    public String style = "PROGRESS";
    /** Título custom. Vacío = usa el displayName de la entidad */
    public String title = "";

    public BossEvent.BossBarColor getColor() {
        try { return BossEvent.BossBarColor.valueOf(color.toUpperCase()); }
        catch (Exception e) { return BossEvent.BossBarColor.RED; }
    }

    public BossEvent.BossBarOverlay getOverlay() {
        try { return BossEvent.BossBarOverlay.valueOf(style.toUpperCase()); }
        catch (Exception e) { return BossEvent.BossBarOverlay.PROGRESS; }
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putBoolean("enabled", enabled);
        t.putString("color", color);
        t.putString("style", style);
        t.putString("title", title);
        return t;
    }

    public static BossBarConfig load(CompoundTag t) {
        BossBarConfig c = new BossBarConfig();
        c.enabled = t.getBoolean("enabled");
        c.color = t.getString("color");
        c.style = t.getString("style");
        c.title = t.contains("title") ? t.getString("title") : "";
        return c;
    }
}
