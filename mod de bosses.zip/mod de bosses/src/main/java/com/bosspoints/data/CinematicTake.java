package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import java.util.ArrayList;
import java.util.List;

public class CinematicTake {
    public List<CinematicKeyframe> keyframes = new ArrayList<>();
    public int fadeStartTick = -1;
    public int fadeDurationTicks = 20;
    public int fadeOutStartTick = -1;

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putInt("fadeStartTick", fadeStartTick);
        t.putInt("fadeDurationTicks", fadeDurationTicks);
        t.putInt("fadeOutStartTick", fadeOutStartTick);
        ListTag kfList = new ListTag();
        for (CinematicKeyframe kf : keyframes) kfList.add(kf.save());
        t.put("keyframes", kfList);
        return t;
    }

    public static CinematicTake load(CompoundTag t) {
        CinematicTake take = new CinematicTake();
        take.fadeStartTick = t.contains("fadeStartTick") ? t.getInt("fadeStartTick") : -1;
        take.fadeDurationTicks = t.contains("fadeDurationTicks") ? t.getInt("fadeDurationTicks") : 20;
        take.fadeOutStartTick = t.contains("fadeOutStartTick") ? t.getInt("fadeOutStartTick") : -1;
        if (t.contains("keyframes")) {
            ListTag kfList = t.getList("keyframes", 10);
            for (int i = 0; i < kfList.size(); i++)
                take.keyframes.add(CinematicKeyframe.load(kfList.getCompound(i)));
        }
        return take;
    }
}
