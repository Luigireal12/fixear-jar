package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;

/**
 * Sistema de recompensas al derrotar definitivamente un boss.
 * Compatible con DungeonMaster si está instalado (party system).
 */
public class RewardConfig {

    /** Items con probabilidad y modo de distribución */
    public List<ItemRewardConfig> items = new ArrayList<>();

    /** Comandos ejecutados con permisos de consola. @p = jugador */
    public List<String> commands = new ArrayList<>();

    /** Experiencia entregada */
    public int experience = 0;

    /** Loot table de Minecraft. Null = sin loot table */
    public String lootTable = null;

    /**
     * true  = cada jugador del área recibe experiencia y comandos individualmente
     * false = solo el líder de la party (o el jugador más cercano si no hay party)
     */
    public boolean perPlayer = true;

    /** Sonido de victoria. Null = sin sonido */
    public String sound = "minecraft:ui.toast.challenge_complete";

    /** Mensaje en chat al recibir recompensa */
    public String rewardMessage = "";

    /** Radio en bloques para determinar qué jugadores están en el combate */
    public float rewardRadius = 64f;

    /** % mínimo de daño total del boss que un jugador debe haber hecho para calificar (0 = desactivado) */
    public double minDamagePercent = 0.0;

    /** Items especiales para el jugador con más daño. Lista vacía = sin recompensa */
    public java.util.List<com.bosspoints.data.ItemRewardConfig> topDamageRewards = new java.util.ArrayList<>();

    /** Probabilidad de que el top daño reciba su recompensa especial (0.0-1.0) */
    public double topDamageProbability = 1.0;

    /** Mensaje de top daño. Vars: {player} {damage} {percent} {spawnpoint} */
    public String topDamageMessage = "§6[SummonCore] §7Top Daño: §e{player} §7({damage} puntos - {percent}%)";

    public boolean hasRewards() {
        return experience > 0 || lootTable != null
            || !commands.isEmpty() || !items.isEmpty();
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        ListTag itemList = new ListTag();
        for (ItemRewardConfig ir : items) itemList.add(ir.save());
        t.put("items", itemList);

        ListTag cmdList = new ListTag();
        for (String cmd : commands) cmdList.add(StringTag.valueOf(cmd));
        t.put("commands", cmdList);

        t.putInt("experience", experience);
        if (lootTable != null) t.putString("lootTable", lootTable);
        t.putBoolean("perPlayer", perPlayer);
        if (sound != null) t.putString("sound", sound);
        t.putString("rewardMessage", rewardMessage);
        t.putFloat("rewardRadius", rewardRadius);
        t.putDouble("minDamagePercent", minDamagePercent);
        t.putDouble("topDamageProbability", topDamageProbability);
        t.putString("topDamageMessage", topDamageMessage != null ? topDamageMessage : "");
        net.minecraft.nbt.ListTag topRewardList = new net.minecraft.nbt.ListTag();
        for (com.bosspoints.data.ItemRewardConfig ir : topDamageRewards) topRewardList.add(ir.save());
        t.put("topDamageRewards", topRewardList);
        return t;
    }

    public static RewardConfig load(CompoundTag t) {
        RewardConfig c = new RewardConfig();
        if (t.contains("items"))    c.items    = ItemRewardConfig.loadList(t.getList("items", Tag.TAG_COMPOUND));
        if (t.contains("commands")) { ListTag l = t.getList("commands", Tag.TAG_STRING); for (int i=0;i<l.size();i++) c.commands.add(l.getString(i)); }
        c.experience    = t.getInt("experience");
        c.lootTable     = t.contains("lootTable") ? t.getString("lootTable") : null;
        c.perPlayer     = !t.contains("perPlayer") || t.getBoolean("perPlayer");
        c.sound         = t.contains("sound") ? t.getString("sound") : "minecraft:ui.toast.challenge_complete";
        c.rewardMessage = t.contains("rewardMessage") ? t.getString("rewardMessage") : "";
        c.rewardRadius         = t.contains("rewardRadius")       ? t.getFloat("rewardRadius")         : 64f;
        c.minDamagePercent     = t.contains("minDamagePercent")   ? t.getDouble("minDamagePercent")    : 0.0;
        c.topDamageProbability = t.contains("topDamageProbability")? t.getDouble("topDamageProbability"): 1.0;
        c.topDamageMessage     = t.contains("topDamageMessage")   ? t.getString("topDamageMessage")    : "§6[SummonCore] §7Top Daño: §e{player} §7({damage} puntos - {percent}%)";
        c.topDamageRewards = new java.util.ArrayList<>();
        if (t.contains("topDamageRewards")) {
            net.minecraft.nbt.ListTag trl = t.getList("topDamageRewards", 10);
            for (int i = 0; i < trl.size(); i++) c.topDamageRewards.add(com.bosspoints.data.ItemRewardConfig.load(trl.getCompound(i)));
        } else if (t.contains("topDamageReward")) {
            c.topDamageRewards.add(com.bosspoints.data.ItemRewardConfig.load(t.getCompound("topDamageReward")));
        }
        return c;
    }
}
