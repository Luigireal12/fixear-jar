package com.bosspoints.data;

import com.bosspoints.BossPointsMod;
import com.bosspoints.manager.ConfigFileManager;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * World-level persistent storage for all spawn point definitions.
 * Saved to: world/data/summoncore_data.dat
 */
public class SpawnPointSavedData extends SavedData {

    private static final String DATA_NAME = "summoncore_data";

    private final Map<String, SpawnPointDefinition> spawnPoints = new LinkedHashMap<>();

    public SpawnPointSavedData() {}

    // ── Persistence ──────────────────────────────────────────────────────────

    public static SpawnPointSavedData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
            SpawnPointSavedData::load,
            SpawnPointSavedData::new,
            DATA_NAME
        );
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (SpawnPointDefinition def : spawnPoints.values()) {
            list.add(def.save());
        }
        tag.put("spawnPoints", list);
        return tag;
    }

    public static SpawnPointSavedData load(CompoundTag tag) {
        SpawnPointSavedData data = new SpawnPointSavedData();
        ListTag list = tag.getList("spawnPoints", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            SpawnPointDefinition def = SpawnPointDefinition.load(list.getCompound(i));
            data.spawnPoints.put(def.name.toLowerCase(), def);
        }
        BossPointsMod.LOGGER.info("[BossPoints] Cargados {} spawn points desde disco.", data.spawnPoints.size());
        return data;
    }

    // ── CRUD ─────────────────────────────────────────────────────────────────

    public boolean add(SpawnPointDefinition def) {
        String key = def.name.toLowerCase();
        if (spawnPoints.containsKey(key)) return false;
        spawnPoints.put(key, def);
        setDirty();
        ConfigFileManager.save(spawnPoints.values());
        return true;
    }

    public boolean remove(String name) {
        if (spawnPoints.remove(name.toLowerCase()) != null) {
            setDirty();
            ConfigFileManager.save(spawnPoints.values());
            return true;
        }
        return false;
    }

    @Nullable
    public SpawnPointDefinition get(String name) {
        return spawnPoints.get(name.toLowerCase());
    }

    public boolean exists(String name) {
        return spawnPoints.containsKey(name.toLowerCase());
    }

    public Collection<SpawnPointDefinition> getAll() {
        return spawnPoints.values();
    }

    /** Call this after modifying a definition to mark data as dirty and sync bosses.json. */
    public void markDirty() {
        setDirty();
        ConfigFileManager.save(spawnPoints.values());
    }
}
