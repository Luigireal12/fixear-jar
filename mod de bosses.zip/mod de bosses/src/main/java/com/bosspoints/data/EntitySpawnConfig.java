package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class EntitySpawnConfig {
    public String entityType;
    public String displayName;
    public int count;
    public Map<String, Double> attributes;
    public List<PhaseConfig> phases;
    public List<TransformConfig> transforms;
    public BossBarConfig bossBar;
    public MusicConfig spawnMusic;
    public com.bosspoints.data.CustomTitleConfig customTitles;
    public boolean noLoot;

    public EntitySpawnConfig() {
        this.entityType = "minecraft:zombie";
        this.displayName = "";
        this.count = 1;
        this.attributes = new LinkedHashMap<>();
        this.phases = new ArrayList<>();
        this.transforms = new ArrayList<>();
        this.bossBar = new BossBarConfig();
        this.customTitles = new com.bosspoints.data.CustomTitleConfig();
        this.spawnMusic = new MusicConfig();
        this.noLoot = false;
    }

    public String resolvedDisplayName() {
        if (!displayName.isEmpty()) return displayName;
        return entityType.contains(":") ? entityType.split(":")[1].replace("_", " ") : entityType;
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putString("entityType", entityType);
        tag.putString("displayName", displayName);
        tag.putInt("count", count);
        tag.putBoolean("noLoot", noLoot);

        CompoundTag attrs = new CompoundTag();
        for (Map.Entry<String, Double> e : attributes.entrySet())
            attrs.putDouble(e.getKey(), e.getValue());
        tag.put("attributes", attrs);

        ListTag phaseList = new ListTag();
        for (PhaseConfig p : phases) phaseList.add(p.save());
        tag.put("phases", phaseList);

        ListTag transformList = new ListTag();
        for (TransformConfig t : transforms) transformList.add(t.save());
        tag.put("transforms", transformList);

        tag.put("bossBar", bossBar.save());
        tag.put("customTitles", customTitles.save());
        tag.put("spawnMusic", spawnMusic.save());
        return tag;
    }

    public static EntitySpawnConfig load(CompoundTag tag) {
        EntitySpawnConfig cfg = new EntitySpawnConfig();
        cfg.entityType = tag.getString("entityType");
        cfg.displayName = tag.contains("displayName") ? tag.getString("displayName") : "";
        cfg.count = tag.getInt("count");
        cfg.noLoot = tag.contains("noLoot") && tag.getBoolean("noLoot");

        CompoundTag attrs = tag.getCompound("attributes");
        for (String key : attrs.getAllKeys()) cfg.attributes.put(key, attrs.getDouble(key));

        ListTag phaseList = tag.getList("phases", Tag.TAG_COMPOUND);
        for (int i = 0; i < phaseList.size(); i++)
            cfg.phases.add(PhaseConfig.load(phaseList.getCompound(i)));

        // Soporte formato viejo (single transform) y nuevo (lista)
        if (tag.contains("transforms")) {
            ListTag transformList = tag.getList("transforms", Tag.TAG_COMPOUND);
            for (int i = 0; i < transformList.size(); i++)
                cfg.transforms.add(TransformConfig.load(transformList.getCompound(i)));
        } else if (tag.getBoolean("hasTransform")) {
            cfg.transforms.add(TransformConfig.load(tag.getCompound("transform")));
        }

        if (tag.contains("bossBar"))    cfg.bossBar    = BossBarConfig.load(tag.getCompound("bossBar"));
        if (tag.contains("spawnMusic")) cfg.spawnMusic = MusicConfig.load(tag.getCompound("spawnMusic"));
        return cfg;
    }

    public String describe() {
        StringBuilder sb = new StringBuilder();
        String name = displayName.isEmpty() ? "§e" + entityType : "§b" + displayName + " §7(" + entityType + ")";
        sb.append(name).append(" §7x").append(count);
        if (noLoot) sb.append(" §8[sin loot]");
        if (!attributes.isEmpty()) {
            sb.append("\n  §7Atributos:");
            attributes.forEach((k, v) -> sb.append("\n    §f")
                .append(k.contains(":") ? k.split(":")[1] : k).append("=").append(v));
        }
        if (!phases.isEmpty()) {
            sb.append("\n  §7Fases: §f").append(phases.size());
            for (int i = 0; i < phases.size(); i++) {
                PhaseConfig p = phases.get(i);
                sb.append("\n    §7[").append(i).append("] §f").append((int)(p.healthPercent*100)).append("%");
                if (!p.message.isEmpty()) sb.append(" §7- ").append(p.message);
                if (!p.attributeChanges.isEmpty()) sb.append(" §8[").append(p.attributeChanges.size()).append(" attr]");
                if (p.music.enabled) sb.append(" §8[♪]");
            }
        }
        if (!transforms.isEmpty()) {
            sb.append("\n  §7Transformaciones: §f").append(transforms.size());
            for (int i = 0; i < transforms.size(); i++) {
                TransformConfig t = transforms.get(i);
                String tName = t.displayName.isEmpty() ? t.entityType : t.displayName;
                sb.append("\n    §7[").append(i).append("] §e").append(tName)
                  .append(" §7(").append(t.delayTicks).append("t, ").append(t.cinematicStyle).append(")");
                if (t.noLoot) sb.append(" §8[sin loot]");
                if (t.bossBar.enabled) sb.append(" §8[bossbar]");
            }
        }
        if (bossBar.enabled) sb.append("\n  §7BossBar: §f").append(bossBar.color).append("/").append(bossBar.style);
        if (spawnMusic.enabled) sb.append("\n  §7Música: §f").append(spawnMusic.soundEvent);
        return sb.toString();
    }
}
