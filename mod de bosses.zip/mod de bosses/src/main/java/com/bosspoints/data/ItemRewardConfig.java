package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;

/** Un item de recompensa con probabilidad y modo de distribución */
public class ItemRewardConfig {
    /** Resource location del item. Ej: "minecraft:diamond" */
    public String itemId = "minecraft:diamond";
    /** Cantidad */
    public int count = 1;
    /** Probabilidad de 0.0 a 1.0. 1.0 = siempre */
    public double probability = 1.0;
    /**
     * true  = se entrega a TODOS los jugadores en el área
     * false = se sortea entre los jugadores del área/party
     */
    public boolean allPlayers = true;
    /** NBT opcional. Null = sin NBT */
    public String nbt = null;
    /** Nombre visible en el mensaje de recompensa */
    public String displayName = null;

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("itemId", itemId);
        t.putInt("count", count);
        t.putDouble("probability", probability);
        t.putBoolean("allPlayers", allPlayers);
        if (nbt != null) t.putString("nbt", nbt);
        if (displayName != null) t.putString("displayName", displayName);
        return t;
    }

    public static ItemRewardConfig load(CompoundTag t) {
        ItemRewardConfig c = new ItemRewardConfig();
        c.itemId      = t.getString("itemId");
        c.count       = t.getInt("count");
        c.probability = t.contains("probability") ? t.getDouble("probability") : 1.0;
        c.allPlayers  = !t.contains("allPlayers") || t.getBoolean("allPlayers");
        c.nbt         = t.contains("nbt") ? t.getString("nbt") : null;
        c.displayName = t.contains("displayName") ? t.getString("displayName") : null;
        return c;
    }

    public static List<ItemRewardConfig> loadList(ListTag list) {
        List<ItemRewardConfig> result = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) result.add(load(list.getCompound(i)));
        return result;
    }
}
