package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import java.util.ArrayList;
import java.util.List;

public class CustomTitleConfig {

    public static class TitleEntry {
        public String text = "";
        public String color = "#FFFFFF";
        public float x = 0.5f;       // 0.0 = izquierda, 1.0 = derecha
        public float y = 0.4f;       // 0.0 = arriba, 1.0 = abajo
        public float scale = 1.0f;
        public int startTick = 0;    // tick relativo al spawn/transform
        public int durationTicks = 60;
        public int fadeInTicks = 10;
        public int fadeOutTicks = 10;
        public String font = "minecraft:default"; // fuente de Minecraft
        // Efectos avanzados
        public boolean typewriter = false;      // letra por letra
        public int typewriterSpeed = 2;         // ticks por letra
        public float toX = -1f, toY = -1f;     // posición final (-1 = no se mueve)
        public String shadowColor = "";         // color de sombra (#RRGGBB o vacío)

        public CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putString("text", text);
            t.putString("color", color);
            t.putFloat("x", x); t.putFloat("y", y);
            t.putFloat("scale", scale);
            t.putInt("startTick", startTick);
            t.putInt("durationTicks", durationTicks);
            t.putInt("fadeInTicks", fadeInTicks);
            t.putInt("fadeOutTicks", fadeOutTicks);
            t.putString("font", font);
            t.putBoolean("typewriter", typewriter);
            t.putInt("typewriterSpeed", typewriterSpeed);
            t.putFloat("toX", toX); t.putFloat("toY", toY);
            t.putString("shadowColor", shadowColor);
            return t;
        }

        public static TitleEntry load(CompoundTag t) {
            TitleEntry e = new TitleEntry();
            e.text = t.getString("text");
            e.color = t.contains("color") ? t.getString("color") : "#FFFFFF";
            e.x = t.contains("x") ? t.getFloat("x") : 0.5f;
            e.y = t.contains("y") ? t.getFloat("y") : 0.4f;
            e.scale = t.contains("scale") ? t.getFloat("scale") : 1.0f;
            e.startTick = t.getInt("startTick");
            e.durationTicks = t.contains("durationTicks") ? t.getInt("durationTicks") : 60;
            e.fadeInTicks = t.contains("fadeInTicks") ? t.getInt("fadeInTicks") : 10;
            e.fadeOutTicks = t.contains("fadeOutTicks") ? t.getInt("fadeOutTicks") : 10;
            e.font = t.contains("font") ? t.getString("font") : "minecraft:default";
            e.typewriter = t.contains("typewriter") && t.getBoolean("typewriter");
            e.typewriterSpeed = t.contains("typewriterSpeed") ? t.getInt("typewriterSpeed") : 2;
            e.toX = t.contains("toX") ? t.getFloat("toX") : -1f;
            e.toY = t.contains("toY") ? t.getFloat("toY") : -1f;
            e.shadowColor = t.contains("shadowColor") ? t.getString("shadowColor") : "";
            return e;
        }
    }

    public List<TitleEntry> entries = new ArrayList<>();

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        ListTag list = new ListTag();
        for (TitleEntry e : entries) list.add(e.save());
        t.put("entries", list);
        return t;
    }

    public static CustomTitleConfig load(CompoundTag t) {
        CustomTitleConfig c = new CustomTitleConfig();
        if (t.contains("entries")) {
            ListTag list = t.getList("entries", 10);
            for (int i = 0; i < list.size(); i++)
                c.entries.add(TitleEntry.load(list.getCompound(i)));
        }
        return c;
    }
}
