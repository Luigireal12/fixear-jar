package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.storage.DimensionDataStorage;

import java.util.ArrayList;
import java.util.List;

public class CinematicSavedData extends SavedData {
    private static final String KEY = "summoncore_cinematics";
    public List<CinematicDefinition> cinematics = new ArrayList<>();

    public static CinematicSavedData get(MinecraftServer server) {
        DimensionDataStorage storage = server.overworld().getDataStorage();
        return storage.computeIfAbsent(CinematicSavedData::load, CinematicSavedData::new, KEY);
    }

    public static CinematicSavedData load(CompoundTag tag) {
        CinematicSavedData data = new CinematicSavedData();
        if (tag.contains("cinematics")) {
            ListTag list = tag.getList("cinematics", 10);
            for (int i = 0; i < list.size(); i++)
                data.cinematics.add(CinematicDefinition.load(list.getCompound(i)));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (CinematicDefinition def : cinematics) list.add(def.save());
        tag.put("cinematics", list);
        return tag;
    }

    public CinematicDefinition get(String name) {
        return cinematics.stream().filter(c -> c.name.equals(name)).findFirst().orElse(null);
    }

    public void add(CinematicDefinition def) { cinematics.add(def); setDirty(); }
    public void remove(String name) { cinematics.removeIf(c -> c.name.equals(name)); setDirty(); }
}
