package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;

/**
 * Configuración de música para una entidad o fase.
 * El sound event debe existir en el resource pack del cliente.
 * Ejemplo: "summoncore:boss_theme" -> assets/summoncore/sounds/boss_theme.ogg
 */
public class MusicConfig {

    public boolean enabled = false;
    /** Resource location del sonido. Ej: "summoncore:boss_theme" o "minecraft:music.boss" */
    public String soundEvent = "";
    /** Radio en bloques desde el spawn point en que los jugadores escuchan la música */
    public float radius = 64.0f;
    /** Volumen (0.0 - 1.0) */
    public float volume = 1.0f;
    /** Pitch (0.5 - 2.0) */
    public float pitch = 1.0f;

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putBoolean("enabled", enabled);
        t.putString("soundEvent", soundEvent);
        t.putFloat("radius", radius);
        t.putFloat("volume", volume);
        t.putFloat("pitch", pitch);
        return t;
    }

    public static MusicConfig load(CompoundTag t) {
        MusicConfig c = new MusicConfig();
        c.enabled   = t.getBoolean("enabled");
        c.soundEvent = t.getString("soundEvent");
        c.radius    = t.contains("radius") ? t.getFloat("radius") : 64.0f;
        c.volume    = t.contains("volume") ? t.getFloat("volume") : 1.0f;
        c.pitch     = t.contains("pitch")  ? t.getFloat("pitch")  : 1.0f;
        return c;
    }
}
