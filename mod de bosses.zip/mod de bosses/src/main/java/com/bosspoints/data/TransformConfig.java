package com.bosspoints.data;

import net.minecraft.nbt.*;
import net.minecraft.nbt.Tag;

import java.util.LinkedHashMap;
import java.util.Map;

public class TransformConfig {
    public String entityType;
    /** Nombre custom de la entidad transformada. Vacío = nombre por defecto */
    public String displayName;
    /** Mensaje broadcast. Vacío = usa el default del config */
    public String message;
    /** false = no se manda ningún mensaje al transformar */
    public boolean broadcastMessage;
    /** Ticks de cinemática antes de spawnear */
    public int delayTicks;
    /** explosion, portal, smoke, ender */
    public String cinematicStyle;
    /** Atributos de la entidad transformada */
    public Map<String, Double> attributes;
    /** Si true, la entidad que spawna de esta transformación no dropea loot */
    public boolean noLoot;
    /** Color de fog al spawnear esta transformación. -1 = sin cambio */
    public TitleConfig titleConfig;
    public float fogR = -1, fogG = -1, fogB = -1;
    public int fogFadeTicks = 40;
    public float fogRadius = 128f;
    public float skyR = -1, skyG = -1, skyB = -1;
    public int skyFadeTicks = 40;
    /** Ticks de invulnerabilidad al spawnear (0 = sin invulnerabilidad) */
    public int invulnerabilityTicks = 0;
    /** Keyframes de cinemática. Vacío = sin cinemática */
    public java.util.List<com.bosspoints.data.CinematicKeyframe> cinematicKeyframes = new java.util.ArrayList<>();
    public java.util.List<com.bosspoints.data.CinematicTake> cinematicTakes = new java.util.ArrayList<>();
    public int fadeStartTick = -1;
    public int fadeBlackDurationTicks = 20;
    public int fadeOutStartTick = -1;
    public int fadeInDurationTicks = 10;
    public int fadeOutDurationTicks = 10;
    /** Radio en bloques para incluir jugadores en la cinemática */
    public float cinematicRadius = 50f;
    /** Títulos custom para esta transformación */
    public com.bosspoints.data.CustomTitleConfig customTitles = new com.bosspoints.data.CustomTitleConfig();
    /** Auras de partículas para esta transformación */
    public com.bosspoints.data.ParticleAuraConfig particleAura = new com.bosspoints.data.ParticleAuraConfig();
    /** Punto de referencia para calcular offsets (posición del spawn del boss) */
    public double refX = 0, refY = 0, refZ = 0;
    public java.util.List<PotionEffectConfig> potionEffects;
    /** Música que empieza cuando spawna la entidad transformada */
    public MusicConfig spawnMusic;
    /** BossBar para la entidad transformada */
    public BossBarConfig bossBar;

    public TransformConfig() {
        this.entityType = "minecraft:zombie";
        this.displayName = "";
        this.message = "";
        this.broadcastMessage = true;
        this.delayTicks = 60;
        this.cinematicStyle = "explosion";
        this.attributes = new LinkedHashMap<>();
        this.noLoot = false;
        this.potionEffects = new java.util.ArrayList<>();
        this.spawnMusic = new MusicConfig();
        this.bossBar = new BossBarConfig();
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putString("entityType", entityType);
        tag.putString("displayName", displayName);
        tag.putString("message", message);
        tag.putBoolean("broadcastMessage", broadcastMessage);
        tag.putInt("delayTicks", delayTicks);
        tag.putString("cinematicStyle", cinematicStyle);
        tag.putBoolean("noLoot", noLoot);
        if (titleConfig != null) tag.put("titleConfig", titleConfig.save());
        tag.putFloat("fogR", fogR); tag.putFloat("fogG", fogG); tag.putFloat("fogB", fogB);
        tag.putInt("fogFadeTicks", fogFadeTicks); tag.putFloat("fogRadius", fogRadius);
        tag.putFloat("skyR", skyR); tag.putFloat("skyG", skyG); tag.putFloat("skyB", skyB); tag.putInt("skyFadeTicks", skyFadeTicks);
        tag.putInt("invulnerabilityTicks", invulnerabilityTicks);
        net.minecraft.nbt.ListTag kfList = new net.minecraft.nbt.ListTag();
        for (com.bosspoints.data.CinematicKeyframe kf : cinematicKeyframes) kfList.add(kf.save());
        tag.put("cinematicKeyframes", kfList);
        tag.putFloat("cinematicRadius", cinematicRadius);
        tag.put("customTitles", customTitles.save());
        net.minecraft.nbt.ListTag takesList = new net.minecraft.nbt.ListTag();
        for (com.bosspoints.data.CinematicTake take : cinematicTakes) takesList.add(take.save());
        tag.put("cinematicTakes", takesList);
        tag.putInt("fadeStartTick", fadeStartTick);
        tag.putInt("fadeBlackDurationTicks", fadeBlackDurationTicks);
        tag.putInt("fadeOutStartTick", fadeOutStartTick);
        tag.putInt("fadeInDurationTicks", fadeInDurationTicks);
        tag.putInt("fadeOutDurationTicks", fadeOutDurationTicks);
        tag.put("particleAura", particleAura.save());
        tag.putDouble("refX", refX); tag.putDouble("refY", refY); tag.putDouble("refZ", refZ);
        ListTag effects = new ListTag();
        for (PotionEffectConfig e : potionEffects) effects.add(e.save());
        tag.put("potionEffects", effects);
        tag.put("spawnMusic", spawnMusic.save());
        tag.put("bossBar", bossBar.save());
        CompoundTag attrs = new CompoundTag();
        for (Map.Entry<String, Double> e : attributes.entrySet())
            attrs.putDouble(e.getKey(), e.getValue());
        tag.put("attributes", attrs);
        return tag;
    }

    public static TransformConfig load(CompoundTag tag) {
        TransformConfig cfg = new TransformConfig();
        cfg.entityType = tag.getString("entityType");
        cfg.displayName = tag.contains("displayName") ? tag.getString("displayName") : "";
        cfg.message = tag.contains("message") ? tag.getString("message") : "";
        cfg.broadcastMessage = !tag.contains("broadcastMessage") || tag.getBoolean("broadcastMessage");
        cfg.delayTicks = tag.getInt("delayTicks");
        cfg.cinematicStyle = tag.contains("cinematicStyle") ? tag.getString("cinematicStyle") : "explosion";
        cfg.noLoot = tag.contains("noLoot") && tag.getBoolean("noLoot");
        cfg.fogR = tag.contains("fogR") ? tag.getFloat("fogR") : -1;
        cfg.fogG = tag.contains("fogG") ? tag.getFloat("fogG") : -1;
        cfg.fogB = tag.contains("fogB") ? tag.getFloat("fogB") : -1;
        cfg.fogFadeTicks = tag.contains("fogFadeTicks") ? tag.getInt("fogFadeTicks") : 40;
cfg.titleConfig = tag.contains("titleConfig") ? TitleConfig.load(tag.getCompound("titleConfig")) : new TitleConfig();
        cfg.fogRadius = tag.contains("fogRadius") ? tag.getFloat("fogRadius") : 128f;
        cfg.skyR = tag.contains("skyR") ? tag.getFloat("skyR") : -1;
        cfg.skyG = tag.contains("skyG") ? tag.getFloat("skyG") : -1;
        cfg.skyB = tag.contains("skyB") ? tag.getFloat("skyB") : -1;
        cfg.skyFadeTicks = tag.contains("skyFadeTicks") ? tag.getInt("skyFadeTicks") : 40;
        cfg.invulnerabilityTicks = tag.contains("invulnerabilityTicks") ? tag.getInt("invulnerabilityTicks") : 0;
        cfg.cinematicKeyframes = new java.util.ArrayList<>();
        if (tag.contains("cinematicKeyframes")) {
            net.minecraft.nbt.ListTag kfl = tag.getList("cinematicKeyframes", 10);
            for (int i = 0; i < kfl.size(); i++) cfg.cinematicKeyframes.add(com.bosspoints.data.CinematicKeyframe.load(kfl.getCompound(i)));
        }
        cfg.cinematicRadius = tag.contains("cinematicRadius") ? tag.getFloat("cinematicRadius") : 50f;
        cfg.customTitles = tag.contains("customTitles") ? com.bosspoints.data.CustomTitleConfig.load(tag.getCompound("customTitles")) : new com.bosspoints.data.CustomTitleConfig();
        cfg.cinematicTakes = new java.util.ArrayList<>();
        cfg.fadeStartTick = tag.contains("fadeStartTick") ? tag.getInt("fadeStartTick") : -1;
        cfg.fadeBlackDurationTicks = tag.contains("fadeBlackDurationTicks") ? tag.getInt("fadeBlackDurationTicks") : 20;
        cfg.fadeOutStartTick = tag.contains("fadeOutStartTick") ? tag.getInt("fadeOutStartTick") : -1;
        cfg.fadeInDurationTicks = tag.contains("fadeInDurationTicks") ? tag.getInt("fadeInDurationTicks") : 10;
        cfg.fadeOutDurationTicks = tag.contains("fadeOutDurationTicks") ? tag.getInt("fadeOutDurationTicks") : 10;
        if (tag.contains("cinematicTakes")) {
            net.minecraft.nbt.ListTag takesList = tag.getList("cinematicTakes", 10);
            for (int i = 0; i < takesList.size(); i++)
                cfg.cinematicTakes.add(com.bosspoints.data.CinematicTake.load(takesList.getCompound(i)));
        }
        cfg.particleAura = tag.contains("particleAura") ? com.bosspoints.data.ParticleAuraConfig.load(tag.getCompound("particleAura")) : new com.bosspoints.data.ParticleAuraConfig();
        cfg.refX = tag.contains("refX") ? tag.getDouble("refX") : 0;
        cfg.refY = tag.contains("refY") ? tag.getDouble("refY") : 0;
        cfg.refZ = tag.contains("refZ") ? tag.getDouble("refZ") : 0;
        cfg.potionEffects = tag.contains("potionEffects") ? PotionEffectConfig.loadList(tag.getList("potionEffects", Tag.TAG_COMPOUND)) : new java.util.ArrayList<>();
        cfg.spawnMusic = tag.contains("spawnMusic") ? MusicConfig.load(tag.getCompound("spawnMusic")) : new MusicConfig();
        cfg.bossBar = tag.contains("bossBar") ? BossBarConfig.load(tag.getCompound("bossBar")) : new BossBarConfig();
        CompoundTag attrs = tag.getCompound("attributes");
        for (String key : attrs.getAllKeys()) cfg.attributes.put(key, attrs.getDouble(key));
        return cfg;
    }
}
