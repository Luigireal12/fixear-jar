package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;

/** Keyframe relativo al punto de referencia de spawn */
public class CinematicKeyframe {
    /** Offset relativo al punto de referencia */
    public double dx, dy, dz;
    public float yaw, pitch;
    /** Ticks para llegar a este punto desde el anterior */
    public int durationTicks = 40;

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putDouble("dx", dx); t.putDouble("dy", dy); t.putDouble("dz", dz);
        t.putFloat("yaw", yaw); t.putFloat("pitch", pitch);
        t.putInt("durationTicks", durationTicks);
        return t;
    }

    public static CinematicKeyframe load(CompoundTag t) {
        CinematicKeyframe k = new CinematicKeyframe();
        k.dx = t.getDouble("dx"); k.dy = t.getDouble("dy"); k.dz = t.getDouble("dz");
        k.yaw = t.getFloat("yaw"); k.pitch = t.getFloat("pitch");
        k.durationTicks = t.contains("durationTicks") ? t.getInt("durationTicks") : 40;
        return k;
    }
}
