package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import java.util.ArrayList;
import java.util.List;

/** Cinemática standalone — independiente del sistema de bosses */
public class CinematicDefinition {
    public String name = "";
    public List<CinematicTake> takes = new ArrayList<>();
    public double refX = 0, refY = 0, refZ = 0;

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("name", name);
        t.putDouble("refX", refX); t.putDouble("refY", refY); t.putDouble("refZ", refZ);
        ListTag takeList = new ListTag();
        for (CinematicTake take : takes) takeList.add(take.save());
        t.put("takes", takeList);
        return t;
    }

    public static CinematicDefinition load(CompoundTag t) {
        CinematicDefinition def = new CinematicDefinition();
        def.name = t.getString("name");
        def.refX = t.contains("refX") ? t.getDouble("refX") : 0;
        def.refY = t.contains("refY") ? t.getDouble("refY") : 0;
        def.refZ = t.contains("refZ") ? t.getDouble("refZ") : 0;
        if (t.contains("takes")) {
            ListTag takeList = t.getList("takes", 10);
            for (int i = 0; i < takeList.size(); i++)
                def.takes.add(CinematicTake.load(takeList.getCompound(i)));
        }
        return def;
    }
}
