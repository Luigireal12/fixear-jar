package com.bosspoints.data;

import net.minecraft.nbt.CompoundTag;

public class TitleConfig {
    public boolean enabled = false;
    /** Texto principal. Soporta §color codes */
    public String title = "";
    /** Subtítulo. Vacío = sin subtítulo */
    public String subtitle = "";
    /** Ticks de fade in */
    public int fadeIn = 10;
    /** Ticks que permanece */
    public int stay = 70;
    /** Ticks de fade out */
    public int fadeOut = 20;
    /** Radio de bloques para enviar el título */
    public float radius = 128f;

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putBoolean("enabled", enabled);
        t.putString("title", title);
        t.putString("subtitle", subtitle);
        t.putInt("fadeIn", fadeIn);
        t.putInt("stay", stay);
        t.putInt("fadeOut", fadeOut);
        t.putFloat("radius", radius);
        return t;
    }

    public static TitleConfig load(CompoundTag t) {
        TitleConfig c = new TitleConfig();
        c.enabled   = t.getBoolean("enabled");
        c.title     = t.getString("title");
        c.subtitle  = t.getString("subtitle");
        c.fadeIn    = t.contains("fadeIn")  ? t.getInt("fadeIn")   : 10;
        c.stay      = t.contains("stay")    ? t.getInt("stay")     : 70;
        c.fadeOut   = t.contains("fadeOut") ? t.getInt("fadeOut")  : 20;
        c.radius    = t.contains("radius")  ? t.getFloat("radius") : 128f;
        return c;
    }
}
