package com.bosspoints.data;

import net.minecraft.nbt.*;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PhaseConfig {
    /** Porcentaje de vida (0.0-1.0). Dispara cuando HP cae BAJO este valor */
    public double healthPercent;
    /** Mensaje global. Vacío = sin mensaje. Vars: {entity}, {percent}, {health}, {maxhealth} */
    public String message;
    /** Comandos del servidor que se ejecutan al disparar */
    public List<String> commands;
    /** Cambios de atributos al entrar en esta fase. registry name -> nuevo valor base */
    public Map<String, Double> attributeChanges;
    public java.util.List<PotionEffectConfig> potionEffects;
    /** Color de fog al entrar en esta fase. -1 = sin cambio */
    public TitleConfig titleConfig;
    public float fogR = -1, fogG = -1, fogB = -1;
    public int fogFadeTicks = 40;
    public float fogRadius = 128f;
    public float skyR = -1, skyG = -1, skyB = -1;
    public int skyFadeTicks = 40;
    /** Música que empieza al entrar en esta fase. null/disabled = sin cambio */
    public MusicConfig music;

    public PhaseConfig() {
        this.healthPercent = 0.5;
        this.message = "";
        this.commands = new ArrayList<>();
        this.attributeChanges = new LinkedHashMap<>();
        this.potionEffects = new java.util.ArrayList<>();
        this.music = new MusicConfig();
    }

    public PhaseConfig(double healthPercent, String message) {
        this();
        this.healthPercent = healthPercent;
        this.message = message;
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putDouble("healthPercent", healthPercent);
        tag.putString("message", message);

        ListTag cmds = new ListTag();
        for (String cmd : commands) cmds.add(StringTag.valueOf(cmd));
        tag.put("commands", cmds);

        CompoundTag attrs = new CompoundTag();
        for (Map.Entry<String, Double> e : attributeChanges.entrySet())
            attrs.putDouble(e.getKey(), e.getValue());
        tag.put("attributeChanges", attrs);
        tag.put("music", music.save());
        if (titleConfig != null) tag.put("titleConfig", titleConfig.save());
        tag.putFloat("fogR", fogR); tag.putFloat("fogG", fogG); tag.putFloat("fogB", fogB);
        tag.putInt("fogFadeTicks", fogFadeTicks); tag.putFloat("fogRadius", fogRadius);
        tag.putFloat("skyR", skyR); tag.putFloat("skyG", skyG); tag.putFloat("skyB", skyB); tag.putInt("skyFadeTicks", skyFadeTicks);
        return tag;
    }

    public static PhaseConfig load(CompoundTag tag) {
        PhaseConfig cfg = new PhaseConfig();
        cfg.healthPercent = tag.getDouble("healthPercent");
        cfg.message = tag.getString("message");

        ListTag cmds = tag.getList("commands", Tag.TAG_STRING);
        for (int i = 0; i < cmds.size(); i++) cfg.commands.add(cmds.getString(i));

        CompoundTag attrs = tag.getCompound("attributeChanges");
        for (String key : attrs.getAllKeys()) cfg.attributeChanges.put(key, attrs.getDouble(key));
        if (tag.contains("music")) cfg.music = MusicConfig.load(tag.getCompound("music"));
        cfg.fogR = tag.contains("fogR") ? tag.getFloat("fogR") : -1;
        cfg.fogG = tag.contains("fogG") ? tag.getFloat("fogG") : -1;
        cfg.fogB = tag.contains("fogB") ? tag.getFloat("fogB") : -1;
        cfg.fogFadeTicks = tag.contains("fogFadeTicks") ? tag.getInt("fogFadeTicks") : 40;
cfg.titleConfig = tag.contains("titleConfig") ? TitleConfig.load(tag.getCompound("titleConfig")) : new TitleConfig();
        cfg.fogRadius = tag.contains("fogRadius") ? tag.getFloat("fogRadius") : 128f;
        cfg.skyR = tag.contains("skyR") ? tag.getFloat("skyR") : -1;
        cfg.skyG = tag.contains("skyG") ? tag.getFloat("skyG") : -1;
        cfg.skyB = tag.contains("skyB") ? tag.getFloat("skyB") : -1;
        cfg.skyFadeTicks = tag.contains("skyFadeTicks") ? tag.getInt("skyFadeTicks") : 40;
        return cfg;
    }
}
