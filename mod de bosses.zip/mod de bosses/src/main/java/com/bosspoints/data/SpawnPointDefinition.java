package com.bosspoints.data;

import com.bosspoints.config.BossConfig;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;

public class SpawnPointDefinition {
    public String name;
    public double x, y, z;
    public String dimension;
    public List<EntitySpawnConfig> entities;
    public boolean broadcastSpawn;
    public String spawnMessageFormat;
    public int cooldownTicks;
    public long lastTriggerTick;
    /** Ticks entre spawns automáticos. 0 = desactivado */
    public int autoSpawnIntervalTicks;
    public long lastAutoSpawnTick;
    /** Título en pantalla al derrotar definitivamente el boss */
    public TitleConfig victoryTitleConfig;
    /** Sistema de recompensas al derrotar definitivamente el boss */
    public RewardConfig rewardConfig;
    /** Mensaje global al derrotar el boss. Vars: {boss} {killer} {spawnpoint} */
    public String defeatMessage = "§6[SummonCore] §e{killer} §7derrotó a §c{boss}§7!";
    /** Header del top daño en chat. Vacío = usar el default */
    public String topDamageHeader = "";
    /** Medallas del top daño (5 entradas). Vacío = default */
    public String[] topDamageMedals = {};

    /** Ticks antes de que el boss se vaya sin ser derrotado. 0 = sin límite */
    public int fightTimeoutTicks = 0;
    /** Mensaje cuando el boss se va por timeout. Vars: {boss} {spawnpoint} */
    public String timeoutMessage = "§6[SummonCore] §c{boss} §7se ha ido...";

    public SpawnPointDefinition() {
        this.entities = new ArrayList<>();
        this.broadcastSpawn = true;
        this.spawnMessageFormat = "";
        this.cooldownTicks = 0;
        this.lastTriggerTick = -1;
        this.autoSpawnIntervalTicks = 0;
        this.lastAutoSpawnTick = -1;
        this.victoryTitleConfig = new TitleConfig();
        this.rewardConfig = new RewardConfig();
        this.defeatMessage = "§6[SummonCore] §e{killer} §7derrotó a §c{boss}§7!";
        this.fightTimeoutTicks = 0;
        this.timeoutMessage = "§6[SummonCore] §c{boss} §7se ha ido...";
    }

    public boolean isOnCooldown(long currentTick) {
        if (cooldownTicks <= 0) return false;
        return currentTick - lastTriggerTick < cooldownTicks;
    }

    public long ticksUntilReady(long currentTick) {
        if (!isOnCooldown(currentTick)) return 0;
        return cooldownTicks - (currentTick - lastTriggerTick);
    }

    public String resolvedSpawnFormat() {
        return spawnMessageFormat.isEmpty() ? BossConfig.DEFAULT_SPAWN_FORMAT.get() : spawnMessageFormat;
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putString("name", name);
        tag.putDouble("x", x); tag.putDouble("y", y); tag.putDouble("z", z);
        tag.putString("dimension", dimension);
        tag.putBoolean("broadcastSpawn", broadcastSpawn);
        tag.putString("spawnMessageFormat", spawnMessageFormat);
        tag.putInt("cooldownTicks", cooldownTicks);
        tag.putLong("lastTriggerTick", lastTriggerTick);
        tag.putInt("autoSpawnIntervalTicks", autoSpawnIntervalTicks);
        tag.putLong("lastAutoSpawnTick", lastAutoSpawnTick);

        if (victoryTitleConfig != null) tag.put("victoryTitleConfig", victoryTitleConfig.save());
        tag.put("rewardConfig", rewardConfig != null ? rewardConfig.save() : new RewardConfig().save());
        tag.putString("defeatMessage", defeatMessage != null ? defeatMessage : "");
        tag.putInt("fightTimeoutTicks", fightTimeoutTicks);
        tag.putString("timeoutMessage", timeoutMessage != null ? timeoutMessage : "");
        ListTag entityList = new ListTag();
        for (EntitySpawnConfig e : entities) entityList.add(e.save());
        tag.put("entities", entityList);
        return tag;
    }

    public static SpawnPointDefinition load(CompoundTag tag) {
        SpawnPointDefinition def = new SpawnPointDefinition();
        def.name = tag.getString("name");
        def.x = tag.getDouble("x"); def.y = tag.getDouble("y"); def.z = tag.getDouble("z");
        def.dimension = tag.getString("dimension");
        def.broadcastSpawn = tag.getBoolean("broadcastSpawn");
        def.spawnMessageFormat = tag.getString("spawnMessageFormat");
        def.cooldownTicks = tag.getInt("cooldownTicks");
        def.lastTriggerTick = tag.getLong("lastTriggerTick");
        def.autoSpawnIntervalTicks = tag.contains("autoSpawnIntervalTicks") ? tag.getInt("autoSpawnIntervalTicks") : 0;
        def.lastAutoSpawnTick = tag.contains("lastAutoSpawnTick") ? tag.getLong("lastAutoSpawnTick") : -1;

        def.victoryTitleConfig = tag.contains("victoryTitleConfig") ? TitleConfig.load(tag.getCompound("victoryTitleConfig")) : new TitleConfig();
        def.rewardConfig = tag.contains("rewardConfig") ? RewardConfig.load(tag.getCompound("rewardConfig")) : new RewardConfig();
        def.defeatMessage = tag.contains("defeatMessage") ? tag.getString("defeatMessage") : "§6[SummonCore] §e{killer} §7derrotó a §c{boss}§7!";
        def.fightTimeoutTicks = tag.contains("fightTimeoutTicks") ? tag.getInt("fightTimeoutTicks") : 0;
        def.timeoutMessage = tag.contains("timeoutMessage") ? tag.getString("timeoutMessage") : "§6[SummonCore] §c{boss} §7se ha ido...";
        ListTag entityList = tag.getList("entities", Tag.TAG_COMPOUND);
        for (int i = 0; i < entityList.size(); i++)
            def.entities.add(EntitySpawnConfig.load(entityList.getCompound(i)));
        return def;
    }

    public String describe() {
        StringBuilder sb = new StringBuilder();
        sb.append("§6[").append(name).append("]\n");
        sb.append("§7Pos: §f").append((int)x).append(", ").append((int)y).append(", ").append((int)z)
          .append("  §7Dim: §f").append(dimension).append("\n");
        sb.append("§7Broadcast: §f").append(broadcastSpawn)
          .append("  §7Cooldown: §f").append(cooldownTicks).append("t");
        if (autoSpawnIntervalTicks > 0)
            sb.append("  §7Timer: §f").append(autoSpawnIntervalTicks).append("t (≈").append(autoSpawnIntervalTicks/20).append("s)");
        sb.append("\n§7Entidades (").append(entities.size()).append("):\n");
        for (int i = 0; i < entities.size(); i++)
            sb.append("  §7[").append(i).append("] ").append(entities.get(i).describe()).append("\n");
        return sb.toString().trim();
    }
}
