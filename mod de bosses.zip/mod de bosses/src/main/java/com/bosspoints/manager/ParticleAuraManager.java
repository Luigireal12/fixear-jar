package com.bosspoints.manager;

import com.bosspoints.data.ParticleAuraConfig;
import com.bosspoints.data.ParticleAuraConfig.AuraEntry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;

import java.util.*;

public class ParticleAuraManager {

    private static class ActiveAura {
        final net.minecraft.world.entity.Entity entity;
        final AuraEntry config;
        int ticksAlive = 0;
        ActiveAura(net.minecraft.world.entity.Entity e, AuraEntry c) { entity=e; config=c; }
    }

    private static final List<ActiveAura> active = new ArrayList<>();

    public static void startAuras(net.minecraft.world.entity.Entity entity, ParticleAuraConfig config) {
        for (AuraEntry e : config.entries) active.add(new ActiveAura(entity, e));
    }

    public static void tick(MinecraftServer server) {
        active.removeIf(a -> {
            if (!a.entity.isAlive()) return true;
            a.ticksAlive++;
            if (a.ticksAlive <= a.config.startTick) return false;
            if (a.ticksAlive > a.config.startTick + a.config.durationTicks) return true;
            if (a.entity.level() instanceof ServerLevel sl) spawnParticles(sl, a);
            return false;
        });
    }

    private static void spawnParticles(ServerLevel level, ActiveAura a) {
        AuraEntry c = a.config;
        double ex = a.entity.getX();
        double ey = a.entity.getY() + (a.entity.getBoundingBox().getYsize()) / 2;
        double ez = a.entity.getZ();
        int elapsed = a.ticksAlive - c.startTick;
        double angle = (elapsed * 15.0) * Math.PI / 180.0;

        // Resolver tipo de partícula dinámicamente desde el registro
        net.minecraft.core.particles.SimpleParticleType particle = ParticleTypes.FLAME;
        try {
            String pt = c.particleType.contains(":") ? c.particleType : "minecraft:" + c.particleType;
            net.minecraft.core.particles.ParticleType<?> type =
                net.minecraft.core.registries.BuiltInRegistries.PARTICLE_TYPE
                    .get(net.minecraft.resources.ResourceLocation.parse(pt));
            if (type instanceof net.minecraft.core.particles.SimpleParticleType spt) {
                particle = spt;
            }
        } catch (Exception ignored) {}

        for (int i = 0; i < c.countPerTick; i++) {
            double a2 = angle + (i * 2.0 * Math.PI / Math.max(1, c.countPerTick));
            double px, py, pz, vx, vy, vz;

            switch (c.shape) {
                case ORBIT -> {
                    px = ex + Math.cos(a2) * c.radius;
                    py = ey;
                    pz = ez + Math.sin(a2) * c.radius;
                    vx = 0; vy = c.speedY; vz = 0;
                }
                case RAIN -> {
                    px = ex + (Math.random()*2-1)*c.radius;
                    py = ey + c.radius;
                    pz = ez + (Math.random()*2-1)*c.radius;
                    vx = c.speedX; vy = -Math.abs(c.speedY); vz = c.speedZ;
                }
                case EXPLODE -> {
                    double theta = Math.random()*Math.PI*2, phi = Math.random()*Math.PI;
                    px = ex + Math.sin(phi)*Math.cos(theta)*c.radius;
                    py = ey + Math.cos(phi)*c.radius;
                    pz = ez + Math.sin(phi)*Math.sin(theta)*c.radius;
                    vx = (px-ex)*0.05; vy = (py-ey)*0.05+c.speedY; vz = (pz-ez)*0.05;
                }
                case SPIRAL -> {
                    double t = (double)elapsed / Math.max(1, c.durationTicks);
                    px = ex + Math.cos(a2)*c.radius*(1-t*0.5);
                    py = ey + t*c.radius*2;
                    pz = ez + Math.sin(a2)*c.radius*(1-t*0.5);
                    vx = 0; vy = c.speedY; vz = 0;
                }
                default -> {
                    // AURA y cualquier otro: partículas desde los pies hasta arriba
                    double auraT = Math.random();
                    double entityH = a.entity.getBoundingBox().getYsize();
                    double ringRadius = c.radius * Math.sin(auraT * Math.PI) * 0.8;
                    double angle2 = a2 + elapsed * 0.3;
                    px = ex + Math.cos(angle2) * ringRadius;
                    py = a.entity.getY() + auraT * entityH;
                    pz = ez + Math.sin(angle2) * ringRadius;
                    vx = (px - ex) * 0.02;
                    vy = c.speedY + Math.random() * 0.05;
                    vz = (pz - ez) * 0.02;
                }
            }

            level.sendParticles(particle, px, py, pz, 1, vx, vy, vz, 1.0);
        }
    }

    public static void stopForEntity(net.minecraft.world.entity.Entity entity) {
        active.removeIf(a -> a.entity.getUUID().equals(entity.getUUID()));
    }

    public static void stopAll() { active.clear(); }
}
