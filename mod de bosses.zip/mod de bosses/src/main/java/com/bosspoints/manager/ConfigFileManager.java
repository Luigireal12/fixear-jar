package com.bosspoints.manager;

import com.bosspoints.BossPointsMod;
import com.bosspoints.data.*;
import com.google.gson.*;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Sincroniza los spawn points con config/summoncore/bosses.json.
 * - Se escribe automáticamente en cada cambio.
 * - Se puede editar manualmente y recargar con /smc config reload.
 *
 * El JSON es legible y editable directamente.
 */
public class ConfigFileManager {

    private static final Path CONFIG_DIR  = FMLPaths.CONFIGDIR.get().resolve("summoncore");
    private static final Path CONFIG_FILE = CONFIG_DIR.resolve("bosses.json");

    private static final Gson GSON = new GsonBuilder()
        .setPrettyPrinting()
        .serializeNulls()
        .create();

    // ── Init ──────────────────────────────────────────────────────────────────

    public static void init() {
        try {
            Files.createDirectories(CONFIG_DIR);
        } catch (IOException e) {
            BossPointsMod.LOGGER.error("[SummonCore] Error creando carpeta de config: {}", e.getMessage());
        }
    }

    // ── Save ──────────────────────────────────────────────────────────────────

    public static void save(Collection<SpawnPointDefinition> defs) {
        try {
            List<JsonObject> list = new ArrayList<>();
            for (SpawnPointDefinition def : defs) {
                list.add(serializeDef(def));
            }

            JsonObject root = new JsonObject();
            root.add("spawnPoints", GSON.toJsonTree(list));

            String json = GSON.toJson(root);
            Files.writeString(CONFIG_FILE, json, StandardCharsets.UTF_8);
            BossPointsMod.LOGGER.debug("[SummonCore] bosses.json guardado ({} spawn points).", defs.size());
        } catch (IOException e) {
            BossPointsMod.LOGGER.error("[SummonCore] Error guardando bosses.json: {}", e.getMessage());
        }
    }

    // ── Load ──────────────────────────────────────────────────────────────────

    /**
     * Lee bosses.json y retorna la lista de SpawnPointDefinitions.
     * Retorna null si el archivo no existe o hay error.
     */
    public static List<SpawnPointDefinition> load() {
        if (!Files.exists(CONFIG_FILE)) return null;

        try {
            String json = Files.readString(CONFIG_FILE, StandardCharsets.UTF_8);
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();
            JsonArray array = root.getAsJsonArray("spawnPoints");

            List<SpawnPointDefinition> result = new ArrayList<>();
            for (JsonElement elem : array) {
                SpawnPointDefinition def = deserializeDef(elem.getAsJsonObject());
                if (def != null) result.add(def);
            }

            BossPointsMod.LOGGER.info("[SummonCore] bosses.json cargado: {} spawn points.", result.size());
            return result;
        } catch (Exception e) {
            BossPointsMod.LOGGER.error("[SummonCore] Error leyendo bosses.json: {}", e.getMessage());
            return null;
        }
    }

    // ── Serialize SpawnPointDefinition ────────────────────────────────────────

    private static JsonObject serializeDef(SpawnPointDefinition def) {
        JsonObject o = new JsonObject();
        o.addProperty("name", def.name);
        o.addProperty("x", def.x);
        o.addProperty("y", def.y);
        o.addProperty("z", def.z);
        o.addProperty("dimension", def.dimension);
        o.addProperty("broadcastSpawn", def.broadcastSpawn);
        o.addProperty("spawnMessageFormat", def.spawnMessageFormat);
        o.addProperty("cooldownTicks", def.cooldownTicks);
        o.addProperty("autoSpawnIntervalTicks", def.autoSpawnIntervalTicks);

        JsonArray entities = new JsonArray();
        for (EntitySpawnConfig e : def.entities) entities.add(serializeEntity(e));
        o.add("entities", entities);
        return o;
    }

    private static JsonObject serializeEntity(EntitySpawnConfig e) {
        JsonObject o = new JsonObject();
        o.addProperty("entityType", e.entityType);
        o.addProperty("displayName", e.displayName);
        o.addProperty("count", e.count);
        o.addProperty("noLoot", e.noLoot);
        o.add("attributes", serializeMap(e.attributes));

        JsonArray phases = new JsonArray();
        for (PhaseConfig p : e.phases) phases.add(serializePhase(p));
        o.add("phases", phases);

        JsonArray transforms = new JsonArray();
        for (TransformConfig t : e.transforms) transforms.add(serializeTransform(t));
        o.add("transforms", transforms);

        o.add("bossBar", serializeBossBar(e.bossBar));
        o.add("spawnMusic", serializeMusic(e.spawnMusic));
        return o;
    }

    private static JsonObject serializePhase(PhaseConfig p) {
        JsonObject o = new JsonObject();
        o.addProperty("healthPercent", (int)(p.healthPercent * 100) + "%");
        o.addProperty("message", p.message);
        o.add("attributeChanges", serializeMap(p.attributeChanges));
        o.addProperty("fogR", p.fogR);
        o.addProperty("fogG", p.fogG);
        o.addProperty("fogB", p.fogB);
        o.addProperty("fogFadeTicks", p.fogFadeTicks);
        o.addProperty("fogRadius", p.fogRadius);
        o.addProperty("skyR", p.skyR);
        o.addProperty("skyG", p.skyG);
        o.addProperty("skyB", p.skyB);
        o.addProperty("skyFadeTicks", p.skyFadeTicks);
        o.add("music", serializeMusic(p.music));
        JsonArray cmds = new JsonArray();
        p.commands.forEach(cmds::add);
        o.add("commands", cmds);
        return o;
    }

    private static JsonObject serializeTransform(TransformConfig t) {
        JsonObject o = new JsonObject();
        o.addProperty("entityType", t.entityType);
        o.addProperty("displayName", t.displayName);
        o.addProperty("broadcastMessage", t.broadcastMessage);
        o.addProperty("message", t.message);
        o.addProperty("delayTicks", t.delayTicks);
        o.addProperty("cinematicStyle", t.cinematicStyle);
        o.addProperty("noLoot", t.noLoot);
        o.addProperty("fogR", t.fogR);
        o.addProperty("fogG", t.fogG);
        o.addProperty("fogB", t.fogB);
        o.addProperty("fogFadeTicks", t.fogFadeTicks);
        o.addProperty("fogRadius", t.fogRadius);
        o.addProperty("skyR", t.skyR);
        o.addProperty("skyG", t.skyG);
        o.addProperty("skyB", t.skyB);
        o.addProperty("skyFadeTicks", t.skyFadeTicks);
        o.addProperty("invulnerabilityTicks", t.invulnerabilityTicks);
        com.google.gson.JsonArray kfArr = new com.google.gson.JsonArray();
        for (com.bosspoints.data.CinematicKeyframe kf : t.cinematicKeyframes) {
            com.google.gson.JsonObject kfo = new com.google.gson.JsonObject();
            kfo.addProperty("dx", kf.dx); kfo.addProperty("dy", kf.dy); kfo.addProperty("dz", kf.dz);
            kfo.addProperty("yaw", kf.yaw); kfo.addProperty("pitch", kf.pitch);
            kfo.addProperty("durationTicks", kf.durationTicks);
            kfArr.add(kfo);
        }
        o.add("cinematicKeyframes", kfArr);
        o.addProperty("cinematicRadius", t.cinematicRadius);
        o.addProperty("refX", t.refX); o.addProperty("refY", t.refY); o.addProperty("refZ", t.refZ);
        o.add("attributes", serializeMap(t.attributes));
        o.add("bossBar", serializeBossBar(t.bossBar));
        o.add("spawnMusic", serializeMusic(t.spawnMusic));
        // Cinematic Takes
        com.google.gson.JsonArray takesArr = new com.google.gson.JsonArray();
        for (com.bosspoints.data.CinematicTake take : t.cinematicTakes) {
            com.google.gson.JsonObject takeObj = new com.google.gson.JsonObject();
            takeObj.addProperty("fadeStartTick", take.fadeStartTick);
            takeObj.addProperty("fadeDurationTicks", take.fadeDurationTicks);
            takeObj.addProperty("fadeOutStartTick", take.fadeOutStartTick);
            com.google.gson.JsonArray kfArr2 = new com.google.gson.JsonArray();
            for (com.bosspoints.data.CinematicKeyframe kf : take.keyframes) {
                com.google.gson.JsonObject kfo = new com.google.gson.JsonObject();
                kfo.addProperty("dx", kf.dx); kfo.addProperty("dy", kf.dy); kfo.addProperty("dz", kf.dz);
                kfo.addProperty("yaw", kf.yaw); kfo.addProperty("pitch", kf.pitch);
                kfo.addProperty("durationTicks", kf.durationTicks);
                kfArr2.add(kfo);
            }
            takeObj.add("keyframes", kfArr2);
            takesArr.add(takeObj);
        }
        o.add("cinematicTakes", takesArr);
        o.addProperty("fadeStartTick", t.fadeStartTick);
        o.addProperty("fadeBlackDurationTicks", t.fadeBlackDurationTicks);
        o.addProperty("fadeOutStartTick", t.fadeOutStartTick);
        o.addProperty("fadeInDurationTicks", t.fadeInDurationTicks);
        o.addProperty("fadeOutDurationTicks", t.fadeOutDurationTicks);

        // Custom titles
        com.google.gson.JsonArray ctArr = new com.google.gson.JsonArray();
        for (com.bosspoints.data.CustomTitleConfig.TitleEntry te : t.customTitles.entries) {
            com.google.gson.JsonObject teo = new com.google.gson.JsonObject();
            teo.addProperty("text", te.text); teo.addProperty("color", te.color);
            teo.addProperty("x", te.x); teo.addProperty("y", te.y);
            teo.addProperty("scale", te.scale);
            teo.addProperty("startTick", te.startTick); teo.addProperty("durationTicks", te.durationTicks);
            teo.addProperty("fadeInTicks", te.fadeInTicks); teo.addProperty("fadeOutTicks", te.fadeOutTicks);
            teo.addProperty("font", te.font);
            teo.addProperty("typewriter", te.typewriter); teo.addProperty("typewriterSpeed", te.typewriterSpeed);
            teo.addProperty("toX", te.toX); teo.addProperty("toY", te.toY);
            teo.addProperty("shadowColor", te.shadowColor);
            ctArr.add(teo);
        }
        com.google.gson.JsonObject ctObj = new com.google.gson.JsonObject();
        ctObj.add("entries", ctArr);
        o.add("customTitles", ctObj);
        // Particle auras
        com.google.gson.JsonArray paArr = new com.google.gson.JsonArray();
        for (com.bosspoints.data.ParticleAuraConfig.AuraEntry ae : t.particleAura.entries) {
            com.google.gson.JsonObject aeo = new com.google.gson.JsonObject();
            aeo.addProperty("particleType", ae.particleType);
            aeo.addProperty("radius", ae.radius);
            aeo.addProperty("countPerTick", ae.countPerTick);
            aeo.addProperty("durationTicks", ae.durationTicks);
            aeo.addProperty("startTick", ae.startTick);
            aeo.addProperty("shape", ae.shape.name());
            aeo.addProperty("speedX", ae.speedX); aeo.addProperty("speedY", ae.speedY); aeo.addProperty("speedZ", ae.speedZ);
            paArr.add(aeo);
        }
        com.google.gson.JsonObject paObj = new com.google.gson.JsonObject();
        paObj.add("entries", paArr);
        o.add("particleAura", paObj);
        return o;
    }

    private static JsonObject serializeBossBar(BossBarConfig b) {
        JsonObject o = new JsonObject();
        o.addProperty("enabled", b.enabled);
        o.addProperty("color", b.color);
        o.addProperty("style", b.style);
        o.addProperty("title", b.title);
        return o;
    }

    private static JsonObject serializeMusic(MusicConfig m) {
        JsonObject o = new JsonObject();
        o.addProperty("enabled", m.enabled);
        o.addProperty("soundEvent", m.soundEvent);
        o.addProperty("radius", m.radius);
        o.addProperty("volume", m.volume);
        o.addProperty("pitch", m.pitch);
        return o;
    }

    private static JsonObject serializeMap(Map<String, Double> map) {
        JsonObject o = new JsonObject();
        map.forEach(o::addProperty);
        return o;
    }

    // ── Deserialize SpawnPointDefinition ──────────────────────────────────────

    private static SpawnPointDefinition deserializeDef(JsonObject o) {
        try {
            SpawnPointDefinition def = new SpawnPointDefinition();
            def.name      = o.get("name").getAsString();
            def.x         = o.get("x").getAsDouble();
            def.y         = o.get("y").getAsDouble();
            def.z         = o.get("z").getAsDouble();
            def.dimension = o.get("dimension").getAsString();
            def.broadcastSpawn        = getBoolean(o, "broadcastSpawn", true);
            def.spawnMessageFormat    = getString(o, "spawnMessageFormat", "");
            def.cooldownTicks         = getInt(o, "cooldownTicks", 0);
            def.autoSpawnIntervalTicks = getInt(o, "autoSpawnIntervalTicks", 0);

            if (o.has("entities")) {
                for (JsonElement e : o.getAsJsonArray("entities"))
                    def.entities.add(deserializeEntity(e.getAsJsonObject()));
            }
            return def;
        } catch (Exception e) {
            BossPointsMod.LOGGER.error("[SummonCore] Error deserializando spawn point: {}", e.getMessage());
            return null;
        }
    }

    private static EntitySpawnConfig deserializeEntity(JsonObject o) {
        EntitySpawnConfig e = new EntitySpawnConfig();
        e.entityType  = getString(o, "entityType", "minecraft:zombie");
        e.displayName = getString(o, "displayName", "");
        e.count       = getInt(o, "count", 1);
        e.noLoot      = getBoolean(o, "noLoot", false);
        if (o.has("attributes")) e.attributes = deserializeMap(o.getAsJsonObject("attributes"));
        if (o.has("phases"))
            for (JsonElement p : o.getAsJsonArray("phases"))
                e.phases.add(deserializePhase(p.getAsJsonObject()));
        if (o.has("transforms"))
            for (JsonElement t : o.getAsJsonArray("transforms"))
                e.transforms.add(deserializeTransform(t.getAsJsonObject()));
        if (o.has("bossBar"))  e.bossBar    = deserializeBossBar(o.getAsJsonObject("bossBar"));
        if (o.has("spawnMusic")) e.spawnMusic = deserializeMusic(o.getAsJsonObject("spawnMusic"));
        return e;
    }

    private static PhaseConfig deserializePhase(JsonObject o) {
        PhaseConfig p = new PhaseConfig();
        // Acepta "75%" o 0.75 como healthPercent
        if (o.has("healthPercent")) {
            String hp = o.get("healthPercent").getAsString();
            p.healthPercent = hp.endsWith("%")
                ? Double.parseDouble(hp.replace("%", "")) / 100.0
                : Double.parseDouble(hp);
        }
        p.message = getString(o, "message", "");
        p.fogR        = getFloat(o, "fogR", -1f);
        p.fogG        = getFloat(o, "fogG", -1f);
        p.fogB        = getFloat(o, "fogB", -1f);
        p.fogFadeTicks = getInt(o, "fogFadeTicks", 40);
        p.fogRadius   = getFloat(o, "fogRadius", 128f);
        if (o.has("attributeChanges")) p.attributeChanges = deserializeMap(o.getAsJsonObject("attributeChanges"));
        if (o.has("music"))  p.music = deserializeMusic(o.getAsJsonObject("music"));
        if (o.has("commands"))
            for (JsonElement c : o.getAsJsonArray("commands"))
                p.commands.add(c.getAsString());
        return p;
    }

    private static TransformConfig deserializeTransform(JsonObject o) {
        TransformConfig t = new TransformConfig();
        t.entityType       = getString(o, "entityType", "minecraft:zombie");
        t.displayName      = getString(o, "displayName", "");
        t.broadcastMessage = getBoolean(o, "broadcastMessage", true);
        t.message          = getString(o, "message", "");
        t.delayTicks       = getInt(o, "delayTicks", 60);
        t.cinematicStyle   = getString(o, "cinematicStyle", "explosion");
        t.noLoot           = getBoolean(o, "noLoot", false);
        t.fogR         = getFloat(o, "fogR", -1f);
        t.fogG         = getFloat(o, "fogG", -1f);
        t.fogB         = getFloat(o, "fogB", -1f);
        t.fogFadeTicks = getInt(o, "fogFadeTicks", 40);
        t.fogRadius    = getFloat(o, "fogRadius", 128f);
        t.skyR         = getFloat(o, "skyR", -1f);
        t.skyG         = getFloat(o, "skyG", -1f);
        t.skyB         = getFloat(o, "skyB", -1f);
        t.skyFadeTicks = getInt(o, "skyFadeTicks", 40);
        if (o.has("attributes")) t.attributes = deserializeMap(o.getAsJsonObject("attributes"));
        if (o.has("bossBar"))    t.bossBar    = deserializeBossBar(o.getAsJsonObject("bossBar"));
        if (o.has("spawnMusic")) t.spawnMusic = deserializeMusic(o.getAsJsonObject("spawnMusic"));
        t.invulnerabilityTicks = getInt(o, "invulnerabilityTicks", 0);
        t.cinematicRadius = getFloat(o, "cinematicRadius", 50f);
        t.refX = o.has("refX") ? o.get("refX").getAsDouble() : 0;
        t.refY = o.has("refY") ? o.get("refY").getAsDouble() : 0;
        t.refZ = o.has("refZ") ? o.get("refZ").getAsDouble() : 0;
        t.cinematicKeyframes = new java.util.ArrayList<>();
        if (o.has("cinematicKeyframes")) {
            for (com.google.gson.JsonElement e : o.getAsJsonArray("cinematicKeyframes")) {
                com.google.gson.JsonObject ko = e.getAsJsonObject();
                com.bosspoints.data.CinematicKeyframe kf = new com.bosspoints.data.CinematicKeyframe();
                kf.dx = ko.get("dx").getAsDouble(); kf.dy = ko.get("dy").getAsDouble(); kf.dz = ko.get("dz").getAsDouble();
                kf.yaw = ko.get("yaw").getAsFloat(); kf.pitch = ko.get("pitch").getAsFloat();
                kf.durationTicks = ko.has("durationTicks") ? ko.get("durationTicks").getAsInt() : 40;
                t.cinematicKeyframes.add(kf);
            }
        }
        t.fadeStartTick = o.has("fadeStartTick") ? o.get("fadeStartTick").getAsInt() : -1;
        t.fadeBlackDurationTicks = o.has("fadeBlackDurationTicks") ? o.get("fadeBlackDurationTicks").getAsInt() : 20;
        t.fadeOutStartTick = o.has("fadeOutStartTick") ? o.get("fadeOutStartTick").getAsInt() : -1;
        t.fadeInDurationTicks = o.has("fadeInDurationTicks") ? o.get("fadeInDurationTicks").getAsInt() : 10;
        t.fadeOutDurationTicks = o.has("fadeOutDurationTicks") ? o.get("fadeOutDurationTicks").getAsInt() : 10;
        t.cinematicTakes = new java.util.ArrayList<>();
        if (o.has("cinematicTakes")) {
            for (com.google.gson.JsonElement te : o.getAsJsonArray("cinematicTakes")) {
                com.google.gson.JsonObject to = te.getAsJsonObject();
                com.bosspoints.data.CinematicTake take = new com.bosspoints.data.CinematicTake();
                take.fadeStartTick = to.has("fadeStartTick") ? to.get("fadeStartTick").getAsInt() : -1;
                take.fadeDurationTicks = to.has("fadeDurationTicks") ? to.get("fadeDurationTicks").getAsInt() : 20;
                take.fadeOutStartTick = to.has("fadeOutStartTick") ? to.get("fadeOutStartTick").getAsInt() : -1;
                if (to.has("keyframes")) {
                    for (com.google.gson.JsonElement ke : to.getAsJsonArray("keyframes")) {
                        com.google.gson.JsonObject ko = ke.getAsJsonObject();
                        com.bosspoints.data.CinematicKeyframe kf = new com.bosspoints.data.CinematicKeyframe();
                        kf.dx = ko.get("dx").getAsDouble(); kf.dy = ko.get("dy").getAsDouble(); kf.dz = ko.get("dz").getAsDouble();
                        kf.yaw = ko.get("yaw").getAsFloat(); kf.pitch = ko.get("pitch").getAsFloat();
                        kf.durationTicks = ko.has("durationTicks") ? ko.get("durationTicks").getAsInt() : 40;
                        take.keyframes.add(kf);
                    }
                }
                t.cinematicTakes.add(take);
            }
        }

        t.customTitles = new com.bosspoints.data.CustomTitleConfig();
        if (o.has("customTitles") && o.get("customTitles").isJsonObject()) {
            com.google.gson.JsonObject ct = o.getAsJsonObject("customTitles");
            if (ct.has("entries")) {
                for (com.google.gson.JsonElement e : ct.getAsJsonArray("entries")) {
                    com.google.gson.JsonObject eo = e.getAsJsonObject();
                    com.bosspoints.data.CustomTitleConfig.TitleEntry te = new com.bosspoints.data.CustomTitleConfig.TitleEntry();
                    te.text = getString(eo, "text", "");
                    te.color = getString(eo, "color", "#FFFFFF");
                    te.x = getFloat(eo, "x", 0.5f); te.y = getFloat(eo, "y", 0.4f);
                    te.scale = getFloat(eo, "scale", 1f);
                    te.startTick = getInt(eo, "startTick", 0);
                    te.durationTicks = getInt(eo, "durationTicks", 60);
                    te.fadeInTicks = getInt(eo, "fadeInTicks", 10);
                    te.fadeOutTicks = getInt(eo, "fadeOutTicks", 10);
                    te.font = getString(eo, "font", "minecraft:default");
                    te.typewriter = eo.has("typewriter") && eo.get("typewriter").getAsBoolean();
                    te.typewriterSpeed = getInt(eo, "typewriterSpeed", 2);
                    te.toX = getFloat(eo, "toX", -1f); te.toY = getFloat(eo, "toY", -1f);
                    te.shadowColor = getString(eo, "shadowColor", "");
                    t.customTitles.entries.add(te);
                }
            }
        }
        t.particleAura = new com.bosspoints.data.ParticleAuraConfig();
        if (o.has("particleAura") && o.get("particleAura").isJsonObject()) {
            com.google.gson.JsonObject pa = o.getAsJsonObject("particleAura");
            if (pa.has("entries")) {
                for (com.google.gson.JsonElement e : pa.getAsJsonArray("entries")) {
                    com.google.gson.JsonObject eo = e.getAsJsonObject();
                    com.bosspoints.data.ParticleAuraConfig.AuraEntry ae = new com.bosspoints.data.ParticleAuraConfig.AuraEntry();
                    ae.particleType = getString(eo, "particleType", "minecraft:flame");
                    ae.radius = getFloat(eo, "radius", 2f);
                    ae.countPerTick = getInt(eo, "countPerTick", 3);
                    ae.durationTicks = getInt(eo, "durationTicks", 60);
                    ae.startTick = getInt(eo, "startTick", 0);
                    try { ae.shape = com.bosspoints.data.ParticleAuraConfig.AuraShape.valueOf(getString(eo, "shape", "ORBIT")); } catch (Exception ex) {}
                    ae.speedX = getFloat(eo, "speedX", 0f); ae.speedY = getFloat(eo, "speedY", 0.1f); ae.speedZ = getFloat(eo, "speedZ", 0f);
                    t.particleAura.entries.add(ae);
                }
            }
        }
        return t;
    }

    private static BossBarConfig deserializeBossBar(JsonObject o) {
        BossBarConfig b = new BossBarConfig();
        b.enabled = getBoolean(o, "enabled", false);
        b.color   = getString(o, "color", "RED");
        b.style   = getString(o, "style", "PROGRESS");
        b.title   = getString(o, "title", "");
        return b;
    }

    private static MusicConfig deserializeMusic(JsonObject o) {
        MusicConfig m = new MusicConfig();
        m.enabled    = getBoolean(o, "enabled", false);
        m.soundEvent = getString(o, "soundEvent", "");
        m.radius     = getFloat(o, "radius", 64f);
        m.volume     = getFloat(o, "volume", 1f);
        m.pitch      = getFloat(o, "pitch", 1f);
        return m;
    }

    private static Map<String, Double> deserializeMap(JsonObject o) {
        Map<String, Double> map = new java.util.LinkedHashMap<>();
        for (Map.Entry<String, JsonElement> e : o.entrySet())
            map.put(e.getKey(), e.getValue().getAsDouble());
        return map;
    }

    // ── JSON helpers ──────────────────────────────────────────────────────────

    private static String  getString (JsonObject o, String key, String  def) { return o.has(key) ? o.get(key).getAsString()  : def; }
    private static boolean getBoolean(JsonObject o, String key, boolean def) { return o.has(key) ? o.get(key).getAsBoolean() : def; }
    private static int     getInt    (JsonObject o, String key, int     def) { return o.has(key) ? o.get(key).getAsInt()     : def; }
    private static float   getFloat  (JsonObject o, String key, float   def) { return o.has(key) ? o.get(key).getAsFloat()   : def; }
}
