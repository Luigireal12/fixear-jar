package com.bosspoints.manager;

import com.bosspoints.BossPointsMod;
import com.bosspoints.data.ItemRewardConfig;
import com.bosspoints.data.RewardConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.registries.ForgeRegistries;

import com.bosspoints.manager.DamageTracker;
import java.util.*;

/**
 * Gestiona la distribución de recompensas al derrotar un boss.
 * Si DungeonMaster está instalado, usa su PartyManager para detectar parties.
 */
public class BossRewardManager {

    private static final Random RNG = new Random();

    /**
     * Entrega las recompensas a los jugadores en el área.
     * Integra el sistema de parties de DungeonMaster si está disponible.
     *
     * @param reward     Configuración de recompensas
     * @param bossX/Y/Z  Posición del boss para detectar jugadores en radio
     * @param level      Dimensión del boss
     * @param server     Servidor
     */
    public static void grantRewards(RewardConfig reward, double bossX, double bossY, double bossZ,
                                    ServerLevel level, MinecraftServer server) {
        if (reward == null || !reward.hasRewards()) return;

        // Encontrar jugadores en el radio del boss
        List<ServerPlayer> nearby = new ArrayList<>();
        for (ServerPlayer p : level.players()) {
            double dx = p.getX()-bossX, dy = p.getY()-bossY, dz = p.getZ()-bossZ;
            if (Math.sqrt(dx*dx+dy*dy+dz*dz) <= reward.rewardRadius) nearby.add(p);
        }
        if (nearby.isEmpty()) nearby.addAll(level.players()); // fallback: todos en la dimensión
        if (nearby.isEmpty()) return;

        // Expandir con party de DungeonMaster si está cargado
        List<ServerPlayer> recipients = expandWithParty(nearby, server);

        BossPointsMod.LOGGER.info("[SummonCore] Entregando recompensas a {} jugadores", recipients.size());

        // Experiencia y comandos
        if (reward.perPlayer) {
            for (ServerPlayer p : recipients) {
                grantBasicRewards(reward, p, server);
            }
        } else {
            // Solo al jugador más cercano (o líder de party)
            grantBasicRewards(reward, getClosest(nearby, bossX, bossY, bossZ), server);
        }

        // Loot table
        if (reward.lootTable != null && !reward.lootTable.isEmpty()) {
            if (reward.perPlayer) {
                for (ServerPlayer p : recipients) grantLootTable(reward.lootTable, p);
            } else {
                grantLootTable(reward.lootTable, getClosest(nearby, bossX, bossY, bossZ));
            }
        }

        // Items con probabilidad y modo de distribución
        for (ItemRewardConfig ir : reward.items) {
            if (RNG.nextDouble() > ir.probability) continue; // no ganado esta vez
            if (ir.allPlayers) {
                for (ServerPlayer p : recipients) grantItem(ir, p);
            } else {
                // Sortear entre los jugadores cercanos
                ServerPlayer winner = nearby.get(RNG.nextInt(nearby.size()));
                grantItem(ir, winner);
            }
        }

        // Sonido de victoria
        if (reward.sound != null && !reward.sound.isEmpty()) {
            for (ServerPlayer p : recipients) playSound(reward.sound, p);
        }
    }

    /**
     * Otorga recompensas al grupo/jugador que mató al boss.
     *
     * Flujo:
     * 1. Detecta al jugador más cercano al boss (el "killer")
     * 2. Obtiene su party via DungeonMaster si está disponible
     * 3. De los miembros de la party, filtra los que hicieron el % mínimo de daño
     * 4. Da recompensas solo a los que calificaron
     */
    public static void grantRewardsWithDamageFilter(RewardConfig reward,
            double bossX, double bossY, double bossZ, ServerLevel level,
            MinecraftServer server, String spawnPointName,
            com.bosspoints.data.SpawnPointDefinition def, int entityIdx,
            ServerPlayer actualKiller) {

        if (reward == null || !reward.hasRewards()) return;

        // 1. Usar el killer real (quien dio el golpe final)
        ServerPlayer killer = actualKiller;
        // Si no hay killer directo, usar el último en atacar al boss
        if (killer == null) {
            java.util.UUID lastUUID = DamageTracker.getLastAttacker(spawnPointName);
            if (lastUUID != null) killer = level.getServer().getPlayerList().getPlayer(lastUUID);
        }
        if (killer == null) return;

        // 2. Obtener party del killer (o solo él si no tiene party)
        List<ServerPlayer> partyMembers = getPartyMembers(killer, server);

        // 3. Filtrar por daño mínimo si está configurado
        List<ServerPlayer> qualified;
        if (reward.minDamagePercent > 0) {
            double totalHealth = DamageTracker.calcTotalHealth(def, entityIdx);
            List<java.util.UUID> qualifiedUUIDs = DamageTracker.getQualifiedPlayers(
                spawnPointName, totalHealth, reward.minDamagePercent);
            qualified = new ArrayList<>();
            for (ServerPlayer p : partyMembers) {
                if (qualifiedUUIDs.contains(p.getUUID())) qualified.add(p);
            }
            if (qualified.isEmpty()) {
                BossPointsMod.LOGGER.info("[SummonCore] Nadie en la party alcanzó el {}% de daño mínimo", reward.minDamagePercent);
                // Si nadie calificó, igual dar recompensa al killer
                qualified.add(killer);
            }
        } else {
            qualified = partyMembers;
        }

        BossPointsMod.LOGGER.info("[SummonCore] {} jugadores reciben recompensa de '{}'", qualified.size(), spawnPointName);

        // 4. Dar recompensas
        if (reward.perPlayer) {
            for (ServerPlayer p : qualified) grantBasicRewards(reward, p, server);
        } else {
            grantBasicRewards(reward, killer, server);
        }
        if (reward.lootTable != null && !reward.lootTable.isEmpty()) {
            if (reward.perPlayer) {
                for (ServerPlayer p : qualified) grantLootTable(reward.lootTable, p);
            } else {
                grantLootTable(reward.lootTable, killer);
            }
        }
        for (com.bosspoints.data.ItemRewardConfig ir : reward.items) {
            if (Math.random() > ir.probability) continue;
            if (ir.allPlayers) {
                for (ServerPlayer p : qualified) grantItem(ir, p);
            } else {
                grantItem(ir, qualified.get(new java.util.Random().nextInt(qualified.size())));
            }
        }
        if (reward.sound != null && !reward.sound.isEmpty()) {
            for (ServerPlayer p : qualified) playSound(reward.sound, p);
        }
    }

    /** Retorna los miembros de la party del jugador, o solo él si no tiene party */
    private static List<ServerPlayer> getPartyMembers(ServerPlayer player, MinecraftServer server) {
        try {
            if (net.minecraftforge.fml.ModList.get().isLoaded("dungeonmaster")) {
                Class<?> pmClass = Class.forName("com.dungeonmaster.manager.PartyManager");
                Object pm = pmClass.getMethod("getInstance").invoke(null);
                @SuppressWarnings("unchecked")
                List<java.util.UUID> members = (List<java.util.UUID>) pmClass
                    .getMethod("getGroupOrSolo", java.util.UUID.class).invoke(pm, player.getUUID());
                List<ServerPlayer> result = new ArrayList<>();
                for (java.util.UUID uid : members) {
                    ServerPlayer p = server.getPlayerList().getPlayer(uid);
                    if (p != null) result.add(p);
                }
                if (!result.isEmpty()) return result;
            }
        } catch (Exception e) {
            BossPointsMod.LOGGER.debug("[SummonCore] Party lookup: {}", e.getMessage());
        }
        return java.util.Collections.singletonList(player);
    }

    /** Entrega la recompensa especial de top daño */
    public static void grantTopDamageReward(com.bosspoints.data.ItemRewardConfig ir,
                                             ServerPlayer player, ServerLevel level) {
        grantItem(ir, player);
        BossPointsMod.LOGGER.info("[SummonCore] Recompensa top daño entregada a {}",
            player.getName().getString());
    }

    // ── DungeonMaster party integration ───────────────────────────────────────

    private static List<ServerPlayer> expandWithParty(List<ServerPlayer> nearby, MinecraftServer server) {
        if (!ModList.get().isLoaded("dungeonmaster")) return nearby;
        try {
            // Reflexión para no requerir DungeonMaster en compile time
            Class<?> pmClass = Class.forName("com.dungeonmaster.manager.PartyManager");
            Object pm = pmClass.getMethod("getInstance").invoke(null);
            Set<UUID> allUUIDs = new HashSet<>();
            for (ServerPlayer p : nearby) {
                @SuppressWarnings("unchecked")
                List<UUID> members = (List<UUID>) pmClass
                    .getMethod("getGroupOrSolo", UUID.class).invoke(pm, p.getUUID());
                allUUIDs.addAll(members);
            }
            List<ServerPlayer> result = new ArrayList<>();
            for (UUID uid : allUUIDs) {
                ServerPlayer p = server.getPlayerList().getPlayer(uid);
                if (p != null) result.add(p);
            }
            if (!result.isEmpty()) return result;
        } catch (Exception e) {
            BossPointsMod.LOGGER.debug("[SummonCore] DungeonMaster party lookup: {}", e.getMessage());
        }
        return nearby;
    }

    // ── Reward helpers ────────────────────────────────────────────────────────

    private static void grantBasicRewards(RewardConfig reward, ServerPlayer player, MinecraftServer server) {
        if (reward.experience > 0) player.giveExperiencePoints(reward.experience);
        if (!reward.rewardMessage.isEmpty()) {
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                reward.rewardMessage.replace("&", "§")));
        }
        for (String cmd : reward.commands) {
            String processed = cmd.replace("@p", player.getName().getString())
                                  .replace("@s", player.getName().getString());
            try { server.getCommands().performPrefixedCommand(server.createCommandSourceStack(), processed); }
            catch (Exception e) { BossPointsMod.LOGGER.warn("[SummonCore] Error ejecutando comando reward '{}': {}", cmd, e.getMessage()); }
        }
    }

    private static void grantItem(ItemRewardConfig ir, ServerPlayer player) {
        try {
            ResourceLocation rl = ResourceLocation.tryParse(ir.itemId);
            if (rl == null) return;
            var item = ForgeRegistries.ITEMS.getValue(rl);
            if (item == null) { BossPointsMod.LOGGER.warn("[SummonCore] Item reward no encontrado: {}", ir.itemId); return; }
            ItemStack stack = new ItemStack(item, Math.max(1, ir.count));
            if (ir.nbt != null && !ir.nbt.isEmpty()) {
                try { stack.setTag(net.minecraft.nbt.TagParser.parseTag(ir.nbt)); }
                catch (Exception e) { BossPointsMod.LOGGER.warn("[SummonCore] NBT inválido para {}: {}", ir.itemId, e.getMessage()); }
            }
            if (!player.getInventory().add(stack)) {
                ServerLevel l = (ServerLevel) player.level();
                l.addFreshEntity(new ItemEntity(l, player.getX(), player.getY(), player.getZ(), stack));
            }
            String name = (ir.displayName != null ? ir.displayName : ir.itemId).replace("&","§");
            String probStr = ir.probability < 1.0 ? " §8("+Math.round(ir.probability*100)+"%)" : "";
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                com.bosspoints.config.BossConfig.prefix() + " §aRecibiste: §e" + name + (ir.count>1?" ×"+ir.count:"") + probStr));
        } catch (Exception e) {
            BossPointsMod.LOGGER.error("[SummonCore] Error entregando item reward {}: {}", ir.itemId, e.getMessage());
        }
    }

    private static void grantLootTable(String lootTableId, ServerPlayer player) {
        try {
            ServerLevel level = (ServerLevel) player.level();
            ResourceLocation tableRL = ResourceLocation.tryParse(lootTableId);
            if (tableRL == null) return;
            LootTable table = level.getServer().getLootData().getLootTable(tableRL);
            if (table == LootTable.EMPTY) { BossPointsMod.LOGGER.warn("[SummonCore] Loot table no encontrada: {}", lootTableId); return; }
            LootParams params = new LootParams.Builder(level)
                .withParameter(LootContextParams.THIS_ENTITY, player)
                .withParameter(LootContextParams.ORIGIN, player.position())
                .create(LootContextParamSets.ENTITY);
            BlockPos pos = player.blockPosition();
            for (ItemStack stack : table.getRandomItems(params)) {
                if (!player.addItem(stack)) {
                    level.addFreshEntity(new ItemEntity(level, pos.getX()+.5, pos.getY()+.5, pos.getZ()+.5, stack));
                }
            }
        } catch (Exception e) {
            BossPointsMod.LOGGER.error("[SummonCore] Error con loot table '{}': {}", lootTableId, e.getMessage());
        }
    }

    private static void playSound(String soundId, ServerPlayer player) {
        try {
            SoundEvent sound = ForgeRegistries.SOUND_EVENTS.getValue(ResourceLocation.tryParse(soundId));
            if (sound != null) player.level().playSound(null, player.blockPosition(), sound, SoundSource.PLAYERS, 1f, 1f);
        } catch (Exception ignored) {}
    }

    private static ServerPlayer getClosest(List<ServerPlayer> players, double x, double y, double z) {
        return players.stream().min(Comparator.comparingDouble(p -> {
            double dx=p.getX()-x, dy=p.getY()-y, dz=p.getZ()-z;
            return dx*dx+dy*dy+dz*dz;
        })).orElse(players.get(0));
    }
}
