package com.bosspoints.manager;

import com.bosspoints.BossPointsMod;

import java.util.*;

/**
 * Rastrea el daño que cada jugador hace a los bosses trackeados.
 * Se limpia automáticamente al terminar la pelea.
 */
public class DamageTracker {

    // spawnPointName → (playerUUID → daño total acumulado)
    private static final Map<String, Map<UUID, Double>> damage = new HashMap<>();
    // Cache de nombres de jugadores para mostrar aunque se desconecten
    private static final Map<UUID, String> nameCache = new HashMap<>();

    /** Último jugador en atacar cada boss */
    private static final Map<String, UUID> lastAttacker = new HashMap<>();

    /** Registra daño de un jugador a un boss */
    public static void recordDamage(String spawnPointName, UUID playerUUID, double amount) {
        damage.computeIfAbsent(spawnPointName, k -> new HashMap<>())
              .merge(playerUUID, amount, Double::sum);
        lastAttacker.put(spawnPointName, playerUUID);
    }

    /** Retorna el último jugador en atacar al boss */
    public static UUID getLastAttacker(String spawnPointName) {
        return lastAttacker.get(spawnPointName);
    }

    /** Guarda el nombre del jugador en caché */
    public static void cachePlayerName(UUID uuid, String name) {
        nameCache.put(uuid, name);
    }

    /** Retorna el nombre del jugador, desde caché si se desconectó */
    public static String getPlayerName(UUID uuid, net.minecraft.server.MinecraftServer server) {
        net.minecraft.server.level.ServerPlayer p = server.getPlayerList().getPlayer(uuid);
        if (p != null) return p.getName().getString();
        return nameCache.getOrDefault(uuid, uuid.toString().substring(0, 8));
    }

    /** Retorna el mapa de daño de un spawn point (puede ser null) */
    public static Map<UUID, Double> getDamageMap(String spawnPointName) {
        return damage.getOrDefault(spawnPointName, Collections.emptyMap());
    }

    /**
     * Retorna los jugadores que superaron el umbral mínimo de daño.
     * @param spawnPointName nombre del spawn point
     * @param totalHealth    vida total del boss (suma de todas las transformaciones)
     * @param minPercent     porcentaje mínimo requerido (0-100)
     */
    public static List<UUID> getQualifiedPlayers(String spawnPointName,
                                                  double totalHealth, double minPercent) {
        Map<UUID, Double> map = getDamageMap(spawnPointName);
        if (map.isEmpty()) return Collections.emptyList();

        double threshold = totalHealth * (minPercent / 100.0);
        List<UUID> qualified = new ArrayList<>();
        for (Map.Entry<UUID, Double> entry : map.entrySet()) {
            if (entry.getValue() >= threshold) qualified.add(entry.getKey());
        }
        return qualified;
    }

    /**
     * Retorna el jugador con más daño hecho.
     */
    public static Map.Entry<UUID, Double> getTopDamage(String spawnPointName) {
        Map<UUID, Double> map = getDamageMap(spawnPointName);
        return map.entrySet().stream()
                  .max(Map.Entry.comparingByValue())
                  .orElse(null);
    }

    /** Calcula la vida total de la cadena de un boss (entidad base + todas las transformaciones) */
    public static double calcTotalHealth(com.bosspoints.data.SpawnPointDefinition def, int entityIdx) {
        if (def == null || entityIdx >= def.entities.size()) return 100.0;
        var entity = def.entities.get(entityIdx);
        double total = entity.attributes.getOrDefault("minecraft:generic.max_health", 20.0);
        for (var t : entity.transforms) {
            total += t.attributes.getOrDefault("minecraft:generic.max_health", 20.0);
        }
        return total;
    }

    /** Limpia el tracking de un spawn point al terminar la pelea */
    public static void clear(String spawnPointName) {
        damage.remove(spawnPointName);
        lastAttacker.remove(spawnPointName);
        // No limpiar nameCache — puede usarse entre peleas
        BossPointsMod.LOGGER.debug("[SummonCore] DamageTracker limpiado para: {}", spawnPointName);
    }
}
