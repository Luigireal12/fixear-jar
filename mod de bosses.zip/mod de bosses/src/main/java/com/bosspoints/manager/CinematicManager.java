package com.bosspoints.manager;

import com.bosspoints.BossPointsMod;
import com.bosspoints.data.CinematicKeyframe;
import com.bosspoints.network.NetworkHandler;
import com.bosspoints.network.PacketCinematicBars;
import com.bosspoints.network.PacketCinematicRestore;
import com.bosspoints.network.PacketStartCinematic;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;

import java.util.*;

public class CinematicManager {

    private static class SavedState {
        final GameType gameType;
        final double x, y, z;
        final float yaw, pitch;
        SavedState(ServerPlayer p) {
            gameType = p.gameMode.getGameModeForPlayer();
            x=p.getX(); y=p.getY(); z=p.getZ();
            yaw=p.getYRot(); pitch=p.getXRot();
        }
    }
    private static final Map<UUID, SavedState> savedStates = new HashMap<>();

    public static void startTakes(java.util.List<net.minecraft.server.level.ServerPlayer> players,
                                   java.util.List<com.bosspoints.data.CinematicTake> takes,
                                   double sx, double sy, double sz,
                                   int fadeStartTick, int fadeBlackDurationTicks, int fadeOutStartTick,
                                   int fadeInDurationTicks, int fadeOutDurationTicks) {
        for (net.minecraft.server.level.ServerPlayer player : players) {
            SavedState state = new SavedState(player);
            savedStates.put(player.getUUID(), state);
            player.setGameMode(net.minecraft.world.level.GameType.SPECTATOR);
            NetworkHandler.sendToPlayer(player, new com.bosspoints.network.PacketCinematicBars(true));
            NetworkHandler.sendToPlayer(player, new com.bosspoints.network.PacketStartCinematic(
                sx, sy, sz, takes, fadeStartTick, fadeBlackDurationTicks, fadeOutStartTick, fadeInDurationTicks, fadeOutDurationTicks));
        }
    }

    public static void start(List<ServerPlayer> players, ServerLevel level,
                             List<CinematicKeyframe> keyframes,
                             double spawnX, double spawnY, double spawnZ) {
        if (keyframes == null || keyframes.size() < 2) return;

        // Calcular posición absoluta del primer keyframe
        CinematicKeyframe first = keyframes.get(0);
        double firstX = spawnX + first.dx;
        double firstY = spawnY + first.dy;
        double firstZ = spawnZ + first.dz;

        for (ServerPlayer player : players) {
            savedStates.put(player.getUUID(), new SavedState(player));
            player.setGameMode(GameType.SPECTATOR);

            // Teletransportar al primer keyframe desde el servidor para evitar "moved too quickly"
            player.connection.teleport(firstX, firstY, firstZ, first.yaw, first.pitch);

            // Enviar datos de cinemática al cliente — el cliente corre la animación a 60fps
            com.bosspoints.data.CinematicTake legacyTake = new com.bosspoints.data.CinematicTake();
            legacyTake.keyframes = new java.util.ArrayList<>(keyframes);
            NetworkHandler.sendToPlayer(player, new com.bosspoints.network.PacketStartCinematic(spawnX, spawnY, spawnZ, java.util.List.of(legacyTake), -1, 10, -1, 10, 10));

            BossPointsMod.LOGGER.info("[SummonCore|Cinematic] START player:{} keyframes:{} spawn:({},{},{})",
                player.getName().getString(), keyframes.size(), spawnX, spawnY, spawnZ);
        }
    }

    /** Llamado cuando el cliente termina la cinemática */
    public static void onClientFinished(ServerPlayer player) {
        SavedState saved = savedStates.remove(player.getUUID());
        if (saved != null) {
            player.setGameMode(saved.gameType);
            player.connection.teleport(saved.x, saved.y, saved.z, saved.yaw, saved.pitch);
            // Enviar al cliente para que restaure perspectiva DESPUÉS de la teleportación
            NetworkHandler.sendToPlayer(player, new PacketCinematicRestore(
                saved.x, saved.y, saved.z, saved.yaw, saved.pitch, saved.gameType));
            BossPointsMod.LOGGER.info("[SummonCore|Cinematic] END player:{} restored to ({},{},{}) gamemode:{}",
                player.getName().getString(), saved.x, saved.y, saved.z, saved.gameType);
        }
    }

    /** Si el jugador se desconecta durante la cinemática */
    public static void stopForPlayer(UUID playerUUID, MinecraftServer server) {
        savedStates.remove(playerUUID);
    }

    public static void stopAll(MinecraftServer server) {
        for (UUID uuid : savedStates.keySet()) {
            ServerPlayer p = server.getPlayerList().getPlayer(uuid);
            if (p != null) p.setGameMode(GameType.SURVIVAL);
        }
        savedStates.clear();
    }

    // Suprimir correcciones de velocidad del servidor durante la cinemática
    public static void tick(MinecraftServer server) {
        for (UUID uuid : savedStates.keySet()) {
            ServerPlayer p = server.getPlayerList().getPlayer(uuid);
            if (p != null) {
                // Resetear el contador de movimiento para que el servidor no corrija la posición
                p.connection.resetPosition();
            }
        }
    }
}
