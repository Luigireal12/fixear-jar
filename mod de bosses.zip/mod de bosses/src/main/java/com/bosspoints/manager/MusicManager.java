package com.bosspoints.manager;

import com.bosspoints.BossPointsMod;
import com.bosspoints.data.MusicConfig;
import com.bosspoints.network.NetworkHandler;
import com.bosspoints.network.PacketPlayMusic;
import com.bosspoints.network.PacketStopMusic;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.Arrays;

/**
 * Gestiona la reproducción de música en el servidor.
 * Lee los .ogg de config/summoncore/sounds/ y los envía a los clientes.
 *
 * Estructura de carpeta:
 *   config/
 *     summoncore/
 *       sounds/
 *         boss_theme.ogg
 *         phase2.ogg
 *         ...
 *
 * En los comandos se referencia sin extensión: "boss_theme"
 */
public class MusicManager {

    private static final Path SOUNDS_DIR = FMLPaths.CONFIGDIR.get()
        .resolve("summoncore").resolve("sounds");

    /** musicId → lista de jugadores que lo están escuchando */
    private static final Map<String, Set<UUID>> listeners = new HashMap<>();

    /** Caché de audio server-side: nombre → bytes. Evita releer del disco en cada update */
    private static final Map<String, byte[]> audioCache = new HashMap<>();
    /** Última vez que se leyó cada archivo (para detectar cambios) */
    private static final Map<String, Long> cacheTimestamp = new HashMap<>();

    /** Música activa por área: musicId → config de área */
    private static final Map<String, AreaMusic> activeAreaMusic = new HashMap<>();

    private static class AreaMusic {
        final UUID entityUUID;
        final MusicConfig config;
        final String musicId;
        final String dimension;
        final Set<UUID> inRange = new HashSet<>();

        AreaMusic(UUID entityUUID, MusicConfig config, String musicId, String dimension) {
            this.entityUUID = entityUUID; this.config = config;
            this.musicId = musicId; this.dimension = dimension;
        }
    }

    // ── Init ──────────────────────────────────────────────────────────────────

    public static void init() {
        try {
            Files.createDirectories(SOUNDS_DIR);
            BossPointsMod.LOGGER.info("[SummonCore] Carpeta de música: {}", SOUNDS_DIR);
        } catch (IOException e) {
            BossPointsMod.LOGGER.error("[SummonCore] No se pudo crear carpeta de música: {}", e.getMessage());
        }
    }

    // ── Play ──────────────────────────────────────────────────────────────────

    /**
     * Envía la música a todos los jugadores en el radio alrededor de la posición dada.
     * @param musicId ID único para esta reproducción (ej: spawnPointName + "_spawn")
     */
    public static void playToNearby(ServerLevel level, double x, double y, double z,
                                    MusicConfig cfg, String musicId) {
        if (cfg == null) {
            BossPointsMod.LOGGER.warn("[SummonCore] playToNearby: MusicConfig es null para musicId={}", musicId);
            return;
        }
        if (!cfg.enabled || cfg.soundEvent.isEmpty()) {
            BossPointsMod.LOGGER.debug("[SummonCore] playToNearby: música desactivada o sin soundEvent para musicId={}", musicId);
            return;
        }

        BossPointsMod.LOGGER.info("[SummonCore] Intentando reproducir '{}' (musicId={})", cfg.soundEvent, musicId);

        byte[] audioData = loadSoundCached(cfg.soundEvent);
        if (audioData == null) return;

        List<ServerPlayer> targets = getPlayersInRadius(level, x, y, z, cfg.radius);
        BossPointsMod.LOGGER.info("[SummonCore] Jugadores en radio {}: {}", cfg.radius, targets.size());
        if (targets.isEmpty()) {
            BossPointsMod.LOGGER.warn("[SummonCore] Ningún jugador en radio {} de la posición {},{},{}", cfg.radius, (int)x, (int)y, (int)z);
            return;
        }

        // Dividir en chunks de 900KB para no superar el límite de Forge
        int chunkSize = PacketPlayMusic.CHUNK_SIZE;
        int totalChunks = (int) Math.ceil((double) audioData.length / chunkSize);

        Set<UUID> listenerSet = new HashSet<>();
        for (ServerPlayer player : targets) {
            for (int i = 0; i < totalChunks; i++) {
                int start = i * chunkSize;
                int end = Math.min(start + chunkSize, audioData.length);
                byte[] chunk = java.util.Arrays.copyOfRange(audioData, start, end);
                PacketPlayMusic packet = new PacketPlayMusic(
                    musicId, cfg.soundEvent, cfg.volume, cfg.pitch, true, i, totalChunks, chunk
                );
                NetworkHandler.sendToPlayer(player, packet);
            }
            listenerSet.add(player.getUUID());
        }
        listeners.put(musicId, listenerSet);

        BossPointsMod.LOGGER.debug("[SummonCore] Música '{}' enviada a {} jugadores.", cfg.soundEvent, targets.size());
    }

    // ── Stop ──────────────────────────────────────────────────────────────────

    public static void stop(String musicId, int fadeTicks, MinecraftServer server) {
        Set<UUID> listenerSet = listeners.remove(musicId);
        if (listenerSet == null) return;

        PacketStopMusic packet = new PacketStopMusic(musicId, fadeTicks);
        for (UUID uuid : listenerSet) {
            ServerPlayer player = server.getPlayerList().getPlayer(uuid);
            if (player != null) NetworkHandler.sendToPlayer(player, packet);
        }
    }

    public static void stopAll(int fadeTicks, MinecraftServer server) {
        for (String musicId : new HashSet<>(listeners.keySet())) {
            stop(musicId, fadeTicks, server);
        }
    }

    public static void stopForSpawnPoint(String spawnPointName, int fadeTicks, MinecraftServer server) {
        List<String> toStop = new ArrayList<>();
        for (String id : listeners.keySet()) {
            if (id.startsWith(spawnPointName + "_")) toStop.add(id);
        }
        for (String id : toStop) stop(id, fadeTicks, server);
    }

    // ── Area music tracking ───────────────────────────────────────────────────────

    public static void registerAreaMusic(UUID entityUUID, MusicConfig config, String musicId, String dimension) {
        if (!config.enabled || config.soundEvent.isEmpty()) return;
        activeAreaMusic.put(musicId, new AreaMusic(entityUUID, config, musicId, dimension));
    }

    public static void unregisterAreaMusic(String musicId, int fadeTicks, MinecraftServer server) {
        AreaMusic am = activeAreaMusic.remove(musicId);
        if (am == null) return;
        // Enviar stop a TODOS los jugadores online — el cliente ignora si no está reproduciendo ese ID
        PacketStopMusic packet = new PacketStopMusic(musicId, fadeTicks);
        for (net.minecraft.server.level.ServerPlayer p : server.getPlayerList().getPlayers()) {
            NetworkHandler.sendToPlayer(p, packet);
        }
        listeners.remove(musicId);
    }

    public static void unregisterAreaMusicForSpawnPoint(String spawnPointName, int fadeTicks, MinecraftServer server) {
        List<String> toRemove = new ArrayList<>();
        for (String id : activeAreaMusic.keySet()) {
            if (id.startsWith(spawnPointName + "_")) toRemove.add(id);
        }
        for (String id : toRemove) unregisterAreaMusic(id, fadeTicks, server);
    }

    /** Llamado cada 20 ticks — actualiza qué jugadores están en rango */
    public static void updateAreas(MinecraftServer server) {
        if (activeAreaMusic.isEmpty()) return;

        for (AreaMusic am : new ArrayList<>(activeAreaMusic.values())) {
            var dimKey = net.minecraft.resources.ResourceKey.create(
                net.minecraft.core.registries.Registries.DIMENSION,
                net.minecraft.resources.ResourceLocation.parse(am.dimension));
            net.minecraft.server.level.ServerLevel level = server.getLevel(dimKey);
            if (level == null) continue;

            net.minecraft.world.entity.Entity entity = level.getEntity(am.entityUUID);
            if (entity == null || !entity.isAlive()) continue;

            double ex = entity.getX(), ey = entity.getY(), ez = entity.getZ();
            float radius = am.config.radius;

            Set<UUID> nowInRange = new HashSet<>();
            for (net.minecraft.server.level.ServerPlayer player : level.players()) {
                double dx = player.getX()-ex, dy = player.getY()-ey, dz = player.getZ()-ez;
                if (Math.sqrt(dx*dx+dy*dy+dz*dz) <= radius) nowInRange.add(player.getUUID());
            }

            // Jugadores que entraron al rango → enviar música con fade in
            for (UUID uid : nowInRange) {
                if (!am.inRange.contains(uid)) {
                    net.minecraft.server.level.ServerPlayer player = server.getPlayerList().getPlayer(uid);
                    if (player == null) continue;
                    final byte[] audioData = loadSoundCached(am.config.soundEvent);
                    if (audioData == null) continue;
                    final net.minecraft.server.level.ServerPlayer fp = player;
                    final String mid = am.musicId;
                    final MusicConfig mcfg = am.config;
                    // Enviar en hilo separado para no bloquear el tick del servidor
                    Thread t = new Thread(() -> sendChunks(fp, mid, mcfg, audioData), "SummonCore-MusicSend");
                    t.setDaemon(true);
                    t.start();
                }
            }

            // Jugadores que salieron del rango → fade out
            for (UUID uid : new HashSet<>(am.inRange)) {
                if (!nowInRange.contains(uid)) {
                    net.minecraft.server.level.ServerPlayer player = server.getPlayerList().getPlayer(uid);
                    if (player != null) NetworkHandler.sendToPlayer(player, new PacketStopMusic(am.musicId, 60));
                }
            }

            am.inRange.clear();
            am.inRange.addAll(nowInRange);
        }
    }

    private static void sendChunks(net.minecraft.server.level.ServerPlayer player,
                                    String musicId, MusicConfig cfg, byte[] data) {
        try {
            int chunkSize = PacketPlayMusic.CHUNK_SIZE;
            int total = (int) Math.ceil((double) data.length / chunkSize);
            for (int i = 0; i < total; i++) {
                int start = i * chunkSize;
                int end = Math.min(start + chunkSize, data.length);
                byte[] chunk = java.util.Arrays.copyOfRange(data, start, end);
                NetworkHandler.sendToPlayer(player, new PacketPlayMusic(
                    musicId, cfg.soundEvent, cfg.volume, cfg.pitch, true, i, total, chunk));
                // Pequeña pausa entre chunks para no saturar el buffer de red
                if (total > 4) Thread.sleep(10);
            }
        } catch (Exception e) {
            BossPointsMod.LOGGER.warn("[SummonCore] Error enviando música a {}: {}", player.getName().getString(), e.getMessage());
        }
    }

    /** Quita al jugador del tracking de área cuando se desconecta */
    public static void onPlayerDisconnect(java.util.UUID playerId) {
        for (AreaMusic am : activeAreaMusic.values()) {
            am.inRange.remove(playerId);
        }
    }

    /** Limpia el caché de audio (útil al hacer /smc config reload) */
    public static void clearAudioCache() { audioCache.clear(); cacheTimestamp.clear(); }

    // ── List available sounds ─────────────────────────────────────────────────

    public static List<String> listSounds() {
        List<String> result = new ArrayList<>();
        try {
            if (Files.exists(SOUNDS_DIR)) {
                Files.list(SOUNDS_DIR)
                    .filter(p -> p.toString().endsWith(".ogg"))
                    .forEach(p -> result.add(p.getFileName().toString().replace(".ogg", "")));
            }
        } catch (IOException e) {
            BossPointsMod.LOGGER.error("[SummonCore] Error listando sonidos: {}", e.getMessage());
        }
        return result;
    }

    // ── Internal ──────────────────────────────────────────────────────────────

    /** Carga el audio con caché — recarga si el archivo cambió desde la última vez */
    private static byte[] loadSoundCached(String name) {
        try {
            java.io.File f = new java.io.File("config/summoncore/sounds/" + name + ".ogg");
            if (!f.exists()) { BossPointsMod.LOGGER.warn("[SummonCore] Archivo de música no encontrado: {}", f.getAbsolutePath()); return null; }
            long modified = f.lastModified();
            if (audioCache.containsKey(name) && cacheTimestamp.getOrDefault(name, 0L) == modified)
                return audioCache.get(name);
            byte[] data = java.nio.file.Files.readAllBytes(f.toPath());
            audioCache.put(name, data);
            cacheTimestamp.put(name, modified);
            BossPointsMod.LOGGER.info("[SummonCore] Audio cargado en caché: {} ({} KB)", name, data.length/1024);
            return data;
        } catch (Exception e) {
            BossPointsMod.LOGGER.error("[SummonCore] Error cargando audio '{}': {}", name, e.getMessage());
            return null;
        }
    }

    private static byte[] loadSound(String name) {
        // Soporta con o sin extensión
        String fileName = name.endsWith(".ogg") ? name : name + ".ogg";
        // Si tiene namespace (ej: "summoncore:boss"), tomar solo la parte del nombre
        if (fileName.contains(":")) fileName = fileName.split(":")[1] + ".ogg";

        Path file = SOUNDS_DIR.resolve(fileName);
        if (!Files.exists(file)) {
            BossPointsMod.LOGGER.warn("[SummonCore] Sonido no encontrado: {} (buscado en {})", fileName, SOUNDS_DIR);
            return null;
        }
        try {
            byte[] data = Files.readAllBytes(file);
            BossPointsMod.LOGGER.debug("[SummonCore] Sonido '{}' cargado ({} bytes).", fileName, data.length);
            return data;
        } catch (IOException e) {
            BossPointsMod.LOGGER.error("[SummonCore] Error leyendo sonido '{}': {}", fileName, e.getMessage());
            return null;
        }
    }

    private static List<ServerPlayer> getPlayersInRadius(ServerLevel level,
                                                          double x, double y, double z, float radius) {
        List<ServerPlayer> result = new ArrayList<>();
        for (ServerPlayer player : level.players()) {
            double dx = player.getX() - x, dy = player.getY() - y, dz = player.getZ() - z;
            if (Math.sqrt(dx*dx + dy*dy + dz*dz) <= radius) result.add(player);
        }
        return result;
    }
}
