package com.bosspoints.manager;

import com.bosspoints.data.BossBarConfig;
import com.bosspoints.data.EntitySpawnConfig;
import net.minecraft.core.registries.Registries;
import java.lang.reflect.Field;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import java.util.*;

public class BossBarManager {

    private static final Map<UUID, ManagedBar> bars = new HashMap<>();

    public static void createBar(LivingEntity entity, EntitySpawnConfig cfg, String spawnPointName, ServerLevel level) {
        BossBarConfig barCfg = cfg.bossBar;
        if (!barCfg.enabled) return;

        String title = barCfg.title.isEmpty() ? cfg.resolvedDisplayName() : barCfg.title;
        ServerBossEvent bar = new ServerBossEvent(
            Component.literal(title),
            barCfg.getColor(),
            barCfg.getOverlay()
        );
        bar.setProgress(entity.getHealth() / entity.getMaxHealth());
        // Suprimir bossbar nativo si el mob ya tiene uno (Wither, Ender Dragon, etc.)
        suppressNativeBossBar(entity);
        for (ServerPlayer p : level.players()) bar.addPlayer(p);

        bars.put(entity.getUUID(), new ManagedBar(bar, spawnPointName, level.dimension().location().toString()));
    }

    private static void suppressNativeBossBar(LivingEntity entity) {
        try {
            for (Field f : entity.getClass().getDeclaredFields()) {
                if (f.getType() == ServerBossEvent.class) {
                    f.setAccessible(true);
                    ServerBossEvent native_ = (ServerBossEvent) f.get(entity);
                    if (native_ != null) native_.setVisible(false);
                }
            }
        } catch (Exception ignored) {}
    }

    public static void update(MinecraftServer server) {
        Iterator<Map.Entry<UUID, ManagedBar>> iter = bars.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<UUID, ManagedBar> entry = iter.next();
            ManagedBar mb = entry.getValue();

            ResourceKey<net.minecraft.world.level.Level> dimKey = ResourceKey.create(
                Registries.DIMENSION, ResourceLocation.parse(mb.dimension));
            ServerLevel level = server.getLevel(dimKey);
            if (level == null) continue;

            Entity e = level.getEntity(entry.getKey());
            if (e == null) {
                // Chunk descargado: ocultar la barra temporalmente pero no borrarla
                mb.bar.removeAllPlayers();
                continue;
            }
            if (!e.isAlive()) {
                mb.bar.removeAllPlayers();
                iter.remove();
                continue;
            }
            if (e instanceof LivingEntity living)
                mb.bar.setProgress(Math.max(0f, living.getHealth() / living.getMaxHealth()));

            // Sync player list with current dimension players
            Set<ServerPlayer> current = new HashSet<>(level.players());
            new HashSet<>(mb.bar.getPlayers()).forEach(p -> { if (!current.contains(p)) mb.bar.removePlayer(p); });
            current.forEach(p -> { if (!mb.bar.getPlayers().contains(p)) mb.bar.addPlayer(p); });
        }
    }

    public static void remove(UUID uuid) {
        ManagedBar mb = bars.remove(uuid);
        if (mb != null) mb.bar.removeAllPlayers();
    }

    public static void removeForSpawnPoint(String spawnPointName) {
        bars.entrySet().removeIf(e -> {
            if (e.getValue().spawnPointName.equalsIgnoreCase(spawnPointName)) {
                e.getValue().bar.removeAllPlayers();
                return true;
            }
            return false;
        });
    }

    public static void removeAll() {
        bars.values().forEach(mb -> mb.bar.removeAllPlayers());
        bars.clear();
    }

    private static class ManagedBar {
        final ServerBossEvent bar;
        final String spawnPointName;
        final String dimension;
        ManagedBar(ServerBossEvent bar, String spawnPointName, String dimension) {
            this.bar = bar; this.spawnPointName = spawnPointName; this.dimension = dimension;
        }
    }
}
