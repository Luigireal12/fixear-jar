package com.bosspoints.manager;

import com.bosspoints.BossPointsMod;
import com.bosspoints.config.BossConfig;
import com.bosspoints.data.*;
import com.bosspoints.manager.BossRewardManager;
import com.bosspoints.data.TitleConfig;
import com.bosspoints.data.PotionEffectConfig;
import com.bosspoints.network.NetworkHandler;
import com.bosspoints.network.PacketFogColor;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.util.*;

public class SpawnManager {

    public static final String NBT_SPAWN_POINT = "bp_spawnPoint";
    public static final String NBT_ENTITY_IDX  = "bp_entityIdx";
    public static final String NBT_MAX_HEALTH  = "bp_maxHealth";
    public static final String NBT_PHASES_DONE = "bp_phasesDone";
    public static final String NBT_TRANSFORM_IDX = "bp_transformIdx"; // índice en la lista de transforms
    public static final String NBT_NO_LOOT = "bp_noLoot";

    public static final Map<UUID, TrackedEntity> tracked = new HashMap<>();
    public static final List<PendingTransform> pendingTransforms = new ArrayList<>();

    // ── Trigger spawn point ───────────────────────────────────────────────────

    public static String trigger(SpawnPointDefinition def, ServerLevel level, @Nullable ServerPlayer player) {
        if (def.entities.isEmpty()) return "§cEste spawn point no tiene entidades configuradas.";

        ResourceKey<net.minecraft.world.level.Level> dimKey = ResourceKey.create(
            Registries.DIMENSION, ResourceLocation.parse(def.dimension));
        ServerLevel targetLevel = level.getServer().getLevel(dimKey);
        if (targetLevel == null) return "§cDimensión no encontrada: " + def.dimension;

        def.lastTriggerTick = level.getServer().overworld().getGameTime();

        // Registrar como pendiente — spawneará cuando un jugador llegue al área
        pendingSpawns.put(def.name, new PendingSpawn(def, def.name, level.getServer().getTickCount()));
        startFightTimer(def.name, level.getServer());

        // Broadcast inmediato del trigger
        if (def.broadcastSpawn) {
            String playerName = player != null ? player.getName().getString() : "Server";
            String firstEntity = def.entities.isEmpty() ? "?" : def.entities.get(0).displayName;
            if (firstEntity.isEmpty()) firstEntity = def.entities.get(0).entityType;
            String msg = def.resolvedSpawnFormat()
                .replace("{player}", playerName)
                .replace("{entity}", firstEntity)
                .replace("{x}", String.valueOf((int) def.x))
                .replace("{y}", String.valueOf((int) def.y))
                .replace("{z}", String.valueOf((int) def.z))
                .replace("{spawnpoint}", def.name);
            broadcast(level.getServer(), msg);
        }

        return "§aSpawn point §e" + def.name + " §atriggerado. Spawneará cuando un jugador llegue al área.";
    }

    // ── Spawn single entity ───────────────────────────────────────────────────

    @Nullable
    private static String spawnEntity(EntitySpawnConfig cfg, ServerLevel level,
                                      double x, double y, double z,
                                      String spawnPointName, int idx,
                                      @Nullable ServerPlayer player) {
        ResourceLocation typeId = ResourceLocation.tryParse(cfg.entityType);
        if (typeId == null) { BossPointsMod.LOGGER.warn("[SummonCore] Tipo inválido: {}", cfg.entityType); return null; }

        EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(typeId);
        if (type == null) { BossPointsMod.LOGGER.warn("[SummonCore] Entidad no encontrada: {}", cfg.entityType); return null; }

        Entity entity = type.create(level);
        if (entity == null) return null;

        entity.setPos(x, y, z);

        if (entity instanceof LivingEntity living) {
            applyAttributes(living, cfg.attributes);

            if (living instanceof net.minecraft.world.entity.Mob mob)
                mob.finalizeSpawn(level, level.getCurrentDifficultyAt(BlockPos.containing(x, y, z)),
                    MobSpawnType.TRIGGERED, null, null);

            // Nombre custom
            if (living instanceof net.minecraft.world.entity.Mob mob) mob.setPersistenceRequired();
            if (!cfg.displayName.isEmpty()) {
                living.setCustomName(Component.literal(cfg.displayName));
                living.setCustomNameVisible(true);
            }

            double maxHp = living.getMaxHealth();
            CompoundTag pd = entity.getPersistentData();
            pd.putString(NBT_SPAWN_POINT, spawnPointName);
            pd.putInt(NBT_ENTITY_IDX, idx);
            pd.putDouble(NBT_MAX_HEALTH, maxHp);
            pd.putString(NBT_PHASES_DONE, "");
            pd.putInt(NBT_TRANSFORM_IDX, 0);
            pd.putBoolean(NBT_NO_LOOT, cfg.noLoot);

            level.addFreshEntity(entity);

            TrackedEntity te = new TrackedEntity(entity.getUUID(), spawnPointName, idx,
                level.dimension().location().toString(), maxHp);
            tracked.put(entity.getUUID(), te);

            BossBarManager.createBar(living, cfg, spawnPointName, level);

            // Música al spawnear (sistema de área)
            if (cfg.spawnMusic.enabled) {
                String musicId = spawnPointName + "_spawn_" + idx;
                MusicManager.registerAreaMusic(entity.getUUID(), cfg.spawnMusic, musicId,
                    level.dimension().location().toString());
            }
        } else {
            level.addFreshEntity(entity);
        }

        return cfg.resolvedDisplayName();
    }

    // ── Apply attributes ──────────────────────────────────────────────────────

    public static void applyAttributes(LivingEntity entity, Map<String, Double> attrs) {
        for (Map.Entry<String, Double> entry : attrs.entrySet()) {
            ResourceLocation attrId = ResourceLocation.tryParse(entry.getKey());
            if (attrId == null) continue;
            Attribute attr = ForgeRegistries.ATTRIBUTES.getValue(attrId);
            if (attr == null) { BossPointsMod.LOGGER.warn("[SummonCore] Atributo no encontrado: {}", entry.getKey()); continue; }
            AttributeInstance instance = entity.getAttribute(attr);
            if (instance == null) continue;
            instance.setBaseValue(entry.getValue());
            if (attr == Attributes.MAX_HEALTH) entity.setHealth((float) entry.getValue().doubleValue());
        }
    }

    // ── Phase checking (called every N ticks) ─────────────────────────────────

    public static void checkPhases(MinecraftServer server, SpawnPointSavedData data) {
        Iterator<Map.Entry<UUID, TrackedEntity>> iter = tracked.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<UUID, TrackedEntity> entry = iter.next();
            TrackedEntity te = entry.getValue();

            ResourceKey<net.minecraft.world.level.Level> dimKey = ResourceKey.create(
                Registries.DIMENSION, ResourceLocation.parse(te.dimension));
            ServerLevel level = server.getLevel(dimKey);
            if (level == null) continue;

            Entity rawEntity = level.getEntity(entry.getKey());
            if (rawEntity == null || !rawEntity.isAlive()) continue;
            if (!(rawEntity instanceof LivingEntity living)) continue;

            SpawnPointDefinition def = data.get(te.spawnPointName);
            if (def == null || te.entityConfigIdx >= def.entities.size()) continue;
            EntitySpawnConfig cfg = def.entities.get(te.entityConfigIdx);
            if (cfg.phases.isEmpty()) continue;

            double ratio = living.getHealth() / te.maxHealth;

            for (int i = 0; i < cfg.phases.size(); i++) {
                if (te.triggeredPhases.contains(i)) continue;
                PhaseConfig phase = cfg.phases.get(i);
                if (ratio <= phase.healthPercent) {
                    te.triggeredPhases.add(i);
                    CompoundTag pd = rawEntity.getPersistentData();
                    pd.putString(NBT_PHASES_DONE, setToString(te.triggeredPhases));
                    triggerPhase(phase, living, cfg, level, server);
                }
            }
        }
    }

    private static void triggerPhase(PhaseConfig phase, LivingEntity entity,
                                     EntitySpawnConfig cfg, ServerLevel level, MinecraftServer server) {
        // Aplicar cambios de atributos
        if (!phase.attributeChanges.isEmpty()) {
            applyAttributes(entity, phase.attributeChanges);
        }

        // Broadcast mensaje
        if (!phase.message.isEmpty()) {
            int percent = (int)(entity.getHealth() / entity.getMaxHealth() * 100);
            String msg = phase.message
                .replace("{entity}", cfg.resolvedDisplayName())
                .replace("{percent}", String.valueOf(percent))
                .replace("{health}", String.valueOf((int) entity.getHealth()))
                .replace("{maxhealth}", String.valueOf((int) entity.getMaxHealth()));
            broadcast(server, msg);
        }

        // Comandos
        for (String cmd : phase.commands) {
            try { server.getCommands().performPrefixedCommand(server.createCommandSourceStack(), cmd); }
            catch (Exception e) { BossPointsMod.LOGGER.warn("[SummonCore] Error en comando de fase '{}': {}", cmd, e.getMessage()); }
        }

        // Música de fase
        if (phase.music.enabled) {
            // Find spawnPointName from tracked entities
            String spawnPtName = tracked.entrySet().stream()
                .filter(e -> e.getKey().equals(entity.getUUID()))
                .map(e -> e.getValue().spawnPointName)
                .findFirst().orElse("");
            String musicId = spawnPtName + "_phase";
            MusicManager.stopForSpawnPoint(spawnPtName, 40, server);
            MusicManager.playToNearby(level, entity.getX(), entity.getY(), entity.getZ(),
                phase.music, musicId);
        }

        // Título de fase
        if (phase.titleConfig != null && phase.titleConfig.enabled)
            sendTitle(phase.titleConfig, level, entity.getX(), entity.getY(), entity.getZ());

        // Fog color de fase
        Vec3 epos = entity.position();
        if (phase.fogR >= 0)
            sendFogToNearby(level, epos.x, epos.y, epos.z, phase.fogR, phase.fogG, phase.fogB, phase.fogFadeTicks, phase.fogRadius, false);
        if (phase.skyR >= 0)
            sendFogToNearby(level, epos.x, epos.y, epos.z, phase.skyR, phase.skyG, phase.skyB, phase.skyFadeTicks, phase.fogRadius, true);

        // Efectos de poción de la fase
        for (PotionEffectConfig pec : phase.potionEffects) applyPotionEffect(entity, pec);

        Vec3 pos = entity.position();
        double groundY = findGroundBelow(level, pos.x, pos.y, pos.z);
        spawnPhaseParticles(level, pos.x, groundY + 1, pos.z);
    }

    private static void spawnPhaseParticles(ServerLevel level, double x, double y, double z) {
        level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 3, 0.5, 0.5, 0.5, 0.1);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 20, 1.0, 1.0, 1.0, 0.05);
        level.sendParticles(ParticleTypes.FLASH, x, y, z, 1, 0, 0, 0, 0);
    }

    /** Encuentra el suelo más cercano debajo de una posición */
    private static double findGroundBelow(ServerLevel level, double x, double y, double z) {
        net.minecraft.core.BlockPos pos = new net.minecraft.core.BlockPos((int)x, (int)y, (int)z);
        // Buscar hacia abajo hasta 64 bloques
        for (int i = 0; i < 64; i++) {
            net.minecraft.core.BlockPos below = pos.below(i);
            if (!level.getBlockState(below).isAir() && level.getBlockState(below.above()).isAir()) {
                return below.getY() + 1.0;
            }
        }
        return y; // Si no encuentra nada, dejar donde está
    }

    // ── Entity death ──────────────────────────────────────────────────────────

    public static void onEntityDeath(LivingEntity entity, MinecraftServer server, net.minecraft.server.level.ServerPlayer killer) {
        UUID uuid = entity.getUUID();
        TrackedEntity te = tracked.remove(uuid);
        BossBarManager.remove(uuid);
        if (te == null) return;
        MusicManager.unregisterAreaMusicForSpawnPoint(te.spawnPointName, 60, server);
        MusicManager.stopForSpawnPoint(te.spawnPointName, 60, server);
        com.bosspoints.manager.ParticleAuraManager.stopForEntity(entity);

        // Solo resetear fog si no hay más transformaciones pendientes
        SpawnPointSavedData dataFog = SpawnPointSavedData.get(server);
        SpawnPointDefinition defFog = dataFog.get(te.spawnPointName);
        boolean hasMoreTransforms = defFog != null
            && te.entityConfigIdx < defFog.entities.size()
            && entity.getPersistentData().getInt(NBT_TRANSFORM_IDX) < defFog.entities.get(te.entityConfigIdx).transforms.size();

        if (!hasMoreTransforms) {
            var dimKeyFog = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(te.dimension));
            ServerLevel fogLevel = server.getLevel(dimKeyFog);
            if (fogLevel != null) resetFogNearby(fogLevel, 0, 0, 0, 60, Float.MAX_VALUE);
            else NetworkHandler.sendToAll(server, new PacketFogColor(-1,-1,-1,60,false));
            NetworkHandler.sendToAll(server, new PacketFogColor(-1,-1,-1,60,true));

            // Victory title
            if (defFog != null && defFog.victoryTitleConfig != null && defFog.victoryTitleConfig.enabled) {
                var dimVt = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(te.dimension));
                ServerLevel vtLevel = server.getLevel(dimVt);
                if (vtLevel != null) sendTitle(defFog.victoryTitleConfig, vtLevel,
                    entity.getX(), entity.getY(), entity.getZ());
            }

            // Rewards con filtro de daño mínimo
            if (defFog != null && defFog.rewardConfig != null && defFog.rewardConfig.hasRewards()) {
                var dimRw = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(te.dimension));
                ServerLevel rwLevel = server.getLevel(dimRw);
                if (rwLevel != null) BossRewardManager.grantRewardsWithDamageFilter(
                    defFog.rewardConfig, entity.getX(), entity.getY(), entity.getZ(),
                    rwLevel, server, te.spawnPointName, defFog, te.entityConfigIdx, killer);
            }

            // Top daño — diferido 20 ticks (1 segundo) después del mensaje de derrota
            final MinecraftServer srv = server;
            final TrackedEntity finalTe = te;
            final SpawnPointDefinition finalDef = defFog;
            scheduleBroadcast((long) srv.getTickCount() + 20, () -> broadcastTopDamage(srv, finalTe, finalDef));

            // Mensaje global de derrota del boss
            broadcastDefeat(server, entity, te, defFog);

            clearFightTimer(te.spawnPointName);
            unregisterFogEffect(te.spawnPointName, server);
        }

        CompoundTag entityPd = entity.getPersistentData();
        int transformIdx = entityPd.getInt(NBT_TRANSFORM_IDX);

        SpawnPointSavedData data = SpawnPointSavedData.get(server);
        SpawnPointDefinition def = data.get(te.spawnPointName);
        if (def == null || te.entityConfigIdx >= def.entities.size()) return;

        EntitySpawnConfig cfg = def.entities.get(te.entityConfigIdx);
        // Sin más transformaciones en la cadena
        if (transformIdx >= cfg.transforms.size()) return;

        TransformConfig tc = cfg.transforms.get(transformIdx);

        // Broadcast de transformación (opcional)
        if (tc.broadcastMessage) {
            String entityName = cfg.resolvedDisplayName();
            String newEntityName = tc.displayName.isEmpty()
                ? (tc.entityType.contains(":") ? tc.entityType.split(":")[1].replace("_", " ") : tc.entityType)
                : tc.displayName;
            String msg = tc.message.isEmpty() ? BossConfig.DEFAULT_TRANSFORM_FORMAT.get().replace("&", "§").replace("{prefix}", BossConfig.prefix()).replace("&", "§").replace("{prefix}", BossConfig.prefix()) : tc.message;
            msg = msg.replace("{entity}", entityName).replace("{newentity}", newEntityName)
                     .replace("{x}", String.valueOf((int)entity.getX()))
                     .replace("{y}", String.valueOf((int)entity.getY()))
                     .replace("{z}", String.valueOf((int)entity.getZ()));
            broadcast(server, msg);
        }

        PendingTransform pt = new PendingTransform(
            entity.getX(), entity.getY(), entity.getZ(),
            te.dimension, cfg, tc, te.spawnPointName, te.entityConfigIdx, tc.delayTicks, transformIdx
        );
        pendingTransforms.add(pt);

        ResourceKey<net.minecraft.world.level.Level> dimKey = ResourceKey.create(
            Registries.DIMENSION, ResourceLocation.parse(te.dimension));
        ServerLevel level = server.getLevel(dimKey);
        if (level != null)
            playTransformPhase1(level, entity.getX(), entity.getY(), entity.getZ(), tc.cinematicStyle);
    }

    // ── Tick transforms ───────────────────────────────────────────────────────

    public static void tickTransforms(MinecraftServer server) {
        if (pendingTransforms.isEmpty()) return;
        Iterator<PendingTransform> iter = pendingTransforms.iterator();
        while (iter.hasNext()) {
            PendingTransform pt = iter.next();
            pt.countdown--;

            ResourceKey<net.minecraft.world.level.Level> dimKey = ResourceKey.create(
                Registries.DIMENSION, ResourceLocation.parse(pt.dimension));
            ServerLevel level = server.getLevel(dimKey);

            if (level != null) {
                int half = pt.totalDelay / 2, quarter = pt.totalDelay / 4;
                if (!pt.phase2Done && pt.countdown == half) {
                    pt.phase2Done = true;
                    playTransformPhase2(level, pt.x, pt.y, pt.z, pt.transformConfig.cinematicStyle);
                }
                // Spawn + música coinciden exactamente con las partículas de fase 3
                if (!pt.phase3Done && pt.countdown == quarter) {
                    pt.phase3Done = true;
                    playTransformPhase3(level, pt.x, pt.y, pt.z, pt.transformConfig.cinematicStyle);
                    iter.remove();
                    finishTransformation(pt, level);
                    continue;
                }
            }

            // Fallback: si el delay es muy corto y quarter ya pasó
            if (pt.countdown <= 0 && !pt.phase3Done) {
                iter.remove();
                if (level != null) finishTransformation(pt, level);
            }
        }
    }

    private static void finishTransformation(PendingTransform pt, ServerLevel level) {
        TransformConfig tc = pt.transformConfig;
        ResourceLocation typeId = ResourceLocation.tryParse(tc.entityType);
        if (typeId == null) return;
        EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(typeId);
        if (type == null) { BossPointsMod.LOGGER.warn("[SummonCore] Transform: entidad no encontrada: {}", tc.entityType); return; }

        Entity entity = type.create(level);
        if (entity == null) return;
        entity.setPos(pt.x, pt.y + 0.1, pt.z);

        if (entity instanceof LivingEntity living) {
            if (living instanceof net.minecraft.world.entity.Mob mob)
                mob.finalizeSpawn(level, level.getCurrentDifficultyAt(BlockPos.containing(pt.x, pt.y, pt.z)),
                    MobSpawnType.TRIGGERED, null, null);

            // Aplicar atributos de la transformación
            if (!tc.attributes.isEmpty()) applyAttributes(living, tc.attributes);

            // Nombre custom de la transformación
            if (!tc.displayName.isEmpty()) {
                living.setCustomName(Component.literal(tc.displayName));
                living.setCustomNameVisible(true);
            }

            double maxHp = living.getMaxHealth();
            CompoundTag pd = entity.getPersistentData();
            pd.putString(NBT_SPAWN_POINT, pt.spawnPointName);
            pd.putInt(NBT_ENTITY_IDX, pt.entityConfigIdx);
            pd.putDouble(NBT_MAX_HEALTH, maxHp);
            pd.putString(NBT_PHASES_DONE, "");
            pd.putInt(NBT_TRANSFORM_IDX, pt.transformIdx + 1); // siguiente en la cadena
            pd.putBoolean(NBT_NO_LOOT, tc.noLoot);

            // Evitar despawn por distancia
            if (entity instanceof net.minecraft.world.entity.Mob mob) mob.setPersistenceRequired();

            // Snap al suelo más cercano antes de iniciar cinemática
            if (!tc.cinematicKeyframes.isEmpty() && tc.cinematicKeyframes.size() >= 2) {
                double groundY = findGroundBelow(level, entity.getX(), entity.getY(), entity.getZ());
                if (groundY != entity.getY()) {
                    entity.teleportTo(entity.getX(), groundY, entity.getZ());
                }
            }

            // Iniciar auras de partículas — snap al suelo igual que la cinemática
            if (!tc.particleAura.entries.isEmpty()) {
                double groundY = findGroundBelow(level, entity.getX(), entity.getY(), entity.getZ());
                if (groundY != entity.getY()) entity.teleportTo(entity.getX(), groundY, entity.getZ());
                com.bosspoints.manager.ParticleAuraManager.startAuras(entity, tc.particleAura);
            }

            // Enviar títulos custom de la transformación
            if (!tc.customTitles.entries.isEmpty()) {
                for (net.minecraft.server.level.ServerPlayer p : level.players()) {
                    double cdx = p.getX()-entity.getX(), cdz = p.getZ()-entity.getZ();
                    if (Math.sqrt(cdx*cdx+cdz*cdz) <= tc.cinematicRadius)
                        com.bosspoints.network.NetworkHandler.sendToPlayer(p,
                            new com.bosspoints.network.PacketPlayCustomTitle(tc.customTitles.entries));
                }
            }

            // Iniciar cinemática — usar takes si existen, sino keyframes legacy
            java.util.List<com.bosspoints.data.CinematicTake> takes = tc.cinematicTakes;
            if ((takes == null || takes.isEmpty()) && tc.cinematicKeyframes.size() >= 2) {
                com.bosspoints.data.CinematicTake legacyTake = new com.bosspoints.data.CinematicTake();
                legacyTake.keyframes = tc.cinematicKeyframes;
                takes = java.util.List.of(legacyTake);
            }
            if (takes != null && !takes.isEmpty()) {
                List<net.minecraft.server.level.ServerPlayer> nearbyPlayers = new java.util.ArrayList<>();
                double spawnX = entity.getX(), spawnY = entity.getY(), spawnZ = entity.getZ();
                for (net.minecraft.server.level.ServerPlayer p : level.players()) {
                    double cdx = p.getX()-spawnX, cdz = p.getZ()-spawnZ;
                    if (Math.sqrt(cdx*cdx+cdz*cdz) <= tc.cinematicRadius) nearbyPlayers.add(p);
                }
                if (!nearbyPlayers.isEmpty())
                    com.bosspoints.manager.CinematicManager.startTakes(nearbyPlayers, takes, spawnX, spawnY, spawnZ,
                        tc.fadeStartTick, tc.fadeBlackDurationTicks, tc.fadeOutStartTick,
                        tc.fadeInDurationTicks, tc.fadeOutDurationTicks);
            }

            // Invulnerabilidad inicial
            if (tc.invulnerabilityTicks > 0) {
                entity.setInvulnerable(true);
                if (entity instanceof net.minecraft.world.entity.Mob mob) mob.setNoAi(true);
                final net.minecraft.world.entity.Entity finalEntity = entity;
                final int invulTicks = tc.invulnerabilityTicks;
                scheduleBroadcast((long) level.getServer().getTickCount() + invulTicks, () -> {
                    if (finalEntity.isAlive()) {
                        finalEntity.setInvulnerable(false);
                        if (finalEntity instanceof net.minecraft.world.entity.Mob mob) mob.setNoAi(false);
                    }
                });
            }

            level.addFreshEntity(entity);

            TrackedEntity te = new TrackedEntity(entity.getUUID(), pt.spawnPointName,
                pt.entityConfigIdx, level.dimension().location().toString(), maxHp);
            tracked.put(entity.getUUID(), te);

            // Efectos de poción de la transformación
            for (PotionEffectConfig pec : tc.potionEffects) applyPotionEffect(living, pec);

            // Título de transformación
            if (tc.titleConfig != null && tc.titleConfig.enabled)
                sendTitle(tc.titleConfig, level, pt.x, pt.y, pt.z);

            // Registrar fog/sky de transformación con tracking de área
            if (tc.fogR >= 0 || tc.skyR >= 0) {
                registerFogEffect(entity.getUUID(), pt.spawnPointName,
                    level.dimension().location().toString(),
                    tc.fogR, tc.fogG, tc.fogB, tc.fogFadeTicks,
                    tc.skyR, tc.skyG, tc.skyB, tc.skyFadeTicks,
                    tc.fogRadius);
            }

            // Música de spawn de la transformación
            BossPointsMod.LOGGER.info("[SummonCore] finishTransformation: spawnMusic enabled={}, soundEvent='{}'",
                tc.spawnMusic != null && tc.spawnMusic.enabled,
                tc.spawnMusic != null ? tc.spawnMusic.soundEvent : "null");
            if (tc.spawnMusic != null && tc.spawnMusic.enabled) {
                String musicId = pt.spawnPointName + "_transform_" + pt.transformIdx;
                MusicManager.stopForSpawnPoint(pt.spawnPointName, 40, level.getServer());
                MusicManager.registerAreaMusic(entity.getUUID(), tc.spawnMusic, musicId,
                    level.dimension().location().toString());
            }

            // BossBar: usa la config de la transformación si tiene una activa, sino la del entity original
            if (tc.bossBar.enabled) {
                // Crear wrapper EntitySpawnConfig temporal con el bossBar de la transformación
                com.bosspoints.data.EntitySpawnConfig tempCfg = new com.bosspoints.data.EntitySpawnConfig();
                tempCfg.bossBar = tc.bossBar;
                tempCfg.displayName = tc.displayName.isEmpty() ? pt.entityConfig.resolvedDisplayName() : tc.displayName;
                BossBarManager.createBar(living, tempCfg, pt.spawnPointName, level);
            } else if (pt.entityConfig.bossBar.enabled) {
                BossBarManager.createBar(living, pt.entityConfig, pt.spawnPointName, level);
            }

            double ptGroundY = findGroundBelow(level, pt.x, pt.y, pt.z);
            level.sendParticles(ParticleTypes.PORTAL, pt.x, ptGroundY + 1, pt.z, 80, 1.0, 1.5, 1.0, 0.3);
            level.sendParticles(ParticleTypes.END_ROD, pt.x, ptGroundY + 1, pt.z, 30, 1.0, 1.5, 1.0, 0.15);
        } else {
            level.addFreshEntity(entity);
        }
    }

    // ── Kill all entities from a spawn point ──────────────────────────────────

    public static int killSpawnPoint(String spawnPointName, MinecraftServer server) {
        int killed = 0;
        List<UUID> toKill = new ArrayList<>();
        for (Map.Entry<UUID, TrackedEntity> entry : tracked.entrySet())
            if (entry.getValue().spawnPointName.equalsIgnoreCase(spawnPointName))
                toKill.add(entry.getKey());

        for (UUID uuid : toKill) {
            TrackedEntity te = tracked.remove(uuid);
            BossBarManager.remove(uuid);
            if (te == null) continue;
            ResourceKey<net.minecraft.world.level.Level> dimKey = ResourceKey.create(
                Registries.DIMENSION, ResourceLocation.parse(te.dimension));
            ServerLevel level = server.getLevel(dimKey);
            if (level == null) continue;
            Entity e = level.getEntity(uuid);
            if (e != null && e.isAlive()) { e.discard(); killed++; }
        }

        // Cancelar transformaciones pendientes
        pendingTransforms.removeIf(pt -> pt.spawnPointName.equalsIgnoreCase(spawnPointName));
        BossBarManager.removeForSpawnPoint(spawnPointName);
        MusicManager.unregisterAreaMusicForSpawnPoint(spawnPointName, 0, server);
        MusicManager.stopForSpawnPoint(spawnPointName, 0, server);
        clearFightTimer(spawnPointName);
        unregisterFogEffect(spawnPointName, server);
        DamageTracker.clear(spawnPointName);
        // Reset fog para todos (kill es un comando manual)
        NetworkHandler.sendToAll(server, new PacketFogColor(-1,-1,-1,40,false));
        NetworkHandler.sendToAll(server, new PacketFogColor(-1,-1,-1,40,true));
        return killed;
    }

    // ── Restore tracking on entity load ──────────────────────────────────────

    public static void onEntityJoinWorld(Entity entity, ServerLevel level) {
        if (!(entity instanceof LivingEntity)) return;
        CompoundTag pd = entity.getPersistentData();
        if (!pd.contains(NBT_SPAWN_POINT)) return;

        String spawnPoint = pd.getString(NBT_SPAWN_POINT);
        int entityIdx = pd.getInt(NBT_ENTITY_IDX);
        double maxHp = pd.getDouble(NBT_MAX_HEALTH);
        Set<Integer> phases = stringToSet(pd.getString(NBT_PHASES_DONE));

        TrackedEntity te = new TrackedEntity(entity.getUUID(), spawnPoint, entityIdx,
            level.dimension().location().toString(), maxHp);
        te.triggeredPhases.addAll(phases);
        tracked.put(entity.getUUID(), te);
    }

    // ── Cinematic ─────────────────────────────────────────────────────────────

    private static void playTransformPhase1(ServerLevel l, double x, double y, double z, String style) {
        switch (style) {
            case "portal" -> { l.sendParticles(ParticleTypes.PORTAL, x, y+1, z, 60, 1.0, 1.5, 1.0, 0.3); l.sendParticles(ParticleTypes.LARGE_SMOKE, x, y+1, z, 15, 0.5, 1.0, 0.5, 0.05); }
            case "smoke"  -> { l.sendParticles(ParticleTypes.LARGE_SMOKE, x, y+1, z, 40, 1.5, 1.5, 1.5, 0.05); }
            case "ender"  -> { l.sendParticles(ParticleTypes.DRAGON_BREATH, x, y+1, z, 40, 1.0, 1.5, 1.0, 0.1); }
            default       -> { l.sendParticles(ParticleTypes.EXPLOSION, x, y+1, z, 5, 0.5, 0.5, 0.5, 0.2); l.sendParticles(ParticleTypes.LARGE_SMOKE, x, y+1, z, 20, 1.0, 1.0, 1.0, 0.05); }
        }
    }

    private static void playTransformPhase2(ServerLevel l, double x, double y, double z, String style) {
        switch (style) {
            case "portal" -> { l.sendParticles(ParticleTypes.PORTAL, x, y+1, z, 80, 1.5, 2.0, 1.5, 0.4); l.sendParticles(ParticleTypes.FLASH, x, y+1, z, 2, 0, 0, 0, 0); }
            case "smoke"  -> l.sendParticles(ParticleTypes.LARGE_SMOKE, x, y+1, z, 60, 2.0, 2.0, 2.0, 0.08);
            case "ender"  -> { l.sendParticles(ParticleTypes.DRAGON_BREATH, x, y+1, z, 60, 1.5, 2.0, 1.5, 0.15); l.sendParticles(ParticleTypes.FLASH, x, y+1, z, 1, 0, 0, 0, 0); }
            default       -> { l.sendParticles(ParticleTypes.EXPLOSION, x, y+1, z, 8, 1.0, 1.0, 1.0, 0.3); l.sendParticles(ParticleTypes.FLASH, x, y+2, z, 2, 0, 0, 0, 0); }
        }
    }

    private static void playTransformPhase3(ServerLevel l, double x, double y, double z, String style) {
        spawnLightning(l, x, y, z);
        switch (style) {
            case "portal" -> l.sendParticles(ParticleTypes.PORTAL, x, y+1, z, 100, 2.0, 2.5, 2.0, 0.5);
            case "ender"  -> { l.sendParticles(ParticleTypes.DRAGON_BREATH, x, y+1, z, 80, 2.0, 2.5, 2.0, 0.2); spawnLightning(l, x+2, y, z+2); spawnLightning(l, x-2, y, z-2); }
            default       -> { l.sendParticles(ParticleTypes.EXPLOSION, x, y+1, z, 12, 1.5, 1.0, 1.5, 0.4); spawnLightning(l, x+1.5, y, z+1.5); spawnLightning(l, x-1.5, y, z-1.5); }
        }
    }

    private static void spawnLightning(ServerLevel level, double x, double y, double z) {
        net.minecraft.world.entity.LightningBolt bolt = net.minecraft.world.entity.EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) { bolt.setPos(x, y, z); bolt.setVisualOnly(true); level.addFreshEntity(bolt); }
    }

    // ── Title ────────────────────────────────────────────────────────────────────

    private static void sendTitle(TitleConfig tc, ServerLevel level, double x, double y, double z) {
        if (!tc.enabled || tc.title.isEmpty()) return;
        ClientboundSetTitlesAnimationPacket timings = new ClientboundSetTitlesAnimationPacket(tc.fadeIn, tc.stay, tc.fadeOut);
        ClientboundSetTitleTextPacket title = new ClientboundSetTitleTextPacket(Component.literal(tc.title));
        ClientboundSetSubtitleTextPacket subtitle = tc.subtitle.isEmpty() ? null
            : new ClientboundSetSubtitleTextPacket(Component.literal(tc.subtitle));
        for (net.minecraft.server.level.ServerPlayer player : level.players()) {
            double dx = player.getX()-x, dy = player.getY()-y, dz = player.getZ()-z;
            if (Math.sqrt(dx*dx+dy*dy+dz*dz) <= tc.radius) {
                player.connection.send(timings);
                player.connection.send(title);
                if (subtitle != null) player.connection.send(subtitle);
            }
        }
    }

    // ── Fog color ─────────────────────────────────────────────────────────────

    private static void sendFogToNearby(ServerLevel level, double x, double y, double z,
                                        float r, float g, float b, int fadeTicks, float radius, boolean isSky) {
        PacketFogColor packet = new PacketFogColor(r, g, b, fadeTicks, isSky);
        for (net.minecraft.server.level.ServerPlayer player : level.players()) {
            double dx = player.getX() - x, dy = player.getY() - y, dz = player.getZ() - z;
            if (Math.sqrt(dx*dx + dy*dy + dz*dz) <= radius)
                NetworkHandler.sendToPlayer(player, packet);
        }
    }

    private static void resetFogNearby(ServerLevel level, double x, double y, double z,
                                       int fadeTicks, float radius) {
        PacketFogColor fogReset = new PacketFogColor(-1, -1, -1, fadeTicks, false);
        PacketFogColor skyReset = new PacketFogColor(-1, -1, -1, fadeTicks, true);
        for (net.minecraft.server.level.ServerPlayer player : level.players()) {
            double dx = player.getX() - x, dy = player.getY() - y, dz = player.getZ() - z;
            if (Math.sqrt(dx*dx + dy*dy + dz*dz) <= radius) {
                NetworkHandler.sendToPlayer(player, fogReset);
                NetworkHandler.sendToPlayer(player, skyReset);
            }
        }
    }

    // ── Util ──────────────────────────────────────────────────────────────────

    private static void applyPotionEffect(LivingEntity entity, PotionEffectConfig pec) {
        net.minecraft.resources.ResourceLocation effectId = net.minecraft.resources.ResourceLocation.tryParse(pec.effectId);
        if (effectId == null) return;
        MobEffect effect = net.minecraftforge.registries.ForgeRegistries.MOB_EFFECTS.getValue(effectId);
        if (effect == null) { BossPointsMod.LOGGER.warn("[SummonCore] Efecto no encontrado: {}", pec.effectId); return; }
        entity.addEffect(new MobEffectInstance(effect, pec.getDurationTicks(), pec.amplifier, pec.ambient, pec.visible));
    }

    private static void broadcastTopDamage(MinecraftServer server,
                                              TrackedEntity te,
                                              SpawnPointDefinition def) {
        if (def == null || def.rewardConfig == null) return;
        com.bosspoints.data.RewardConfig rc = def.rewardConfig;
        double totalHealth = DamageTracker.calcTotalHealth(def, te.entityConfigIdx);

        // Obtener top 5 ordenado por daño
        Map<java.util.UUID, Double> damageMap = DamageTracker.getDamageMap(te.spawnPointName);
        if (damageMap.isEmpty()) return;

        List<Map.Entry<java.util.UUID, Double>> sorted = new ArrayList<>(damageMap.entrySet());
        sorted.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        // Mensaje header
        broadcast(server, com.bosspoints.config.BossConfig.prefix() + " §e§lTop Daño — §7" + te.spawnPointName);

        int shown = Math.min(5, sorted.size());
        String[] defaultMedals = {"§6①", "§7②", "§7③", "§7④", "§7⑤"};
        String[] medals = (def.topDamageMedals != null && def.topDamageMedals.length >= 5)
            ? def.topDamageMedals : defaultMedals;
        for (int i = 0; i < shown; i++) {
            Map.Entry<java.util.UUID, Double> entry = sorted.get(i);
            String name = DamageTracker.getPlayerName(entry.getKey(), server);
            double cappedDmg = Math.min(entry.getValue(), totalHealth);
            double percent = Math.min(100.0, (cappedDmg / totalHealth) * 100.0);
            String line = com.bosspoints.config.BossConfig.topDamageLineFormat()
                    .replace("{medal}", medals[i])
                    .replace("{name}", name)
                    .replace("{damage}", String.valueOf(Math.round(cappedDmg)))
                    .replace("{percent}", String.format("%.1f", percent));
            broadcast(server, line);
        }

        // Recompensas especiales del top — van al primer top conectado
        if (!sorted.isEmpty() && !rc.topDamageRewards.isEmpty()) {
            var dimKey = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(te.dimension));
            ServerLevel level = server.getLevel(dimKey);
            if (level != null) {
                for (Map.Entry<java.util.UUID, Double> entry : sorted) {
                    net.minecraft.server.level.ServerPlayer candidate = server.getPlayerList().getPlayer(entry.getKey());
                    if (candidate != null) {
                        for (com.bosspoints.data.ItemRewardConfig ir : rc.topDamageRewards) {
                            if (Math.random() <= ir.probability)
                                BossRewardManager.grantTopDamageReward(ir, candidate, level);
                        }
                        break;
                    }
                }
            }
        }

        // Mensaje con template configurable para el top 1
        if (!sorted.isEmpty() && rc.topDamageMessage != null && !rc.topDamageMessage.isEmpty()) {
            Map.Entry<java.util.UUID, Double> top = sorted.get(0);
            net.minecraft.server.level.ServerPlayer topPlayer = server.getPlayerList().getPlayer(top.getKey());
            if (topPlayer != null) {
                double percent = Math.min(100.0, (top.getValue() / totalHealth) * 100.0);
                String msg = rc.topDamageMessage
                    .replace("{player}", topPlayer.getName().getString())
                    .replace("{damage}", String.valueOf(Math.round(top.getValue())))
                    .replace("{percent}", String.format("%.1f", percent))
                    .replace("{spawnpoint}", te.spawnPointName)
                    .replace("&", "§");
                broadcast(server, msg);
            }
        }
        // Limpiar datos de daño DESPUÉS de usarlos
        DamageTracker.clear(te.spawnPointName);
    }

    private static void broadcastDefeat(MinecraftServer server,
                                          net.minecraft.world.entity.LivingEntity entity,
                                          SpawnManager.TrackedEntity te,
                                          SpawnPointDefinition def) {
        // Nombre del boss (última transformación que murió)
        // Obtener nombre del boss desde la config
        SpawnPointSavedData bossData = SpawnPointSavedData.get(server);
        SpawnPointDefinition bossDefLookup = bossData.get(te.spawnPointName);
        String bossName = entity.getType().getDescription().getString();
        if (bossDefLookup != null && te.entityConfigIdx < bossDefLookup.entities.size()) {
            String dn = bossDefLookup.entities.get(te.entityConfigIdx).displayName;
            if (dn != null && !dn.isEmpty()) bossName = dn;
        }

        // Líder de la party o jugador más cercano
        String killerName = getDefeatLeader(server, entity, te);

        String template = (def != null && def.defeatMessage != null && !def.defeatMessage.isEmpty())
            ? def.defeatMessage
            : com.bosspoints.config.BossConfig.prefix() + " §e{killer} §7derrotó a §c{boss}§7!";
        String msg = template
            .replace("{boss}", bossName)
            .replace("{killer}", killerName)
            .replace("{spawnpoint}", te.spawnPointName)
            .replace("&", "§");
        broadcast(server, msg);
    }

    private static String getDefeatLeader(MinecraftServer server,
                                          net.minecraft.world.entity.LivingEntity entity,
                                          SpawnManager.TrackedEntity te) {
        // Intentar obtener el líder de party de DungeonMaster
        if (net.minecraftforge.fml.ModList.get().isLoaded("dungeonmaster")) {
            try {
                // Buscar jugadores cercanos y su party
                ServerLevel level = server.getLevel(
                    ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(te.dimension)));
                if (level != null) {
                    net.minecraft.server.level.ServerPlayer closest = null;
                    double minDist = Double.MAX_VALUE;
                    for (net.minecraft.server.level.ServerPlayer p : level.players()) {
                        double d = p.distanceToSqr(entity);
                        if (d < minDist) { minDist = d; closest = p; }
                    }
                    if (closest != null) {
                        try {
                            Class<?> pmClass = Class.forName("com.dungeonmaster.manager.PartyManager");
                            Object pm = pmClass.getMethod("getInstance").invoke(null);
                            Object party = pmClass.getMethod("getPartyOf", java.util.UUID.class)
                                .invoke(pm, closest.getUUID());
                            if (party != null) {
                                java.util.UUID leaderId = (java.util.UUID) party.getClass()
                                    .getMethod("getLeaderId").invoke(party);
                                int size = (int) party.getClass().getMethod("size").invoke(party);
                                net.minecraft.server.level.ServerPlayer leader =
                                    server.getPlayerList().getPlayer(leaderId);
                                if (leader != null) {
                                    return size > 1
                                        ? "§bEl grupo de §e" + leader.getName().getString()
                                        : "§e" + leader.getName().getString();
                                }
                            }
                        } catch (Exception ignored) {}
                        return "§e" + closest.getName().getString();
                    }
                }
            } catch (Exception e) {
                BossPointsMod.LOGGER.warn("[SummonCore] Error obteniendo party leader: {}", e.getMessage());
            }
        }

        // Sin DungeonMaster — buscar jugador más cercano
        ServerLevel level = server.getLevel(
            ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(te.dimension)));
        if (level != null) {
            net.minecraft.server.level.ServerPlayer closest = null;
            double minDist = Double.MAX_VALUE;
            for (net.minecraft.server.level.ServerPlayer p : level.players()) {
                double d = p.distanceToSqr(entity);
                if (d < minDist) { minDist = d; closest = p; }
            }
            if (closest != null) return "§e" + closest.getName().getString();
        }
        return "§eun jugador";
    }

    /** Retorna el TrackedEntity de una entidad si está siendo trackeada como boss */
    public static TrackedEntity getTracked(java.util.UUID entityUUID) {
        return tracked.get(entityUUID);
    }


    // ── Pending spawns (esperando que un jugador cargue el chunk) ───────────────

    private static class PendingSpawn {
        final SpawnPointDefinition def;
        final String spawnPointName;
        final long triggeredAt; // game tick cuando se triggereo
        PendingSpawn(SpawnPointDefinition def, String name, long tick) {
            this.def = def; this.spawnPointName = name; this.triggeredAt = tick;
        }
    }

    private static final Map<String, PendingSpawn> pendingSpawns = new HashMap<>();

    public static void checkPendingSpawns(MinecraftServer server) {
        for (Map.Entry<String, PendingSpawn> entry : new HashMap<>(pendingSpawns).entrySet()) {
            PendingSpawn ps = entry.getValue();
            SpawnPointDefinition def = ps.def;

            // Verificar si ya está siendo trackeado (ya spawneó)
            if (isActiveSpawnPoint(ps.spawnPointName)) {
                pendingSpawns.remove(entry.getKey());
                continue;
            }

            var dimKey = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(def.dimension));
            ServerLevel level = server.getLevel(dimKey);
            if (level == null) continue;

            // Verificar si algún jugador está cerca (chunk cargado)
            boolean playerNearby = false;
            for (net.minecraft.server.level.ServerPlayer player : level.players()) {
                double dx = player.getX() - def.x;
                double dz = player.getZ() - def.z;
                if (Math.sqrt(dx*dx + dz*dz) <= 128) {
                    playerNearby = true;
                    break;
                }
            }

            if (playerNearby) {
                // Spawnear ahora
                pendingSpawns.remove(entry.getKey());
                doSpawn(def, ps.spawnPointName, level, server);
                BossPointsMod.LOGGER.info("[SummonCore] Spawneando '{}' porque un jugador llegó al área", ps.spawnPointName);
            } else if (def.fightTimeoutTicks > 0) {
                // Verificar timeout — contar desde cuando se triggereo
                long elapsed = server.getTickCount() - ps.triggeredAt;
                if (elapsed >= def.fightTimeoutTicks) {
                    pendingSpawns.remove(entry.getKey());
                    // Mensaje de que el boss se fue sin que nadie lo viera
                    String bossName = def.entities.isEmpty() ? def.name
                        : (def.entities.get(0).displayName.isEmpty() ? def.name : def.entities.get(0).displayName);
                    String msg = (def.timeoutMessage != null ? def.timeoutMessage
                        : com.bosspoints.config.BossConfig.prefix() + " §c{boss} §7se ha ido...")
                        .replace("{boss}", bossName)
                        .replace("{spawnpoint}", ps.spawnPointName)
                        .replace("&", "§");
                    broadcast(server, msg);
                }
            }
        }
    }

    private static boolean isActiveSpawnPoint(String spawnPointName) {
        for (TrackedEntity te : tracked.values()) {
            if (te.spawnPointName.equals(spawnPointName)) return true;
        }
        return false;
    }

    private static void doSpawn(SpawnPointDefinition def, String spawnPointName,
                                 ServerLevel level, MinecraftServer server) {
        for (int i = 0; i < def.entities.size(); i++) {
            EntitySpawnConfig cfg = def.entities.get(i);
            for (int n = 0; n < cfg.count; n++) {
                spawnEntity(cfg, level, def.x, def.y, def.z, def.name, i, null);
            }
        }
        startFightTimer(spawnPointName, server);
    }

        // ── Fog/Sky area tracking ────────────────────────────────────────────────────────

    private static class ActiveFogEffect {
        UUID entityUUID; String dimension;
        float fogR=-1,fogG=-1,fogB=-1; int fogFade=40;
        float skyR=-1,skyG=-1,skyB=-1; int skyFade=40;
        float radius=128f;
        final Set<UUID> fogInRange = new java.util.HashSet<>();
        final Set<UUID> skyInRange = new java.util.HashSet<>();
    }

    private static final Map<String, ActiveFogEffect> activeFogEffects = new HashMap<>();

    public static void registerFogEffect(UUID entityUUID, String spawnPointName, String dimension,
            float fogR, float fogG, float fogB, int fogFade,
            float skyR, float skyG, float skyB, int skyFade, float radius) {
        ActiveFogEffect afe = activeFogEffects.computeIfAbsent(spawnPointName, k -> new ActiveFogEffect());
        afe.entityUUID=entityUUID; afe.dimension=dimension;
        afe.fogR=fogR; afe.fogG=fogG; afe.fogB=fogB; afe.fogFade=fogFade;
        afe.skyR=skyR; afe.skyG=skyG; afe.skyB=skyB; afe.skyFade=skyFade;
        afe.radius=radius;
    }

    public static void unregisterFogEffect(String spawnPointName, MinecraftServer server) {
        ActiveFogEffect afe = activeFogEffects.remove(spawnPointName);
        if (afe == null) return;
        var dimKey = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(afe.dimension));
        ServerLevel level = server.getLevel(dimKey);
        if (level == null) return;
        PacketFogColor fogReset = new PacketFogColor(-1,-1,-1,40,false);
        PacketFogColor skyReset = new PacketFogColor(-1,-1,-1,40,true);
        for (UUID uid : afe.fogInRange) { net.minecraft.server.level.ServerPlayer p=server.getPlayerList().getPlayer(uid); if(p!=null) NetworkHandler.sendToPlayer(p, fogReset); }
        for (UUID uid : afe.skyInRange) { net.minecraft.server.level.ServerPlayer p=server.getPlayerList().getPlayer(uid); if(p!=null) NetworkHandler.sendToPlayer(p, skyReset); }
    }

    public static void updateFogAreas(MinecraftServer server) {
        for (ActiveFogEffect afe : new ArrayList<>(activeFogEffects.values())) {
            if (afe.entityUUID == null || afe.dimension == null) continue;
            var dimKey = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(afe.dimension));
            ServerLevel level = server.getLevel(dimKey);
            if (level == null) continue;
            Entity entity = level.getEntity(afe.entityUUID);
            if (entity == null || !entity.isAlive()) continue;
            double ex=entity.getX(), ey=entity.getY(), ez=entity.getZ();
            Set<UUID> nowInRange = new java.util.HashSet<>();
            for (net.minecraft.server.level.ServerPlayer player : level.players()) {
                double dx=player.getX()-ex, dy=player.getY()-ey, dz=player.getZ()-ez;
                if (Math.sqrt(dx*dx+dy*dy+dz*dz) <= afe.radius) nowInRange.add(player.getUUID());
            }
            if (afe.fogR >= 0) {
                for (UUID uid : nowInRange) if (!afe.fogInRange.contains(uid)) { net.minecraft.server.level.ServerPlayer p=server.getPlayerList().getPlayer(uid); if(p!=null) NetworkHandler.sendToPlayer(p, new PacketFogColor(afe.fogR,afe.fogG,afe.fogB,afe.fogFade,false)); }
                for (UUID uid : new java.util.HashSet<>(afe.fogInRange)) if (!nowInRange.contains(uid)) { net.minecraft.server.level.ServerPlayer p=server.getPlayerList().getPlayer(uid); if(p!=null) NetworkHandler.sendToPlayer(p, new PacketFogColor(-1,-1,-1,afe.fogFade,false)); }
                afe.fogInRange.clear(); afe.fogInRange.addAll(nowInRange);
            }
            if (afe.skyR >= 0) {
                for (UUID uid : nowInRange) if (!afe.skyInRange.contains(uid)) { net.minecraft.server.level.ServerPlayer p=server.getPlayerList().getPlayer(uid); if(p!=null) NetworkHandler.sendToPlayer(p, new PacketFogColor(afe.skyR,afe.skyG,afe.skyB,afe.skyFade,true)); }
                for (UUID uid : new java.util.HashSet<>(afe.skyInRange)) if (!nowInRange.contains(uid)) { net.minecraft.server.level.ServerPlayer p=server.getPlayerList().getPlayer(uid); if(p!=null) NetworkHandler.sendToPlayer(p, new PacketFogColor(-1,-1,-1,afe.skyFade,true)); }
                afe.skyInRange.clear(); afe.skyInRange.addAll(nowInRange);
            }
        }
    }

        // ── Pending broadcasts ──────────────────────────────────────────────────────

    private static final java.util.TreeMap<Long, List<Runnable>> pendingBroadcasts =
        new java.util.TreeMap<>();

    public static void scheduleBroadcast(long targetTick, Runnable task) {
        pendingBroadcasts.computeIfAbsent(targetTick, k -> new ArrayList<>()).add(task);
    }

    public static void processPendingBroadcasts(MinecraftServer server) {
        long now = server.getTickCount();
        while (!pendingBroadcasts.isEmpty() && pendingBroadcasts.firstKey() <= now) {
            pendingBroadcasts.pollFirstEntry().getValue().forEach(Runnable::run);
        }
    }

    // ── Fight timeout ───────────────────────────────────────────────────────────

    private static final Map<String, Long> fightStartTick = new HashMap<>();

    public static void startFightTimer(String spawnPointName, MinecraftServer server) {
        if (server != null) fightStartTick.put(spawnPointName, (long) server.getTickCount());
    }

    public static void clearFightTimer(String spawnPointName) {
        fightStartTick.remove(spawnPointName);
    }

    public static long getFightTimeRemaining(String spawnPointName, MinecraftServer server) {
        Long start = fightStartTick.get(spawnPointName);
        if (start == null) return -1;
        SpawnPointSavedData data = SpawnPointSavedData.get(server);
        SpawnPointDefinition def = data.get(spawnPointName);
        if (def == null || def.fightTimeoutTicks <= 0) return -1;
        long elapsed = server.getTickCount() - start;
        return Math.max(0, def.fightTimeoutTicks - elapsed);
    }

    public static void checkFightTimeouts(MinecraftServer server) {
        for (Map.Entry<String, Long> entry : new HashMap<>(fightStartTick).entrySet()) {
            String spawnPointName = entry.getKey();
            SpawnPointSavedData data = SpawnPointSavedData.get(server);
            SpawnPointDefinition def = data.get(spawnPointName);
            if (def == null || def.fightTimeoutTicks <= 0) continue;
            long elapsed = server.getTickCount() - entry.getValue();
            if (elapsed >= def.fightTimeoutTicks) {
                fightStartTick.remove(spawnPointName);
                killSpawnPoint(spawnPointName, server);
                String bossName = def.entities.isEmpty() ? def.name
                    : (def.entities.get(0).displayName.isEmpty() ? def.name : def.entities.get(0).displayName);
                String msg = (def.timeoutMessage != null ? def.timeoutMessage
                    : com.bosspoints.config.BossConfig.prefix() + " §c{boss} §7se ha ido...")
                    .replace("{boss}", bossName)
                    .replace("{spawnpoint}", spawnPointName)
                    .replace("&", "§");
                broadcast(server, msg);
            }
        }
    }

    public static void broadcast(MinecraftServer server, String message) {
        server.getPlayerList().broadcastSystemMessage(Component.literal(message), false);
    }

    private static String setToString(Set<Integer> set) {
        if (set.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (Integer i : set) { if (sb.length() > 0) sb.append(","); sb.append(i); }
        return sb.toString();
    }

    private static Set<Integer> stringToSet(String s) {
        Set<Integer> set = new HashSet<>();
        if (s == null || s.isEmpty()) return set;
        for (String part : s.split(",")) {
            try { set.add(Integer.parseInt(part.trim())); } catch (NumberFormatException ignored) {}
        }
        return set;
    }

    // ── Inner classes ─────────────────────────────────────────────────────────

    public static class TrackedEntity {
        public final UUID uuid;
        public final String spawnPointName;
        public final int entityConfigIdx;
        public final String dimension;
        public final double maxHealth;
        public final Set<Integer> triggeredPhases = new HashSet<>();

        public TrackedEntity(UUID uuid, String spawnPointName, int entityConfigIdx, String dimension, double maxHealth) {
            this.uuid = uuid; this.spawnPointName = spawnPointName;
            this.entityConfigIdx = entityConfigIdx; this.dimension = dimension; this.maxHealth = maxHealth;
        }
    }

    public static class PendingTransform {
        public final double x, y, z;
        public final String dimension;
        public final EntitySpawnConfig entityConfig;
        public final TransformConfig transformConfig;
        public final String spawnPointName;
        public final int entityConfigIdx;
        public final int totalDelay;
        public final int transformIdx;
        public int countdown;
        public boolean phase2Done = false, phase3Done = false;

        public PendingTransform(double x, double y, double z, String dimension,
                                EntitySpawnConfig entityConfig, TransformConfig transformConfig,
                                String spawnPointName, int entityConfigIdx, int delayTicks, int transformIdx) {
            this.x=x; this.y=y; this.z=z; this.dimension=dimension;
            this.entityConfig=entityConfig; this.transformConfig=transformConfig;
            this.spawnPointName=spawnPointName; this.entityConfigIdx=entityConfigIdx;
            this.totalDelay=delayTicks; this.countdown=delayTicks; this.transformIdx=transformIdx;
        }
    }
}
