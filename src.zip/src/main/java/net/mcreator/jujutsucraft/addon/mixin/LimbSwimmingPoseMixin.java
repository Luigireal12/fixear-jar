package net.mcreator.jujutsucraft.addon.mixin;

import net.mcreator.jujutsucraft.addon.limb.ClientLimbCache;
import net.mcreator.jujutsucraft.addon.limb.LimbState;
import net.mcreator.jujutsucraft.addon.limb.LimbType;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Cuando ambas piernas del jugador están amputadas (no INTACT), hace que Minecraft
 * piense que el jugador está "visualmente nadando".
 * Esto dispara la animación de natación propia del juego en el renderer,
 * incluyendo la rotación correcta y las correcciones de posición.
 * Se cancela automáticamente cuando al menos una pierna vuelve a INTACT.
 */
@Mixin(LivingEntity.class)
@OnlyIn(Dist.CLIENT)
public class LimbSwimmingPoseMixin {

    @Inject(method = "isVisuallySwimming", at = @At("HEAD"), cancellable = true)
    private void limbIsVisuallySwimming(CallbackInfoReturnable<Boolean> cir) {
        if (!((Object)this instanceof AbstractClientPlayer player)) return;
        if (shouldLieDown(player)) cir.setReturnValue(true);
    }

    @Inject(method = "getSwimAmount", at = @At("HEAD"), cancellable = true)
    private void limbGetSwimAmount(float partialTick, CallbackInfoReturnable<Float> cir) {
        if (!((Object)this instanceof AbstractClientPlayer player)) return;
        if (shouldLieDown(player)) cir.setReturnValue(1.0f);
    }

    private static boolean shouldLieDown(AbstractClientPlayer player) {
        ClientLimbCache.EntityLimbSnapshot snap = ClientLimbCache.get(player.getId());
        if (snap == null) return false;
        // Acostado mientras ambas piernas NO estén completamente regeneradas (INTACT)
        return snap.getState(LimbType.LEFT_LEG)  != LimbState.INTACT
            && snap.getState(LimbType.RIGHT_LEG) != LimbState.INTACT;
    }
}
