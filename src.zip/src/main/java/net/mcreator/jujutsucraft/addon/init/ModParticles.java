package net.mcreator.jujutsucraft.addon.init;

import net.mcreator.jujutsucraft.addon.client.particle.blackflash.Kokusen3Particle;
import net.mcreator.jujutsucraft.addon.client.particle.blackflash.Kokusen5Particle;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModParticles {
    @SubscribeEvent
    public static void registerParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticleTypes.KOKUSEN_3.get(), Kokusen3Particle::provider);
        event.registerSpriteSet(ModParticleTypes.KOKUSEN_5.get(), Kokusen5Particle::provider);
    }
}
