package net.mcreator.jujutsucraft.addon.limb;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Persiste el estado "armadura detacheada" en modo vanilla para cada miembro amputado.
 *
 * Problema que resuelve:
 *   LimbArmorHideMixin usa CURRENT_SEVERED que solo contiene miembros actualmente
 *   SEVERED o REVERSING. Al regenerar (INTACT), el miembro sale del set y la armadura
 *   vuelve a aparecer automáticamente aunque no se haya quitado/puesto la pieza.
 *
 * Solución:
 *   Cuando un miembro está SEVERED, guardamos el Item de armadura del slot correspondiente.
 *   Mientras el MISMO item siga equipado, la armadura permanece oculta (shouldHide = true).
 *   Si el item cambia (se saca o se reemplaza), se limpia la entrada → armadura visible.
 *
 * Bug 3 (sacar/poner armadura en vanilla no arregla EF):
 *   Se maneja en LimbRenderHandler via LivingEquipmentChangeEvent, que llama
 *   EFArmorDetachCache.update() cuando el equipo cambia.
 */
public class VanillaArmorDetachCache {

    // entity ID → LimbType → Item que estaba equipado cuando se amputó el miembro
    private static final Map<Integer, EnumMap<LimbType, Item>> CACHE = new ConcurrentHashMap<>();

    /**
     * Registra que este miembro tenía armadura equipada cuando fue amputado.
     * Solo guarda la PRIMERA vez (putIfAbsent) — no sobreescribe si ya había entrada.
     */
    public static void markSevered(int entityId, LimbType limb, Item armorItem) {
        if (armorItem == null || armorItem == Items.AIR) return;
        CACHE.computeIfAbsent(entityId, k -> new EnumMap<>(LimbType.class))
             .putIfAbsent(limb, armorItem);
    }

    /**
     * Devuelve true si la armadura de este miembro debe seguir oculta.
     * Limpia la entrada si el item cambió (sacó o reemplazó la armadura).
     *
     * @param currentItem item actualmente equipado en el slot correspondiente (Items.AIR si vacío)
     */
    public static boolean shouldHide(int entityId, LimbType limb, Item currentItem) {
        EnumMap<LimbType, Item> entry = CACHE.get(entityId);
        if (entry == null) return false;
        Item cached = entry.get(limb);
        if (cached == null) return false;
        // Si el item cambió o se sacó → limpiar y mostrar armadura
        if (currentItem == null || currentItem == Items.AIR || cached != currentItem) {
            entry.remove(limb);
            if (entry.isEmpty()) CACHE.remove(entityId);
            return false;
        }
        return true; // mismo item → seguir ocultando
    }

    /** Limpia un miembro específico (usado cuando el equipo cambia via evento). */
    public static void clearLimb(int entityId, LimbType limb) {
        EnumMap<LimbType, Item> entry = CACHE.get(entityId);
        if (entry == null) return;
        entry.remove(limb);
        if (entry.isEmpty()) CACHE.remove(entityId);
    }

    /** Limpia todos los datos de una entidad (respawn, logout). */
    public static void clearEntity(int entityId) {
        CACHE.remove(entityId);
    }

    /**
     * Mapea un LimbType al slot de armadura cuyo renderizado se ve afectado.
     * HEAD   → HEAD slot
     * RIGHT/LEFT_ARM → CHEST slot (brazos de la pechera)
     * RIGHT/LEFT_LEG → LEGS slot (patas del pantalón)
     */
    public static EquipmentSlot getSlotForLimb(LimbType limb) {
        return switch (limb) {
            case RIGHT_ARM, LEFT_ARM -> EquipmentSlot.CHEST;
            case RIGHT_LEG, LEFT_LEG -> EquipmentSlot.LEGS;
            case HEAD                 -> EquipmentSlot.HEAD;
        };
    }
}
