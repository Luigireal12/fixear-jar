package net.mcreator.jujutsucraft.addon.mixin;

import net.mcreator.jujutsucraft.procedures.RangeAttackProcedure;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * DESACTIVADO POR DISEÑO, A PROPÓSITO — no borrar el archivo, dejar este
 * @Redirect vacío (pass-through puro) en vez de quitarlo de la lista de
 * mixins activos, porque BlackFlashProcDedupeMixin.java sigue siendo el
 * único lugar permitido para interceptar este Math.round (ver advertencia
 * de abajo).
 *
 * Historia real, confirmada con logs y pruebas aisladas del usuario:
 *
 *   1. RangeAttackProcedure.execute() llama a AttackWeakPunchProcedure
 *      (el puño normal) hasta 11 veces por golpe físico, en el mismo tick,
 *      cada una con su PROPIO roll de probabilidad independiente
 *      (BlackFlash es variable local, se reinicia en cada llamada).
 *
 *   2. Eso significa que, SIN ningún dedupe, un % nominal bajo (3-5%) se
 *      siente como un % real mucho más alto: 1-(1-0.03)^11 ≈ 28%,
 *      1-(1-0.05)^11 ≈ 43%. Esto se identificó como "el problema" en una
 *      sesión anterior y se agregó este mixin para limitar a 1 sola
 *      oportunidad real de roll por golpe completo.
 *
 *   3. PERO: con % alto (50-100%, el caso real que el usuario necesita),
 *      1-(1-0.5)^11 ≈ 99.95% y 1-(1-1.0)^11 = 100% — el resultado SIN
 *      dedupe ya es prácticamente indistinguible de "siempre funciona".
 *      El usuario confirmó con una prueba aislada (solo JJSK4 + mod base,
 *      sin este addon) que con BlackFlashChance al 100% el Black Flash
 *      sale siempre, en cualquier golpe — exactamente lo que la matemática
 *      predice sin ningún dedupe.
 *
 *   4. El dedupe que se agregó para resolver el punto 2 introdujo un bug
 *      real y serio en el punto 3: limitar a "1 sola oportunidad por
 *      swing" requiere identificar CUÁL de las 11 sub-llamadas es la que
 *      realmente conecta con un objetivo — eso depende de geometría exacta
 *      (radio, timing de NBT) que nunca se logró replicar con la misma
 *      fidelidad que el propio bucle interno del mod base usa más abajo
 *      (loop separado de búsqueda de entidades, con doble iteración y
 *      varias condiciones intermedias — confirmado con bytecode real que
 *      el roll y la búsqueda de entidades NO son el mismo bloque
 *      condicional). El resultado real, medido con logs: con 100% de
 *      chance, solo ~25% de los golpes confirmaban Black Flash real,
 *      en vez del 100% esperado.
 *
 * Conclusión: el costo de NO deduplicar (probabilidades bajas sintiéndose
 * más altas de lo nominal) es mucho menor que el costo de deduplicar mal
 * (probabilidades altas, incluido 100%, fallando la mayoría de las veces).
 * Se desactiva el dedupe por completo, dejando pasar el valor real de
 * Math.round(num1) siempre — exactamente el comportamiento que el usuario
 * ya confirmó como correcto sin este addon instalado.
 *
 * IMPORTANTE: solo puede existir UN @Redirect apuntando a este Math.round
 * en todo el addon. Si en el futuro se necesita una lógica de dedupe más
 * fiel (por ejemplo, replicando exactamente el loop_num y el radio real
 * del mod base en vez de aproximarlo), debe implementarse en ESTE archivo,
 * no en uno nuevo — dos mixins compitiendo por el mismo punto de inyección
 * causan un crash de Mixin al cargar (InjectionError, "(0/1) succeeded").
 */
@Mixin(value = RangeAttackProcedure.class, remap = false)
public class BlackFlashProcDedupeMixin {

    @Redirect(
        method = "execute",
        at = @At(
            value = "INVOKE",
            target = "Ljava/lang/Math;round(D)J",
            remap = false
        )
    )
    private static long jjkblueredpurple$dedupeBlackFlashRoll(double num1,
                                                                LevelAccessor world, double x, double y, double z, Entity entity) {
        return Math.round(num1);
    }
}
