package net.mcreator.jujutsucraft.addon.potion;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/**
 * Efecto puramente visual (sin ningún cambio de atributo ni daño) que se
 * muestra mientras el jugador está en cooldown del bono de Output 120%
 * (ver Output120Handler). Quitarlo manualmente con /effect clear o cualquier
 * cure NO restaura el cooldown real — el cooldown sigue su propio timer en
 * NBT independiente de este efecto, que solo existe para que el jugador vea
 * en su HUD de efectos cuánto le queda. No necesita ningún override: al no
 * agregar attribute modifiers ni lógica de tick, MobEffect por defecto ya
 * no hace nada por sí mismo.
 */
public class Output120CooldownMobEffect extends MobEffect {
    public Output120CooldownMobEffect() {
        super(MobEffectCategory.NEUTRAL, 0x444444);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return false; // nunca aplica nada tick a tick, es 100% cosmético
    }
}
