package net.mcreator.jujutsucraft.addon.mixin;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.mcreator.jujutsucraft.addon.AddonGameRules;
import net.mcreator.jujutsucraft.addon.BlueRedPurpleNukeMod;
import net.mcreator.jujutsucraft.addon.util.DomainAddonUtils;
import net.mcreator.jujutsucraft.entity.BlueEntity;
import net.mcreator.jujutsucraft.entity.PurpleEntity;
import net.mcreator.jujutsucraft.entity.RedEntity;
import net.mcreator.jujutsucraft.init.JujutsucraftModMobEffects;
import net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes;
import net.mcreator.jujutsucraft.network.JujutsucraftModVariables;
import net.mcreator.jujutsucraft.procedures.CanSeeSukunaSlashProcedure;
import net.mcreator.jujutsucraft.procedures.LogicAttackProcedure;
import net.mcreator.jujutsucraft.procedures.RangeAttackProcedure;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.objectweb.asm.Opcodes;

/**
 * Combat mixin for `RangeAttackProcedure.execute()` that blocks incomplete-domain sure-hit attacks, temporarily scales domain radius for active range calculations, adjusts open-domain combat tuning, and records successful Black Flash procs after the base attack resolves.
 */
// Binds this addon mixin to the original target class so only the selected procedure or entity behavior is altered.
@Mixin(value={RangeAttackProcedure.class}, remap=false)
public class RangeAttackProcedureMixin {
    // Persistent-data key storing the last observed Zone effect duration so Black Flash procs can be detected on the next return pass.
    private static final String KEY_LAST_ZONE_DUR = "jjkbrp_last_zone_dur";
    // Persistent-data key storing the short Black Flash proc cooldown that suppresses immediate repeat boosts.
    private static final String KEY_BF_CD = "jjkbrp_bf_cd";
    /**
     * Solo loguea el resultado real de ChangeDamage1Procedure, sin
     * alterarlo — para confirmar con certeza si damage_sorce cae a 0.0 o
     * menos en algún caso real del usuario, lo cual cancelaría el bloque
     * completo de Black Flash (incluyendo ENTITY_BLACK_FLASH/ZONE) sin
     * afectar visiblemente el daño real aplicado al jugador (que se
     * calcula en otro punto separado del método base).
     */
    @org.spongepowered.asm.mixin.injection.Redirect(
        method = "execute",
        at = @At(value = "INVOKE", target = "Lnet/mcreator/jujutsucraft/procedures/ChangeDamage1Procedure;execute(Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/entity/Entity;)D", remap = false)
    )
    private static double jjkblueredpurple$logChangeDamage1(LevelAccessor world, Entity entity, Entity entityiterator) {
        double result = net.mcreator.jujutsucraft.procedures.ChangeDamage1Procedure.execute(world, entity, entityiterator);
        if (entity instanceof Player) {
            JJKBRP$LOGGER.info("[JJKBRP-DAMAGE-DIAG] ChangeDamage1 entity={} target={} result={}",
                entity.getName().getString(), entityiterator.getClass().getSimpleName(), result);
        }
        return result;
    }

    private static final String KEY_BF_FATIGUE_UNTIL_TICK = "jjkbrp_bf_fatigue_until_tick";
    /** Backup del Damage real antes de forzarlo a 9.0 mínimo para que blackflashable=true sin importar la carga. Restaurado en el RETURN, igual patrón que JJKBRP$cnt6Backup. */
    private static final ThreadLocal<Double> JJKBRP$damageBackup = new ThreadLocal<>();
    /** Tick (level.getGameTime()) hasta el cual el roll está bloqueado por el cooldown post-proc. */
    private static final String KEY_OWN_BF_COOLDOWN_UNTIL = "jjkbrp_own_bf_cooldown_until";
    /** Tick del último swing donde el sistema propio ya consumió su única oportunidad real de roll. */
    private static final Map<UUID, Long> JJKBRP$ownRollSwingTick = new ConcurrentHashMap<>();
    /** Duración configurable (en ticks) del cooldown entre golpes distintos, 0=desactivado por default. Seteable con /jjkbfcooldown. */
    private static final String KEY_OWN_BF_COOLDOWN_TICKS_CONFIG = "jjkbrp_own_bf_cooldown_ticks_config";
    /** Marca, dentro de la MISMA llamada a execute(), si el roll propio de JoQu ya confirmó éxito — leído por el @ModifyConstant para forzar el roll nativo a éxito garantizado. */
    private static final ThreadLocal<Boolean> JJKBRP$ownRollConfirmedThisCall = new ThreadLocal<>();
    /** Marca, dentro de la MISMA llamada a execute(), si el proc confirmado vino de una garantía a voluntad del jugador (Plus Ultra de Todo, o la skill Black Flash de Itadori) — esos NO deben sumar progreso de maestría, ya que el jugador los activa él mismo, no son un roll real de probabilidad. */
    private static final ThreadLocal<Boolean> JJKBRP$confirmedWasGuaranteed = new ThreadLocal<>();

    /**
     * Controla por completo el resultado real del roll del mod base
     * (reemplaza la constante 0.998): devuelve 0.0 (garantizado,
     * Math.random()>0.0 es ~siempre true) si el sistema propio de JoQu ya
     * confirmó éxito para ESTA sub-llamada específica (ver
     * JJKBRP$ownRollConfirmedThisCall), o 1.0 (imposible de superar,
     * Math.random()>1.0 nunca es true) en cualquier otro caso — así el
     * roll NATIVO del mod base nunca decide nada por su cuenta, y el único
     * camino real hacia BlackFlash=true es el sistema propio.
     *
     * Necesita ganarle a JJSK4 en caso de que su mixin siga presente (ver
     * el jar parcheado que ya le quita RangeAttackMixin de su lista de
     * mixins activos) — pero @ModifyConstant ENCADENA entre mixins, no
     * "el que gana se queda solo", así que esta anulación solo es 100%
     * efectiva si JJSK4 realmente no tiene su propio @ModifyConstant
     * cargado (confirmado: se quitó del jar real de JJSK4, no solo de
     * este archivo).
     */
    @org.spongepowered.asm.mixin.injection.ModifyConstant(
        method = "execute",
        constant = @org.spongepowered.asm.mixin.injection.Constant(doubleValue = 0.998),
        remap = false
    )
    private static double jjkblueredpurple$nullifyBaseBlackFlashConstant(double constant, LevelAccessor world, double x, double y, double z, Entity entity) {
        // CRÍTICO (causa real del crash al usar @Redirect sobre
        // Math.random() en su lugar): jujutsualm TAMBIÉN registra su
        // propio @Redirect sobre Math.random() en este mismo método
        // (jujutsualm$random()). Dos @Redirect sobre el MISMO punto de
        // inyección, con la misma prioridad, NO se encadenan como
        // @ModifyConstant — Mixin descarta uno en silencio al cargar
        // ("@Redirect conflict. Skipping...") y el primer uso real del
        // método tira un InjectionError crítico, crasheando el juego al
        // primer golpe (confirmado con log + crash report reales).
        // @ModifyConstant SÍ encadena entre mods sin este problema
        // (confirmado en sesiones anteriores con JJSK4) — por eso se
        // revierte a este enfoque en vez del @Redirect sobre random().
        return Boolean.TRUE.equals(JJKBRP$ownRollConfirmedThisCall.get()) ? 0.0 : 1.0;
    }

    /**
     * Fuerza blackflashable=true SIEMPRE, sin importar Damage>=9.0 — usa
     * la misma sintaxis exacta (index=15, ordinal=1, STORE) que JJSK4 ya
     * usa con éxito confirmado para esta misma variable en este mismo
     * método (ver modifyBlackflashable en su RangeAttackMixin.java), en
     * vez de adivinar el ordinal sin poder verificarlo contra bytecode
     * real. Reemplaza el forzado de Damage del HEAD (que no era
     * necesario: Damage ya superaba 9.0 en los casos reales probados,
     * pero blackflashable seguía sin activarse — la causa real estaba en
     * otro punto del flujo, no en el valor de Damage en sí).
     */
    @org.spongepowered.asm.mixin.injection.ModifyVariable(
        method = "execute",
        at = @At(value = "STORE"),
        index = 15,
        ordinal = 0,
        remap = false
    )
    private static boolean jjkblueredpurple$forceBlackflashableTrue(boolean blackflashable, LevelAccessor world, double x, double y, double z, Entity entity) {
        if (entity instanceof ServerPlayer player) {
            int ctId = net.mcreator.jujutsucraft.addon.mastery.MasteryData.activeCtId(player);
            double masteryPercent = net.mcreator.jujutsucraft.addon.mastery.MasteryData.getTotalMastery(player, ctId);
            if (masteryPercent > 0.0) {
                return true;
            }
        }
        return blackflashable;
    }
    // Persistent-data flag marking that the near-death cooldown reduction was already handled for the current Black Flash event.
    private static final String KEY_BF_ND_HANDLED = "jjkbrp_bf_nd_handled";
    // Persistent-data flag indicating the addon temporarily boosted cnt6 to force OG Black Flash probability for one timed hit.
    private static final String KEY_BF_FORCED_WINDOW = "jjkbrp_bf_forced_window";
    // Persistent-data key storing the forced-window owner UUID so return detection can confirm the same timed hit even when the attacking entity is a projectile.
    private static final String KEY_BF_FORCED_OWNER_UUID = "jjkbrp_bf_forced_owner_uuid";
    // Persistent-data key storing the Zone duration before the forced call so confirmation can handle players already inside Zone.
    private static final String KEY_BF_FORCED_PRE_ZONE_DUR = "jjkbrp_bf_forced_pre_zone_dur";
    // Roll-chance threshold below which the original RangeAttackProcedure cnt6 charge is treated as
    // "uncharged" (e.g. a plain attack click) for the purposes of the HUD-driven chance roll. Above this,
    // the player is already mid-charge and the base game's own cnt6 loop is left alone to avoid double-rolling.
    // (threshold viejo de cnt6<0.5 eliminado: el sistema de maestría no restringe por cnt6, ver jjkblueredpurple$rollMasteryBlackFlashChance)
    // Persistent-data key storing the pre-scaled damage value so rank scaling can be safely reverted after each attack call.
    private static final String KEY_RANK_DAMAGE_BACKUP = "jjkbrp_rank_damage_backup";
    // Persistent-data flag marking that rank-based damage scaling was applied for the current attack execution.
    private static final String KEY_RANK_DAMAGE_APPLIED = "jjkbrp_rank_damage_applied";
    // Persistent-data counter storing how many Infinity-technique damage passes this spawned cast has already consumed.
    private static final String KEY_INFINITY_RANK_PASS_COUNT = "jjkbrp_inf_rank_pass_count";
    // Persistent-data key stored on each Blue victim to throttle repeated AI damage ticks against the same target.
    private static final String KEY_BLUE_LAST_HIT_TICK = "addon_blue_last_hit_tick";
    // Persistent-data key stored on each Red victim to throttle repeated AI damage ticks against the same target.
    private static final String KEY_RED_LAST_HIT_TICK = "addon_red_last_hit_tick";
    // Black Flash proc cooldown applied after a successful ranged proc, measured in ticks.
    private static final int BF_PROC_COOLDOWN_TICKS = 60;
    // Amount of near-death cooldown removed when a valid Black Flash proc is detected.
    private static final int BF_ND_CD_REDUCTION = 600;
    // Thread-local owner reference used to temporarily grant and then safely remove Purple-owner invulnerability around the redirected attack execution.
    // Marks this helper member as mixin-unique so it cannot collide with names inside the target class.
    @Unique
    private static final ThreadLocal<Player> JJKBRP$protectedOwner = new ThreadLocal();
    // Thread-local backup of cnt6 for the current RangeAttackProcedure.execute() call only. Using a
    // ThreadLocal instead of the entity's persistent NBT (the old KEY_CNT6_BACKUP/KEY_CNT6_SUPPRESSED
    // approach) means a corrupted/leftover state from one hit can never bleed into a later, unrelated
    // hit: the value only exists for the duration of this exact HEAD-to-RETURN call on this thread, and
    // is always cleared in a try/finally-equivalent RETURN injection regardless of what the original
    // method body did. The previous NBT-flag approach was observed (via live server logs) to leave
    // cnt6 stuck at the forced guarantee value (99999.0) for an extended period after a single guaranteed
    // Black Flash use, silently turning every subsequent plain attack into a guaranteed proc until some
    // unrelated event (e.g. ResetCounterProcedure on key release) happened to overwrite cnt6 again.
    @Unique
    private static final ThreadLocal<Double> JJKBRP$cnt6Backup = new ThreadLocal();
    /**
     * Marcado con certeza absoluta cuando el método base RangeAttackProcedure
     * realmente confirmó BlackFlash=true — se inyecta en el mismo punto de
     * bytecode exacto que stats ya usa con éxito (lectura GETSTATIC del
     * campo ENTITY_BLACK_FLASH, que el método base solo lee DENTRO del
     * bloque if(BlackFlash) real). Esto reemplaza la heurística anterior
     * basada en si el efecto ZONE "subió" — esa heurística podía dar falsos
     * positivos (mensaje "Black Flash" sin haber pegado nada real) o falsos
     * negativos (Black Flash real pero ZONE no subió lo esperado si ya
     * había uno activo de antes), porque ZONE es también una ENTRADA del
     * cálculo del juego (su amplifier sube con cada proc sucesivo), no
     * exclusivamente una salida — confirmando o no el proc actual con
     * certeza. Leer directo si el campo se accedió es la única señal 100%
     * confiable, sin inferencias.
     */
    private static final ThreadLocal<Boolean> JJKBRP$realBlackFlashConfirmed = new ThreadLocal<>();
    /**
     * Tracks whether cnt6 already arrived at guarantee level (>=99999.0) from OUTSIDE this addon's
     * own branches (e.g. base-game skills like Todo's "Plus Ultra" forcing a guaranteed hit). Read in
     * the RETURN injection to decide whether a successful proc should grow Black Flash mastery: only
     * player-earned rolls (the HUD chance roll, or the base game's own random roll) should count.
     */
    @Unique
    private static final ThreadLocal<Boolean> JJKBRP$externallyForcedCnt6 = new ThreadLocal();
    // Thread-local backup of the global domain radius so the original value can be restored after the attack finishes.
    // Marks this helper member as mixin-unique so it cannot collide with names inside the target class.
    @Unique
    private static final ThreadLocal<Double> JJKBRP$scaledDomainRadiusOriginal = new ThreadLocal();
    // Logger used for periodic domain-state diagnostics around ranged attacks, and for the temporary
    // Black Flash diagnostic instrumentation below (DEBUG-level, intended to be removed once the
    // Itadori guaranteed Black Flash issue is root-caused from live server logs).
    // Marks this helper member as mixin-unique so it cannot collide with names inside the target class.
    @Unique
    private static final Logger JJKBRP$LOGGER = LogUtils.getLogger();

    // ===== HEAD INJECTION =====
    /**
     * Runs at the head of `RangeAttackProcedure.execute()` to cancel incomplete-domain sure-hit attacks, temporarily scale active domain radius, protect Purple owners when needed, and apply open-domain Black Flash tuning before the base procedure executes.
     * @param world world access used by the current mixin callback.
     * @param x world coordinate value used by this callback.
     * @param y world coordinate value used by this callback.
     * @param z world coordinate value used by this callback.
     * @param entity entity involved in the current mixin operation.
     * @param ci callback handle used to cancel or override the original procedure.
     */
    // Injects at method head so the addon can validate, cache, or override state before the original procedure runs.
    @Inject(method={"execute"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    private static void jjkblueredpurple$boostBlackFlash(LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {
        Player ownerPlayer;
        if (entity == null) {
            return;
        }
        // CRÍTICO: sin este chequeo, este mixin corría también del lado del
        // CLIENTE en singleplayer (el server thread y el render thread
        // comparten la misma JVM ahí, y RangeAttackProcedure.execute() se
        // llama de ambos lados — confirmado con logs reales mostrando
        // [Render thread] y [Server thread] en igual cantidad). El dedupe
        // de roll (BlackFlashProcDedupeMixin, Map estático compartido sin
        // distinguir side) podía ser "ganado" por la llamada del cliente
        // (una simulación fantasma que nunca se sincroniza al servidor),
        // dejando la llamada real del servidor sin oportunidad de roll —
        // el roll de maestría parecía tener éxito en los logs (que SÍ
        // corrían del lado servidor donde se logea), pero el efecto real
        // (ZONE) nunca se aplicaba porque esa ejecución específica del
        // servidor ya había sido bloqueada por el dedupe consumido del
        // lado cliente en el mismo tick.
        if (world.isClientSide()) {
            return;
        }
        if (!AddonGameRules.addonEnabled(world)) {
            return;
        }
        CompoundTag data = entity.getPersistentData();
        LivingEntity domainStateSource = RangeAttackProcedureMixin.jjkblueredpurple$resolveDomainStateSource(world, entity, data);
        CompoundTag domainStateData = domainStateSource != null ? domainStateSource.getPersistentData() : data;
        boolean sourceOpen = domainStateSource != null && DomainAddonUtils.isOpenDomainState(domainStateSource);
        // Incomplete domains intentionally lose sure-hit behavior, so the entire ranged attack procedure is cancelled before the base logic can fire.
        if (domainStateSource != null && AddonGameRules.domainForms(domainStateSource) && RangeAttackProcedureMixin.jjkblueredpurple$isIncompleteDomainAttack(world, entity, data)) {
            RangeAttackProcedureMixin.jjkblueredpurple$replayIncompleteShrineVisualHit(world, x, y, z, entity, data, domainStateSource);
            ci.cancel();
            return;
        }
        if (data.getBoolean("DomainAttack") && domainStateSource != null && AddonGameRules.sukunaIncompleteSurehit(domainStateSource) && RangeAttackProcedureMixin.jjkblueredpurple$isSpecialSukunaIncompleteSureHit(domainStateSource) && !data.getBoolean("jjkbrp_sukuna_incomplete_surehit_corrected")) {
            CompoundTag ownerNbt = domainStateSource.getPersistentData();
            Vec3 center = DomainAddonUtils.getDomainCenter((Entity)domainStateSource);
            double range = RangeAttackProcedureMixin.jjkblueredpurple$getSukunaIncompleteSureHitRange(world, domainStateSource);
            data.putDouble("Range", range);
            data.putBoolean("jjkbrp_sukuna_incomplete_surehit_corrected", true);
            ci.cancel();
            RangeAttackProcedure.execute(world, center.x, center.y, center.z, entity);
            data.remove("jjkbrp_sukuna_incomplete_surehit_corrected");
            return;
        }
        // Keep OG Blue/Red/Purple damage on the original RangeAttack + DamageFix path.
        RangeAttackProcedureMixin.jjkblueredpurple$applyRankDamageScale(world, entity, data);
        // Temporarily swap the shared domain radius so all downstream range checks operate on the mastery-scaled radius instead of the global default.
        RangeAttackProcedureMixin.jjkblueredpurple$scaleDomainAttackRadius(world, entity);
        JJKBRP$protectedOwner.remove();
        if (entity instanceof PurpleEntity && (ownerPlayer = RangeAttackProcedureMixin.jjkblueredpurple$resolvePlayerOwner(world, data.getString("OWNER_UUID"))) != null && AddonGameRules.gojoPurpleFusion(ownerPlayer) && RangeAttackProcedureMixin.jjkblueredpurple$isInfinityActive(ownerPlayer) && !ownerPlayer.isInvulnerable()) {
            ownerPlayer.setInvulnerable(true);
            JJKBRP$protectedOwner.set(ownerPlayer);
        }
        if (data.getBoolean("DomainAttack") && sourceOpen && domainStateSource != null && AddonGameRules.domainForms(domainStateSource) && !data.getBoolean("jjkbrp_surehit_corrected")) {
            double surehitMul = domainStateData.getDouble("jjkbrp_open_surehit_multiplier");
            double ceMul = domainStateData.getDouble("jjkbrp_open_ce_drain_multiplier");
            if (surehitMul <= 0.0) {
                surehitMul = 1.0;
            }
            if (ceMul <= 0.0) {
                ceMul = 1.0;
            }
            int domainId = (int)Math.round(domainStateData.getDouble("jjkbrp_domain_id_runtime"));
            if (data.contains("Damage")) {
                data.putDouble("Damage", data.getDouble("Damage") * surehitMul);
            }
            if (entity instanceof Player) {
                Player p = (Player)entity;
                double finalCeMul = ceMul;
                p.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY).ifPresent(vars -> {
                    vars.PlayerCursePowerChange -= 10.0 * (finalCeMul - 1.0);
                    vars.syncPlayerVariables((Entity)p);
                });
            }
            if (domainStateSource != null) {
                CompoundTag ownerNbt = domainStateSource.getPersistentData();
                double cx = ownerNbt.contains("jjkbrp_open_domain_cx") ? ownerNbt.getDouble("jjkbrp_open_domain_cx")
                          : ownerNbt.contains("x_pos_doma") ? ownerNbt.getDouble("x_pos_doma") : x;
                double cy = ownerNbt.contains("jjkbrp_open_domain_cy") ? ownerNbt.getDouble("jjkbrp_open_domain_cy")
                          : ownerNbt.contains("y_pos_doma") ? ownerNbt.getDouble("y_pos_doma") : y;
                double cz = ownerNbt.contains("jjkbrp_open_domain_cz") ? ownerNbt.getDouble("jjkbrp_open_domain_cz")
                          : ownerNbt.contains("z_pos_doma") ? ownerNbt.getDouble("z_pos_doma") : z;
                double addonOpenRange = RangeAttackProcedureMixin.jjkblueredpurple$isSpecialSukunaIncompleteSureHit(domainStateSource)
                        ? RangeAttackProcedureMixin.jjkblueredpurple$getSukunaIncompleteSureHitRange(world, domainStateSource)
                        : DomainAddonUtils.getOpenDomainRange(world, (Entity)domainStateSource);
                double addonSureHitRange = addonOpenRange * 0.5;
                double dx = x - cx;
                double dy = y - cy;
                double dz = z - cz;
                double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                double maxOriginDist = addonSureHitRange * 0.6;
                double corrX = x, corrY = y, corrZ = z;
                if (dist > maxOriginDist && dist > 0.001) {
                    double scale = maxOriginDist / dist;
                    corrX = cx + dx * scale;
                    corrY = cy + dy * scale;
                    corrZ = cz + dz * scale;
                }
                data.putDouble("Range", addonSureHitRange);
                data.putBoolean("jjkbrp_surehit_corrected", true);
                ci.cancel();
                RangeAttackProcedure.execute(world, corrX, corrY, corrZ, entity);
                data.remove("jjkbrp_surehit_corrected");
                return;
            }
        } else if (data.getBoolean("DomainAttack") && sourceOpen && data.getBoolean("jjkbrp_surehit_corrected")) {
            data.remove("jjkbrp_surehit_corrected");
        }
        int bfCd = data.getInt(KEY_BF_CD);
        // The addon suppresses or boosts `cnt6` only for the current execution window, then restores the
        // original value on return via the thread-local backup below (see JJKBRP$cnt6Backup for why a
        // ThreadLocal is used here instead of the entity's persistent NBT).
        if (AddonGameRules.blackFlash(entity) && JJKBRP$cnt6Backup.get() == null) {
            double liveCnt6 = data.getDouble("cnt6");
            // Cooldown de fatiga real (mecanismo confirmado de JJKU, ver el
            // bloque que lo aplica más abajo en el RETURN): mientras esté
            // activo, se bloquea el roll por completo forzando cnt6=-1.0,
            // el mismo valor que el mod base ya usa para bloquear Black
            // Flash en golpes intermedios de combo (gate real: cnt6>=0.0).
            if (entity instanceof ServerPlayer fatigueCheckPlayer) {
                long fatigueUntil = fatigueCheckPlayer.getPersistentData().getLong(KEY_BF_FATIGUE_UNTIL_TICK);
                if (fatigueCheckPlayer.level().getGameTime() < fatigueUntil) {
                    JJKBRP$cnt6Backup.set(liveCnt6);
                    data.putDouble("cnt6", -1.0);
                    return;
                }
            }
            // Captured BEFORE any of our own branches below can touch cnt6. Some base-game skills
            // (e.g. Todo's "Plus Ultra" — AttackTodoBlackFlashProcedure, confirmado real en el
            // código fuente del mod base, putDouble("cnt6", 99999.0) antes de llamar a
            // RangeAttackProcedure.execute()) force cnt6 to 99999.0 themselves as a guaranteed-hit
            // mechanic unrelated to this addon's own guarantee/HUD systems. Mastery gain must
            // exclude those procs (per design: only player-earned rolls grow mastery), so we
            // record whether the value was ALREADY at guarantee level walking in, independent of
            // which branch (if any) ends up running.
            //
            // CRÍTICO (bug real confirmado): con la constante anulada directamente vía
            // jjkblueredpurple$nullifyBaseBlackFlashConstant, inflar cnt6/num1 YA NO tiene ningún
            // efecto sobre el roll real — Math.random()>1.0 nunca es true sin importar num1. Sin
            // conectar esto a JJKBRP$ownRollConfirmedThisCall, cualquier skill del mod base que
            // garantice un Black Flash así (como esta) terminaba cayendo al roll normal de
            // maestría — exactamente el bug reportado ("funciona como un ataque más").
            if (liveCnt6 >= 99999.0) {
                JJKBRP$externallyForcedCnt6.set(true);
                JJKBRP$ownRollConfirmedThisCall.set(true);
                JJKBRP$confirmedWasGuaranteed.set(true);
            }
            // GARANTÍA REAL DE LA SKILL "Black Flash" DE ITADORI (JJSK4) —
            // confirmada en el código fuente exacto de RangeAttackMixin.java
            // (el archivo completo de JJSK4 que se eliminó del jar parcheado
            // para resolver el conflicto de @Redirect sobre Math.random()):
            // return (skill != 2107.0 && !(entity instanceof
            // ItadoriYujiModuloEntity)) ? formula_normal : 0.0; — es decir,
            // garantizado SIEMPRE que skill==2107.0 (la skill real, sin
            // pasar nunca por cnt6=99999) O la entidad sea
            // ItadoriYujiModuloEntity. Se chequea por nombre de clase
            // simple para no atar la compilación de este addon a JJSK4.
            double liveSkill = data.getDouble("skill");
            boolean isItadoriBlackFlashSkill = liveSkill == 2107.0
                    || "ItadoriYujiModuloEntity".equals(entity.getClass().getSimpleName());
            if (isItadoriBlackFlashSkill) {
                JJKBRP$ownRollConfirmedThisCall.set(true);
                JJKBRP$confirmedWasGuaranteed.set(true);
            }
            double domainBonus = Math.max(0.0, data.getDouble("jjkbrp_domain_bf_bonus"));
            ServerPlayer guaranteeOwner = RangeAttackProcedureMixin.jjkblueredpurple$resolveGuaranteedBlackFlashOwner(world, entity, data);
            ServerPlayer hudChanceOwner = guaranteeOwner == null
                    ? RangeAttackProcedureMixin.jjkblueredpurple$resolveHudChanceOwner(world, entity, data)
                    : null;
            // ===== TEMP DIAGNOSTIC LOGGING (remove once the Itadori guaranteed Black Flash issue is
            // root-caused) - dumps every input this mixin uses to decide what happens to cnt6, plus
            // PlayerCursePowerFormer (the value base-game RangeAttackProcedure compares against 150.0
            // to grant a no-roll guaranteed proc for players), right before any branch below runs.
            if (entity instanceof Player) {
                ServerPlayer diagPlayer = entity instanceof ServerPlayer sp ? sp : null;
                double diagCursePowerFormer = diagPlayer != null
                        ? diagPlayer.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null)
                                .map(v -> v.PlayerCursePowerFormer).orElse(-1.0)
                        : -1.0;
                JJKBRP$LOGGER.info(
                        "[JJKBRP-BF-DIAG] entity={} skill={} cnt1={} liveCnt6={} attackFlag={} bfCd={} domainBonus={} guaranteeOwner={} hudChanceOwner={} masteryPercent={} PlayerCursePowerFormer={} Damage={}",
                        entity.getName().getString(),
                        data.getDouble("skill"),
                        data.getDouble("cnt1"),
                        liveCnt6,
                        data.getBoolean("attack"),
                        bfCd,
                        domainBonus,
                        guaranteeOwner != null ? guaranteeOwner.getName().getString() : "null",
                        hudChanceOwner != null ? hudChanceOwner.getName().getString() : "null",
                        diagPlayer != null ? net.mcreator.jujutsucraft.addon.mastery.MasteryData.getTotalMastery(diagPlayer, net.mcreator.jujutsucraft.addon.mastery.MasteryData.activeCtId(diagPlayer)) : -1.0,
                        diagCursePowerFormer,
                        data.getDouble("Damage")
                );
            }
            // ===== END TEMP DIAGNOSTIC LOGGING (pre-branch snapshot) =====
            if (guaranteeOwner != null && BlueRedPurpleNukeMod.isBlackFlashGuaranteeActive(guaranteeOwner)) {
                // CRÍTICO: ya NO se fuerza cnt6=99999 — eso dejó de tener
                // efecto real desde que el roll se decide directamente vía
                // jjkblueredpurple$nullifyBaseBlackFlashConstant (constante
                // anulada a 1.0 siempre que el ThreadLocal no esté en true,
                // sin importar num1/cnt6). Mismo bug que afectaba al viejo
                // HUD_ROLL_WIN — confirmado y corregido a pedido explícito.
                // Esta rama (Plus Ultra de Todo) NO consume el roll de
                // maestría ni le suma progreso — es una garantía que el
                // jugador activa a voluntad, no un roll de probabilidad.
                JJKBRP$ownRollConfirmedThisCall.set(true);
                JJKBRP$confirmedWasGuaranteed.set(true);
                data.putBoolean(KEY_BF_FORCED_WINDOW, true);
                data.putString(KEY_BF_FORCED_OWNER_UUID, guaranteeOwner.getStringUUID());
                MobEffectInstance preZone = guaranteeOwner.getEffect((MobEffect)JujutsucraftModMobEffects.ZONE.get());
                data.putInt(KEY_BF_FORCED_PRE_ZONE_DUR, preZone != null ? preZone.getDuration() : 0);
                JJKBRP$LOGGER.info("[JJKBRP-BF-DIAG] branch=ADDON_GUARANTEE roll confirmed for {}", guaranteeOwner.getName().getString());
            } else if (hudChanceOwner != null && bfCd <= 0
                    && RangeAttackProcedureMixin.jjkblueredpurple$rollOwnBlackFlashChance(world, x, y, z, hudChanceOwner)) {
                // Roll real independiente de JJSK4 (que ya no tiene su
                // @ModifyConstant cargado, ver jar parcheado) y de JJKU.
                // ÚNICA fuente real: la maestría persistente de
                // /jjkmastery (base por CT + farmeado, con cap).
                //
                // No se fuerza cnt6 — ya no hace falta: el resultado real
                // lo decide directamente jjkblueredpurple$nullifyBaseBlackFlashConstant
                // (el @ModifyConstant de arriba), que lee este mismo flag.
                JJKBRP$ownRollConfirmedThisCall.set(true);
                data.putBoolean(KEY_BF_FORCED_WINDOW, true);
                data.putString(KEY_BF_FORCED_OWNER_UUID, hudChanceOwner.getStringUUID());
                MobEffectInstance preZone = hudChanceOwner.getEffect((MobEffect)JujutsucraftModMobEffects.ZONE.get());
                data.putInt(KEY_BF_FORCED_PRE_ZONE_DUR, preZone != null ? preZone.getDuration() : 0);
                JJKBRP$LOGGER.info("[JJKBRP-BF-DIAG] branch=OWN_ROLL_WIN roll confirmed for {}", hudChanceOwner.getName().getString());
            } else if (bfCd > 0 && liveCnt6 >= 0.0 && liveCnt6 < 5.0) {
                // Only suppress cnt6 for the addon's own short-cooldown ranged-proc throttle when
                // the incoming value has NOT already been forced into guaranteed-proc range by base
                // game/addon-independent logic (e.g. Itadori's AttackBlackFlashProcedure forcing
                // cnt6 = 5.0 for a guaranteed hit). Resetting an already-guaranteed cnt6 to 0.0 here
                // silently swallowed those guaranteed procs, since this mixin had no way to tell
                // "high cnt6 from a normal roll" apart from "high cnt6 forced by a guarantee".
                //
                // liveCnt6 >= 0.0 is required because several base-game multi-hit skills (e.g. the
                // Barrage/AttackContinueProcedure combo, AttackWeakSwordProcedure's sword combo)
                // intentionally set cnt6 to a NEGATIVE value on their non-finisher hits specifically
                // to block Black Flash on those hits (RangeAttackProcedure's own Black Flash gate
                // requires cnt6 >= 0.0 to even roll). Normalizing a negative cnt6 to 0.0 here defeats
                // that gate (0.0 satisfies >= 0.0), letting every intermediate hit of those combos
                // roll for Black Flash instead of only the intended finisher hit. Skipping this branch
                // entirely when liveCnt6 is already negative preserves that base-game block for any
                // current or future skill that uses the same pattern, addon-wide.
                JJKBRP$cnt6Backup.set(liveCnt6);
                data.putDouble("cnt6", 0.0);
                JJKBRP$LOGGER.info("[JJKBRP-BF-DIAG] branch=BF_CD_SUPPRESS cnt6 {} forced to 0.0 (bfCd={})", liveCnt6, bfCd);
            } else if (domainBonus > 0.0) {
                JJKBRP$cnt6Backup.set(liveCnt6);
                data.putDouble("cnt6", liveCnt6 + domainBonus);
                JJKBRP$LOGGER.info("[JJKBRP-BF-DIAG] branch=DOMAIN_BONUS cnt6 {} -> {}", liveCnt6, liveCnt6 + domainBonus);
            } else {
                JJKBRP$LOGGER.info("[JJKBRP-BF-DIAG] branch=NONE cnt6 left untouched at {}", liveCnt6);
            }
        }
    }


    // ===== CERTAIN BLACK FLASH DETECTION (same bytecode point stats already uses successfully) =====
    /**
     * Se inyecta en la lectura GETSTATIC del campo ENTITY_BLACK_FLASH —
     * el método base solo lo lee DENTRO del bloque if(BlackFlash) real,
     * así que si este inject se dispara, BlackFlash era true con certeza
     * absoluta, sin inferencias sobre ZONE ni ningún otro efecto.
     */
    @Inject(
        method = "execute",
        at = @At(
            value = "FIELD",
            target = "Lnet/mcreator/jujutsucraft/init/JujutsucraftModEntities;ENTITY_BLACK_FLASH:Lnet/minecraftforge/registries/RegistryObject;",
            opcode = org.objectweb.asm.Opcodes.GETSTATIC,
            remap = false
        )
    )
    private static void jjkblueredpurple$onRealBlackFlashConfirmed(LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {
        JJKBRP$realBlackFlashConfirmed.set(true);
    }


    /**
     * Runs after `RangeAttackProcedure.execute()` returns to restore temporary state, detect Black Flash procs from Zone duration changes, increment addon counters, and apply the short proc cooldown.
     * @param world world access used by the current mixin callback.
     * @param x world coordinate value used by this callback.
     * @param y world coordinate value used by this callback.
     * @param z world coordinate value used by this callback.
     * @param entity entity involved in the current mixin operation.
     * @param ci callback handle used to cancel or override the original procedure.
     */
    // Injects on method return so temporary runtime state can be restored or post-processing can run after the original logic completes.
    @Inject(method={"execute"}, at={@At(value="RETURN", ordinal=2)}, remap=false)
    private static void jjkblueredpurple$resetBlackFlash(LevelAccessor world, double x, double y, double z, Entity entity, CallbackInfo ci) {
        // Restore cnt6 from the thread-local backup FIRST, before any other logic in this method runs,
        // so that an exception or early return anywhere below can never prevent this from happening and
        // leaving cnt6 stuck at a forced value (e.g. 99999.0) on the entity's persistent NBT for future,
        // unrelated hits. See JJKBRP$cnt6Backup's declaration for the live-log evidence that motivated
        // moving this off persistent NBT and onto a ThreadLocal.
        Double cnt6Backup = JJKBRP$cnt6Backup.get();
        if (cnt6Backup != null) {
            JJKBRP$cnt6Backup.remove();
            if (entity != null) {
                entity.getPersistentData().putDouble("cnt6", cnt6Backup);
            }
        }
        // Limpieza del flag de confirmación del sistema propio de Black
        // Flash — debe limpiarse siempre, incondicionalmente, igual que el
        // resto de los ThreadLocal de este método, para que nunca quede
        // "pegado" en true para una sub-llamada futura no relacionada.
        JJKBRP$ownRollConfirmedThisCall.remove();
        JJKBRP$confirmedWasGuaranteed.remove();
        // Always read-and-clear here, unconditionally, so this can never leak into an unrelated
        // future hit regardless of which branch (if any) below ends up running.
        Boolean jjkblueredpurple$wasExternallyForced = JJKBRP$externallyForcedCnt6.get();
        JJKBRP$externallyForcedCnt6.remove();
        Player protectedOwner;
        Double originalRadius = JJKBRP$scaledDomainRadiusOriginal.get();
        if (originalRadius != null) {
            JJKBRP$scaledDomainRadiusOriginal.remove();
            try {
                JujutsucraftModVariables.MapVariables.get((LevelAccessor)world).DomainExpansionRadius = originalRadius;
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        if ((protectedOwner = JJKBRP$protectedOwner.get()) != null) {
            protectedOwner.setInvulnerable(false);
            JJKBRP$protectedOwner.remove();
        }
        if (entity == null) {
            return;
        }
        CompoundTag data = entity.getPersistentData();
        // ===== TEMP DIAGNOSTIC LOGGING (remove once root-caused) =====
        if (entity instanceof Player) {
            JJKBRP$LOGGER.info(
                    "[JJKBRP-BF-DIAG] RETURN entity={} cnt6_after_restore={} hadBackup={}",
                    entity.getName().getString(),
                    data.getDouble("cnt6"),
                    cnt6Backup != null
            );
        }
        // ===== END TEMP DIAGNOSTIC LOGGING =====
        if (data.getBoolean(KEY_RANK_DAMAGE_APPLIED)) {
            if (data.contains(KEY_RANK_DAMAGE_BACKUP)) {
                data.putDouble("Damage", data.getDouble(KEY_RANK_DAMAGE_BACKUP));
            }
            data.remove(KEY_RANK_DAMAGE_BACKUP);
            data.putBoolean(KEY_RANK_DAMAGE_APPLIED, false);
        }
        if (entity instanceof LivingEntity && AddonGameRules.blackFlash(entity) && !world.isClientSide()) {
            boolean bfJustProcced;
            LivingEntity le = (LivingEntity)entity;
            ServerPlayer forcedOwner = RangeAttackProcedureMixin.jjkblueredpurple$resolveForcedBlackFlashOwner(world, data);
            LivingEntity procSource = forcedOwner != null ? forcedOwner : le;
            boolean forcedWindow = data.getBoolean(KEY_BF_FORCED_WINDOW);
            // Detección CERTERA, única fuente de verdad: JJKBRP$realBlackFlashConfirmed
            // solo está en true si el inject de arriba (mismo punto de bytecode
            // GETSTATIC ENTITY_BLACK_FLASH que stats ya usa con éxito) se
            // disparó durante ESTA llamada al método base — es decir,
            // BlackFlash realmente fue true ahí dentro. Ya no se usa ZONE
            // para nada (ni para decidir ni para inferir): era una heurística
            // vieja (sesión previa) que asumía mal el comportamiento real de
            // addEffect con duraciones iguales/no estrictamente mayores,
            // dando falsos negativos en la rama de garantía forzada.
            boolean rawConfirmed = Boolean.TRUE.equals(JJKBRP$realBlackFlashConfirmed.get());
            boolean bl = bfJustProcced = rawConfirmed;
            JJKBRP$realBlackFlashConfirmed.remove();
            if (procSource instanceof Player) {
                JJKBRP$LOGGER.info(
                        "[JJKBRP-BF-DIAG] PROC-CHECK entity={} forcedWindow={} rawConfirmed={} bfJustProcced={}",
                        procSource.getName().getString(), forcedWindow, rawConfirmed, bfJustProcced
                );
            }
            if (bfJustProcced) {
                // Cooldown propio simple tras cada proc real, configurable
                // (default 0 = sin cooldown extra, ya que el chequeo
                // geométrico de rollOwnBlackFlashChance ya resuelve el
                // problema real de inflación dentro de un mismo golpe). Si
                // se quiere un cooldown entre golpes DISTINTOS además, se
                // puede setear con /jjkbfcooldown <ticks> — 0 por default.
                if (procSource instanceof ServerPlayer cooldownPlayer) {
                    int ownCooldownTicks = cooldownPlayer.getPersistentData().getInt(KEY_OWN_BF_COOLDOWN_TICKS_CONFIG);
                    if (ownCooldownTicks > 0) {
                        cooldownPlayer.getPersistentData().putLong(KEY_OWN_BF_COOLDOWN_UNTIL, cooldownPlayer.level().getGameTime() + ownCooldownTicks);
                    }
                }
                ServerPlayer guaranteeOwner = forcedOwner != null ? forcedOwner : RangeAttackProcedureMixin.jjkblueredpurple$resolveGuaranteedBlackFlashOwner(world, entity, data);
                CompoundTag counterData = procSource.getPersistentData();
                int totalHits = counterData.getInt("addon_bf_total_hits");
                int newTotalHits = totalHits + 1;
                // Successful procs permanently increase the tracked Black Flash hit counter used by other addon systems.
                counterData.putInt("addon_bf_total_hits", newTotalHits);
                ServerPlayer progressPlayer = forcedOwner != null ? forcedOwner : (le instanceof ServerPlayer ? (ServerPlayer)le : null);
                RangeAttackProcedureMixin.jjkblueredpurple$notifyBlackFlashProgress(progressPlayer, newTotalHits);
                // Mastery growth moved to jjkblueredpurple$onRealBlackFlashProc below, which hooks the
                // exact same point stats's own RangeAttackProcedureMixin uses (the GETSTATIC read of
                // ENTITY_BLACK_FLASH, only reached when BlackFlash is actually true) instead of this
                // ZONE-duration-jump heuristic. That heuristic is what made mastery feel like it grew
                // "whenever it felt like it" — dur>lastDur can fail to register a real proc if ZONE was
                // already near its cap from a recent hit, even though BlackFlash was genuinely true.
                int ndCd = counterData.getInt("jjkbrp_near_death_cd");
                if (ndCd > 0 && AddonGameRules.nearDeath(procSource)) {
                    counterData.putInt("jjkbrp_near_death_cd", Math.max(0, ndCd - 600));
                }
                // Apply the short ranged Black Flash cooldown only to random/addon-boosted procs. Timed guaranteed Black Flash must ignore this cooldown.
                if (guaranteeOwner == null) {
                    counterData.putInt(KEY_BF_CD, 60);
                }
                counterData.putBoolean(KEY_BF_ND_HANDLED, true);
                counterData.putBoolean("jjkbrp_bf_regen_boost", true);
                // BUG REAL ENCONTRADO Y CORREGIDO: antes, cuando forcedOwner
                // venía de HUD_ROLL_WIN (roll de maestría simple, sin
                // minijuego de timing), se llamaba a
                // confirmBlackFlashGuaranteeHit — un método diseñado
                // específicamente para el flujo de garantía CON minijuego
                // (Todo/Plus Ultra), que exige un estado (BF_STATE_WAITING_HIT,
                // addon_bf_guaranteed, addon_bf_waiting_hit) que un roll de
                // maestría simple NUNCA activa. Esa llamada siempre fallaba
                // en silencio (return false sin avisar), así que el
                // jugador nunca veía el mensaje ni el efecto, aunque el
                // contador interno de hits sí se incrementaba (línea de
                // arriba) — de ahí que a veces sí contara para la barra de
                // output pero nunca se viera/sintiera el Black Flash real.
                // Ahora: solo la garantía REAL con minijuego (ADDON_GUARANTEE,
                // que sí setea ese estado) usa confirmBlackFlashGuaranteeHit;
                // cualquier otro caso (HUD_ROLL_WIN incluido) manda el
                // feedback directo, igual que un proc normal del juego.
                boolean isTimedGuarantee = guaranteeOwner != null
                        && BlueRedPurpleNukeMod.BF_STATE_WAITING_HIT.equals(
                                BlueRedPurpleNukeMod.getBlackFlashState(guaranteeOwner.getPersistentData()));
                if (isTimedGuarantee) {
                    BlueRedPurpleNukeMod.confirmBlackFlashGuaranteeHit(guaranteeOwner);
                } else if (le instanceof ServerPlayer serverPlayer) {
                    net.mcreator.jujutsucraft.addon.ModNetworking.sendBlackFlashFeedback(serverPlayer, true, true);
                }
            }
            data.putBoolean(KEY_BF_FORCED_WINDOW, false);
            data.remove(KEY_BF_FORCED_OWNER_UUID);
            data.remove(KEY_BF_FORCED_PRE_ZONE_DUR);
        }
    }


    // ===== RUNTIME RADIUS SUPPORT =====
    /**
     * Temporarily swaps the shared domain radius with the caster's actual mastery-scaled radius so range-based attack logic sees the correct value during execution.
     * @param world world access used by the current mixin callback.
     * @param entity entity involved in the current mixin operation.
     */
    // Marks this helper member as mixin-unique so it cannot collide with names inside the target class.
    @Unique
    private static void jjkblueredpurple$scaleDomainAttackRadius(LevelAccessor world, Entity entity) {
        JJKBRP$scaledDomainRadiusOriginal.remove();
        if (world.isClientSide() || entity == null || !AddonGameRules.domainRadiusRules(world)) {
            return;
        }
        LivingEntity radiusSource = DomainAddonUtils.resolveOwnerEntity(world, entity);
        if (radiusSource == null && entity instanceof LivingEntity) {
            LivingEntity living;
            radiusSource = living = (LivingEntity)entity;
        }
        if (radiusSource == null || !DomainAddonUtils.hasActiveDomainExpansion(radiusSource)) {
            return;
        }
        CompoundTag radiusNbt = radiusSource.getPersistentData();
        if (!radiusNbt.contains("jjkbrp_base_domain_radius")) {
            return;
        }
        try {
            JujutsucraftModVariables.MapVariables mapVars = JujutsucraftModVariables.MapVariables.get((LevelAccessor)world);
            double original = mapVars.DomainExpansionRadius;
            double scaled = DomainAddonUtils.getActualDomainRadius(world, radiusNbt);
            if (RangeAttackProcedureMixin.jjkblueredpurple$isShrineDomainSource(radiusSource)) {
                scaled = Math.max(6.0, scaled);
            }
            if (Math.abs(original - scaled) < 1.0E-4) {
                return;
            }
            JJKBRP$scaledDomainRadiusOriginal.set(original);
            // Match integer-rounding used by other addon radius mixins so range-attack hits
            // place sphere blocks at the same boundary as the barrier builder.
            mapVars.DomainExpansionRadius = Math.max(1.0, Math.round(scaled));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }


    // ===== DOMAIN STATE HELPERS =====
    /**
     * Checks whether the current ranged attack belongs to an incomplete domain and therefore must skip sure-hit handling entirely.
     * @param world world access used by the current mixin callback.
     * @param entity entity involved in the current mixin operation.
     * @param data persistent data container used by this helper.
     * @return whether is incomplete domain attack is true for the current runtime state.
     */
    // Marks this helper member as mixin-unique so it cannot collide with names inside the target class.
    @Unique
    private static boolean jjkblueredpurple$isIncompleteDomainAttack(LevelAccessor world, Entity entity, CompoundTag data) {
        if (data == null || !data.getBoolean("DomainAttack")) {
            return false;
        }
        LivingEntity domainStateSource = RangeAttackProcedureMixin.jjkblueredpurple$resolveDomainStateSource(world, entity, data);
        if (domainStateSource == null || !AddonGameRules.domainForms(domainStateSource)) {
            return false;
        }
        if (RangeAttackProcedureMixin.jjkblueredpurple$isSpecialSukunaIncompleteSureHit(domainStateSource)) {
            return false;
        }
        return domainStateSource != null && domainStateSource.hasEffect((MobEffect)JujutsucraftModMobEffects.DOMAIN_EXPANSION.get()) && DomainAddonUtils.isIncompleteDomainState(domainStateSource);
    }

    @Unique
    private static boolean jjkblueredpurple$isSpecialSukunaIncompleteSureHit(LivingEntity domainStateSource) {
        if (domainStateSource == null || !AddonGameRules.sukunaIncompleteSurehit(domainStateSource)) {
            return false;
        }
        if (!DomainAddonUtils.isActiveSukunaIncompleteShrine(domainStateSource)) {
            return false;
        }
        CompoundTag data = domainStateSource.getPersistentData();
        data.putBoolean("jjkbrp_sukuna_incomplete_surehit_active", true);
        data.putBoolean("jjkbrp_sukuna_incomplete_surehit_had_domain", true);
        return true;
    }

    @Unique
    private static double jjkblueredpurple$getSukunaIncompleteSureHitRange(LevelAccessor world, LivingEntity domainStateSource) {
        if (domainStateSource == null) {
            return 40.0;
        }
        double baseRadius = DomainAddonUtils.getActualDomainRadius(world, domainStateSource.getPersistentData());
        double openMultiplier = Math.max(2.5, domainStateSource.getPersistentData().getDouble("jjkbrp_open_range_multiplier"));
        return baseRadius * openMultiplier * AddonGameRules.percent(world, AddonGameRules.SUKUNA_INCOMPLETE_SUREHIT_RANGE_PERCENT, 100);
    }

    @Unique
    private static void jjkblueredpurple$replayIncompleteShrineVisualHit(LevelAccessor world, double x, double y, double z, Entity entity, CompoundTag data, LivingEntity domainStateSource) {
        if (!(world instanceof ServerLevel) || entity == null || data == null || !RangeAttackProcedureMixin.jjkblueredpurple$isShrineDomainSource(domainStateSource)) {
            return;
        }
        double range = data.getDouble("Range");
        if (range <= 0.0) {
            return;
        }
        ServerLevel serverLevel = (ServerLevel)world;
        Vec3 center = new Vec3(x, y, z);
        AABB hitBox = new AABB(center, center).inflate(range / 2.0);
        List<Entity> targets = serverLevel.getEntitiesOfClass(Entity.class, hitBox, target -> target instanceof LivingEntity);
        for (Entity target : targets) {
            if (target == entity || !LogicAttackProcedure.execute(world, entity, target)) {
                continue;
            }
            RangeAttackProcedureMixin.jjkblueredpurple$sendIncompleteShrineHitVfx(serverLevel, entity, target);
        }
    }

    @Unique
    private static boolean jjkblueredpurple$isShrineDomainSource(LivingEntity domainStateSource) {
        if (!(domainStateSource instanceof Player) || !AddonGameRules.sukunaIncompleteSurehit(domainStateSource)) {
            return false;
        }
        CompoundTag nbt = domainStateSource.getPersistentData();
        int domainId = (int)Math.round(nbt.getDouble("jjkbrp_domain_id_runtime"));
        if (domainId <= 0) {
            domainId = (int)Math.round(nbt.getDouble("skill_domain"));
        }
        if (domainId <= 0) {
            domainId = (int)Math.round(nbt.getDouble("select"));
        }
        return domainId == 1;
    }

    @Unique
    private static void jjkblueredpurple$sendIncompleteShrineHitVfx(ServerLevel world, Entity caster, Entity target) {
        double xPos = target.getX();
        double yPos = target.getY() + caster.getBbHeight() * 0.5;
        double zPos = target.getZ();
        double sizeWidth = target.getBbWidth() * 0.3;
        double sizeHeight = target.getBbHeight() * 0.3;
        int count = (int)Math.max(1L, Math.round((sizeHeight + sizeWidth) * 1.5));
        SoundEvent crush = ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("jujutsucraft:crush"));
        if (crush != null) {
            world.playSound(null, BlockPos.containing(xPos, yPos, zPos), crush, SoundSource.NEUTRAL, 0.5F, (float)(1.0 + Math.random() * 0.5));
        }
        String command = "particle jujutsucraft:particle_slash " + xPos + " " + yPos + " " + zPos + " " + sizeWidth + " " + sizeHeight + " " + sizeWidth + " 0 " + count + " normal";
        for (Entity viewer : world.getAllEntities()) {
            if (!CanSeeSukunaSlashProcedure.execute(world, caster, viewer)) {
                continue;
            }
            world.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, viewer.position(), Vec2.ZERO, world, 4, "", Component.literal(""), world.getServer(), viewer).withSuppressedOutput(), command);
        }
        world.sendParticles((ParticleOptions)ParticleTypes.CRIT, xPos, yPos, zPos, count, sizeWidth, sizeHeight, sizeWidth, 0.5);
        if (target.isAlive() && Math.random() < 0.5) {
            ParticleOptions blood = target.getPersistentData().getBoolean("CursedSpirit")
                    ? (ParticleOptions)JujutsucraftModParticleTypes.PARTICLE_BLOOD_PURPLE.get()
                    : (ParticleOptions)JujutsucraftModParticleTypes.PARTICLE_BLOOD_RED.get();
            world.sendParticles(blood, xPos, yPos, zPos, 1, 0.2, 0.2, 0.2, 0.25);
        }
    }

    /**
     * Checks raw persistent-data flags that mark an entity or spawned attack as being in incomplete-domain form.
     * @param data persistent data container used by this helper.
     * @return whether is incomplete domain state is true for the current runtime state.
     */
    // Marks this helper member as mixin-unique so it cannot collide with names inside the target class.
    @Unique
    private static boolean jjkblueredpurple$isIncompleteDomainState(CompoundTag data) {
        if (data == null) {
            return false;
        }
        if (data.getBoolean("jjkbrp_incomplete_form_active")) {
            return true;
        }
        if (data.contains("jjkbrp_domain_form_cast_locked") && data.getInt("jjkbrp_domain_form_cast_locked") == 0) {
            return true;
        }
        return data.contains("jjkbrp_domain_form_effective") && data.getInt("jjkbrp_domain_form_effective") == 0;
    }

    /**
     * Checks raw persistent-data flags that mark an entity or spawned attack as being in open-domain form.
     * @param data persistent data container used by this helper.
     * @return whether is open domain state is true for the current runtime state.
     */
    // Marks this helper member as mixin-unique so it cannot collide with names inside the target class.
    @Unique
    private static boolean jjkblueredpurple$isOpenDomainState(CompoundTag data) {
        if (data == null) {
            return false;
        }
        if (data.getBoolean("jjkbrp_open_form_active")) {
            return true;
        }
        if (data.contains("jjkbrp_domain_form_cast_locked") && data.getInt("jjkbrp_domain_form_cast_locked") == 2) {
            return true;
        }
        return data.contains("jjkbrp_domain_form_effective") && data.getInt("jjkbrp_domain_form_effective") == 2;
    }

    /**
     * Resolves the living entity whose domain-state flags should control the current ranged attack instance.
     * @param world world access used by the current mixin callback.
     * @param entity entity involved in the current mixin operation.
     * @param data persistent data container used by this helper.
     * @return the resulting resolve domain state source value.
     */
    // Marks this helper member as mixin-unique so it cannot collide with names inside the target class.
    @Unique
    private static LivingEntity jjkblueredpurple$resolveDomainStateSource(LevelAccessor world, Entity entity, CompoundTag data) {
        LivingEntity living;
        LivingEntity owner = DomainAddonUtils.resolveOwnerEntity(world, entity);
        if (owner != null) {
            return owner;
        }
        return entity instanceof LivingEntity ? (living = (LivingEntity)entity) : null;
    }

    /**
     * Cancels direct Blue AI damage when the same victim would be hit again before the short anti-multihit cooldown expires.
     * Red no longer uses this coarse path because OG crouch Red still needs its repeated `RangeAttackProcedure.execute()` calls for terrain and world behavior.
     * @param world world access used by the current mixin callback.
     * @param x world coordinate value used by this callback.
     * @param y world coordinate value used by this callback.
     * @param z world coordinate value used by this callback.
     * @param entity entity involved in the current mixin operation.
     * @param data persistent data container used by this helper.
     * @return whether the current Blue damage tick should be cancelled.
     */
    @Unique
    private static boolean jjkblueredpurple$cancelBlueDamageCooldown(LevelAccessor world, double x, double y, double z, Entity entity, CompoundTag data) {
        return false;
    }

    /**
     * Redirects Red's light Black Flash probe hit so cooldown suppression can be applied per target without cancelling the rest of the original procedure.
     */
    @Redirect(method={"execute"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/entity/Entity;m_6469_(Lnet/minecraft/world/damagesource/DamageSource;F)Z", ordinal=0), remap=false)
    private static boolean jjkblueredpurple$redirectProbeDamage(Entity target, DamageSource source, float amount, LevelAccessor world, double x, double y, double z, Entity entity) {
        return RangeAttackProcedureMixin.jjkblueredpurple$applyRedirectedRangeDamage(target, source, amount, world, entity, false);
    }

    /**
     * Redirects the real ranged damage call so Red can keep OG block destruction and movement while repeated entity damage is suppressed per victim.
     */
    @Redirect(method={"execute"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/entity/Entity;m_6469_(Lnet/minecraft/world/damagesource/DamageSource;F)Z", ordinal=1), remap=false)
    private static boolean jjkblueredpurple$redirectFinalDamage(Entity target, DamageSource source, float amount, LevelAccessor world, double x, double y, double z, Entity entity) {
        return RangeAttackProcedureMixin.jjkblueredpurple$applyRedirectedRangeDamage(target, source, amount, world, entity, true);
    }

    /**
     * Applies per-target Red cooldown gating at the actual hurt call site so OG crouch Red can continue running world/block logic every tick while entities only take the first valid hit inside the cooldown window.
     */
    @Unique
    private static boolean jjkblueredpurple$applyRedirectedRangeDamage(Entity target, DamageSource source, float amount, LevelAccessor world, Entity attacker, boolean commitCooldown) {
        return target.hurt(source, amount);
    }

    /**
     * Applies rank-based damage scaling for addon RED/BLUE/PURPLE paths that route through RangeAttackProcedure.
     * @param world world access used by the current mixin callback.
     * @param entity entity involved in the current mixin operation.
     * @param data persistent data container used by this helper.
     */
    @Unique
    private static void jjkblueredpurple$applyRankDamageScale(LevelAccessor world, Entity entity, CompoundTag data) {
        if (data == null || entity == null || data.getBoolean(KEY_RANK_DAMAGE_APPLIED) || !data.contains("Damage")) {
            return;
        }
        if (!AddonGameRules.enabled(world, AddonGameRules.GOJO_ENABLED, AddonGameRules.GOJO_RANK_DAMAGE_SCALING_ENABLED)) {
            return;
        }
        if (entity instanceof RedEntity || entity instanceof BlueEntity || entity instanceof PurpleEntity) {
            return;
        }
        if (RangeAttackProcedureMixin.jjkblueredpurple$isOgCrouchLowChargeRed(entity, data)) {
            return;
        }
        double ownerRankScale = 1.0;
        double rankScale = 1.0;
        if (entity instanceof RedEntity || entity instanceof BlueEntity || entity instanceof PurpleEntity && data.getBoolean("addon_purple_fusion")) {
            ownerRankScale = RangeAttackProcedureMixin.jjkblueredpurple$getOwnerRankDamageScale(world, data.getString("OWNER_UUID"));
            rankScale = RangeAttackProcedureMixin.jjkblueredpurple$getAdjustedInfinityTechniqueRankScale(entity, data, ownerRankScale);
        }
        if (rankScale <= 1.0) {
            return;
        }
        data.putDouble(KEY_RANK_DAMAGE_BACKUP, data.getDouble("Damage"));
        data.putDouble("Damage", data.getDouble("Damage") * rankScale);
        data.putBoolean(KEY_RANK_DAMAGE_APPLIED, true);
    }

    /**
     * Detects the original crouch low-charge Red route so its base AIRed damage stays unmodified by addon owner-rank scaling.
     * @param entity entity involved in the current mixin operation.
     * @param data persistent data container used by this helper.
     * @return whether the current Red attack is the OG crouch low-charge route.
     */
    @Unique
    private static boolean jjkblueredpurple$isOgCrouchLowChargeRed(Entity entity, CompoundTag data) {
        if (!(entity instanceof RedEntity) || data == null || !data.getBoolean("addon_red_use_og")) {
            return false;
        }
        boolean routeLocked = data.getBoolean("addon_red_route_mode_locked") || data.getBoolean("addon_red_crouch_cast_seen");
        if (!routeLocked) {
            return false;
        }
        double routedCharge = Math.max(Math.max(data.getDouble("cnt6"), data.getDouble("addon_red_route_charge")), Math.max(data.getDouble("addon_red_charge_cached"), data.getDouble("addon_red_charge_used")));
        return routedCharge < 5.0;
    }

    /**
     * Resolves Infinity-technique rank scaling for RangeAttackProcedure paths so Blue uses its damped per-pass helper, Red shift-finisher uses a narrower finisher-only scale, and Purple fusion keeps its existing direct owner-rank behavior.
     * @param entity entity involved in the current mixin operation.
     * @param data persistent data container used by this helper.
     * @param ownerRankScale raw owner-rank multiplier resolved for the current cast.
     * @return adjusted rank multiplier suitable for the current attack path.
     */
     @Unique
     private static double jjkblueredpurple$getAdjustedInfinityTechniqueRankScale(Entity entity, CompoundTag data, double ownerRankScale) {
         int passIndex = RangeAttackProcedureMixin.jjkblueredpurple$nextInfinityTechniquePass(data);
         if (entity instanceof BlueEntity) {
             return BlueRedPurpleNukeMod.getBlueRankScaleForPass(ownerRankScale, passIndex);
         }
         if (entity instanceof RedEntity) {
             if (data.getBoolean("addon_red_shift_finisher_damage_active")) {
                 return BlueRedPurpleNukeMod.getRedShiftFinisherRankScaleForPass(ownerRankScale, passIndex);
             }
             return BlueRedPurpleNukeMod.getDirectOwnerRankScaleForPass(ownerRankScale, passIndex);
         }
         if (entity instanceof PurpleEntity && data.getBoolean("addon_purple_fusion")) {
             return BlueRedPurpleNukeMod.getDirectOwnerRankScaleForPass(ownerRankScale, passIndex);
         }
         return ownerRankScale;
     }

    /**
     * Advances the per-cast Infinity rank-pass counter so multi-hit skills cannot reuse the full rank multiplier on every `RangeAttackProcedure.execute()` call.
     * @param data persistent data container used by this helper.
     * @return one-based rank pass index for the current Infinity cast.
     */
    @Unique
    private static int jjkblueredpurple$nextInfinityTechniquePass(CompoundTag data) {
        int passIndex = Math.max(0, data.getInt(KEY_INFINITY_RANK_PASS_COUNT)) + 1;
        data.putInt(KEY_INFINITY_RANK_PASS_COUNT, passIndex);
        return passIndex;
    }

    /**
     * Resolves rank damage scaling by mirroring the base mod's damage-fix behavior on the owner.
     * @param world world access used by the current mixin callback.
     * @param ownerUUID identifier used to resolve runtime state for this operation.
     * @return rank multiplier resolved for the current owner.
     */
    @Unique
    private static double jjkblueredpurple$getOwnerRankDamageScale(LevelAccessor world, String ownerUUID) {
        Player owner = RangeAttackProcedureMixin.jjkblueredpurple$resolvePlayerOwner(world, ownerUUID);
        if (!(owner instanceof ServerPlayer)) {
            return 1.0;
        }
        ServerPlayer player = (ServerPlayer)owner;
        return RangeAttackProcedureMixin.jjkblueredpurple$getDamageFixEquivalentScale(player);
    }

    /**
     * Converts a player level into the same baseline damage gain shape used by base Strength-driven combat.
     * @param playerLevel level value used by this helper.
     * @return converted baseline damage scale.
     */
    @Unique
    private static double jjkblueredpurple$getScaleFromPlayerLevel(double playerLevel) {
        if (playerLevel <= 0.0) {
            return 1.0;
        }
        double level = Math.max(playerLevel - 1.0, 0.0);
        double levelPower = Math.round(level);
        if (levelPower < 3.0) {
            levelPower = Math.min(levelPower, 1.0);
        }
        // Base formula: Damage *= 1 + ((1 + StrengthAmp) * 0.333), where StrengthAmp is derived from level.
        return Math.max(1.0, 1.0 + (1.0 + levelPower) * 0.333);
    }

    /**
     * Pulls owner `PlayerLevel` from capability data and converts it to base-like damage scaling.
     * @param player entity involved in the current mixin operation.
     * @return capability-derived damage scale.
     */
    @Unique
    private static double jjkblueredpurple$getPlayerLevelDamageScale(ServerPlayer player) {
        JujutsucraftModVariables.PlayerVariables vars = (JujutsucraftModVariables.PlayerVariables)player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(null);
        if (vars == null) {
            return 1.0;
        }
        return RangeAttackProcedureMixin.jjkblueredpurple$getScaleFromPlayerLevel(vars.PlayerLevel);
    }

    /**
     * Uses completed grade advancements as a fallback baseline when capability data is stale.
     * @param player entity involved in the current mixin operation.
     * @return advancement-derived baseline scale.
     */
    @Unique
    private static double jjkblueredpurple$getAdvancementRankDamageScale(ServerPlayer player) {
        if (RangeAttackProcedureMixin.jjkblueredpurple$hasAdvancement(player, "jujutsucraft:sorcerer_grade_special")) {
            return RangeAttackProcedureMixin.jjkblueredpurple$getScaleFromPlayerLevel(20.0);
        }
        if (RangeAttackProcedureMixin.jjkblueredpurple$hasAdvancement(player, "jujutsucraft:sorcerer_grade_1")) {
            return RangeAttackProcedureMixin.jjkblueredpurple$getScaleFromPlayerLevel(13.0);
        }
        if (RangeAttackProcedureMixin.jjkblueredpurple$hasAdvancement(player, "jujutsucraft:sorcerer_grade_1_semi")) {
            return RangeAttackProcedureMixin.jjkblueredpurple$getScaleFromPlayerLevel(11.0);
        }
        if (RangeAttackProcedureMixin.jjkblueredpurple$hasAdvancement(player, "jujutsucraft:sorcerer_grade_2")) {
            return RangeAttackProcedureMixin.jjkblueredpurple$getScaleFromPlayerLevel(9.0);
        }
        if (RangeAttackProcedureMixin.jjkblueredpurple$hasAdvancement(player, "jujutsucraft:sorcerer_grade_2_semi")) {
            return RangeAttackProcedureMixin.jjkblueredpurple$getScaleFromPlayerLevel(7.0);
        }
        if (RangeAttackProcedureMixin.jjkblueredpurple$hasAdvancement(player, "jujutsucraft:sorcerer_grade_3")) {
            return RangeAttackProcedureMixin.jjkblueredpurple$getScaleFromPlayerLevel(4.0);
        }
        if (RangeAttackProcedureMixin.jjkblueredpurple$hasAdvancement(player, "jujutsucraft:sorcerer_grade_4")) {
            return RangeAttackProcedureMixin.jjkblueredpurple$getScaleFromPlayerLevel(2.0);
        }
        return 1.0;
    }

    /**
     * Reproduces the core DamageFix multipliers from the owner's current effects and attack attribute.
     * @param player entity involved in the current mixin operation.
     * @return live damage-fix equivalent scale.
     */
    @Unique
    private static double jjkblueredpurple$getDamageFixEquivalentScale(ServerPlayer player) {
        double strengthLevel = 0.0;
        if (player.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE)) {
            strengthLevel += player.getAttributeValue(Attributes.ATTACK_DAMAGE) * 0.333;
        }
        MobEffectInstance strength = player.getEffect(MobEffects.DAMAGE_BOOST);
        if (strength != null) {
            strengthLevel += 1.0 + strength.getAmplifier();
        }
        MobEffectInstance weakness = player.getEffect(MobEffects.WEAKNESS);
        if (weakness != null) {
            strengthLevel -= 1.0 + weakness.getAmplifier();
        }
        double scale = 1.0 + strengthLevel * 0.333;
        MobEffectInstance zone = player.getEffect((MobEffect)JujutsucraftModMobEffects.ZONE.get());
        if (zone != null) {
            scale *= 1.2 + 0.1 * zone.getAmplifier();
        }
        return Math.max(scale, 1.0);
    }

    /**
     * Sends a red Close Call-style Black Flash mastery progress chat line to the player that actually performed the proc.
     * @param player player instance involved in this operation.
     * @param currentHits current Black Flash hit total after the successful proc.
     */
    @Unique
    private static void jjkblueredpurple$notifyBlackFlashProgress(ServerPlayer player, int currentHits) {
        if (player == null || player.level().isClientSide()) {
            return;
        }
        if (!AddonGameRules.enabled(player, AddonGameRules.BLACK_FLASH_ENABLED, AddonGameRules.BLACK_FLASH_MASTERY_ENABLED)) {
            return;
        }
        CompoundTag data = player.getPersistentData();
        if (data.getBoolean("addon_bf_mastery") || RangeAttackProcedureMixin.jjkblueredpurple$hasAdvancement(player, "jjkblueredpurple:black_flash_mastery")) {
            return;
        }
        int threshold = RangeAttackProcedureMixin.jjkblueredpurple$getBlackFlashMasteryThreshold(player);
        if (currentHits >= threshold) {
            return;
        }
        int remaining = threshold - currentHits;
        int milestone = (int)Math.floor((double)currentHits * 100.0 / (double)Math.max(1, threshold));
        String bar = RangeAttackProcedureMixin.jjkblueredpurple$progressBar(currentHits, threshold, 24);
        String title = "\u00a74\u26a1 \u00a70Black \u00a7cFlash";
        String msg = milestone >= 90 ? title + " \u00a7c" + currentHits + "\u00a70/\u00a7c" + threshold + " \u00a70[" + bar + "\u00a70] \u00a7f— \u00a7a" + remaining + " more!"
                : (milestone >= 75 ? title + " \u00a7c" + currentHits + "\u00a70/\u00a7c" + threshold + " \u00a70[" + bar + "\u00a70] \u00a7f— \u00a7eAlmost there!"
                : title + " \u00a7c" + currentHits + "\u00a70/\u00a7c" + threshold + " \u00a70[" + bar + "\u00a70]");
        player.displayClientMessage((Component)Component.literal((String)msg), false);
    }

    /**
     * Builds a compact text progress bar matching the Close Call progression layout.
     * @param current current progress value.
     * @param max maximum progress value.
     * @param width number of bar characters to render.
     * @return formatted bar contents.
     */
    @Unique
    private static String jjkblueredpurple$progressBar(int current, int max, int width) {
        int filled = (int)Math.round((double)Math.max(0, current) * (double)width / (double)Math.max(1, max));
        filled = Math.max(0, Math.min(width, filled));
        StringBuilder sb = new StringBuilder(width * 3);
        for (int i = 0; i < width; ++i) {
            sb.append(i < filled ? "\u00a7c\u2588" : "\u00a78\u2591");
        }
        return sb.toString();
    }

    /**
     * Resolves the current player's Black Flash mastery threshold, including Yuji's reduced requirement.
     * @param player player instance involved in this operation.
     * @return 50 for Yuji, otherwise 100.
     */
    @Unique
    private static int jjkblueredpurple$getBlackFlashMasteryThreshold(ServerPlayer player) {
        JujutsucraftModVariables.PlayerVariables vars = (JujutsucraftModVariables.PlayerVariables)player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new JujutsucraftModVariables.PlayerVariables());
        double activeTech = vars.SecondTechnique ? vars.PlayerCurseTechnique2 : vars.PlayerCurseTechnique;
        int base = (int)Math.round(activeTech) == 21 ? 50 : 100;
        return Math.max(1, (int)Math.round(base * AddonGameRules.percent(player, AddonGameRules.BLACK_FLASH_MASTERY_THRESHOLD_PERCENT, 100)));
    }

    /**
     * Checks whether the owner has completed a specific advancement.
     * @param player entity involved in the current mixin operation.
     * @param advancementId identifier used to resolve runtime state for this operation.
     * @return true when the advancement is completed; otherwise false.
     */
    @Unique
    private static boolean jjkblueredpurple$hasAdvancement(ServerPlayer player, String advancementId) {
        try {
            Advancement adv = player.server.getAdvancements().getAdvancement(new ResourceLocation(advancementId));
            if (adv == null) {
                return false;
            }
            AdvancementProgress progress = player.getAdvancements().getOrStartProgress(adv);
            return progress.isDone();
        }
        catch (Exception ignored) {
            return false;
        }
    }

    /**
     * Replica EXACTAMENTE la condición real de LogicItadoriModuloProcedure
     * (JJSK4): PlayerCurseTechnique==21.0 (Itadori) Y advancement
     * "jujutsucrafts:skill_itadori_modulo" desbloqueado, O modo creativo,
     * O instancia de la entidad ItadoriYujiModuloEntity (chequeada por
     * nombre de clase simple, sin import directo de JJSK4, para no atar
     * la compilación de este addon a la presencia de ese mod específico).
     */
    private static boolean jjkblueredpurple$isItadoriModulo(LevelAccessor world, Entity entity) {
        if (entity == null) {
            return false;
        }
        if ("ItadoriYujiModuloEntity".equals(entity.getClass().getSimpleName())) {
            return true;
        }
        if (!(entity instanceof ServerPlayer player)) {
            return false;
        }
        // CRÍTICO (bug real confirmado): la estructura real de paréntesis
        // del código fuente de JJSK4 es (CT==21) && (advancement ||
        // creativo) — el chequeo de modo creativo SOLO cuenta si el CT YA
        // es Itadori (21), no es una condición independiente. La versión
        // anterior trataba "instabuild" como un atajo aislado, sin exigir
        // el CT primero, así que CUALQUIER jugador en creativo activaba
        // la garantía sin importar su técnica real — confirmado que esto
        // es lo que rompía todos los ataques físicos.
        double ct1 = player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null)
                .map(v -> v.PlayerCurseTechnique).orElse(-1.0);
        double ct2 = player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null)
                .map(v -> v.PlayerCurseTechnique2).orElse(-1.0);
        boolean isItadori = ct1 == 21.0 || ct2 == 21.0;
        if (!isItadori) {
            return false;
        }
        boolean hasAdvancement = RangeAttackProcedureMixin.jjkblueredpurple$hasAdvancement(player, "jujutsucrafts:skill_itadori_modulo");
        boolean isCreative = player.getAbilities().instabuild;
        return hasAdvancement || isCreative;
    }

    @Unique
    private static ServerPlayer jjkblueredpurple$resolveForcedBlackFlashOwner(LevelAccessor world, CompoundTag data) {
        if (!(world instanceof ServerLevel) || data == null || !data.getBoolean(KEY_BF_FORCED_WINDOW)) {
            return null;
        }
        String ownerUuid = data.getString(KEY_BF_FORCED_OWNER_UUID);
        if (ownerUuid == null || ownerUuid.isEmpty()) {
            return null;
        }
        try {
            return ((ServerLevel)world).getServer().getPlayerList().getPlayer(UUID.fromString(ownerUuid));
        }
        catch (Exception ignored) {
            return null;
        }
    }

    @Unique
    private static ServerPlayer jjkblueredpurple$resolveGuaranteedBlackFlashOwner(LevelAccessor world, Entity entity, CompoundTag data) {
        if (!(world instanceof ServerLevel)) {
            return null;
        }
        ServerPlayer player = null;
        if (entity instanceof ServerPlayer serverPlayer) {
            player = serverPlayer;
        } else {
            Player owner = RangeAttackProcedureMixin.jjkblueredpurple$resolvePlayerOwner(world, data.getString("OWNER_UUID"));
            if (owner instanceof ServerPlayer serverOwner) {
                player = serverOwner;
            }
        }
        if (player == null || !BlueRedPurpleNukeMod.isBlackFlashGuaranteeActive(player)) {
            return null;
        }
        return player;
    }

    /**
     * Resolves the player whose live HUD Black Flash chance ({@code addon_bf_chance}, computed in
     * CooldownTrackerEvents from base/combat/domain/mastery bonuses) should be rolled against for the
     * current attack instance. Mirrors {@code resolveGuaranteedBlackFlashOwner}'s entity/owner-UUID
     * resolution but without requiring an active full guarantee, since this path handles the ordinary
     * percentage-based chance instead of an absolute guarantee.
     * @param world world access used by the current mixin callback.
     * @param entity entity involved in the current mixin operation.
     * @param data persistent data container used by this helper.
     * @return the resolved player, or null if none could be resolved.
     */
    @Unique
    private static ServerPlayer jjkblueredpurple$resolveHudChanceOwner(LevelAccessor world, Entity entity, CompoundTag data) {
        if (!(world instanceof ServerLevel)) {
            return null;
        }
        if (entity instanceof ServerPlayer serverPlayer) {
            return serverPlayer;
        }
        Player owner = RangeAttackProcedureMixin.jjkblueredpurple$resolvePlayerOwner(world, data.getString("OWNER_UUID"));
        return owner instanceof ServerPlayer serverOwner ? serverOwner : null;
    }

    /**
     * Deduplication map for the mastery roll: a swing of the fist calls
     * RangeAttackProcedure.execute() up to 11 times within the same server tick
     * (see AttackWeakPunchProcedure/AttackStrongPunchProcedure's loop_num).
     * Without this, a single swing would get up to 11 independent rolls against
     * the player's mastery %, inflating the real per-swing chance far above the
     * displayed number — exactly the bug this whole system replaces.
     */
    @Unique
    private static final Map<UUID, Long> JJKBRP$lastMasteryRollTick = new ConcurrentHashMap<>();

    /**
     * Rolls against the player's current persistent Black Flash mastery %
     * (MasteryData.getTotalMastery: base % for their active Curse Technique,
     * plus whatever they've farmed, capped per-CT or globally). Only one roll
     * is honored per swing (same server tick) — see JJKBRP$lastMasteryRollTick.
     * @param player the player whose mastery should be rolled.
     * @return whether the roll succeeded.
     */
    @Unique
    private static boolean jjkblueredpurple$rollOwnBlackFlashChance(LevelAccessor world, double x, double y, double z, ServerPlayer player) {
        UUID id = player.getUUID();

        // ÚNICA fuente real del % de Black Flash: la maestría persistente
        // de /jjkmastery (base por CT + farmeado, con cap), ya existente
        // antes de este sistema. El comando /jjkbfchance (% separado,
        // sumado al de maestría) se eliminó por completo a pedido
        // explícito — generaba confusión real (20% en cada uno de los dos
        // comandos se SUMABA a 40% real, no a 20% como se esperaba).
        int ctId = net.mcreator.jujutsucraft.addon.mastery.MasteryData.activeCtId(player);
        double preChargePercent = net.mcreator.jujutsucraft.addon.mastery.MasteryData.getTotalMastery(player, ctId);
        // Bonus por carga real (cnt6), PORCENTUAL sobre el valor de maestría
        // (no puntos fijos): con carga completa (cnt6=5.0, el máximo real de
        // cualquier skill de carga del juego), el % efectivo sube hasta un
        // 15% MÁS de su propio valor (ej. 50% -> 57.5%, 0.2% -> 0.23%) — la
        // misma proporción sin importar si el % base es alto o bajo. Carga
        // parcial escala linealmente (la mitad de cnt6 = la mitad del bonus).
        double liveCnt6ForBonus = Math.max(0.0, Math.min(5.0, player.getPersistentData().getDouble("cnt6")));
        double chargeFraction = liveCnt6ForBonus / 5.0;
        double chargeBonus = 0.15 * chargeFraction;
        // Bonus por ZONE activo, PORCENTUAL igual que el de carga (no
        // puntos fijos), +10% del propio valor de maestría — se SUMA al
        // bonus de carga si ambos están activos a la vez (ej. 50% con
        // carga completa Y Zone = 50% * (1+0.15+0.10) = 62.5%). En el mod
        // base original ZONE multiplicaba la probabilidad por ~x3 (num1
        // pasaba de 1.0 a 3.0) — a pedido explícito se usa un bonus mucho
        // más moderado (+10% relativo) en vez de replicar ese multiplicador.
        boolean hasZone = player.getEffect((MobEffect) JujutsucraftModMobEffects.ZONE.get()) != null;
        double zoneBonus = hasZone ? 0.10 : 0.0;
        double chancePercent = Math.min(100.0, preChargePercent * (1.0 + chargeBonus + zoneBonus));
        if (chancePercent <= 0.0) {
            return false;
        }

        // Cooldown post-proc (mismo mecanismo confirmado en JJKU, ver
        // KEY_OWN_BF_COOLDOWN_UNTIL aplicado en el RETURN tras cada proc
        // real): mientras esté activo, ningún roll nuevo puede tener éxito,
        // sin importar el %. Medido en level.getGameTime() (ticks del
        // mundo), no player.tickCount (se reinicia al relog) ni
        // System.currentTimeMillis() (sigue corriendo en pausa).
        long cooldownUntil = player.getPersistentData().getLong(KEY_OWN_BF_COOLDOWN_UNTIL);
        if (player.level().getGameTime() < cooldownUntil) {
            return false;
        }

        // Chequeo geométrico real (causa confirmada del bug original): el
        // puño normal llama a RangeAttackProcedure.execute() hasta 11
        // veces por golpe físico, cada una en una posición distinta a lo
        // largo del arco. Sin este chequeo, cualquiera de esas 11
        // sub-llamadas podría "ganar" el roll, incluyendo las que caen en
        // el vacío sin tocar al objetivo real — confirmado con logs reales
        // que eso producía tanto fallos (100% no procediendo siempre) como
        // inflación (% bajo sintiéndose mucho más alto, hasta ~11x).
        double range = player.getPersistentData().getDouble("Range");
        double radius = range > 0.0 ? range / 2.0 : 1.5;
        AABB box = new AABB(x, y, z, x, y, z).inflate(radius);
        // CRÍTICO: debe exigir LivingEntity, igual que el mod base exige
        // implícitamente más abajo (su propio chequeo de daño usa
        // old_health = entityiterator instanceof LivingEntity ? ... :
        // -1.0, y si NO es LivingEntity, el probe damage de 0.1 nunca baja
        // la vida real -1.0<-1.0 es false- así que cae a BlackFlash=false
        // automáticamente). Sin este filtro, cualquier entidad no-viva
        // cerca del jugador (ítem dropeado, flecha, proyectil, etc.) hacía
        // que mi roll "ganara" pensando que había un objetivo válido,
        // pero el mod base cancelaba el proc real al no encontrar vida
        // que bajar en esa misma entidad — explicando el patrón real
        // confirmado en logs (~25% de confirmación real, no 100%, con
        // maestría al 100%).
        // CRÍTICO #2 (confirmado con logs reales de hoy): además de exigir
        // LivingEntity, hay que EXCLUIR net.mcreator.jujutsucraft.entity.EntityAttackStrikeEntity
        // — una entidad propia del mod base que SÍ es LivingEntity (extiende
        // PathfinderMob) pero su propio m_6469_() (hurt) está hardcodeado
        // para devolver false cuando source.getEntity() instanceof Player
        // (confirmado en su código fuente real) — es decir, NUNCA puede
        // recibir daño real de un jugador. El roll geométrico la contaba
        // como objetivo válido (sí es LivingEntity), pero el mod base
        // siempre fallaba su propio probe damage contra ella y cancelaba
        // BlackFlash, sin importar el roll — esto era la causa real
        // confirmada del ~25% (rawConfirmed=true solo cuando, además de
        // EntityAttackStrikeEntity, había un EntityCustomNpc real cerca).
        boolean hasTarget = !world.getEntitiesOfClass(Entity.class, box, e -> e != player
                && e instanceof LivingEntity
                && !e.getClass().getSimpleName().equals("EntityAttackStrikeEntity")).isEmpty();
        if (player instanceof ServerPlayer) {
            java.util.List<Entity> allNearby = world.getEntitiesOfClass(Entity.class, box, e -> e != player);
            StringBuilder sb = new StringBuilder();
            for (Entity e : allNearby) {
                sb.append(e.getClass().getSimpleName()).append("(isLiving=").append(e instanceof LivingEntity).append(") ");
            }
            JJKBRP$LOGGER.info(
                "[JJKBRP-OWN-GEO-DIAG] radius={} totalNearby={} entidades=[{}] hasTargetReal={}",
                radius, allNearby.size(), sb.toString(), hasTarget
            );
        }
        if (!hasTarget) {
            return false;
        }

        // Dedupe por SWING (mismo tick de servidor): solo la PRIMERA
        // sub-llamada que realmente tiene un objetivo cerca consume la
        // única oportunidad de roll del golpe completo.
        long currentTick = player.tickCount;
        Long lastTick = JJKBRP$ownRollSwingTick.get(id);
        if (lastTick != null && lastTick == currentTick) {
            return false;
        }
        JJKBRP$ownRollSwingTick.put(id, currentTick);

        return Math.random() * 100.0 < chancePercent;
    }

    /**
     * Resolves the owning player from the stored UUID so owner-only protections can be applied safely.
     * @param world world access used by the current mixin callback.
     * @param ownerUUID identifier used to resolve runtime state for this operation.
     * @return the resulting resolve player owner value.
     */
    // Marks this helper member as mixin-unique so it cannot collide with names inside the target class.
    @Unique
    private static Player jjkblueredpurple$resolvePlayerOwner(LevelAccessor world, String ownerUUID) {
        if (ownerUUID == null || ownerUUID.isEmpty() || !(world instanceof ServerLevel)) {
            return null;
        }
        ServerLevel sl = (ServerLevel)world;
        try {
            UUID uuid = UUID.fromString(ownerUUID);
            Entity ownerEntity = sl.getEntity(uuid);
            if (ownerEntity instanceof Player) {
                Player player = (Player)ownerEntity;
                return player;
            }
            return sl.getServer().getPlayerList().getPlayer(uuid);
        }
        catch (Exception ignored) {
            return null;
        }
    }

    /**
     * Checks whether the resolved player currently has the Infinity state that should protect them during Purple handling.
     * @param player entity involved in the current mixin operation.
     * @return whether is infinity active is true for the current runtime state.
     */
    // Marks this helper member as mixin-unique so it cannot collide with names inside the target class.
    @Unique
    private static boolean jjkblueredpurple$isInfinityActive(Player player) {
        return player != null && (player.getPersistentData().getBoolean("infinity") || player.hasEffect((MobEffect)JujutsucraftModMobEffects.INFINITY_EFFECT.get()));
    }

    /**
     * Detección confiable de un Black Flash REAL, igual al mecanismo que ya
     * usa el addon stats para su mensaje de chat/title (ver
     * com.jujutsucraft.jjkstats.mixin.RangeAttackProcedureMixin): se
     * inyecta justo en la lectura de ENTITY_BLACK_FLASH, que el código base
     * solo alcanza cuando BlackFlash ya es true de verdad — sin pasar por
     * el heurístico de "duración de ZONE saltó mucho", que podía fallar en
     * registrar un proc real si ZONE ya estaba cerca de su techo.
     *
     * Misma ventana de dedupe que stats (250ms) para no contar 11 veces el
     * mismo golpe de puño, y excluye explícitamente cualquier garantía
     * (cnt6=99999, sea de JoQu o de una skill base como Todo's "Plus
     * Ultra"): la maestría solo debe crecer con procs ganados por el
     * jugador, no con golpes garantizados.
     */
    @Unique
    private static final long JJKBRP$MASTERY_DEDUPE_WINDOW_MS = 250L;
    @Unique
    private static final Map<UUID, Long> JJKBRP$lastMasteryGrowthMs = new ConcurrentHashMap<>();

    @Inject(
        method = "execute",
        at = @At(
            value = "FIELD",
            target = "Lnet/mcreator/jujutsucraft/init/JujutsucraftModEntities;" +
                     "ENTITY_BLACK_FLASH:Lnet/minecraftforge/registries/RegistryObject;",
            opcode = Opcodes.GETSTATIC,
            remap = false
        ),
        require = 0
    )
    private static void jjkblueredpurple$onRealBlackFlashProc(LevelAccessor world, double x, double y, double z,
                                                                Entity entity, CallbackInfo ci) {
        if (!(entity instanceof ServerPlayer player)) {
            return;
        }

        if (Boolean.TRUE.equals(JJKBRP$confirmedWasGuaranteed.get())) {
            // Golpe garantizado (Plus Ultra de Todo, o la skill Black Flash
            // de Itadori — ambos marcan este flag en vez de inflar cnt6,
            // ya que ese forzado dejó de tener efecto real sobre el roll
            // desde que la constante se anula directamente): no cuenta
            // para maestría, el jugador lo activa a voluntad.
            return;
        }

        long now = System.currentTimeMillis();
        UUID id = player.getUUID();
        Long lastGrowth = JJKBRP$lastMasteryGrowthMs.get(id);
        if (lastGrowth != null && (now - lastGrowth) < JJKBRP$MASTERY_DEDUPE_WINDOW_MS) {
            // Ya se contó un proc de este mismo golpe (las hasta 11 llamadas
            // del swing comparten esta ventana).
            return;
        }
        JJKBRP$lastMasteryGrowthMs.put(id, now);

        int ctId = net.mcreator.jujutsucraft.addon.mastery.MasteryData.activeCtId(player);
        net.mcreator.jujutsucraft.addon.mastery.MasteryData.onSuccessfulProc(player, ctId);

        net.mcreator.jujutsucraft.addon.mastery.Output120Handler.onBlackFlashProc(player);
    }
}
