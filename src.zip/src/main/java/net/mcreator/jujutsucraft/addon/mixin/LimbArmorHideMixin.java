package net.mcreator.jujutsucraft.addon.mixin;

import net.mcreator.jujutsucraft.addon.limb.LimbRenderHandler;
import net.mcreator.jujutsucraft.addon.limb.LimbType;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Filtra bodyParts() para ocultar partes de armadura Y skin vanilla de miembros
 * amputados o en fase flesh.
 *
 * Se eliminó el check `instanceof PlayerModel` que antes excluía el modelo del
 * jugador. Ahora el filtro aplica a TODOS los HumanoidModel, incluyendo PlayerModel.
 *
 * Esto permite:
 * - Ocultar la skin vanilla durante fase flesh (sin tocar visible=false)
 * - JJK llama a model.rightArm.render() directamente → no pasa por bodyParts()
 *   → la capa de carne de JJK NO se ve afectada
 *
 * Durante severed normal, visible=false ya oculta todo. El filtro de bodyParts()
 * es una capa extra de seguridad y el mecanismo principal para flesh phase.
 */
@OnlyIn(Dist.CLIENT)
@Mixin(HumanoidModel.class)
public class LimbArmorHideMixin {

    @Inject(method = "bodyParts", at = @At("RETURN"), cancellable = true)
    private void filterSeveredBodyParts(CallbackInfoReturnable<Iterable<ModelPart>> cir) {
        // Solo filtrar modelos de ARMADURA (HumanoidModel puro).
        // El PlayerModel usa visible=false para ocultar la skin vanilla durante flesh phase.
        // Si filtramos el PlayerModel aquí, el brazo queda invisible al regenerarse.
        if ((Object) this instanceof net.minecraft.client.model.PlayerModel) return;

        Set<LimbType> severed = LimbRenderHandler.CURRENT_SEVERED.get();
        if (severed == null || severed.isEmpty()) return;

        HumanoidModel<?> model = (HumanoidModel<?>) (Object) this;

        List<ModelPart> filtered = new ArrayList<>();
        for (ModelPart part : cir.getReturnValue()) {
            boolean hide = false;
            if (severed.contains(LimbType.RIGHT_ARM) && part == model.rightArm) hide = true;
            if (severed.contains(LimbType.LEFT_ARM)  && part == model.leftArm)  hide = true;
            if (severed.contains(LimbType.RIGHT_LEG) && part == model.rightLeg) hide = true;
            if (severed.contains(LimbType.LEFT_LEG)  && part == model.leftLeg)  hide = true;
            if (severed.contains(LimbType.HEAD)      && part == model.head)     hide = true;
            if (!hide) filtered.add(part);
        }
        cir.setReturnValue(filtered);
    }
}
