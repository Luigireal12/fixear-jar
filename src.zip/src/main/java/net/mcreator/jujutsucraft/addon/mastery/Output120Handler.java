package net.mcreator.jujutsucraft.addon.mastery;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Sistema de "Output 120%": completar N Black Flash exitosos seguidos
 * (configurable), cada uno estando al 100% de output en el momento exacto
 * del proc, activa un bono temporal de +daño/+velocidad. Bajar el output
 * mientras el bono está activo lo cancela de inmediato y fuerza el output a
 * 100%, entrando en cooldown.
 *
 * Todas las duraciones se miden en TICKS DEL MUNDO (level.getGameTime()), no
 * en System.currentTimeMillis() ni en player.tickCount:
 *   - System.currentTimeMillis() sigue corriendo durante la pausa
 *     (singleplayer), haciendo que el bono/cooldown expirara solo por tener
 *     el juego pausado.
 *   - player.tickCount se reinicia a 0 cada vez que el jugador vuelve a
 *     entrar al mundo (es un contador en memoria del objeto Entity, no algo
 *     persistido) — guardar un valor absoluto basado en él y compararlo
 *     después de un relog daba números sin sentido (cooldowns mostrando
 *     mucho más tiempo del configurado).
 *   - level.getGameTime() SÍ persiste correctamente en el level.dat del
 *     mundo entre sesiones, y se congela igual que tickCount durante la
 *     pausa en singleplayer — es la única de las tres opciones que cumple
 *     ambos requisitos a la vez.
 *
 * El % de output en sí vive en el addon stats (capability propia, sin
 * dependencia de compilación con JoQu) — se lee vía el espejo en NBT plano
 * que stats mantiene actualizado (jjkstats_output_percent_mirror), mismo
 * patrón que Jjsk4BlackFlashChanceBridge usa para leer JJSK4.
 */
@net.minecraftforge.fml.common.Mod.EventBusSubscriber(modid = "jjkblueredpurple", bus = net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus.FORGE)
public final class Output120Handler {

    private Output120Handler() {
    }

    private static final String KEY_PROGRESS_COUNT = "jjkbrp_output120_progress_count";
    private static final String KEY_LAST_PROC_TICK = "jjkbrp_output120_last_proc_tick";
    private static final String KEY_ACTIVE_UNTIL_TICK = "jjkbrp_output120_active_until_tick";
    private static final String KEY_COOLDOWN_UNTIL_TICK = "jjkbrp_output120_cooldown_until_tick";
    private static final String KEY_PENDING_ACTIVATION_TICK = "jjkbrp_output120_pending_activation_tick";
    private static final String OUTPUT_MIRROR_KEY = "jjkstats_output_percent_mirror";
    /** Delay real entre mostrar la última rayita llena (progressCount==required) y activar el bono de 120% — a pedido explícito, para que el HUD (sincroniza cada 20 ticks) tenga tiempo de renderizar el estado intermedio antes de que la barra cambie. */
    private static final long ACTIVATION_DELAY_TICKS = 20L;

    private static int readOutputPercent(ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        if (!data.contains(OUTPUT_MIRROR_KEY)) {
            return 5;
        }
        return data.getInt(OUTPUT_MIRROR_KEY);
    }

    /** Llamado desde RangeAttackProcedureMixin cada vez que se confirma un Black Flash real (no garantizado). */
    public static void onBlackFlashProc(ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        long now = player.level().getGameTime();

        if (isActive(player)) {
            return;
        }

        if (data.getLong(KEY_PENDING_ACTIVATION_TICK) > 0) {
            // Ya está esperando el delay de 1 segundo antes de activar —
            // no contar más procs ni reprogramar mientras tanto.
            return;
        }

        if (readOutputPercent(player) < 100) {
            return;
        }

        long cooldownUntil = data.getLong(KEY_COOLDOWN_UNTIL_TICK);
        if (now < cooldownUntil) {
            return;
        }

        long lastProcTick = data.getLong(KEY_LAST_PROC_TICK);
        long windowTicks = MasteryConfig.OUTPUT_120_WINDOW_SECONDS.get() * 20L;
        int currentCount = data.getInt(KEY_PROGRESS_COUNT);

        if (lastProcTick > 0 && (now - lastProcTick) > windowTicks) {
            currentCount = 0;
        }

        currentCount += 1;
        data.putInt(KEY_PROGRESS_COUNT, currentCount);
        data.putLong(KEY_LAST_PROC_TICK, now);

        int required = MasteryConfig.OUTPUT_120_PROCS_REQUIRED.get();
        if (currentCount >= required) {
            // No se activa en el mismo tick: se programa para
            // ACTIVATION_DELAY_TICKS más adelante, dejando KEY_PROGRESS_COUNT
            // en su valor máximo (required) durante ese tiempo, para que el
            // HUD (sincroniza cada 20 ticks) muestre la última rayita
            // realmente llena antes de que la barra cambie a 120%.
            data.putLong(KEY_PENDING_ACTIVATION_TICK, now + ACTIVATION_DELAY_TICKS);
        }
    }

    private static void activate(ServerPlayer player, long now) {
        CompoundTag data = player.getPersistentData();
        long durationTicks = MasteryConfig.OUTPUT_120_DURATION_SECONDS.get() * 20L;
        data.putLong(KEY_ACTIVE_UNTIL_TICK, now + durationTicks);
        data.putInt(KEY_PROGRESS_COUNT, 0);
        data.putLong(KEY_LAST_PROC_TICK, 0);
        // Espejo de los valores de bono en NBT plano, para que stats (sin
        // dependencia de compilación con JoQu) pueda leer el % real sin
        // necesitar el ForgeConfigSpec de este addon.
        data.putDouble("jjkbrp_output120_damage_bonus_mirror", MasteryConfig.OUTPUT_120_DAMAGE_BONUS.get());
        data.putDouble("jjkbrp_output120_speed_bonus_mirror", MasteryConfig.OUTPUT_120_SPEED_BONUS.get());
        data.putLong("jjkbrp_output120_cooldown_seconds_mirror", MasteryConfig.OUTPUT_120_COOLDOWN_SECONDS.get());

        player.displayClientMessage(
            net.minecraft.network.chat.Component.literal("\u00a7b\u00a7lYou have reached 120% of your potential"), true
        );
        // Dos capas de sonido para que se note y no se confunda con el
        // sonido normal de Black Flash: el trueno (subido de volumen) más
        // un growl grave de fondo, casi simultáneos.
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
            net.minecraft.sounds.SoundEvents.LIGHTNING_BOLT_THUNDER, net.minecraft.sounds.SoundSource.PLAYERS,
            1.5f, 1.3f);
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
            net.minecraft.sounds.SoundEvents.ENDER_DRAGON_GROWL, net.minecraft.sounds.SoundSource.PLAYERS,
            1.0f, 0.8f);

        // Efecto puramente visual para mostrar la duración restante en el
        // HUD de efectos del jugador. La fuente real de verdad sigue siendo
        // KEY_ACTIVE_UNTIL_TICK — si el jugador cancela este efecto a mano
        // (ej. /effect clear), onPlayerTick detecta la ausencia y cancela
        // también el bono real (ver más abajo).
        player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
            (net.minecraft.world.effect.MobEffect) net.mcreator.jujutsucraft.addon.init.ModMobEffects.OUTPUT_120_ACTIVE.get(),
            (int) durationTicks, 0, false, true));

        net.mcreator.jujutsucraft.addon.ModNetworking.CHANNEL.send(
            net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> player),
            new net.mcreator.jujutsucraft.addon.client.Output120MusicPacket(true)
        );
    }

    public static boolean isActive(ServerPlayer player) {
        long activeUntil = player.getPersistentData().getLong(KEY_ACTIVE_UNTIL_TICK);
        return player.level().getGameTime() < activeUntil;
    }

    public static int getProgressCount(ServerPlayer player) {
        return player.getPersistentData().getInt(KEY_PROGRESS_COUNT);
    }

    public static int getProgressRequired() {
        return MasteryConfig.OUTPUT_120_PROCS_REQUIRED.get();
    }

    /** Resetea el cooldown del Output 120% de un jugador (usado por /jjkmastery resetcd). NO toca el progreso/firma de sync ni el bono si ya está activo — solo el cooldown. */
    public static void resetCooldown(ServerPlayer player) {
        player.getPersistentData().putLong(KEY_COOLDOWN_UNTIL_TICK, 0);
    }

    /**
     * Invocado por reflexión desde stats (OutputHandler.onChargeInput) cuando
     * el jugador cancela el 120% bajando el output a mano — ese camino
     * escribe las keys NBT directamente sin pasar por
     * cancelIfActiveAndForceTo100, así que el aviso al cliente para
     * cortar el fade/.ogg de música se hace desde este método público
     * separado, sin que stats necesite importar ninguna clase de JoQu.
     */
    public static void notifyMusicCancelled(ServerPlayer player) {
        net.mcreator.jujutsucraft.addon.ModNetworking.CHANNEL.send(
            net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> player),
            new net.mcreator.jujutsucraft.addon.client.Output120MusicPacket(false)
        );
    }

    /**
     * Llamado desde OutputHandler (stats) cuando el jugador intenta bajar su
     * output mientras el bono de 120% está activo: cancela el bono, fuerza
     * el output a exactamente 100%, y entra en cooldown.
     */
    public static boolean cancelIfActiveAndForceTo100(ServerPlayer player) {
        if (!isActive(player)) {
            return false;
        }
        CompoundTag data = player.getPersistentData();
        data.putLong(KEY_ACTIVE_UNTIL_TICK, 0);
        long cooldownTicks = MasteryConfig.OUTPUT_120_COOLDOWN_SECONDS.get() * 20L;
        data.putLong(KEY_COOLDOWN_UNTIL_TICK, player.level().getGameTime() + cooldownTicks);

        player.displayClientMessage(
            net.minecraft.network.chat.Component.literal("\u00a77Output 120% perdido."), true
        );
        player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
            net.minecraft.sounds.SoundEvents.LAVA_EXTINGUISH, net.minecraft.sounds.SoundSource.PLAYERS,
            0.8f, 1.1f);
        player.removeEffect((net.minecraft.world.effect.MobEffect) net.mcreator.jujutsucraft.addon.init.ModMobEffects.OUTPUT_120_ACTIVE.get());
        Output120Handler.notifyMusicCancelled(player);
        return true;
    }

    public static double damageBonus(ServerPlayer player) {
        return isActive(player) ? MasteryConfig.OUTPUT_120_DAMAGE_BONUS.get() : 0.0;
    }

    public static double speedBonus(ServerPlayer player) {
        return isActive(player) ? MasteryConfig.OUTPUT_120_SPEED_BONUS.get() : 0.0;
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (event.player.level().isClientSide()) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.tickCount % 20 != 0) return;

        CompoundTag data = player.getPersistentData();
        long now = player.level().getGameTime();

        long pendingActivationTick = data.getLong(KEY_PENDING_ACTIVATION_TICK);
        if (pendingActivationTick > 0 && now >= pendingActivationTick) {
            data.putLong(KEY_PENDING_ACTIVATION_TICK, 0);
            activate(player, now);
        }

        long activeUntil = data.getLong(KEY_ACTIVE_UNTIL_TICK);
        if (activeUntil > 0 && now >= activeUntil) {
            data.putLong(KEY_ACTIVE_UNTIL_TICK, 0);
            long cooldownTicks = MasteryConfig.OUTPUT_120_COOLDOWN_SECONDS.get() * 20L;
            data.putLong(KEY_COOLDOWN_UNTIL_TICK, now + cooldownTicks);
            player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                net.minecraft.sounds.SoundEvents.LAVA_EXTINGUISH, net.minecraft.sounds.SoundSource.PLAYERS,
                0.8f, 1.1f);
            Output120Handler.notifyMusicCancelled(player);
        } else if (activeUntil > 0
                && !player.hasEffect((net.minecraft.world.effect.MobEffect) net.mcreator.jujutsucraft.addon.init.ModMobEffects.OUTPUT_120_ACTIVE.get())) {
            // El bono real seguía activo (activeUntil en el futuro), pero el
            // efecto visual ya no está — el jugador lo quitó manualmente
            // (ej. /effect clear, leche, etc.). A pedido explícito: en ese
            // caso el bono simplemente desaparece, SIN entrar en cooldown
            // (distinto del caso de bajar el output a mano, que sí tiene
            // penalización — esto es solo "cancelar la indicación visual").
            data.putLong(KEY_ACTIVE_UNTIL_TICK, 0);
            Output120Handler.notifyMusicCancelled(player);
        }

        long lastProcTick = data.getLong(KEY_LAST_PROC_TICK);
        long windowTicks = MasteryConfig.OUTPUT_120_WINDOW_SECONDS.get() * 20L;
        if (lastProcTick > 0 && (now - lastProcTick) > windowTicks && data.getInt(KEY_PROGRESS_COUNT) > 0) {
            data.putInt(KEY_PROGRESS_COUNT, 0);
            data.putLong(KEY_LAST_PROC_TICK, 0);
        }

        // Espejo de procs_required, leído cada tick para que stats siempre
        // muestre el número actual aunque se edite el .toml en caliente.
        data.putInt("jjkbrp_output120_procs_required_mirror", MasteryConfig.OUTPUT_120_PROCS_REQUIRED.get());

        // Efecto visual de cooldown: 100% cosmético, no afecta el timer real
        // (que sigue en KEY_COOLDOWN_UNTIL_TICK independientemente). Se
        // aplica mientras el jugador esté en cooldown, y se quita solo
        // cuando termina — quitarlo a mano (ej. /effect clear) no restaura nada.
        long cooldownUntil = data.getLong(KEY_COOLDOWN_UNTIL_TICK);
        boolean shouldShowCooldownEffect = now < cooldownUntil;
        net.minecraft.world.effect.MobEffect cooldownEffect =
            net.mcreator.jujutsucraft.addon.init.ModMobEffects.OUTPUT_120_COOLDOWN.get();
        boolean hasCooldownEffect = player.hasEffect(cooldownEffect);

        if (shouldShowCooldownEffect && !hasCooldownEffect) {
            int remainingTicks = (int) (cooldownUntil - now) + 20; // margen
            player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                cooldownEffect, remainingTicks, 0, false, false, true
            ));
        } else if (!shouldShowCooldownEffect && hasCooldownEffect) {
            player.removeEffect(cooldownEffect);
        }
    }
}
