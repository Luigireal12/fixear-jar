package net.mcreator.jujutsucraft.addon.client;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * Avisa al cliente que el bono de Output 120% se activó (started=true) o se
 * canceló (started=false), para que reproduzca/corte el .ogg de
 * "output_120_potential" y maneje el fade del volumen de música ambiente
 * (ver Output120MusicHandler, que es quien realmente hace el trabajo en el
 * cliente al recibir este paquete).
 */
public class Output120MusicPacket {
    private final boolean started;

    public Output120MusicPacket(boolean started) {
        this.started = started;
    }

    public static void encode(Output120MusicPacket pkt, FriendlyByteBuf buf) {
        buf.writeBoolean(pkt.started);
    }

    public static Output120MusicPacket decode(FriendlyByteBuf buf) {
        return new Output120MusicPacket(buf.readBoolean());
    }

    public static void handle(Output120MusicPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist) Dist.CLIENT, () -> () -> {
            if (pkt.started) {
                Output120MusicHandler.onActivated();
            } else {
                Output120MusicHandler.onCancelled();
            }
        }));
        ctx.setPacketHandled(true);
    }
}
