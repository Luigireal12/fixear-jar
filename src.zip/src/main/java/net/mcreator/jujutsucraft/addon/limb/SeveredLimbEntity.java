package net.mcreator.jujutsucraft.addon.limb;

import java.util.Optional;
import java.util.UUID;
import net.mcreator.jujutsucraft.addon.limb.LimbEntityRegistry;
import net.mcreator.jujutsucraft.addon.limb.LimbType;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializer;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import org.joml.Vector3f;

/**
 * Physical detached limb entity spawned when a limb is severed.
 *
 * <p>The entity stores which limb it represents, who it came from, a small amount of cosmetic state,
 * and simple falling/bouncing physics before despawning after a short lifetime.</p>
 */
public class SeveredLimbEntity
extends Entity {
    /** Synced integer id identifying which limb this entity represents. */
    private static final EntityDataAccessor<Integer> LIMB_TYPE_ID = SynchedEntityData.defineId(SeveredLimbEntity.class, (EntityDataSerializer)EntityDataSerializers.INT);
    /** Synced owner UUID used for skin selection and source tracking. */
    private static final EntityDataAccessor<Optional<UUID>> OWNER_UUID = SynchedEntityData.defineId(SeveredLimbEntity.class, (EntityDataSerializer)EntityDataSerializers.OPTIONAL_UUID);
    /** Synced owner name retained for display/debug information. */
    private static final EntityDataAccessor<String> OWNER_NAME = SynchedEntityData.defineId(SeveredLimbEntity.class, (EntityDataSerializer)EntityDataSerializers.STRING);
    /** Synced flag indicating whether the originating player used the slim model variant. */
    private static final EntityDataAccessor<Boolean> SLIM_MODEL = SynchedEntityData.defineId(SeveredLimbEntity.class, (EntityDataSerializer)EntityDataSerializers.BOOLEAN);
    /** Client-side blood drip particle used while the detached limb is still fresh. */
    private static final DustParticleOptions BLOOD_DRIP = new DustParticleOptions(new Vector3f(0.5f, 0.02f, 0.02f), 0.6f);
    /** Maximum lifetime before the detached limb despawns, measured in ticks. */
    private static final int MAX_LIFETIME = 200;
    /** Number of ticks this detached limb has existed. */
    private int lifetime = 0;
    /** Cosmetic X-axis rotation used by the renderer. */
    private float rotX;
    /** Cosmetic Z-axis rotation used by the renderer. */
    private float rotZ;
    /** Angular velocity on X axis (degrees/tick). Decelerates with friction. */
    private float spinX;
    /** Angular velocity on Z axis (degrees/tick). Decelerates with friction. */
    private float spinZ;
    /** Snap target for X rotation (set once when spin slows, NaN = unset). */
    private float snapTargetX = Float.NaN;
    /** Snap target for Z rotation (set once when spin slows, NaN = unset). */
    private float snapTargetZ = Float.NaN;

    /**
     * Base constructor used by the entity type registration and spawning system.
     *
     * @param type registered entity type
     * @param level level the entity exists in
     */
    public SeveredLimbEntity(EntityType<?> type, Level level) {
        super(type, level);
        // Start with random tumble angles and spin velocities for variety.
        this.rotX  = level.getRandom().nextFloat() * 360.0f;
        this.rotZ  = level.getRandom().nextFloat() * 360.0f;
        this.spinX = (level.getRandom().nextFloat() - 0.5f) * 22.0f; // ±11 deg/tick
        this.spinZ = (level.getRandom().nextFloat() - 0.5f) * 16.0f; // ±8 deg/tick
    }

    /**
     * Convenience constructor used when spawning a detached limb from an owner.
     *
     * @param level level the entity exists in
     * @param owner entity that lost the limb
     * @param limbType limb represented by this detached entity
     */
    public SeveredLimbEntity(Level level, LivingEntity owner, LimbType limbType) {
        this((EntityType)LimbEntityRegistry.SEVERED_LIMB.get(), level);
        this.entityData.set(LIMB_TYPE_ID, limbType.getIndex());
        this.entityData.set(OWNER_UUID, Optional.of(owner.getUUID()));
        this.entityData.set(OWNER_NAME, owner.getName().getString());
        this.entityData.set(SLIM_MODEL, false);
    }

    /**
     * Defines all synced data parameters required on both client and server.
     */
    protected void defineSynchedData() {
        this.entityData.define(LIMB_TYPE_ID, 0);
        this.entityData.define(OWNER_UUID, Optional.empty());
        this.entityData.define(OWNER_NAME, "");
        this.entityData.define(SLIM_MODEL, false);
    }

    /**
     * Returns the represented limb type.
     *
     * @return resolved limb type, or {@code null} if the synced id is invalid
     */
    public LimbType getLimbType() {
        return LimbType.fromIndex((Integer)this.entityData.get(LIMB_TYPE_ID));
    }

    /**
     * Returns the UUID of the original owner when known.
     *
     * @return optional owner UUID
     */
    public Optional<UUID> getOwnerUUID() {
        return (Optional)this.entityData.get(OWNER_UUID);
    }

    /**
     * Returns the stored owner name.
     *
     * @return owner display name snapshot
     */
    public String getOwnerName() {
        return (String)this.entityData.get(OWNER_NAME);
    }

    /**
     * Returns whether the renderer should use the slim player model.
     *
     * @return {@code true} for the slim model variant
     */
    public boolean isSlimModel() {
        return (Boolean)this.entityData.get(SLIM_MODEL);
    }

    /**
     * Returns the cosmetic X-axis tumble rotation.
     *
     * @return X rotation in degrees
     */
    public float getLimbRotX() {
        return this.rotX;
    }

    /**
     * Returns the cosmetic Z-axis tumble rotation.
     *
     * @return Z rotation in degrees
     */
    public float getLimbRotZ() {
        return this.rotZ;
    }

    /**
     * Updates lifetime, simple physics, and client blood drip particles.
     */
    public void tick() {
        super.tick();
        ++this.lifetime;
        if (this.lifetime > MAX_LIFETIME && !this.level().isClientSide) {
            this.discard();
            return;
        }

        Vec3 motion = this.getDeltaMovement();

        // ── Física de rotación con inercia ────────────────────────────────
        if (!this.onGround()) {
            // En el aire: girar según velocidad angular, leve resistencia del aire
            this.rotX += this.spinX;
            this.rotZ += this.spinZ;
            this.spinX *= 0.985f;
            this.spinZ *= 0.985f;
            // Reset snap targets para que tras un rebote recalcule con el nuevo spin
            this.snapTargetX = Float.NaN;
            this.snapTargetZ = Float.NaN;

            // Gravedad
            motion = motion.subtract(0.0, 0.04, 0.0);
        } else {
            // En el suelo: fricción angular fuerte, desacelera hasta parar
            this.spinX *= 0.70f;
            this.spinZ *= 0.70f;
            if (Math.abs(this.spinX) < 0.3f) this.spinX = 0.0f;
            if (Math.abs(this.spinZ) < 0.3f) this.spinZ = 0.0f;
            this.rotX += this.spinX;
            this.rotZ += this.spinZ;

            // Cuando el spin casi paró, hacer lerp suave hacia la cara plana más cercana.
            // Un bloque rectangular siempre queda apoyado en una cara (múltiplo de 90°),
            // nunca balanceado en una esquina.
            if (Math.abs(this.spinX) < 0.5f && Math.abs(this.spinZ) < 0.5f) {
                // Fijar el target de snap UNA SOLA VEZ cuando el spin cae bajo el umbral.
                // Usamos la DIRECCIÓN de la inercia para elegir el lado plano que viene
                // ADELANTE en esa dirección — nunca reversa para ir al lado más cercano.
                if (Float.isNaN(this.snapTargetX)) {
                    // Si el ángulo actual ya está muy cerca de un lado plano (< 12°),
                    // ir directo a ese sin importar dirección (corrección mínima).
                    float nearestX = Math.round((this.rotX - 90.0f) / 180.0f) * 180.0f + 90.0f;
                    if (Math.abs(nearestX - this.rotX) < 12.0f) {
                        this.snapTargetX = nearestX;
                    } else if (this.spinX >= 0) {
                        // Spin iba hacia adelante: próximo lado plano en dirección positiva
                        this.snapTargetX = (float)Math.ceil((this.rotX - 90.0f) / 180.0f) * 180.0f + 90.0f;
                    } else {
                        // Spin iba hacia atrás: próximo lado plano en dirección negativa
                        this.snapTargetX = (float)Math.floor((this.rotX - 90.0f) / 180.0f) * 180.0f + 90.0f;
                    }
                    // Z: sección transversal cuadrada → cualquier 90° sirve, respetar dirección
                    float nearestZ = Math.round(this.rotZ / 90.0f) * 90.0f;
                    if (Math.abs(nearestZ - this.rotZ) < 12.0f) {
                        this.snapTargetZ = nearestZ;
                    } else if (this.spinZ >= 0) {
                        this.snapTargetZ = (float)Math.ceil(this.rotZ / 90.0f) * 90.0f;
                    } else {
                        this.snapTargetZ = (float)Math.floor(this.rotZ / 90.0f) * 90.0f;
                    }
                }
                // Lerp suave hacia el target fijado — siempre en la dirección de la inercia
                float dX = this.snapTargetX - this.rotX;
                float dZ = this.snapTargetZ - this.rotZ;
                this.rotX += Math.abs(dX) < 0.5f ? dX : dX * 0.18f;
                this.rotZ += Math.abs(dZ) < 0.5f ? dZ : dZ * 0.18f;
            }

            // Fricción horizontal
            motion = new Vec3(motion.x * 0.80, motion.y, motion.z * 0.80);
        }

        this.setDeltaMovement(motion);

        // ── Movimiento con colisión ───────────────────────────────────────
        // Guardar velocidad Y antes del move para detectar impacto real
        double preY = motion.y;
        this.move(MoverType.SELF, this.getDeltaMovement());

        // ── Rebote al tocar el suelo ──────────────────────────────────────
        Vec3 post = this.getDeltaMovement();
        if (this.onGround() && preY < -0.08) {
            // Rebote: conserva 25% de energía vertical, reduce horizontal
            this.setDeltaMovement(post.x * 0.75, -preY * 0.25, post.z * 0.75);
            // El impacto agrega un impulso de spin
            this.spinX += (this.random.nextFloat() - 0.5f) * Math.abs(preY) * 60.0f;
            this.spinZ += (this.random.nextFloat() - 0.5f) * Math.abs(preY) * 60.0f;
        }

        // ── Partículas de sangre ──────────────────────────────────────────
        if (this.level().isClientSide && this.lifetime < 80 && this.level().getRandom().nextInt(3) == 0) {
            this.level().addParticle((ParticleOptions)BLOOD_DRIP,
                this.getX() + this.level().getRandom().nextGaussian() * 0.05,
                this.getY() + 0.1,
                this.getZ() + this.level().getRandom().nextGaussian() * 0.05,
                0.0, -0.03, 0.0);
        }
    }

    /**
     * Restores detached limb state from saved entity data.
     *
     * @param tag saved entity NBT
     */
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(LIMB_TYPE_ID, tag.getInt("LimbType"));
        if (tag.hasUUID("OwnerUUID")) {
            this.entityData.set(OWNER_UUID, Optional.of(tag.getUUID("OwnerUUID")));
        }
        this.entityData.set(OWNER_NAME, tag.getString("OwnerName"));
        this.entityData.set(SLIM_MODEL, tag.getBoolean("SlimModel"));
        this.lifetime = tag.getInt("Lifetime");
        this.rotX  = tag.getFloat("RotX");
        this.rotZ  = tag.getFloat("RotZ");
        this.spinX = tag.getFloat("SpinX");
        this.spinZ = tag.getFloat("SpinZ");
    }

    /**
     * Saves detached limb state into entity NBT.
     *
     * @param tag target entity NBT
     */
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("LimbType", ((Integer)this.entityData.get(LIMB_TYPE_ID)).intValue());
        this.getOwnerUUID().ifPresent(uuid -> tag.putUUID("OwnerUUID", uuid));
        tag.putString("OwnerName", this.getOwnerName());
        tag.putBoolean("SlimModel", this.isSlimModel());
        tag.putInt("Lifetime", this.lifetime);
        tag.putFloat("RotX",   this.rotX);
        tag.putFloat("RotZ",   this.rotZ);
        tag.putFloat("SpinX",  this.spinX);
        tag.putFloat("SpinZ",  this.spinZ);
    }

    /**
     * Creates the vanilla/Forge spawn packet for this custom entity.
     *
     * @return network packet used to spawn the entity on clients
     */
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket((Entity)this);
    }

    /**
     * Prevents the detached limb from being targeted as a pickable hitbox.
     *
     * @return always {@code false}
     */
    public boolean isPickable() {
        return false;
    }
}
