package net.mcreator.jujutsucraft.addon.limb;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.mcreator.jujutsucraft.addon.limb.LimbState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.event.entity.living.LivingEquipmentChangeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

import java.lang.reflect.Field;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * Client-side render hook para amputación y regeneración de extremidades.
 *
 * - CURRENT_SEVERED: leído por LimbArmorHideMixin para ocultar armadura
 * - FLESH_PROGRESS: datos de la fase carne (0.75→1.0) pasados de Pre a Post
 *   para el efecto de revelado progresivo de la skin de arriba hacia abajo.
 */
@Mod.EventBusSubscriber(modid = "jjkblueredpurple", value = {Dist.CLIENT})
public class LimbRenderHandler {

    private static final float PHASE_FLESH = 0.75f;

    public static final ThreadLocal<Set<LimbType>> CURRENT_SEVERED = new ThreadLocal<>();

    /**
     * Mapa entityId→(LimbType→subProgress 0..1) para la fase flesh.
     * Poblado en Pre, consumido y limpiado en Post.
     */
    private static final ThreadLocal<EnumMap<LimbType, Float>> FLESH_PROGRESS =
            ThreadLocal.withInitial(() -> new EnumMap<>(LimbType.class));

    // ─── Reflexión para internals privados de ModelPart (MC 1.20.1) ─────────
    // ModelPart.Cube.polygons, ModelPart.Polygon.vertices/normal,
    // ModelPart.Vertex.pos/u/v son todos privados o de clases privadas.

    private static Field reflPolygons  = null; // Cube.polygons  → Object[] (Polygon[])
    private static Field reflVertices  = null; // Polygon.vertices → Object[] (Vertex[])
    private static Field reflNormal    = null; // Polygon.normal   → Vector3f
    private static Field reflPos       = null; // Vertex.pos       → Vector3f
    private static Field reflU         = null; // Vertex.u         → float
    private static Field reflV         = null; // Vertex.v         → float
    private static Field reflCubes     = null; // ModelPart.cubes  → List<Cube>
    private static boolean reflInit    = false;

    static void ensureModelReflect() {
        if (reflInit) return;
        reflInit = true;
        try {
            // Cube.polygons: array de Polygon
            for (Field f : ModelPart.Cube.class.getDeclaredFields()) {
                if (f.getType().isArray()) {
                    f.setAccessible(true);
                    reflPolygons = f;
                    break;
                }
            }
            if (reflPolygons == null) return;

            // Obtener clase Polygon y Vertex a través del tipo del array
            Class<?> polygonCls = reflPolygons.getType().getComponentType();

            for (Field f : polygonCls.getDeclaredFields()) {
                if (f.getType().isArray()) {
                    f.setAccessible(true);
                    reflVertices = f; // Polygon.vertices
                } else if (f.getType() == org.joml.Vector3f.class) {
                    f.setAccessible(true);
                    reflNormal = f;   // Polygon.normal
                }
            }
            if (reflVertices == null || reflNormal == null) return;

            Class<?> vertexCls = reflVertices.getType().getComponentType();
            for (Field f : vertexCls.getDeclaredFields()) {
                if (f.getType() == org.joml.Vector3f.class) {
                    f.setAccessible(true);
                    reflPos = f;
                } else if (f.getType() == float.class) {
                    f.setAccessible(true);
                    // u viene antes que v en la clase
                    if (reflU == null) reflU = f;
                    else               reflV = f;
                }
            }
        } catch (Throwable ignored) {}

        // ModelPart.cubes (List<Cube>) - también privado en 1.20.1
        try {
            for (Field f : ModelPart.class.getDeclaredFields()) {
                if (java.util.List.class.isAssignableFrom(f.getType())) {
                    f.setAccessible(true);
                    reflCubes = f;
                    break;
                }
            }
        } catch (Throwable ignored) {}
    }

    @SuppressWarnings("unchecked")
    static java.util.List<ModelPart.Cube> getCubes(ModelPart part) {
        ensureModelReflect();
        if (reflCubes == null) return java.util.Collections.emptyList();
        try { return (java.util.List<ModelPart.Cube>) reflCubes.get(part); }
        catch (Exception e) { return java.util.Collections.emptyList(); }
    }

    static Object[] getPolygons(ModelPart.Cube cube) {
        ensureModelReflect();
        if (reflPolygons == null) return new Object[0];
        try { return (Object[]) reflPolygons.get(cube); }
        catch (Exception e) { return new Object[0]; }
    }

    static Object[] getVertices(Object polygon) {
        if (reflVertices == null) return new Object[0];
        try { return (Object[]) reflVertices.get(polygon); }
        catch (Exception e) { return new Object[0]; }
    }

    static org.joml.Vector3f getNormal(Object polygon) {
        if (reflNormal == null) return new org.joml.Vector3f(0,1,0);
        try { return (org.joml.Vector3f) reflNormal.get(polygon); }
        catch (Exception e) { return new org.joml.Vector3f(0,1,0); }
    }

    static org.joml.Vector3f getPos(Object vertex) {
        if (reflPos == null) return new org.joml.Vector3f();
        try { return (org.joml.Vector3f) reflPos.get(vertex); }
        catch (Exception e) { return new org.joml.Vector3f(); }
    }

    static float getU(Object vertex) {
        if (reflU == null) return 0f;
        try { return reflU.getFloat(vertex); } catch (Exception e) { return 0f; }
    }

    static float getV(Object vertex) {
        if (reflV == null) return 0f;
        try { return reflV.getFloat(vertex); } catch (Exception e) { return 0f; }
    }

    // ─── Eventos ──────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        ClientLimbCache.clear();
        VanillaArmorDetachCache.clearEntity(event.getEntity().getId());
    }

    @SubscribeEvent
    public static void onRenderLivingPre(RenderLivingEvent.Pre<?, ?> event) {
        LivingEntity entity = event.getEntity();
        int entityId = entity.getId();

        // ── VanillaArmorDetachCache (siempre, incluso si snapshot=null) ──
        Set<LimbType> severed = EnumSet.noneOf(LimbType.class);
        if (entity instanceof Player player) {
            for (LimbType type : LimbType.values()) {
                EquipmentSlot slot = VanillaArmorDetachCache.getSlotForLimb(type);
                ItemStack stack = player.getItemBySlot(slot);
                Item currentItem = stack.isEmpty() ? Items.AIR : stack.getItem();
                if (VanillaArmorDetachCache.shouldHide(entityId, type, currentItem)) {
                    severed.add(type);
                }
            }
        }

        ClientLimbCache.EntityLimbSnapshot snapshot = ClientLimbCache.get(entityId);
        if (snapshot != null) {
            for (LimbType type : LimbType.values()) {
                if (snapshot.isLimbMissing(type)) {
                    severed.add(type);
                    if (entity instanceof Player player) {
                        EquipmentSlot slot = VanillaArmorDetachCache.getSlotForLimb(type);
                        ItemStack stack = player.getItemBySlot(slot);
                        if (!stack.isEmpty()) {
                            VanillaArmorDetachCache.markSevered(entityId, type, stack.getItem());
                        }
                    }
                }
            }
        }

        if (!severed.isEmpty()) CURRENT_SEVERED.set(severed);
        else CURRENT_SEVERED.remove();

        if (snapshot == null) return;

        EntityModel<?> model = event.getRenderer().getModel();
        if (model instanceof PlayerModel<?> pm) {
            applyPreVisibility(pm, snapshot);
        } else if (model instanceof HumanoidModel<?> hm) {
            applyHumanoidModelVisibility(hm, snapshot);
        }
    }

    @SubscribeEvent
    @SuppressWarnings("unchecked")
    public static void onRenderLivingPost(RenderLivingEvent.Post<?, ?> event) {
        CURRENT_SEVERED.remove();

        EnumMap<LimbType, Float> fleshMap = FLESH_PROGRESS.get();
        if (fleshMap.isEmpty()) return;

        LivingEntity entity = event.getEntity();
        if (!(entity instanceof AbstractClientPlayer player)) { fleshMap.clear(); return; }

        EntityModel<?> model = event.getRenderer().getModel();
        if (!(model instanceof PlayerModel<?> pm)) { fleshMap.clear(); return; }

        // Recopilar partes ANTES de cualquier return para poder restaurar en finally
        java.util.EnumMap<LimbType, ModelPart> parts    = new java.util.EnumMap<>(LimbType.class);
        java.util.EnumMap<LimbType, ModelPart> overlays = new java.util.EnumMap<>(LimbType.class);
        for (LimbType t : fleshMap.keySet()) {
            if (t == LimbType.HEAD) continue;
            parts.put(t, getModelPart((PlayerModel<?>) pm, t));
            ModelPart ov = getOverlayPart((PlayerModel<?>) pm, t);
            if (ov != null) overlays.put(t, ov);
        }

        try {
            PoseStack ps  = event.getPoseStack();
            MultiBufferSource buf = event.getMultiBufferSource();
            int light   = event.getPackedLight();
            int overlay = OverlayTexture.NO_OVERLAY;

            // getTextureLocation via reflection (mismatch de tipo genérico)
            ResourceLocation texture = null;
            try {
                java.lang.reflect.Method m = event.getRenderer().getClass()
                        .getMethod("getTextureLocation", net.minecraft.world.entity.Entity.class);
                texture = (ResourceLocation) m.invoke(event.getRenderer(), entity);
            } catch (Throwable t) {
                try {
                    Class<?> cls = event.getRenderer().getClass();
                    outer:
                    while (cls != null) {
                        for (java.lang.reflect.Method m2 : cls.getDeclaredMethods()) {
                            if (m2.getName().equals("getTextureLocation") ||
                                    m2.getName().equals("m_5478_")) {
                                m2.setAccessible(true);
                                texture = (ResourceLocation) m2.invoke(event.getRenderer(), entity);
                                break outer;
                            }
                        }
                        cls = cls.getSuperclass();
                    }
                } catch (Throwable ignored) {}
            }
            if (texture == null) return; // finally restaura visibilidad

            // entityCutoutNoCull: es el render type que usa el PlayerModel vanilla para la skin.
            // Con PHASE_FLESH=0.75 (mismo corte que JJK), no hay solapamiento con la carne
            // → sin z-fighting, sin carne negra, sin carne desapareciendo.
            RenderType renderType = net.minecraft.client.renderer.RenderType.entityCutoutNoCull(texture);
            VertexConsumer vc = buf.getBuffer(renderType);

            float bodyYaw     = net.minecraft.util.Mth.rotLerp(
                    event.getPartialTick(), player.yBodyRotO, player.yBodyRot);
            float scaleFactor = player.getScale();

            for (var entry : fleshMap.entrySet()) {
                    LimbType type    = entry.getKey();
                    float subProgress = entry.getValue();
                    if (type == LimbType.HEAD) continue;

                    ModelPart part     = parts.get(type);
                    ModelPart overlay2 = overlays.get(type);

                    ps.pushPose();
                    ps.mulPose(com.mojang.math.Axis.YP.rotationDegrees(180.0f - bodyYaw));
                    ps.scale(-scaleFactor, -scaleFactor, scaleFactor);
                    ps.translate(0.0f, -1.501f, 0.0f);
                    part.translateAndRotate(ps);
                    renderClippedPart(part, ps, vc, light, overlay, subProgress);
                    ps.popPose();

                    if (overlay2 != null) {
                        ps.pushPose();
                        ps.mulPose(com.mojang.math.Axis.YP.rotationDegrees(180.0f - bodyYaw));
                        ps.scale(-scaleFactor, -scaleFactor, scaleFactor);
                        ps.translate(0.0f, -1.501f, 0.0f);
                        overlay2.translateAndRotate(ps);
                        renderClippedPart(overlay2, ps, vc, light, overlay, subProgress);
                        ps.popPose();
                    }
            }

        } finally {
            // Restaurar visibilidad SIEMPRE, incluso si hubo excepción o return anticipado
            for (ModelPart p : parts.values()) {
                p.visible = true;
                p.xScale = p.yScale = p.zScale = 1.0f;
            }
            for (ModelPart p : overlays.values()) {
                p.visible = true;
                p.xScale = p.yScale = p.zScale = 1.0f;
            }
            fleshMap.clear();
        }
    }

    // ─── Renderizado con recorte UV ───────────────────────────────────────────

    /**
     * Renderiza un ModelPart con la skin revelándose de arriba hacia abajo.
     * subProgress 0.0 = nada visible, 1.0 = todo visible.
     * El UV se interpola para que no haya estiramiento (los píxeles aparecen
     * uno a uno desde el pivot hacia la punta).
     */
    private static void renderClippedPart(ModelPart part, PoseStack ps,
                                          VertexConsumer vc, int light, int overlay,
                                          float subProgress) {
        PoseStack.Pose pose = ps.last();

        ensureModelReflect();
        for (ModelPart.Cube cube : getCubes(part)) {
            Object[] polygons = getPolygons(cube);
            if (polygons.length == 0) continue;

            // Calcular límites Y del cubo (espacio local del ModelPart)
            float yMin = Float.MAX_VALUE, yMax = -Float.MAX_VALUE;
            for (Object poly : polygons) {
                for (Object v : getVertices(poly)) {
                    float y = getPos(v).y();
                    if (y < yMin) yMin = y;
                    if (y > yMax) yMax = y;
                }
            }
            if (yMax - yMin < 0.001f) continue;

            // Línea de corte actual: revela de yMin (hombro/cadera) hacia yMax (mano/pie)
            float targetY = yMin + subProgress * (yMax - yMin);

            for (Object poly : polygons) {
                org.joml.Vector3f normal = getNormal(poly);
                Object[] verts = getVertices(poly);
                if (verts.length == 0) continue;

                // ¿Cara horizontal? (todos los vértices con mismo Y)
                float firstY = getPos(verts[0]).y();
                boolean allSameY = true;
                for (Object v : verts) {
                    if (Math.abs(getPos(v).y() - firstY) > 0.001f) { allSameY = false; break; }
                }

                if (allSameY) {
                    boolean isTop    = Math.abs(firstY - yMin) < 0.001f;
                    boolean isBottom = Math.abs(firstY - yMax) < 0.001f;
                    if (isTop) {
                        emitQuad(pose, vc, verts, normal, firstY, light, overlay);
                    } else if (isBottom) {
                        emitQuad(pose, vc, verts, normal, targetY, light, overlay);
                    }
                } else {
                    emitClippedVerticalFace(pose, vc, verts, normal,
                            yMin, yMax, targetY, light, overlay);
                }
            }
        }
    }

    /**
     * Emite un quad horizontal, con todos los vértices a la misma Y indicada.
     * (Se usa para la cara superior en su posición y para la cara inferior desplazada.)
     */
    private static final float PIXEL_SCALE = 1.0f / 16.0f;

    // ModelPart.Cube.compile() divide las posiciones por 16 (pixels → bloques).
    // Hay que replicar eso aquí, de lo contrario el miembro aparece 16x más grande.
    private static void emitQuad(PoseStack.Pose pose, VertexConsumer vc,
                                  Object[] verts, org.joml.Vector3f normal,
                                  float y, int light, int overlay) {
        for (Object v : verts) {
            org.joml.Vector3f p = getPos(v);
            vc.vertex(pose.pose(), p.x() * PIXEL_SCALE, y * PIXEL_SCALE, p.z() * PIXEL_SCALE)
              .color(1f, 1f, 1f, 1f)
              .uv(getU(v), getV(v))
              .overlayCoords(overlay)
              .uv2(light)
              .normal(pose.normal(), normal.x(), normal.y(), normal.z())
              .endVertex();
        }
    }

    /**
     * Emite una cara vertical recortando los vértices que están por debajo de
     * targetY e interpolando su coordenada V para no estirar la textura.
     * El resultado: la skin aparece de arriba hacia abajo sin deformación.
     */
    private static void emitClippedVerticalFace(PoseStack.Pose pose, VertexConsumer vc,
                                                 Object[] verts, org.joml.Vector3f normal,
                                                 float yMin, float yMax, float targetY,
                                                 int light, int overlay) {
        for (Object v : verts) {
            org.joml.Vector3f p = getPos(v);
            float finalY = p.y();
            float finalU = getU(v);
            float finalV = getV(v);

            if (p.y() > targetY) {
                finalY = targetY;
                // Buscar el vértice hermano superior (mismo X y Z, Y en yMin)
                for (Object other : verts) {
                    org.joml.Vector3f op = getPos(other);
                    if (Math.abs(op.y() - yMin) < 0.001f
                            && Math.abs(op.x() - p.x()) < 0.1f
                            && Math.abs(op.z() - p.z()) < 0.1f) {
                        float t = (targetY - yMin) / (yMax - yMin);
                        finalU = getU(other) + t * (getU(v) - getU(other));
                        finalV = getV(other) + t * (getV(v) - getV(other));
                        break;
                    }
                }
            }

            vc.vertex(pose.pose(), p.x() * PIXEL_SCALE, finalY * PIXEL_SCALE, p.z() * PIXEL_SCALE)
              .color(1f, 1f, 1f, 1f)
              .uv(finalU, finalV)
              .overlayCoords(overlay)
              .uv2(light)
              .normal(pose.normal(), normal.x(), normal.y(), normal.z())
              .endVertex();
        }
    }

    // ─── Visibilidad del modelo ───────────────────────────────────────────────

    private static void applyPreVisibility(PlayerModel<?> model,
                                           ClientLimbCache.EntityLimbSnapshot snapshot) {
        EnumMap<LimbType, Float> fleshMap = FLESH_PROGRESS.get();
        fleshMap.clear();

        for (LimbType type : LimbType.values()) {
            ModelPart part    = getModelPart(model, type);
            ModelPart overlay = getOverlayPart(model, type);
            LimbState state   = snapshot.getState(type);
            float progress    = snapshot.getRegenProgress(type);

            if (state == LimbState.SEVERED) {
                part.visible = false;
                if (overlay != null) overlay.visible = false;
                continue;
            }

            if (state == LimbState.REVERSING) {
                if (progress < PHASE_FLESH) {
                    // Fases bone/muscle: invisible (dibuja EFLimbRegrowthLayer en EF mode)
                    part.visible = false;
                    if (overlay != null) overlay.visible = false;
                } else {
                    // Fase flesh (0.75→1.0): revelar skin progresivamente (brazos/piernas)
                    float subProgress = (progress - PHASE_FLESH) / (1.0f - PHASE_FLESH);

                    if (type == LimbType.HEAD) {
                        // Cabeza: mostrar directo sin efecto de revelado
                        part.visible = true;
                        part.xScale = part.yScale = part.zScale = 1.0f;
                        if (overlay != null) {
                            overlay.visible = true;
                            overlay.xScale = overlay.yScale = overlay.zScale = 1.0f;
                        }
                    } else {
                        // Brazos y piernas: skin reveal manejado por LimbRegrowthLayer.
                        // Solo ocultar el ModelPart para que no se renderice el modelo completo.
                        part.visible = false;
                        if (overlay != null) overlay.visible = false;
                        // NO agregar a fleshMap — LimbRegrowthLayer.render() lo dibuja vía revealModelPart.
                        // Agregarlo causaría un duplicado (LimbRegrowthLayer + onRenderLivingPost).
                    }
                }
                continue;
            }

            // INTACT u otro estado: mostrar normal
            part.visible = true;
            part.xScale = part.yScale = part.zScale = 1.0f;
            if (overlay != null) {
                overlay.visible = true;
                overlay.xScale = overlay.yScale = overlay.zScale = 1.0f;
            }
        }
    }

    private static void applyHumanoidModelVisibility(HumanoidModel<?> model,
                                                      ClientLimbCache.EntityLimbSnapshot snapshot) {
        if (snapshot.isLimbMissing(LimbType.LEFT_ARM))  model.leftArm.visible  = false;
        if (snapshot.isLimbMissing(LimbType.RIGHT_ARM)) model.rightArm.visible = false;
        if (snapshot.isLimbMissing(LimbType.LEFT_LEG))  model.leftLeg.visible  = false;
        if (snapshot.isLimbMissing(LimbType.RIGHT_LEG)) model.rightLeg.visible = false;
        if (snapshot.isLimbMissing(LimbType.HEAD))      model.head.visible     = false;
    }

    // ─── Bug 3: sacar/poner armadura en vanilla resetea EFArmorDetachCache ────

    private static java.lang.reflect.Method EF_CACHE_UPDATE = null;
    private static boolean EF_CACHE_INIT = false;

    private static void ensureEfCacheReflect() {
        if (EF_CACHE_INIT) return;
        EF_CACHE_INIT = true;
        try {
            Class<?> cache = Class.forName(
                    "yesman.epicfight.client.renderer.patched.layer.EFArmorDetachCache");
            EF_CACHE_UPDATE = cache.getMethod("update",
                    int.class, EquipmentSlot.class, Item.class,
                    boolean.class, boolean.class, boolean.class, boolean.class, boolean.class);
        } catch (Throwable ignored) {}
    }

    @SubscribeEvent
    public static void onEquipmentChange(LivingEquipmentChangeEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        EquipmentSlot slot = event.getSlot();
        if (slot.getType() != EquipmentSlot.Type.ARMOR) return;

        int entityId = player.getId();

        for (LimbType type : LimbType.values()) {
            if (VanillaArmorDetachCache.getSlotForLimb(type) == slot) {
                VanillaArmorDetachCache.clearLimb(entityId, type);
            }
        }

        try {
            ensureEfCacheReflect();
            if (EF_CACHE_UPDATE != null) {
                ItemStack newStack = event.getTo();
                Item newItem = newStack.isEmpty() ? Items.AIR : newStack.getItem();
                EF_CACHE_UPDATE.invoke(null, entityId, slot, newItem,
                        false, false, false, false, false);
            }
        } catch (Throwable ignored) {}
    }

    // ─── FOV fix: speed penalty de piernas reduce el FOV de MC ──────────────
    @SubscribeEvent
    public static void onComputeFov(ViewportEvent.ComputeFov event) {
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
        if (mc.player == null) return;
        ClientLimbCache.EntityLimbSnapshot snap = ClientLimbCache.get(mc.player.getId());
        if (snap == null) return;
        // onRenderLivingPre no se ejecuta para el jugador local en cámara de 1ª persona
        // (MC no renderiza el modelo propio ahí), así que VanillaArmorDetachCache nunca
        // se actualizaba al cortar/regenerar un miembro estando en 1ª persona.
        // onComputeFov sí corre todos los frames sin importar la cámara → sincronizamos acá.
        syncLocalArmorCache(mc.player);
        if (snap.getState(LimbType.LEFT_LEG)  == LimbState.INTACT
         && snap.getState(LimbType.RIGHT_LEG) == LimbState.INTACT) return;
        event.setFOV((double) mc.options.fov().get());
    }

    /**
     * Sincroniza VanillaArmorDetachCache para el jugador local. Misma lógica que el bloque
     * de onRenderLivingPre, pero invocable desde un evento que corre en cualquier cámara.
     */
    private static void syncLocalArmorCache(Player player) {
        int entityId = player.getId();
        ClientLimbCache.EntityLimbSnapshot snapshot = ClientLimbCache.get(entityId);
        if (snapshot == null) return;
        for (LimbType type : LimbType.values()) {
            EquipmentSlot slot = VanillaArmorDetachCache.getSlotForLimb(type);
            ItemStack stack = player.getItemBySlot(slot);
            if (snapshot.isLimbMissing(type)) {
                if (!stack.isEmpty()) {
                    VanillaArmorDetachCache.markSevered(entityId, type, stack.getItem());
                }
            } else {
                VanillaArmorDetachCache.clearLimb(entityId, type);
            }
        }
    }

    // ─── Primera persona: ocultar brazo SEVERED ───────────────────────────────
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
        if (mc.player == null) return;
        ClientLimbCache.EntityLimbSnapshot snap = ClientLimbCache.get(mc.player.getId());
        if (snap == null) return;
        HumanoidArm mainArm  = mc.options.mainHand().get();
        boolean isMainHand   = event.getHand() == InteractionHand.MAIN_HAND;
        LimbType limbForHand = (mainArm == HumanoidArm.RIGHT)
            ? (isMainHand ? LimbType.RIGHT_ARM : LimbType.LEFT_ARM)
            : (isMainHand ? LimbType.LEFT_ARM  : LimbType.RIGHT_ARM);
        if (snap.getState(limbForHand) == LimbState.SEVERED) {
            event.setCanceled(true);
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private static ModelPart getModelPart(PlayerModel<?> model, LimbType type) {
        return switch (type) {
            case LEFT_ARM  -> model.leftArm;
            case RIGHT_ARM -> model.rightArm;
            case LEFT_LEG  -> model.leftLeg;
            case RIGHT_LEG -> model.rightLeg;
            case HEAD      -> model.head;
        };
    }

    private static ModelPart getOverlayPart(PlayerModel<?> model, LimbType type) {
        return switch (type) {
            case LEFT_ARM  -> model.leftSleeve;
            case RIGHT_ARM -> model.rightSleeve;
            case LEFT_LEG  -> model.leftPants;
            case RIGHT_LEG -> model.rightPants;
            case HEAD      -> model.hat;
        };
    }
}
