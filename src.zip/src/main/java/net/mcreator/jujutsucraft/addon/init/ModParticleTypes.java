package net.mcreator.jujutsucraft.addon.init;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModParticleTypes {
    public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, "jjkblueredpurple");
    public static final RegistryObject<SimpleParticleType> KOKUSEN_3 = REGISTRY.register("kokusen_3", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> KOKUSEN_5 = REGISTRY.register("kokusen_5", () -> new SimpleParticleType(false));
}
