package net.mcreator.jujutsucraft.addon.mastery;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Compatibilidad con /blackflashchance (comando de JJSK4, addon externo no
 * presente en el classpath de compilación de JoQu). JJSK4 guarda ese valor en
 * su propia capability (net.mcreator.jujutsucrafts.network.JujutsucraftsModVariables.PlayerVariables,
 * NBT "jujutsucrafts:player_variables" -> "BlackFlashChance", rango 0-1000,
 * % real = valor/10).
 *
 * Como JJSK4 no es una dependencia de compilación, no se puede mixinear su
 * clase directamente. En cambio, este handler lee el NBT crudo del jugador
 * cada pocos ticks (igual de barato que cualquier otro polling del addon) y,
 * si detecta que /blackflashchance cambió el valor desde la última lectura,
 * lo traduce a un cambio de maestría (settotal) para el CT activo del
 * jugador — así "usar /blackflashchance" se ve y se comporta exactamente
 * como cambiarle la maestría a mano.
 *
 * Si JJSK4 no está instalado, este handler simplemente nunca encuentra el
 * NBT esperado y no hace nada (costo cercano a cero).
 */
@net.minecraftforge.fml.common.Mod.EventBusSubscriber(modid = "jjkblueredpurple", bus = net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus.FORGE)
public final class Jjsk4BlackFlashChanceBridge {

    private Jjsk4BlackFlashChanceBridge() {
    }

    private static final String JJSK4_CAP_KEY = "jujutsucrafts:player_variables";
    private static final String JJSK4_FIELD = "BlackFlashChance";
    private static final String LAST_SEEN_KEY = "jjkbrp_jjsk4_bfchance_last_seen";

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (event.player.level().isClientSide()) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        // Polling cada 20 ticks (1s): /blackflashchance es un comando manual de admin,
        // no necesita resolución por tick.
        if (player.tickCount % 20 != 0) return;

        Double jjsk4Raw = readJjsk4BlackFlashChance(player);
        if (jjsk4Raw == null) {
            return; // JJSK4 no instalado, o capability no presente todavía.
        }

        CompoundTag data = player.getPersistentData();
        double lastSeen = data.contains(LAST_SEEN_KEY) ? data.getDouble(LAST_SEEN_KEY) : Double.NaN;

        if (Double.isNaN(lastSeen) || Math.abs(jjsk4Raw - lastSeen) > 0.001) {
            data.putDouble(LAST_SEEN_KEY, jjsk4Raw);
            // BlackFlashChance es 0-1000, % real = valor/10.
            double percent = Math.max(0.0, Math.min(100.0, jjsk4Raw / 10.0));
            int ctId = MasteryData.activeCtId(player);
            MasteryData.setTotalMastery(player, ctId, percent);
        }
    }

    /**
     * Lee el campo BlackFlashChance de la capability de JJSK4 desde el NBT crudo
     * del jugador, sin necesitar la clase Java de JJSK4 en el classpath.
     * Devuelve null si JJSK4 no está instalado (la key no existe en ForgeCaps).
     */
    private static Double readJjsk4BlackFlashChance(ServerPlayer player) {
        try {
            CompoundTag root = player.saveWithoutId(new CompoundTag());
            if (!root.contains("ForgeCaps")) return null;
            CompoundTag forgeCaps = root.getCompound("ForgeCaps");
            if (!forgeCaps.contains(JJSK4_CAP_KEY)) return null;
            Tag capTag = forgeCaps.get(JJSK4_CAP_KEY);
            if (!(capTag instanceof CompoundTag capData)) return null;
            if (!capData.contains(JJSK4_FIELD)) return null;
            return capData.getDouble(JJSK4_FIELD);
        } catch (Exception ignored) {
            return null;
        }
    }
}
