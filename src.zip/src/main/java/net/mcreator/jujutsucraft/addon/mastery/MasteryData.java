package net.mcreator.jujutsucraft.addon.mastery;

import net.mcreator.jujutsucraft.network.JujutsucraftModVariables;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;

/**
 * Lee y escribe el % de maestría de Black Flash de un jugador, persistido en
 * su NBT bajo una key por Curse Technique (cada CT lleva su propia maestría
 * independiente, ya que el % base y el límite varían por CT).
 */
public final class MasteryData {

    private MasteryData() {
    }

    private static final String KEY_PREFIX = "jjkbrp_mastery_ct_";

    /** El Curse Technique activo del jugador en este momento (respeta SecondTechnique). */
    public static int activeCtId(ServerPlayer player) {
        JujutsucraftModVariables.PlayerVariables vars = player
            .getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null)
            .orElse(new JujutsucraftModVariables.PlayerVariables());
        double activeTech = vars.SecondTechnique ? vars.PlayerCurseTechnique2 : vars.PlayerCurseTechnique;
        return (int) Math.round(activeTech);
    }

    private static String keyFor(int ctId) {
        return KEY_PREFIX + ctId;
    }

    /** % de maestría actual del jugador para su CT activo (sin contar el base, solo lo farmeado). */
    public static double getFarmedMastery(ServerPlayer player, int ctId) {
        return player.getPersistentData().getDouble(keyFor(ctId));
    }

    /** % total actual: base del CT + lo farmeado, ya clampeado al límite efectivo. */
    public static double getTotalMastery(ServerPlayer player, int ctId) {
        double base = MasteryConfig.baseFor(ctId);
        double farmed = getFarmedMastery(player, ctId);
        double cap = MasteryConfig.effectiveCapFor(ctId);
        return Math.min(base + farmed, Math.max(base, cap));
    }

    /** Suma el % de ganancia configurado tras un Black Flash exitoso (no garantizado), clampeado al cap. */
    public static void onSuccessfulProc(ServerPlayer player, int ctId) {
        double base = MasteryConfig.baseFor(ctId);
        double cap = MasteryConfig.effectiveCapFor(ctId);
        double maxFarmed = Math.max(0.0, cap - base);

        double farmed = getFarmedMastery(player, ctId);
        double gain = MasteryConfig.GLOBAL_GAIN_PER_PROC.get();
        double newFarmed = Math.min(farmed + gain, maxFarmed);

        player.getPersistentData().putDouble(keyFor(ctId), newFarmed);
    }

    /**
     * Setea directamente el % farmeado (no el total) para un CT específico.
     * Usado por /jjkmastery set y por la compatibilidad con /blackflashchance.
     */
    public static void setFarmedMastery(ServerPlayer player, int ctId, double farmedPercent) {
        double base = MasteryConfig.baseFor(ctId);
        double cap = MasteryConfig.effectiveCapFor(ctId);
        double maxFarmed = Math.max(0.0, cap - base);
        double clamped = Math.max(0.0, Math.min(farmedPercent, maxFarmed));
        player.getPersistentData().putDouble(keyFor(ctId), clamped);
    }

    /**
     * Setea el % TOTAL deseado (base + farmeado) resolviendo cuánto hay que
     * guardar como "farmeado" para llegar a ese total. Usado por
     * /jjkmastery settotal y por la compatibilidad con /blackflashchance
     * (que en JJSK4 trabaja con un % total directo, no con un delta).
     */
    public static void setTotalMastery(ServerPlayer player, int ctId, double totalPercent) {
        double base = MasteryConfig.baseFor(ctId);
        double farmedEquivalent = totalPercent - base;
        setFarmedMastery(player, ctId, farmedEquivalent);
    }

    /** Cambia el límite efectivo (cap) que puede farmear un jugador para un CT puntual, vía comando. */
    public static double getCapPercent(int ctId) {
        return MasteryConfig.effectiveCapFor(ctId);
    }

    /**
     * Borra el progreso farmeado de TODOS los CT del jugador (vuelve cada uno
     * a su % base, sin nada acumulado). Usado al detectar un cambio de Curse
     * Technique (ver MasteryCtSwitchReset): la maestría es única por
     * jugador, no se acumula por separado en cada CT que haya usado antes.
     *
     * BLINDAJE DEFINITIVO, A PEDIDO EXPLÍCITO: la maestría NUNCA debe
     * tocarse por un evento de muerte, sin importar cuál sea la causa real
     * o quién termine llamando a este método. En vez de seguir parchando
     * cada lugar posible que podría dispararlo durante una muerte, se
     * bloquea directamente AQUÍ, en el método en sí: si el jugador está
     * muerto o muriendo en este instante, el borrado simplemente no
     * ocurre, sin excepciones, sin importar el camino de código que haya
     * llevado hasta esta llamada.
     */
    public static void resetAllFarmedMastery(ServerPlayer player) {
        if (player.isDeadOrDying() || player.getHealth() <= 0.0F) {
            return;
        }
        // Misma ventana de gracia que usa MasteryCtSwitchReset
        // (jjkbrp_mastery_grace_until_tick) — chequeada también acá, sin
        // depender de que el llamador externo ya la haya respetado.
        long graceUntil = player.getPersistentData().getLong("jjkbrp_mastery_grace_until_tick");
        if (player.level().getGameTime() < graceUntil) {
            return;
        }
        CompoundTag data = player.getPersistentData();
        java.util.List<String> keysToRemove = new java.util.ArrayList<>();
        for (String key : data.getAllKeys()) {
            if (key.startsWith(KEY_PREFIX)) {
                keysToRemove.add(key);
            }
        }
        for (String key : keysToRemove) {
            data.remove(key);
        }
    }
}
