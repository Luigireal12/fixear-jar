package net.mcreator.jujutsucraft.addon;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.mcreator.jujutsucraft.addon.mastery.MasteryConfig;
import net.mcreator.jujutsucraft.addon.mastery.MasteryData;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Registers /jjkmastery commands.
 *
 * Usage:
 *   /jjkmastery gain <player> <percent>     - suma/resta percent al % farmeado del jugador para su CT activo
 *   /jjkmastery settotal <player> <percent> - fija el % TOTAL (base+farmeado) del jugador para su CT activo
 *   /jjkmastery setcap <ctId> <percent>     - fija el limite de maestria farmeable para un Curse Technique
 *   /jjkmastery show <player>               - muestra la maestria actual del jugador
 *   /jjkmastery reload                      - relee jjkblueredpurple-mastery.toml desde disco sin reiniciar
 *
 * Requires OP level 2.
 */
public final class MasteryCommands {

    private MasteryCommands() {
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("jjkmastery")
            .requires(src -> src.hasPermission(2))
            .then(Commands.literal("gain")
                .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("percent", DoubleArgumentType.doubleArg(-100.0, 100.0))
                        .executes(ctx -> {
                            ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                            double delta = DoubleArgumentType.getDouble(ctx, "percent");
                            int ctId = MasteryData.activeCtId(target);
                            double current = MasteryData.getFarmedMastery(target, ctId);
                            MasteryData.setFarmedMastery(target, ctId, current + delta);
                            double newTotal = MasteryData.getTotalMastery(target, ctId);
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                "Maestria de Black Flash de " + target.getName().getString()
                                    + ": " + String.format("%.2f", newTotal) + "%"
                            ), true);
                            return 1;
                        }))))
            .then(Commands.literal("settotal")
                .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("percent", DoubleArgumentType.doubleArg(0.0, 100.0))
                        .executes(ctx -> {
                            ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                            double total = DoubleArgumentType.getDouble(ctx, "percent");
                            int ctId = MasteryData.activeCtId(target);
                            MasteryData.setTotalMastery(target, ctId, total);
                            double newTotal = MasteryData.getTotalMastery(target, ctId);
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                "Maestria de Black Flash de " + target.getName().getString()
                                    + " fijada a: " + String.format("%.2f", newTotal) + "%"
                            ), true);
                            return 1;
                        }))))
            .then(Commands.literal("setcap")
                .then(Commands.argument("ctId", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 1000))
                    .then(Commands.argument("percent", DoubleArgumentType.doubleArg(-1.0, 100.0))
                        .executes(ctx -> {
                            int ctId = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "ctId");
                            double cap = DoubleArgumentType.getDouble(ctx, "percent");
                            MasteryConfig.CtMasteryEntry entry = MasteryConfig.CT_ENTRIES.get(ctId);
                            if (entry == null) {
                                ctx.getSource().sendFailure(Component.literal(
                                    "CT " + ctId + " no esta registrado en jjkblueredpurple-mastery.toml."
                                ));
                                return 0;
                            }
                            entry.capPercent().set(cap);
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                "Limite de maestria para " + entry.displayName() + " (CT " + ctId + ") fijado a: "
                                    + (cap < 0 ? "limite global" : String.format("%.2f%%", cap))
                            ), true);
                            return 1;
                        }))))
            .then(Commands.literal("show")
                .then(Commands.argument("player", EntityArgument.player())
                    .executes(ctx -> {
                        ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                        int ctId = MasteryData.activeCtId(target);
                        double total = MasteryData.getTotalMastery(target, ctId);
                        double cap = MasteryData.getCapPercent(ctId);
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "Maestria de " + target.getName().getString() + " (CT " + ctId + "): "
                                + String.format("%.2f", total) + "% / " + String.format("%.2f", cap) + "%"
                        ), false);
                        return 1;
                    })))
            .then(Commands.literal("reload")
                .executes(ctx -> {
                    boolean ok = MasteryConfig.reloadFromDisk();
                    if (ok) {
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "jjkblueredpurple-mastery.toml recargado desde disco."
                        ), true);
                        return 1;
                    } else {
                        ctx.getSource().sendFailure(Component.literal(
                            "No se pudo recargar el config (no se encontro el archivo registrado)."
                        ));
                        return 0;
                    }
                }))
            .then(Commands.literal("resetcd")
                .then(Commands.argument("player", EntityArgument.player())
                    .executes(ctx -> {
                        ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                        net.mcreator.jujutsucraft.addon.mastery.Output120Handler.resetCooldown(target);
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "Cooldown de Output 120% de " + target.getName().getString() + " reiniciado."
                        ), true);
                        return 1;
                    }))
                .then(Commands.literal("all")
                    .executes(ctx -> {
                        java.util.List<ServerPlayer> targets = ctx.getSource().getServer().getPlayerList().getPlayers();
                        for (ServerPlayer target : targets) {
                            net.mcreator.jujutsucraft.addon.mastery.Output120Handler.resetCooldown(target);
                        }
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "Cooldown de Output 120% reiniciado para " + targets.size() + " jugador(es) online."
                        ), true);
                        return targets.size();
                    }))));
    }
}
