package net.mcreator.jujutsucraft.addon.init;

import net.mcreator.jujutsucraft.addon.potion.Output120CooldownMobEffect;
import net.mcreator.jujutsucraft.addon.potion.Output120ActiveMobEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModMobEffects {
    public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, "jjkblueredpurple");
    public static final RegistryObject<MobEffect> OUTPUT_120_COOLDOWN = REGISTRY.register("output_120_cooldown", Output120CooldownMobEffect::new);
    public static final RegistryObject<MobEffect> OUTPUT_120_ACTIVE = REGISTRY.register("output_120_active", Output120ActiveMobEffect::new);
}
