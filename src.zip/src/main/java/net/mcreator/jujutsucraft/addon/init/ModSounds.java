package net.mcreator.jujutsucraft.addon.init;

import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, "jjkblueredpurple");

    public static final RegistryObject<SoundEvent> OUTPUT_120_POTENTIAL = REGISTRY.register("output_120_potential",
            () -> SoundEvent.createVariableRangeEvent(new net.minecraft.resources.ResourceLocation("jjkblueredpurple", "output_120_potential")));
}
