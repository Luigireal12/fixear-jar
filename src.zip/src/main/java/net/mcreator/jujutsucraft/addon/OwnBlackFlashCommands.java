package net.mcreator.jujutsucraft.addon;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Registra /jjkbfcooldown — único comando propio que queda. El % real de
 * Black Flash NO se configura aquí: la ÚNICA fuente es la maestría
 * persistente de /jjkmastery (ver MasteryData/MasteryConfig), que ya
 * existía antes de este sistema.
 *
 * El comando /jjkbfchance (un % separado, sumado al de maestría) se quitó
 * por completo a pedido explícito — sumar dos números por separado
 * generaba confusión real (20% en cada uno de los dos comandos se sumaba
 * a 40% real, no a 20% como se esperaba). El roll real vive en
 * RangeAttackProcedureMixin.jjkblueredpurple$rollOwnBlackFlashChance,
 * leyendo MasteryData.getTotalMastery directo, sin ningún número propio
 * de por medio.
 *
 * Uso:
 *   /jjkbfcooldown <player> <ticks>   - fija un cooldown extra entre golpes DISTINTOS tras cada proc (0 = sin cooldown extra, default)
 *
 * Requiere OP nivel 2.
 */
public final class OwnBlackFlashCommands {

    private OwnBlackFlashCommands() {
    }

    private static final String KEY_OWN_BF_COOLDOWN_TICKS_CONFIG = "jjkbrp_own_bf_cooldown_ticks_config";

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("jjkbfcooldown")
            .requires(src -> src.hasPermission(2))
            .then(Commands.argument("player", EntityArgument.player())
                .then(Commands.argument("ticks", IntegerArgumentType.integer(0, 72000))
                    .executes(ctx -> {
                        ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                        int ticks = IntegerArgumentType.getInteger(ctx, "ticks");
                        target.getPersistentData().putInt(KEY_OWN_BF_COOLDOWN_TICKS_CONFIG, ticks);
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "Cooldown propio entre golpes distintos de " + target.getName().getString()
                                + " fijado a: " + ticks + " ticks (" + String.format("%.1f", ticks / 20.0) + "s)"
                        ), true);
                        return 1;
                    }))));
    }
}
