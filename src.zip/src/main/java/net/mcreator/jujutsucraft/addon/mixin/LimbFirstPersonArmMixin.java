package net.mcreator.jujutsucraft.addon.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import net.mcreator.jujutsucraft.addon.limb.ClientLimbCache;
import net.mcreator.jujutsucraft.addon.limb.LimbRegrowthLayer;
import net.mcreator.jujutsucraft.addon.limb.LimbState;
import net.mcreator.jujutsucraft.addon.limb.LimbType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Intercepts first-person arm rendering at the exact correct PoseStack state
 * (AFTER all of renderArmWithItem's transforms are applied).
 * Used to:
 * - Hide the arm entirely when SEVERED (handled by RenderHandEvent)
 * - Show the bone→flesh→skin regrowth animation when REVERSING
 *
 * renderRightHand/renderLeftHand are called ONLY for first-person rendering,
 * never for third-person (which uses LivingEntityRenderer instead).
 */
@Mixin(PlayerRenderer.class)
@OnlyIn(Dist.CLIENT)
@SuppressWarnings("unchecked")
public class LimbFirstPersonArmMixin {

    @Inject(method = "renderRightHand", at = @At("HEAD"), cancellable = true)
    private void onRenderRightHand(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                                    AbstractClientPlayer player, CallbackInfo ci) {
        handleFirstPersonArm(poseStack, buffer, packedLight, player, LimbType.RIGHT_ARM, ci);
    }

    @Inject(method = "renderLeftHand", at = @At("HEAD"), cancellable = true)
    private void onRenderLeftHand(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                                   AbstractClientPlayer player, CallbackInfo ci) {
        handleFirstPersonArm(poseStack, buffer, packedLight, player, LimbType.LEFT_ARM, ci);
    }

    private void handleFirstPersonArm(PoseStack poseStack, MultiBufferSource buffer, int light,
                                       AbstractClientPlayer player, LimbType limbType, CallbackInfo ci) {
        // Solo aplica al jugador local en primera persona
        if (Minecraft.getInstance().player != player) return;

        ClientLimbCache.EntityLimbSnapshot snap = ClientLimbCache.get(player.getId());
        if (snap == null) return;

        LimbState state = snap.getState(limbType);
        if (state != LimbState.REVERSING) return; // SEVERED lo maneja RenderHandEvent; INTACT pasa

        // Cancelar el render normal del brazo
        ci.cancel();

        float progress = snap.getRegenProgress(limbType);
        if (progress <= 0f || progress >= 1f) return;

        // El PoseStack ya tiene TODOS los transforms de primera persona aplicados.
        // Solo renderizamos los cubos del brazo con las fases de regeneración.
        PlayerRenderer renderer = (PlayerRenderer)(Object)this;
        PlayerModel<?> model = (PlayerModel<?>) renderer.getModel();

        ModelPart armPart     = limbType == LimbType.RIGHT_ARM ? model.rightArm    : model.leftArm;
        ModelPart overlayPart = limbType == LimbType.RIGHT_ARM ? model.rightSleeve : model.leftSleeve;

        LimbRegrowthLayer.renderForFirstPerson(
            armPart, overlayPart, poseStack, buffer, light, player, limbType, progress
        );
    }
}
