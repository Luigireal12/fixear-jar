package net.mcreator.jujutsucraft.addon.potion;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/**
 * Efecto puramente visual (sin ningún cambio de atributo ni daño) que se
 * muestra mientras el bono real de Output 120% está activo (ver
 * Output120Handler.activate). Su duración real en NBT (KEY_ACTIVE_UNTIL_TICK)
 * sigue siendo la única fuente de verdad — este MobEffect solo refleja ese
 * estado en el HUD de efectos del jugador. Si el jugador lo cancela
 * manualmente (ej. /effect clear), Output120Handler debe detectar la
 * ausencia del efecto y cancelar también el bono real (ver
 * jjkblueredpurple$syncOutput120ActiveEffect), para que ambos queden
 * siempre sincronizados en ambas direcciones.
 */
public class Output120ActiveMobEffect extends MobEffect {
    public Output120ActiveMobEffect() {
        super(MobEffectCategory.BENEFICIAL, 0xFFD700);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return false; // nunca aplica nada tick a tick, es 100% cosmético
    }
}
