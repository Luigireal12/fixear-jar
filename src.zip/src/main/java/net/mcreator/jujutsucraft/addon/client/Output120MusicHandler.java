package net.mcreator.jujutsucraft.addon.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Maneja, del lado cliente, el .ogg que suena al alcanzar Output 120%
 * (ver Output120MusicPacket, que dispara onActivated/onCancelled).
 *
 * Baja DOS categorías reales de Minecraft con un fade abrupto al activarse:
 *   - AMBIENT: cubre tanto los sonidos ambiente nativos del juego como el
 *     sonido propio de Black Flash de stats (que se reproduce explícitamente
 *     con SoundSource.AMBIENT en su RangeAttackProcedureMixin, sin importar
 *     lo que diga la categoría declarada en su sounds.json).
 *   - RECORDS: la categoría real de "Bloques Musicales" en las Opciones de
 *     Sonido de Minecraft (discos/jukebox).
 *
 * El propio .ogg del 120% se reproduce en SoundSource.MASTER (vía
 * SimpleSoundInstance.forUI), una categoría DISTINTA a las dos de arriba —
 * así el fade que aplicamos nunca afecta el volumen de nuestro propio
 * sonido.
 *
 * El fade real se hace sobre Minecraft.options (los sliders reales de
 * Opciones de Sonido) — confirmado que OptionInstance.set() solo actualiza
 * el valor en memoria y dispara el callback que ajusta el motor de sonido
 * en tiempo real; NO escribe a options.txt por sí solo (eso solo pasa si
 * el jugador cierra el menú de Opciones mientras el valor está en el punto
 * intermedio del fade, un caso borde aceptado).
 */
@OnlyIn(Dist.CLIENT)
public final class Output120MusicHandler {

    private Output120MusicHandler() {
    }

    /** Volumen real de cada categoría justo antes de empezar el fade — se restaura a este valor exacto al cortar, sin asumir que era 1.0. */
    private static double savedAmbientVolume = -1.0;
    private static double savedRecordsVolume = -1.0;
    private static Thread fadeThread;
    private static Thread monitorThread;
    private static SoundInstance activeOggInstance;

    /** Duración real del fade "abrupto" hacia abajo, a pedido explícito: rápido, no gradual como una transición normal de música. */
    private static final long FADE_DOWN_MS = 250L;
    /** Restauración del volumen original: más suave que la bajada, para no notarse tan brusco al volver. */
    private static final long FADE_UP_MS = 1500L;
    /** Tope FIJO (no relativo) al que se baja AMBIENT y RECORDS — a pedido explícito: si el jugador ya tiene el volumen en este valor o menos, no se toca en absoluto. */
    private static final double VOLUME_CAP = 0.20;

    public static void onActivated() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }

        cancelFadeThread();
        cancelMonitorThread();

        OptionInstance<Double> ambientOption = mc.options.getSoundSourceOptionInstance(SoundSource.AMBIENT);
        OptionInstance<Double> recordsOption = mc.options.getSoundSourceOptionInstance(SoundSource.RECORDS);
        savedAmbientVolume = ambientOption.get();
        savedRecordsVolume = recordsOption.get();
        // Tope fijo, no relativo: si el jugador ya está en VOLUME_CAP o por
        // debajo, su valor real se preserva sin tocar (el target queda
        // igual al valor actual, así fadeBothVolumes no mueve nada para
        // esa categoría en particular).
        double ambientTarget = Math.min(savedAmbientVolume, VOLUME_CAP);
        double recordsTarget = Math.min(savedRecordsVolume, VOLUME_CAP);

        fadeThread = new Thread(() -> {
            try {
                fadeBothVolumes(ambientOption, savedAmbientVolume, ambientTarget,
                                 recordsOption, savedRecordsVolume, recordsTarget, FADE_DOWN_MS);
            } catch (InterruptedException ignored) {
                return;
            }
            mc.execute(() -> {
                net.minecraft.sounds.SoundEvent oggEvent = net.mcreator.jujutsucraft.addon.init.ModSounds.OUTPUT_120_POTENTIAL.get();
                activeOggInstance = SimpleSoundInstance.forUI(oggEvent, 1.0f, 1.0f);
                mc.getSoundManager().play(activeOggInstance);
                // CRÍTICO (bug real reportado y corregido): startMonitorThread
                // se llamaba afuera de este mc.execute(), en el mismo
                // fadeThread, INMEDIATAMENTE después de encolar esta lambda
                // — pero mc.execute() es asíncrono (solo encola la tarea
                // para el hilo de render), así que el monitor podía arrancar
                // su while ANTES de que activeOggInstance se asignara acá,
                // entrando con null, saliendo del while al instante, y
                // restaurando el volumen casi enseguida (~1 segundo,
                // confirmado real) en vez de esperar a que el .ogg termine.
                // Se mueve el arranque del monitor a DENTRO de esta misma
                // lambda, así se garantiza el orden real.
                startMonitorThread(mc);
            });
        }, "JJKBRP-Output120-Music-FadeDown");
        fadeThread.setDaemon(true);
        fadeThread.start();
    }

    /** Llamado por Output120MusicPacket si el SERVIDOR cancela el bono antes de que el .ogg termine solo (ej. el jugador bajó el output a mano) — en ese caso sí hay que cortar todo de inmediato, sin esperar al monitor. */
    public static void onCancelled() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || savedAmbientVolume < 0.0) {
            return;
        }
        cancelMonitorThread();
        if (activeOggInstance != null) {
            mc.getSoundManager().stop(activeOggInstance);
            activeOggInstance = null;
        }
        restoreVolumes(mc);
    }

    private static void startMonitorThread(Minecraft mc) {
        monitorThread = new Thread(() -> {
            try {
                while (activeOggInstance != null && mc.getSoundManager().isActive(activeOggInstance)) {
                    Thread.sleep(100);
                }
            } catch (InterruptedException ignored) {
                return;
            }
            activeOggInstance = null;
            restoreVolumes(mc);
        }, "JJKBRP-Output120-Music-Monitor");
        monitorThread.setDaemon(true);
        monitorThread.start();
    }

    private static void restoreVolumes(Minecraft mc) {
        if (savedAmbientVolume < 0.0) {
            return; // ya se restauró (ej. onCancelled y el monitor dispararon casi al mismo tiempo)
        }
        cancelFadeThread();

        OptionInstance<Double> ambientOption = mc.options.getSoundSourceOptionInstance(SoundSource.AMBIENT);
        OptionInstance<Double> recordsOption = mc.options.getSoundSourceOptionInstance(SoundSource.RECORDS);
        double ambientFrom = ambientOption.get();
        double recordsFrom = recordsOption.get();
        double ambientTo = savedAmbientVolume;
        double recordsTo = savedRecordsVolume;
        savedAmbientVolume = -1.0;
        savedRecordsVolume = -1.0;

        fadeThread = new Thread(() -> {
            try {
                fadeBothVolumes(ambientOption, ambientFrom, ambientTo,
                                 recordsOption, recordsFrom, recordsTo, FADE_UP_MS);
            } catch (InterruptedException ignored) {
            }
        }, "JJKBRP-Output120-Music-FadeUp");
        fadeThread.setDaemon(true);
        fadeThread.start();
    }

    private static void cancelFadeThread() {
        if (fadeThread != null && fadeThread.isAlive()) {
            fadeThread.interrupt();
        }
    }

    private static void cancelMonitorThread() {
        if (monitorThread != null && monitorThread.isAlive()) {
            monitorThread.interrupt();
        }
    }

    private static void fadeBothVolumes(OptionInstance<Double> ambientOption, double ambientFrom, double ambientTo,
                                          OptionInstance<Double> recordsOption, double recordsFrom, double recordsTo,
                                          long durationMs) throws InterruptedException {
        int steps = 25;
        long stepMs = Math.max(1, durationMs / steps);
        Minecraft mc = Minecraft.getInstance();
        for (int i = 1; i <= steps; i++) {
            double fraction = (double) i / steps;
            double ambientValue = Math.max(0.0, Math.min(1.0, ambientFrom + (ambientTo - ambientFrom) * fraction));
            double recordsValue = Math.max(0.0, Math.min(1.0, recordsFrom + (recordsTo - recordsFrom) * fraction));
            mc.execute(() -> {
                ambientOption.set(ambientValue);
                recordsOption.set(recordsValue);
            });
            Thread.sleep(stepMs);
        }
    }
}
