package net.mcreator.jujutsucraft.addon.limb;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.EnumSet;

@Mod.EventBusSubscriber(modid = "jjkblueredpurple", value = { Dist.CLIENT })
public class LimbArmorFix {

    /** Miembros amputados del jugador que se está renderizando actualmente. */
    public static final ThreadLocal<EnumSet<LimbType>> CURRENT_SEVERED = new ThreadLocal<>();

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderLivingPre(RenderLivingEvent.Pre<?, ?> event) {
        LivingEntity entity = event.getEntity();
        if (!(entity instanceof Player)) { CURRENT_SEVERED.remove(); return; }

        ClientLimbCache.EntityLimbSnapshot snapshot = ClientLimbCache.get(entity.getId());
        if (snapshot == null) { CURRENT_SEVERED.remove(); return; }

        EnumSet<LimbType> severed = EnumSet.noneOf(LimbType.class);
        for (LimbType type : LimbType.values()) {
            if (snapshot.isLimbMissing(type)) severed.add(type);
        }

        if (!severed.isEmpty()) {
            CURRENT_SEVERED.set(severed);
        } else {
            CURRENT_SEVERED.remove();
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onRenderLivingPost(RenderLivingEvent.Post<?, ?> event) {
        CURRENT_SEVERED.remove();
    }
}
