package net.mcreator.jujutsucraft.addon;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.mcreator.jujutsucraft.addon.limb.LimbLossHandler;
import net.mcreator.jujutsucraft.addon.limb.LimbType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Registers /joqu commands.
 *
 * Usage:
 *   /joqu cut <limb> <player>
 *
 * Limbs: left_arm  right_arm  left_leg  right_leg  head
 * Requires OP level 2.
 */
public final class JoquCommands {

    private static final SuggestionProvider<CommandSourceStack> LIMB_SUGGESTIONS =
        (ctx, builder) -> {
            for (String limb : new String[]{"left_arm", "right_arm", "left_leg", "right_leg", "head"}) {
                if (limb.startsWith(builder.getRemaining().toLowerCase())) {
                    builder.suggest(limb);
                }
            }
            return builder.buildFuture();
        };

    private JoquCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
            Commands.literal("joqu")
                .requires(src -> src.hasPermission(2)) // OP level 2
                .then(Commands.literal("cut")
                    .then(Commands.argument("limb", StringArgumentType.word())
                        .suggests(LIMB_SUGGESTIONS)
                        .then(Commands.argument("player", EntityArgument.player())
                            .executes(JoquCommands::executeCut)
                        )
                    )
                )
                .then(Commands.literal("dismantle")
                    .then(Commands.argument("player", EntityArgument.player())
                        .executes(JoquCommands::executeDismantle)
                    )
                )
        );
    }

    private static int executeCut(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        String limbArg = StringArgumentType.getString(ctx, "limb").toLowerCase();

        LimbType limbType;
        switch (limbArg) {
            case "left_arm"  -> limbType = LimbType.LEFT_ARM;
            case "right_arm" -> limbType = LimbType.RIGHT_ARM;
            case "left_leg"  -> limbType = LimbType.LEFT_LEG;
            case "right_leg" -> limbType = LimbType.RIGHT_LEG;
            case "head"      -> limbType = LimbType.HEAD;
            default -> {
                source.sendFailure(Component.literal(
                    "§cExtremidad desconocida: §e" + limbArg +
                    "§c. Opciones: left_arm, right_arm, left_leg, right_leg, head"
                ));
                return 0;
            }
        }

        ServerPlayer target;
        try {
            target = EntityArgument.getPlayer(ctx, "player");
        } catch (Exception e) {
            source.sendFailure(Component.literal("§cJugador no encontrado."));
            return 0;
        }

        boolean severed = LimbLossHandler.forceSeverLimb(target, limbType);
        if (severed) {
            source.sendSuccess(() -> Component.literal(
                "§6[JoQu] §aCorte aplicado: §e" + limbArg + " §ade §b" + target.getName().getString()
            ), true);
            return 1;
        } else {
            source.sendFailure(Component.literal(
                "§c" + target.getName().getString() + " §cya tiene §e" + limbArg + " §ccortado o no disponible."
            ));
            return 0;
        }
    }

    private static int executeDismantle(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack source = ctx.getSource();
        ServerPlayer target;
        try {
            target = EntityArgument.getPlayer(ctx, "player");
        } catch (Exception e) {
            source.sendFailure(Component.literal("§cJugador no encontrado."));
            return 0;
        }
        LimbLossHandler.forceDismantle(target);
        source.sendSuccess(() -> Component.literal(
            "§6[JoQu] §c☠ §b" + target.getName().getString() + " §cfue desmantelado."
        ), true);
        return 1;
    }
}
