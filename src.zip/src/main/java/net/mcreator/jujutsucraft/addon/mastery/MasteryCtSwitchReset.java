package net.mcreator.jujutsucraft.addon.mastery;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * La maestría de Black Flash es única por jugador (no por CT): al cambiar
 * de Curse Technique, la maestría se resetea al % base del CT nuevo,
 * descartando lo farmeado en el CT anterior. Esto detecta el cambio
 * comparando el CT activo actual contra el último visto, y si cambió, borra
 * el progreso farmeado (vuelve a 0, dejando que MasteryData.getTotalMastery
 * caiga al % base del nuevo CT).
 */
@net.minecraftforge.fml.common.Mod.EventBusSubscriber(modid = "jjkblueredpurple", bus = net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus.FORGE)
public final class MasteryCtSwitchReset {

    private MasteryCtSwitchReset() {
    }

    private static final String LAST_CT_KEY = "jjkbrp_mastery_last_ct";
    private static final String GRACE_UNTIL_KEY = "jjkbrp_mastery_grace_until_tick";
    /** Ventana tras respawnear donde este detector no corre en absoluto — a pedido explícito: la maestría nunca debe tocarse al morir, ni por un falso "cambio de CT" detectado por timing de capability justo después del respawn. */
    private static final long GRACE_TICKS = 40L; // 2 segundos

    /**
     * Capa extra de seguridad explícita, además del chequeo isDeadOrDying()
     * en onPlayerTick: marca el momento exacto en ticks de servidor en que
     * el jugador murió, para que ningún tick cercano a ese instante
     * (incluso si por algún motivo isDeadOrDying() ya no devuelve true en
     * ese punto del ciclo de vida del jugador) pueda disparar el reset.
     */
    @net.minecraftforge.eventbus.api.SubscribeEvent
    public static void onLivingDeath(net.minecraftforge.event.entity.living.LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        player.getPersistentData().putLong(GRACE_UNTIL_KEY, player.level().getGameTime() + GRACE_TICKS);
    }

    @net.minecraftforge.eventbus.api.SubscribeEvent
    public static void onPlayerClone(net.minecraftforge.event.entity.player.PlayerEvent.Clone event) {
        if (!event.isWasDeath()) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        CompoundTag oldData = event.getOriginal().getPersistentData();
        CompoundTag newData = player.getPersistentData();
        // Copia directa de LAST_CT_KEY: no depender de que otro archivo
        // (CooldownTrackerEvents) se acuerde de copiar esta key específica
        // cada vez que algo nuevo se agregue a este sistema.
        if (oldData.contains(LAST_CT_KEY)) {
            newData.putInt(LAST_CT_KEY, oldData.getInt(LAST_CT_KEY));
        }
        // Grace period: aunque la key de arriba ya debería evitar el falso
        // "cambio", esto es una segunda capa de seguridad explícita — nunca
        // resetear maestría en los primeros segundos tras un respawn.
        newData.putLong(GRACE_UNTIL_KEY, player.level().getGameTime() + GRACE_TICKS);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (event.player.level().isClientSide()) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        // BUG REAL ENCONTRADO Y CORREGIDO, CONFIRMADO CON LOG REAL: este
        // chequeo NUNCA existía. El tick de este sistema podía correr en el
        // mismo instante en que el jugador está muerto/muriendo (entre
        // LivingDeathEvent y el respawn real), momento en el que
        // MasteryData.activeCtId(player) puede leer un valor de capability
        // distinto al normal (por timing de reviveCaps/invalidateCaps u
        // otra causa), siendo visto como un "cambio de CT" y disparando
        // resetAllFarmedMastery() — confirmado real: el log mostró
        // masteryKeysFound=0 en el Clone, es decir, la maestría YA estaba
        // en cero ANTES de que mi copia del Clone llegara a actuar. Ahora
        // este sistema simplemente no corre si el jugador está
        // muerto/muriendo, dejando la detección de cambio de CT solo para
        // cuando el jugador está realmente vivo y jugando normal.
        if (player.isDeadOrDying() || player.getHealth() <= 0.0F) return;
        // No necesita resolución por tick: el cambio de técnica es una acción
        // manual del jugador, no algo que ocurra varias veces por segundo.
        if (player.tickCount % 20 != 0) return;

        CompoundTag data = player.getPersistentData();
        long now = player.level().getGameTime();
        long graceUntil = data.getLong(GRACE_UNTIL_KEY);
        if (now < graceUntil) {
            // Todavía en la ventana de gracia post-respawn: solo actualizar
            // el CT visto, sin evaluar ni disparar ningún reset.
            data.putInt(LAST_CT_KEY, MasteryData.activeCtId(player));
            return;
        }

        int currentCt = MasteryData.activeCtId(player);

        boolean hasLastCt = data.contains(LAST_CT_KEY);
        int lastCt = data.getInt(LAST_CT_KEY);

        if (!hasLastCt) {
            // Primera vez que vemos a este jugador: solo registrar el CT
            // actual, sin resetear nada (no hubo "cambio" real todavía).
            data.putInt(LAST_CT_KEY, currentCt);
            return;
        }

        if (currentCt != lastCt) {
            data.putInt(LAST_CT_KEY, currentCt);
            // Borra el progreso farmeado de TODOS los CTs (no solo el nuevo),
            // ya que la maestría es única por jugador, no acumulable por CT
            // separado: cambiar de técnica siempre debe dejarte en el %
            // default del CT que acabás de elegir.
            MasteryData.resetAllFarmedMastery(player);
        }
    }
}
