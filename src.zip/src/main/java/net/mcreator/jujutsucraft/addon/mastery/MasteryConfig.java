package net.mcreator.jujutsucraft.addon.mastery;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.config.ModConfig;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Configuración del sistema de maestría de Black Flash. Reemplaza al
 * porcentaje "que sube con el tiempo en combate" (CooldownTrackerEvents /
 * addon_bf_chance) por un sistema persistente: cada jugador arranca con el
 * % base de su Curse Technique actual, y ese % sube de forma permanente
 * cada vez que conecta un Black Flash real (no cuenta el garantizado de
 * Todo's "Plus Ultra"), hasta el límite de su CT o el límite global, el
 * que sea menor.
 *
 * Los IDs de Curse Technique (PlayerCurseTechnique) están confirmados
 * contra el código fuente real de cada addon:
 *   1-47    -> JujutsuCraft base (net.mcreator.jujutsucraft, Select*Procedure)
 *   33,42,70-127 -> JJSK4 (net.mcreator.jujutsucrafts, Button*Procedure)
 *   601-633 -> JujutsuCraftV (net.mcreator.jujutsucraftv, Button*Procedure)
 *
 * Solo Itadori (21) tiene un % base distinto por defecto, replicando el
 * único caso real de tratamiento especial que existe en el código del mod
 * base (bono de "level" en PlayerPhysicalAbilityProcedure / num1 en
 * RangeAttackProcedure). El resto arranca igual, editable a mano en este
 * archivo según se necesite.
 */
public final class MasteryConfig {

    private MasteryConfig() {
    }

    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.DoubleValue GLOBAL_GAIN_PER_PROC;
    public static final ForgeConfigSpec.DoubleValue GLOBAL_MASTERY_CAP;

    public static final ForgeConfigSpec.IntValue OUTPUT_120_PROCS_REQUIRED;
    public static final ForgeConfigSpec.IntValue OUTPUT_120_WINDOW_SECONDS;
    public static final ForgeConfigSpec.IntValue OUTPUT_120_DURATION_SECONDS;
    public static final ForgeConfigSpec.IntValue OUTPUT_120_COOLDOWN_SECONDS;
    public static final ForgeConfigSpec.DoubleValue OUTPUT_120_DAMAGE_BONUS;
    public static final ForgeConfigSpec.DoubleValue OUTPUT_120_SPEED_BONUS;

    /** ID de Curse Technique -> handle de config (% base, % límite, nombre legible). */
    public static final Map<Integer, CtMasteryEntry> CT_ENTRIES = new LinkedHashMap<>();

    public record CtMasteryEntry(int ctId, String displayName,
                                  ForgeConfigSpec.DoubleValue basePercent,
                                  ForgeConfigSpec.DoubleValue capPercent) {
    }

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();

        builder.push("global");
        builder.comment("Cuanto % de maestria se gana por cada Black Flash EXITOSO (no cuenta el garantizado de Todo's Plus Ultra).");
        GLOBAL_GAIN_PER_PROC = builder.defineInRange("gain_per_proc", 0.5, 0.0, 100.0);
        builder.comment("Limite maximo de maestria farmeable, salvo que el CT tenga su propio limite (el limite por CT reemplaza a este, no se suman).");
        GLOBAL_MASTERY_CAP = builder.defineInRange("global_cap_percent", 35.0, 0.0, 100.0);
        builder.pop();

        builder.push("output_120");
        builder.comment("Cuantos Black Flash exitosos seguidos (estando al 100% de output en cada uno) hacen falta para activar el bono de 120%.");
        OUTPUT_120_PROCS_REQUIRED = builder.defineInRange("procs_required", 3, 1, 100);
        builder.comment("Ventana en segundos entre un Black Flash de progreso y el siguiente. Si se pasa este tiempo sin completar el siguiente, el progreso se resetea a 0.");
        OUTPUT_120_WINDOW_SECONDS = builder.defineInRange("window_seconds", 120, 1, 3600);
        builder.comment("Duracion en segundos del bono de 120% una vez activado.");
        OUTPUT_120_DURATION_SECONDS = builder.defineInRange("duration_seconds", 30, 1, 3600);
        builder.comment("Cooldown en segundos antes de poder volver a activar el bono, despues de que termine o se pierda por bajar el output.");
        OUTPUT_120_COOLDOWN_SECONDS = builder.defineInRange("cooldown_seconds", 60, 0, 3600);
        builder.comment("Bono de daño mientras el efecto esta activo (0.20 = +20%).");
        OUTPUT_120_DAMAGE_BONUS = builder.defineInRange("damage_bonus_percent", 0.20, 0.0, 5.0);
        builder.comment("Bono de velocidad mientras el efecto esta activo (0.20 = +20%).");
        OUTPUT_120_SPEED_BONUS = builder.defineInRange("speed_bonus_percent", 0.20, 0.0, 5.0);
        builder.pop();

        builder.push("curse_techniques");
        builder.comment(
            "Una entrada por cada Curse Technique (PlayerCurseTechnique). base_percent = chance inicial",
            "antes de farmear nada. cap_percent = limite maximo que ESE CT puede farmear (reemplaza",
            "al limite global para ese CT especifico, no se suma). Los numeros estan confirmados",
            "contra el codigo fuente real de cada addon (ver comentario de clase)."
        );

        // ── JujutsuCraft base (1-47) ────────────────────────────────────────────
        ct(builder, 1,  "Sukuna",            0.2, -1);
        ct(builder, 2,  "Satoru Gojo",       0.2, -1);
        ct(builder, 3,  "Toge Inumaki",      0.2, -1);
        ct(builder, 4,  "Jogo",              0.2, -1);
        ct(builder, 5,  "Yuta Okkotsu",      0.2, -1);
        ct(builder, 6,  "Megumi Fushiguro",  0.2, -1);
        ct(builder, 7,  "Hajime Kashimo",    0.2, -1);
        ct(builder, 8,  "Dagon",             0.2, -1);
        ct(builder, 9,  "Yuki Tsukumo",      0.2, -1);
        ct(builder, 10, "Choso",             0.2, -1);
        ct(builder, 11, "Mei Mei",           0.2, -1);
        ct(builder, 12, "Ryu Ishigori",      0.2, -1);
        ct(builder, 13, "Kento Nanami",      0.2, -1);
        ct(builder, 14, "Hanami",            0.2, -1);
        ct(builder, 15, "Mahito",            0.2, -1);
        ct(builder, 16, "Mahoraga",          0.2, -1);
        ct(builder, 17, "Fumihiko Takaba",   0.2, -1);
        ct(builder, 18, "Suguru Geto",       0.2, -1);
        ct(builder, 19, "Naoya Zenin",       0.2, -1);
        ct(builder, 20, "Aoi Todo",          0.2, -1);
        ct(builder, 21, "Yuji Itadori",      0.5, -1); // único caso real con bonus en el código base
        ct(builder, 22, "Jinichi Zenin",     0.2, -1);
        ct(builder, 23, "Kurourushi",        0.2, -1);
        ct(builder, 24, "Uraume",            0.2, -1);
        ct(builder, 25, "Smallpox Deity",    0.2, -1);
        ct(builder, 26, "Ogi Zenin",         0.2, -1);
        ct(builder, 27, "Hiromi Higuruma",   0.2, -1);
        ct(builder, 28, "Angel",             0.2, -1);
        ct(builder, 29, "Kinji Hakari",      0.2, -1);
        ct(builder, 30, "Miguel Oduol",      0.2, -1);
        ct(builder, 31, "Atsuya Kusakabe",   0.2, -1);
        ct(builder, 32, "Chojuro Zenin",     0.2, -1);
        ct(builder, 33, "Masamichi Yaga",    0.2, -1);
        ct(builder, 34, "Nobara Kugisaki",   0.2, -1);
        ct(builder, 35, "Junpei Yoshino",    0.2, -1);
        ct(builder, 36, "Momo Nishimiya",    0.2, -1);
        ct(builder, 37, "Dhruv Lakdawalla",  0.2, -1);
        ct(builder, 38, "Takako Uro",        0.2, -1);
        ct(builder, 39, "Yorozu",            0.2, -1);
        ct(builder, 40, "Takuma Ino",        0.2, -1);
        ct(builder, 41, "Kaori Itadori",     0.2, -1);
        ct(builder, 43, "Rozetsu",           0.2, -1);
        ct(builder, 44, "Reggie Star",       0.2, -1);
        ct(builder, 45, "Iori Hazenoki",     0.2, -1);
        ct(builder, 46, "Ranta Zenin",       0.2, -1);
        ct(builder, 47, "Crystal Curse",     0.2, -1);

        // ── JJSK4 (33 colisiona con Yaga del mod base; 70-127) ──────────────────
        // Verificado contra com/jujutsurebalanced/data/JJSKRegistry.java (registro
        // real de jujutsurebalanced, que reimplementa el mismo addon).
        ct(builder, 70,  "Practitioner (JJSK4)",     0.2, -1);
        ct(builder, 71,  "Dabura (JJSK4)",            0.2, -1);
        ct(builder, 72,  "Akuro (JJSK4)",              0.2, -1);
        ct(builder, 73,  "Samurai (JJSK4)",            0.2, -1);
        ct(builder, 74,  "Cursed Sword (JJSK4)",       0.2, -1);
        ct(builder, 75,  "Tsuchigumo (JJSK4)",         0.2, -1);
        ct(builder, 80,  "Kaito (JJSK4)",              0.2, -1);
        ct(builder, 81,  "Saki (JJSK4)",               0.2, -1);
        ct(builder, 82,  "Haba (JJSK4)",               0.2, -1);
        ct(builder, 83,  "Hanyu (JJSK4)",              0.2, -1);
        ct(builder, 84,  "Aizen (JJSK4)",              0.2, -1);
        ct(builder, 85,  "Utahime (JJSK4)",            0.2, -1);
        ct(builder, 86,  "Eso (JJSK4)",                0.2, -1);
        ct(builder, 87,  "Haruta (JJSK4)",             0.2, -1);
        ct(builder, 88,  "Ganesha (JJSK4)",            0.2, -1);
        ct(builder, 89,  "Sugawara (JJSK4)",           0.2, -1);
        ct(builder, 90,  "Teru Teru (JJSK4)",          0.2, -1);
        ct(builder, 91,  "Harden (JJSK4)",             0.2, -1);
        ct(builder, 92,  "Driver (JJSK4)",             0.2, -1);
        ct(builder, 93,  "Necklace (JJSK4)",           0.2, -1);
        ct(builder, 94,  "Kiss (JJSK4)",                0.2, -1);
        ct(builder, 95,  "Remi (JJSK4)",                0.2, -1);
        ct(builder, 96,  "Rika (JJSK4)",                0.2, -1);
        ct(builder, 97,  "Chameleon (JJSK4)",           0.2, -1);
        ct(builder, 98,  "Division (JJSK4)",            0.2, -1);
        ct(builder, 99,  "Kappa (JJSK4)",               0.2, -1);
        ct(builder, 104, "Kuchisake (JJSK4)",           0.2, -1);
        ct(builder, 105, "Mammoth (JJSK4)",             0.2, -1);
        ct(builder, 106, "Blindness (JJSK4)",           0.2, -1);
        ct(builder, 107, "Forest (JJSK4)",              0.2, -1);
        ct(builder, 108, "Tamamo (JJSK4)",              0.2, -1);
        ct(builder, 109, "Charles (JJSK4)",             0.2, -1);
        ct(builder, 110, "Gakuganji (JJSK4)",           0.2, -1);
        ct(builder, 111, "Ogami (JJSK4)",               0.2, -1);
        ct(builder, 112, "Larue (JJSK4)",               0.2, -1);
        ct(builder, 113, "Marulu Val Vol Yelvori (JJSK4)", 0.2, -1);
        ct(builder, 114, "Kurosu Varu Vuru Yeruvuri (JJSK4)", 0.2, -1);
        ct(builder, 115, "Kenjaku (JJSK4)",             0.2, -1);
        ct(builder, 116, "Ui Ui (JJSK4)",               0.2, -1);
        ct(builder, 117, "Insect (JJSK4)",              0.2, -1);
        ct(builder, 119, "Jiro (JJSK4)",                0.2, -1);
        ct(builder, 120, "Nanako (JJSK4)",              0.2, -1);
        ct(builder, 121, "Mimiko (JJSK4)",              0.2, -1);
        ct(builder, 122, "Mask (JJSK4)",                0.2, -1);
        ct(builder, 123, "Bayer (JJSK4)",               0.2, -1);
        ct(builder, 124, "Hanako (JJSK4)",              0.2, -1);
        ct(builder, 125, "Panda (JJSK4)",               0.2, -1);
        ct(builder, 126, "Hari (JJSK4)",                0.2, -1);
        ct(builder, 127, "Daido (JJSK4)",               0.2, -1);

        // ── JujutsuCraftV (601-633) ──────────────────────────────────────────────
        ct(builder, 601, "Without Cursed Technique (V)", 0.2, -1);
        ct(builder, 602, "Blindness (V)",                0.2, -1);
        ct(builder, 603, "Tamamonomae Incarnate (V)",    0.2, -1);
        ct(builder, 604, "Forest (V)",                   0.2, -1);
        ct(builder, 605, "Insect (V)",                   0.2, -1);
        ct(builder, 606, "Mammoth (V)",                  0.2, -1);
        ct(builder, 607, "Ganesha (V)",                  0.2, -1);
        ct(builder, 608, "Kuchisakeonna (V)",             0.2, -1);
        ct(builder, 609, "Bayer (V)",                     0.2, -1);
        ct(builder, 610, "Bagmask (V)",                   0.2, -1);
        ct(builder, 611, "Uiui (V)",                       0.2, -1);
        ct(builder, 612, "Eso/Kechizu (V)",               0.2, -1);
        ct(builder, 613, "Whackamole (V)",                0.2, -1);
        ct(builder, 614, "Necknecklace (V)",              0.2, -1);
        ct(builder, 615, "Gakuganji (V)",                 0.2, -1);
        ct(builder, 616, "Utahime (V)",                   0.2, -1);
        ct(builder, 617, "Hazenoki (V)",                  0.2, -1);
        ct(builder, 618, "Crystal Ore (V)",               0.2, -1);
        ct(builder, 619, "O. Tsurugi (V)",                0.2, -1);
        ct(builder, 620, "Yuki (V)",                       0.2, -1);
        ct(builder, 621, "Rindou (V)",                     0.2, -1);
        ct(builder, 622, "Amai (V)",                       0.2, -1);
        ct(builder, 623, "Samurai Armor (V)",             0.2, -1);
        ct(builder, 624, "Akuroo (V)",                     0.2, -1);
        ct(builder, 625, "Hanako (V)",                     0.2, -1);
        ct(builder, 626, "Mouse (V)",                      0.2, -1);
        ct(builder, 627, "Doodle (V)",                     0.2, -1);
        ct(builder, 628, "H. Mimiko (V)",                  0.2, -1);
        ct(builder, 629, "H. Nanako (V)",                  0.2, -1);
        ct(builder, 630, "Dabura (V)",                     0.2, -1);
        ct(builder, 631, "Tsuchigumo (V)",                 0.2, -1);
        ct(builder, 632, "Nostalgia (V)",                  0.2, -1);
        ct(builder, 633, "Mayfly (V)",                     0.2, -1);

        builder.pop();

        SPEC = builder.build();
    }

    private static void ct(ForgeConfigSpec.Builder builder, int id, String name, double basePercent, double capPercentOrMinusOneForGlobal) {
        builder.push("ct_" + id + "_" + sanitize(name));
        ForgeConfigSpec.DoubleValue base = builder
            .comment(name + " (PlayerCurseTechnique=" + id + ") - chance base antes de farmear nada.")
            .defineInRange("base_percent", basePercent, 0.0, 100.0);
        ForgeConfigSpec.DoubleValue cap = builder
            .comment(name + " - limite maximo de maestria para este CT. -1 = usar el limite global en su lugar.")
            .defineInRange("cap_percent", capPercentOrMinusOneForGlobal, -1.0, 100.0);
        builder.pop();
        CT_ENTRIES.put(id, new CtMasteryEntry(id, name, base, cap));
    }

    private static String sanitize(String name) {
        return name.toLowerCase().replaceAll("[^a-z0-9]+", "_").replaceAll("^_+|_+$", "");
    }

    public static void register(net.minecraftforge.fml.ModLoadingContext context) {
        context.registerConfig(ModConfig.Type.COMMON, SPEC, "jjkblueredpurple-mastery.toml");
    }

    /**
     * Fuerza a Forge a releer jjkblueredpurple-mastery.toml desde disco ahora
     * mismo, sin esperar al file watcher automático ni reiniciar. Usado por
     * /jjkmastery reload.
     * @return true si se pudo recargar, false si no se encontró el config
     *         registrado o el reload falló.
     */
    public static boolean reloadFromDisk() {
        try {
            for (java.util.Set<ModConfig> configs : net.minecraftforge.fml.config.ConfigTracker.INSTANCE.configSets().values()) {
                for (ModConfig modConfig : configs) {
                    if (modConfig.getSpec() == SPEC) {
                        Object configData = modConfig.getConfigData();
                        if (configData instanceof com.electronwill.nightconfig.core.file.CommentedFileConfig fileConfig) {
                            fileConfig.load();
                            return true;
                        }
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    /** % límite efectivo para un CT: su propio cap si está definido (>=0), si no el global. */
    public static double effectiveCapFor(int ctId) {
        CtMasteryEntry entry = CT_ENTRIES.get(ctId);
        if (entry == null) {
            return GLOBAL_MASTERY_CAP.get();
        }
        double ownCap = entry.capPercent().get();
        return ownCap >= 0.0 ? ownCap : GLOBAL_MASTERY_CAP.get();
    }

    /** % base para un CT, o un valor genérico (0.2%, el original de JujutsuCraft) si no está registrado. */
    public static double baseFor(int ctId) {
        CtMasteryEntry entry = CT_ENTRIES.get(ctId);
        return entry != null ? entry.basePercent().get() : 0.2;
    }
}
