package net.mcreator.jujutsucraft.addon;

import java.util.List;
import java.util.Objects;
import java.util.Random;
import net.mcreator.jujutsucraft.addon.ClientPacketHandler;
import net.mcreator.jujutsucraft.addon.DomainMasteryCapabilityProvider;
import net.mcreator.jujutsucraft.addon.DomainMasteryData;
import net.mcreator.jujutsucraft.addon.DomainMasteryProperties;
import net.mcreator.jujutsucraft.addon.ModNetworking;
import net.mcreator.jujutsucraft.addon.clash.power.PowerCalculator;
import net.mcreator.jujutsucraft.addon.logic.HeaderLayout;
import net.mcreator.jujutsucraft.addon.logic.Rect;
import net.mcreator.jujutsucraft.addon.util.DomainForm;
import net.mcreator.jujutsucraft.init.JujutsucraftModMobEffects;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;

/**
 * Full custom client GUI for domain mastery management. The screen renders animated panels, XP and form widgets, eight property cards, negative modify controls, and mutation locks during combat or active domains.
 */
// ===== SCREEN LIFECYCLE =====
public class DomainMasteryScreen
extends Screen {
    // Base panel width in screen pixels before UI scaling is applied.
    private static final int PANEL_W = 640;
    // Base panel height in screen pixels before UI scaling is applied.
    private static final int PANEL_H = 682;
    // Base header height used by the animated mastery panel layout.
    private static final int HEADER_H = 154;
    // Base footer height reserved for reset and close buttons.
    private static final int FOOTER_H = 56;
    // Base height of a single property card row.
    private static final int PROP_ROW = 82;
    // Base width of a single property column.
    private static final int PROP_COL_W = 143;
    // Base horizontal gap between property columns.
    private static final int PROP_GAP_X = 16;
    // Base vertical gap between property rows.
    private static final int PROP_GAP_Y = 12;
    // Scaled panel width calculated for the current client resolution.
    private int drawW = 640;
    // Scaled panel height calculated for the current client resolution.
    private int drawH = 682;
    // Scaled header height used during rendering.
    private int drawHeaderH = 154;
    // Scaled footer height used during rendering.
    private int drawFooterH = 56;
    // Scaled property row height used during rendering.
    private int drawPropRow = 82;
    // Scaled property column width used during rendering.
    private int drawPropColW = 143;
    // Scaled horizontal property gap used during rendering.
    private int drawPropGapX = 16;
    // Scaled vertical property gap used during rendering.
    private int drawPropGapY = 12;
    // Packed color used for the main mastery panel background.
    private static final int PANEL_BG = 463645;
    // Packed color used for the mastery panel border.
    private static final int PANEL_BORDER = 3718648;
    // Packed color used for the header background block.
    private static final int HEADER_BG = 728106;
    // Accent color used for the cursed energy drain property card.
    private static final int C_CE_DRAIN = 3718648;
    // Accent color used for the Black Flash chance property card.
    private static final int C_BF_CHANCE = 16096779;
    // Accent color used for the reverse cursed technique healing property card.
    private static final int C_RCT_HEAL = 2278750;
    // Accent color used for the blind property card.
    private static final int C_BLIND = 16007006;
    // Accent color used for the slow property card.
    private static final int C_SLOW = 6333946;
    // Accent color used for the duration property card.
    private static final int C_DURATION = 16486972;
    // Accent color used for the radius property card.
    private static final int C_RADIUS = 1357990;
    // Accent color used for the incomplete form button.
    private static final int C_FORM_INC = 4674921;
    // Accent color used for the closed form button.
    private static final int C_FORM_CLS = 165063;
    // Accent color used for the open form button.
    private static final int C_FORM_OPN = 1483594;
    // Accent color used for locked form states.
    private static final int C_FORM_LCK = 2042167;
    // Primary bright text color used throughout the screen.
    private static final int TEXT_WHITE = 15857145;
    // Secondary text color used for neutral details.
    private static final int TEXT_MID = 9741240;
    // Low-contrast text color used for subdued labels.
    private static final int TEXT_DIM = 4674921;
    // Highlight text color used for XP and mastery emphasis.
    private static final int TEXT_GOLD = 16569165;
    // Muted text color used when controls are locked.
    private static final int TEXT_LOCK = 4937059;
    private static final int UI_PANEL_TOP = 0x09111F;
    private static final int UI_PANEL_BOTTOM = 0x03050D;
    private static final int UI_HEADER_TOP = 0x141D34;
    private static final int UI_HEADER_BOTTOM = 0x07101F;
    private static final int UI_ROW = 0x101827;
    private static final int UI_ROW_HOVER = 0x172238;
    private static final int UI_TEXT = 0xEAF2FF;
    private static final int UI_TEXT_MID = 0x9CAFC6;
    private static final int UI_TEXT_DIM = 0x5F7088;
    private static final int UI_BLUE = 0x38BDF8;
    private static final int UI_RED = 0xEF4444;
    private static final int UI_GREEN = 0x22C55E;
    private static final int UI_GOLD = 0xFBBF24;
    // Base color for the reset button.
    private static final int BTN_RESET_BG = 1013358;
    // Hover color for the reset button.
    private static final int BTN_RESET_HV = 1357990;
    // Base color for the close button.
    private static final int BTN_CLOSE_BG = 1976635;
    // Hover color for the close button.
    private static final int BTN_CLOSE_HV = 3359061;
    // Base color for plus buttons that spend points.
    private static final int BTN_PLUS_BG = 366185;
    // Hover color for plus buttons that spend points.
    private static final int BTN_PLUS_HV = 1096065;
    // Base color for minus buttons that refund or deepen negatives.
    private static final int BTN_MINUS_BG = 14427686;
    // Hover color for minus buttons that refund or deepen negatives.
    private static final int BTN_MINUS_HV = 0xEF4444;
    // ===== RESTRAINED HEADER TITLE PALETTE (Issue 1) =====
    // The "DOMAIN MASTERY" title uses at most two cohesive colors: a light icy-blue base
    // and its dark emboss/shadow color. The single underline uses one accent color. This
    // small, cohesive blue-family palette replaces the removed per-character chromatic
    // colors[] / lineColors[] arrays so the header reads as restrained, not multi-color.
    // Light base fill color for the title text.
    private static final int TITLE_BASE_COLOR = 0xE0F2FE;
    // Dark emboss/outline/shadow color paired with the base (second of the two colors).
    private static final int TITLE_SHADOW_COLOR = 0x0C4A6E;
    // Single accent color used for the lone title underline (shared with the panel accent).
    private static final int TITLE_ACCENT_COLOR = 0x38BDF8;
    // Left edge of the scaled mastery panel.
    private int panelX;
    // Top edge of the scaled mastery panel.
    private int panelY;
    // Timestamp captured when the screen opens so the intro animation can be timed.
    private long openTimeMs;
    // Global UI scale derived from the current window size.
    private float fontScale = 1.0f;
    // Normalized open animation progress used for fade and panel transitions.
    private float openAnim = 0.0f;
    // Tick-like counter used to animate subtle UI pulsing.
    private float pulseTick = 0.0f;
    // Timestamp of the last pulse counter advance.
    private long lastPulse = 0L;
    // Currently hovered property index, or -1 when no property control is highlighted.
    private int hoveredPropIdx = -1;
    // Locally cached selected domain form shown by the form buttons.
    private int selectedForm = 0;
    // Whether the player currently has access to the closed form.
    private boolean closedUnlocked = false;
    // Whether the player currently has access to the open form.
    private boolean openUnlocked = false;
    // Tracks whether any form button is currently hovered.
    private boolean hoveredFormBtn = false;
    // Index of the currently hovered form button, or -1 when none is hovered.
    private int hoveredFormIdx = -1;
    // Whether the reset button is currently hovered.
    private boolean hoveredReset = false;
    // Whether the close button is currently hovered.
    private boolean hoveredClose = false;
    private boolean hoveredSukunaSureHit = false;
    // Per-property hover flags for the plus buttons.
    private boolean[] hoveredPlus = new boolean[DomainMasteryProperties.values().length];
    // Per-property hover flags for the minus buttons.
    private boolean[] hoveredMinus = new boolean[DomainMasteryProperties.values().length];
    // Previously hovered control id so hover sounds only fire on transitions.
    private int lastHoveredControl = -1;
    // Whether domain mastery changes are currently blocked by combat or active domains.
    private boolean masteryMutationLocked = false;
    // Whether the cursor is currently over a control that is locked by mutation restrictions.
    private boolean hoveredMutationControl = false;
    // Human-readable explanation shown when mastery mutation is blocked.
    private String masteryMutationLockReason = "";
    // Random instance used for small decorative animation variations.
    private final Random rng = new Random();
    // Guard flag that prevents the opening sound from replaying unnecessarily.
    private boolean playedOpenSound = false;

    /**
     * Creates a new domain mastery screen instance and initializes its addon state.
     */
    public DomainMasteryScreen() {
        super((Component)Component.literal((String)"Domain Mastery"));
        this.openTimeMs = System.currentTimeMillis();
    }

    /**
     * Performs init for this addon component.
     */
    protected void init() {
        super.init();
        this.computeResponsiveLayout();
        this.refreshFormState();
        this.refreshMutationLockState();
        this.playUiOpenSound();
    }

    private void computeResponsiveLayout() {
        int availW = Math.max(180, (int)((float)this.width * 0.9f));
        int availH = Math.max(180, (int)((float)this.height * 0.9f));
        this.fontScale = Math.min(1.0f, Math.min((float)availW / 640.0f, (float)availH / 682.0f));
        this.drawW = Math.max(180, (int)((float)PANEL_W * this.fontScale));
        this.drawH = Math.max(180, (int)((float)PANEL_H * this.fontScale));
        this.drawHeaderH = Math.max(52, (int)(154.0f * this.fontScale));
        this.drawFooterH = Math.max(28, (int)(56.0f * this.fontScale));
        this.drawPropRow = Math.max(32, (int)(82.0f * this.fontScale));
        this.drawPropGapX = Math.max(6, (int)(16.0f * this.fontScale));
        this.drawPropGapY = Math.max(4, (int)(12.0f * this.fontScale));
        this.drawPropColW = Math.max(72, (this.getPropertyAreaWidth() - this.drawPropGapX) / 2);
        this.panelX = (this.width - this.drawW) / 2;
        this.panelY = (this.height - this.drawH) / 2;
    }

    // ===== STATE REFRESH =====
    private void refreshFormState() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            try {
                this.selectedForm = mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(DomainMasteryData::getDomainTypeSelected).orElse(0);
                this.closedUnlocked = mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(DomainMasteryData::isClosedFormUnlocked).orElse(false);
                this.openUnlocked = mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(DomainMasteryData::isOpenFormUnlocked).orElse(false);
            }
            catch (Exception e) {
                this.selectedForm = 0;
                this.openUnlocked = false;
                this.closedUnlocked = false;
            }
        }
    }

    /**
     * Determines whether mastery changes should be blocked because the player is in combat or already using a domain.
     */
    private void refreshMutationLockState() {
        boolean inCombat;
        Minecraft mc = Minecraft.getInstance();
        this.masteryMutationLocked = false;
        this.masteryMutationLockReason = "";
        if (mc.player == null) {
            return;
        }
        // Mutation locks intentionally mirror gameplay restrictions so players cannot reconfigure mastery in combat or while a domain is active.
        boolean hasActiveDomain = mc.player.hasEffect((MobEffect)JujutsucraftModMobEffects.DOMAIN_EXPANSION.get()) || mc.player.getPersistentData().getDouble("DomainExpansion") > 0.0;
        boolean bl = inCombat = mc.player.hasEffect((MobEffect)JujutsucraftModMobEffects.COOLDOWN_TIME_COMBAT.get()) || ClientPacketHandler.ClientCooldownCache.getRemaining(true) > 0;
        if (hasActiveDomain) {
            this.masteryMutationLocked = true;
            this.masteryMutationLockReason = "Cannot change Domain Mastery while Domain Expansion is active";
        } else if (inCombat) {
            this.masteryMutationLocked = true;
            this.masteryMutationLockReason = "Cannot change Domain Mastery while in combat";
        }
    }

    // ===== INPUT AND TICK FLOW =====
    public boolean isPauseScreen() {
        return false;
    }

    /**
     * Routes left-click input across form buttons, property controls, reset, and close actions.
     * @param mouseX mouse x used by this method.
     * @param mouseY mouse y used by this method.
     * @param button button used by this method.
     * @return true when mouse clicked succeeds; otherwise false.
     */
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int i;
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }
        this.computeResponsiveLayout();
        float mx = (float)mouseX;
        float my = (float)mouseY;
        // Form buttons are processed before property cards so a direct form click always wins over overlapping hover state.
        for (i = 0; i < 3; ++i) {
            if (!this.isInRect(mx, my, this.getFormBtnBounds(i))) continue;
            if (this.masteryMutationLocked) {
                this.playUiLockSound();
                this.sendMutationLockMessage();
                return true;
            }
            if (i == 1 && !this.closedUnlocked) {
                this.playUiLockSound();
                this.sendFormLockMessage(i);
                return true;
            }
            if (i == 2 && !this.openUnlocked) {
                this.playUiLockSound();
                this.sendFormLockMessage(i);
                return true;
            }
            this.setForm(i);
            this.selectedForm = i;
            this.playFormSelectSound(i);
            return true;
        }
        // Each property card exposes both normal upgrades and the negative modify flow, so the click handler checks every property control pair each frame.
        for (i = 0; i < DomainMasteryProperties.values().length; ++i) {
            if (this.isInRect(mx, my, this.getPlusBtnBounds(i))) {
                if (this.masteryMutationLocked) {
                    this.playUiLockSound();
                    this.sendMutationLockMessage();
                } else if (this.isNegativeProperty(i) && this.canNegativeIncreaseProperty(i)) {
                    this.negativeIncrease(i);
                    this.playUpgradeSound();
                } else if (this.canUpgradeProperty(i)) {
                    this.upgradeProperty(i);
                    this.playUpgradeSound();
                } else {
                    this.playUiLockSound();
                }
                return true;
            }
            if (!this.isInRect(mx, my, this.getMinusBtnBounds(i))) continue;
            if (this.masteryMutationLocked) {
                this.playUiLockSound();
                this.sendMutationLockMessage();
            } else if (this.canRefundProperty(i)) {
                this.refundProperty(i);
                this.playRefundSound();
            } else if (this.canNegativeDecreaseProperty(i)) {
                this.negativeDecrease(i);
                this.playRefundSound();
            } else {
                this.playUiLockSound();
            }
            return true;
        }
        if (this.shouldShowSukunaSureHitOption() && this.isInRect(mx, my, this.getSukunaSureHitBtnBounds())) {
            if (this.masteryMutationLocked) {
                this.playUiLockSound();
                this.sendMutationLockMessage();
            } else if (this.isInRect(mx, my, this.getSukunaSureHitSealBtnBounds())) {
                if (this.isSukunaSureHitUnlocked()) {
                    this.buySukunaSureHit();
                    this.playRefundSound();
                } else {
                    this.playUiLockSound();
                }
            } else if (this.isInRect(mx, my, this.getSukunaSureHitForgeBtnBounds())) {
                if (this.canBuySukunaSureHit()) {
                    this.buySukunaSureHit();
                    this.playUpgradeSound();
                } else {
                    this.playUiLockSound();
                }
            } else {
                this.playUiLockSound();
            }
            return true;
        }
        if (this.isInRect(mx, my, this.getResetBtnBounds())) {
            if (this.masteryMutationLocked) {
                this.playUiLockSound();
                this.sendMutationLockMessage();
            } else {
                this.resetAll();
                this.playResetSound();
            }
            return true;
        }
        if (this.isInRect(mx, my, this.getCloseBtnBounds())) {
            this.playCloseSound();
            this.onClose();
            return true;
        }
        return super.mouseClicked((double)mx, (double)my, button);
    }

    /**
     * Performs mouse dragged for this addon component.
     * @param mouseX mouse x used by this method.
     * @param mouseY mouse y used by this method.
     * @param button button used by this method.
     * @param dragX drag x used by this method.
     * @param dragY drag y used by this method.
     * @return true when mouse dragged succeeds; otherwise false.
     */
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    /**
     * Advances this state by one tick.
     */
    public void tick() {
        super.tick();
        this.refreshFormState();
        this.refreshMutationLockState();
        long now = System.currentTimeMillis();
        float elapsed = (float)(now - this.openTimeMs) / 300.0f;
        this.openAnim = Math.min(1.0f, elapsed);
        if (now - this.lastPulse > 80L) {
            this.pulseTick += 1.0f;
            this.lastPulse = now;
        }
    }

    // ===== PRIMARY RENDER FLOW =====
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        int i;
        this.computeResponsiveLayout();
        int bgAlpha = (int)(170.0f * this.openAnim);
        this.fillVerticalGradient(graphics, 0, 0, this.width, this.height, argb(bgAlpha, 0x02040A), argb(Math.min(210, bgAlpha + 20), 0x120711));
        float mx = mouseX;
        float my = mouseY;
        this.hoveredFormBtn = false;
        this.hoveredFormIdx = -1;
        this.hoveredMutationControl = false;
        for (i = 0; i < 3; ++i) {
            if (!this.isInRect(mx, my, this.getFormBtnBounds(i))) continue;
            this.hoveredFormBtn = true;
            this.hoveredFormIdx = i;
            break;
        }
        this.hoveredReset = this.isInRect(mx, my, this.getResetBtnBounds());
        this.hoveredClose = this.isInRect(mx, my, this.getCloseBtnBounds());
        this.hoveredSukunaSureHit = this.shouldShowSukunaSureHitOption() && this.isInRect(mx, my, this.getSukunaSureHitBtnBounds());
        // Locked hover tracking allows the screen to show an explanation tooltip even when the underlying action cannot be executed.
        this.hoveredMutationControl = this.masteryMutationLocked && (this.hoveredFormIdx >= 0 || this.hoveredReset || this.hoveredSukunaSureHit);
        this.hoveredPropIdx = -1;
        for (i = 0; i < DomainMasteryProperties.values().length; ++i) {
            this.hoveredPlus[i] = this.isInRect(mx, my, this.getPlusBtnBounds(i));
            this.hoveredMinus[i] = this.isInRect(mx, my, this.getMinusBtnBounds(i));
            if (!this.hoveredPlus[i] && !this.hoveredMinus[i]) continue;
            this.hoveredPropIdx = i;
            if (!this.masteryMutationLocked) continue;
            this.hoveredMutationControl = true;
        }
        int hoveredControl = this.getHoveredControlId();
        if (hoveredControl != this.lastHoveredControl) {
            if (hoveredControl >= 0) {
                this.playUiHoverSound(hoveredControl);
            }
            this.lastHoveredControl = hoveredControl;
        }
        this.drawPanelBackground(graphics, mouseX, mouseY);
        this.drawHeader(graphics, mouseX, mouseY);
        this.drawPropertiesGrid(graphics, mouseX, mouseY);
        this.drawFooter(graphics);
        if (this.masteryMutationLocked && this.hoveredMutationControl) {
            this.drawMutationLockTooltip(graphics, mouseX, mouseY);
        } else if (this.hoveredSukunaSureHit) {
            this.drawSukunaSureHitTooltip(graphics, mouseX, mouseY);
        } else if (this.hoveredPropIdx >= 0) {
            this.drawPropertyTooltip(graphics, mouseX, mouseY);
        }
    }

    /**
     * Draws panel background as part of the addon presentation layer.
     * @param graphics render context used to draw the current frame.
     * @param mx screen or world coordinate used by this calculation.
     * @param my screen or world coordinate used by this calculation.
     */
    private void drawPanelBackground(GuiGraphics graphics, int mx, int my) {
        int a = (int)(this.openAnim * 255.0f);
        graphics.fill(this.panelX - 2, this.panelY - 2, this.panelX + this.drawW + 2, this.panelY - 1, argb((int)(this.openAnim * 74.0f), UI_BLUE));
        graphics.fill(this.panelX - 2, this.panelY + this.drawH + 1, this.panelX + this.drawW + 2, this.panelY + this.drawH + 2, argb((int)(this.openAnim * 66.0f), UI_RED));
        graphics.fill(this.panelX - 2, this.panelY - 1, this.panelX - 1, this.panelY + this.drawH + 1, argb((int)(this.openAnim * 58.0f), UI_BLUE));
        graphics.fill(this.panelX + this.drawW + 1, this.panelY - 1, this.panelX + this.drawW + 2, this.panelY + this.drawH + 1, argb((int)(this.openAnim * 58.0f), UI_RED));
        this.fillVerticalGradient(graphics, this.panelX, this.panelY, this.panelX + this.drawW, this.panelY + this.drawH, argb(a, UI_PANEL_TOP), argb(a, UI_PANEL_BOTTOM));
        this.fillVerticalGradient(graphics, this.panelX, this.panelY, this.panelX + this.drawW, this.panelY + this.drawHeaderH, argb((int)(this.openAnim * 248.0f), UI_HEADER_TOP), argb((int)(this.openAnim * 238.0f), UI_HEADER_BOTTOM));
        this.fillVerticalGradient(graphics, this.panelX, this.panelY + this.drawHeaderH, this.panelX + this.drawW, this.panelY + this.drawH - this.drawFooterH, argb((int)(this.openAnim * 230.0f), 0x0C1424), argb((int)(this.openAnim * 224.0f), 0x060A14));
        this.fillVerticalGradient(graphics, this.panelX, this.panelY + this.drawH - this.drawFooterH, this.panelX + this.drawW, this.panelY + this.drawH, argb((int)(this.openAnim * 232.0f), 0x0A1020), argb((int)(this.openAnim * 226.0f), 0x050813));
        graphics.fill(this.panelX, this.panelY, this.panelX + this.drawW, this.panelY + 1, argb((int)(this.openAnim * 156.0f), UI_BLUE));
        graphics.fill(this.panelX, this.panelY + this.drawH - 1, this.panelX + this.drawW, this.panelY + this.drawH, argb((int)(this.openAnim * 132.0f), UI_RED));
        graphics.fill(this.panelX, this.panelY, this.panelX + 1, this.panelY + this.drawH, argb((int)(this.openAnim * 128.0f), UI_BLUE));
        graphics.fill(this.panelX + this.drawW - 1, this.panelY, this.panelX + this.drawW, this.panelY + this.drawH, argb((int)(this.openAnim * 128.0f), UI_RED));
        graphics.fill(this.panelX, this.panelY + this.drawHeaderH - 1, this.panelX + this.drawW, this.panelY + this.drawHeaderH, argb((int)(this.openAnim * 72.0f), UI_BLUE));
        graphics.fill(this.panelX, this.panelY + this.drawH - this.drawFooterH, this.panelX + this.drawW, this.panelY + this.drawH - this.drawFooterH + 1, argb((int)(this.openAnim * 62.0f), UI_BLUE));
        int gridSep = argb((int)(this.openAnim * 26.0f), UI_BLUE);
        int propStartX = this.getPropertyStartX();
        int propStartY = this.getPropertyStartY();
        int propGridW = this.drawPropColW * 2 + this.drawPropGapX;
        int visibleRows = this.shouldShowSukunaSureHitOption() ? 5 : 5;
        int propGridH = this.drawPropRow * visibleRows + this.drawPropGapY * (visibleRows - 1);
        for (int i = 1; i <= 4; ++i) {
            int lineY = propStartY + i * this.drawPropRow + (i - 1) * this.drawPropGapY + this.drawPropGapY / 2;
            graphics.fill(propStartX, lineY, propStartX + propGridW, lineY + 1, gridSep);
        }
        int midX = propStartX + this.drawPropColW + this.drawPropGapX / 2;
        graphics.fill(midX, propStartY, midX + 1, propStartY + propGridH, gridSep);
    }

    // ===== HEADER AND FORM RENDERING =====
    private void drawHeader(GuiGraphics graphics, int mx, int my) {
        String xpText;
        Font font = this.font;
        String title = "DOMAIN MASTERY";
        int a = (int)(this.openAnim * 255.0f);
        int titleAlpha = Math.round(this.openAnim * 255.0f);
        HeaderLayout layout = HeaderLayout.compute(this.fontScale, this.panelX, this.panelY, this.drawW, this.drawHeaderH);
        Rect titleRect = layout.title();
        float desiredTitleScale = Math.max(0.92f, this.fontScale * 1.18f);
        float titleScale = this.resolveFittedTextScale(font, title, titleRect.w(), desiredTitleScale, 0.01f);
        int titleRenderW = this.getScaledTextWidth(font, title, titleScale);
        int titleRenderH = this.getScaledTextHeight(font, titleScale);
        int titleX = titleRect.x() + (titleRect.w() - titleRenderW) / 2;
        int titleY = titleRect.y() + Math.max(0, (titleRect.h() - titleRenderH) / 2);
        this.drawScaledForegroundText(graphics, font, title, titleX + 1, titleY + 1, argb((int)(titleAlpha * 0.58f), 0x000000), titleScale);
        this.drawScaledForegroundText(graphics, font, title, titleX, titleY, argb(titleAlpha, UI_TEXT), titleScale);
        int level = this.getDomainMasteryLevel();
        int pp = this.getDomainPropertyPoints();
        Rect masteryPill = layout.masteryPill();
        Rect pointsPill = layout.pointsPill();
        this.drawHeaderStatPill(graphics, masteryPill.x(), masteryPill.y(), masteryPill.w(), masteryPill.h(), "MASTERY", "LV " + level, level >= 5 ? UI_GOLD : UI_BLUE);
        this.drawHeaderStatPill(graphics, pointsPill.x(), pointsPill.y(), pointsPill.w(), pointsPill.h(), "POINTS", pp + " PP", pp > 0 ? UI_GREEN : 0x64748B);
        if (level >= 5) {
            xpText = "MAX XP";
        } else {
            int cur = (int)this.getDomainXP();
            int nxt = this.getXPToNext();
            xpText = cur + " / " + nxt + " XP";
        }
        int xpCol = argb((int)(this.openAnim * 255.0f), level >= 5 ? UI_GOLD : UI_TEXT_MID);
        Rect xpBar = layout.xpBar();
        float xpLabelScale = Math.max(0.55f, this.fontScale * 0.82f);
        int xpLabelW = this.getScaledTextWidth(font, xpText, xpLabelScale);
        int xpLabelH = this.getScaledTextHeight(font, xpLabelScale);
        int xpLabelX = xpBar.x() + (xpBar.w() - xpLabelW) / 2;
        int xpLabelY = xpBar.y() - xpLabelH - Math.max(1, (int)(this.fontScale * 2.0f));
        this.drawScaledForegroundText(graphics, font, xpText, xpLabelX, xpLabelY, xpCol, xpLabelScale);
        this.drawXPBar(graphics, xpBar.x(), xpBar.y(), xpBar.w(), xpBar.h());
        this.drawFormButtons(graphics, mx, my, layout);
        this.drawFormHint(graphics, layout);
    }

    /**
     * Renders the "DOMAIN MASTERY" title with the Restrained_Title_Style (Req 1.1/1.2):
     * a single fitted draw of the full string with a stylized emboss/outline treatment
     * using at most two cohesive colors (a light base color plus its dark shadow/outline
     * color). There is no per-character color cycling and no chromatic palette. The title
     * alpha tracks the open-animation progress and a shared pulse-driven glow is layered
     * on top so the title brightens with the surrounding panel.
     *
     * @param g     render context used to draw the current frame.
     * @param font  the client font.
     * @param title the full title string (drawn in one piece, never per-character).
     * @param x     left edge of the fitted title text.
     * @param y     top edge of the fitted title text.
     * @param alpha title alpha = Math.round(openAnim * 255) (0 at openAnim 0, 255 at 1.0).
     * @param pulse shared pulse value (sin(pulseTick * k) * 0.5 + 0.5) used for the glow.
     * @param scale the fitted text scale that keeps the full string within the title rect.
     */
    private void drawRestrainedTitle(GuiGraphics g, Font font, String title, int x, int y, int alpha, float pulse, float scale) {
        int clampedAlpha = Math.max(0, Math.min(255, alpha));
        // Dark emboss/outline drawn first as a 1px drop shadow around the base text. This is
        // the second of the two cohesive colors; it stays subordinate to the base alpha.
        int shadowAlpha = (int)((float)clampedAlpha * 0.7f);
        int shadowCol = shadowAlpha << 24 | TITLE_SHADOW_COLOR;
        this.drawScaledForegroundText(g, font, title, x + 1, y + 1, shadowCol, scale);
        this.drawScaledForegroundText(g, font, title, x - 1, y + 1, shadowCol, scale);
        this.drawScaledForegroundText(g, font, title, x + 1, y - 1, shadowCol, scale);
        // Base title color drawn on top in one fitted pass.
        int baseCol = clampedAlpha << 24 | TITLE_BASE_COLOR;
        this.drawScaledForegroundText(g, font, title, x, y, baseCol, scale);
        // Shared pulse glow: a faint extra pass of the base color whose alpha follows the
        // panel's pulse, so the title softly brightens in time with the surrounding panel.
        int glowAlpha = (int)((float)clampedAlpha * (pulse * 0.35f));
        if (glowAlpha > 0) {
            this.drawScaledForegroundText(g, font, title, x, y, glowAlpha << 24 | TITLE_BASE_COLOR, scale);
        }
    }

    /**
     * Draws the restrained header backdrop (Req 1.1): a calm dark fill over the header
     * bounds whose alpha scales with the open animation, plus a single subtle accent glow
     * line at the bottom whose intensity follows the shared pulse. No multi-color shards,
     * stripes, or accent bars — just a cohesive backdrop behind the restrained title.
     *
     * @param g            render context used to draw the current frame.
     * @param headerBounds the header area (above the separator) to fill.
     * @param alpha        open-animation alpha = Math.round(openAnim * 255).
     * @param pulse        shared pulse value used to modulate the accent glow.
     */
    private void drawHeaderBackdrop(GuiGraphics g, Rect headerBounds, int alpha, float pulse) {
        int top = headerBounds.y();
        int left = headerBounds.x();
        int right = headerBounds.x() + headerBounds.w();
        int bottom = headerBounds.y() + headerBounds.h();
        int headerH = headerBounds.h();
        int clampedAlpha = Math.max(0, Math.min(255, alpha));
        // Base restrained fill plus a soft vertical gradient in the same blue family.
        g.fill(left, top, right, bottom, clampedAlpha << 24 | 0x07111F);
        g.fill(left, top, right, top + Math.max(16, headerH / 4), (int)(this.openAnim * 120.0f) << 24 | 0x172554);
        g.fill(left, top + headerH / 3, right, bottom, (int)(this.openAnim * 90.0f) << 24 | 0x0B1A2E);
        // Single accent glow line along the header separator, modulated by the shared pulse.
        int glowA = (int)(this.openAnim * (90.0f + pulse * 60.0f));
        g.fill(left, bottom - 2, right, bottom, Math.max(0, Math.min(255, glowA)) << 24 | TITLE_ACCENT_COLOR);
    }

    private void drawHeaderStatPill(GuiGraphics g, int x, int y, int w, int h, String label, String value, int accent) {
        Font font = this.font;
        int a = (int)(this.openAnim * 255.0f);
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, argb((int)(this.openAnim * 82.0f), accent));
        this.fillVerticalGradient(g, x, y, x + w, y + h, argb((int)(this.openAnim * 238.0f), blend(accent, 0x0B1427, 0.18f)), argb((int)(this.openAnim * 206.0f), 0x050812));
        g.fill(x, y, x + Math.max(3, (int)(this.fontScale * 4.0f)), y + h, argb(a, accent));
        g.fill(x, y, x + w, y + 1, argb((int)(this.openAnim * 128.0f), accent));
        float labelScale = this.resolveFittedTextScale(font, label, Math.max(22, w - 12), 0.56f, 0.42f);
        float valueScale = this.resolveFittedTextScale(font, value, Math.max(22, w - 12), 0.88f, 0.56f);
        int textX = x + Math.max(8, (int)(this.fontScale * 10.0f));
        int labelY = y + Math.max(3, (int)(this.fontScale * 4.0f));
        int valueY = y + h - this.getScaledTextHeight(font, valueScale) - Math.max(3, (int)(this.fontScale * 4.0f));
        this.drawScaledForegroundText(g, font, label, textX, labelY, argb((int)(this.openAnim * 170.0f), UI_TEXT_MID), labelScale);
        this.drawScaledForegroundText(g, font, value, textX, valueY, argb(a, UI_TEXT), valueScale);
    }

    /**
     * Draws level badge as part of the addon presentation layer.
     * @param g render context used to draw the current frame.
     * @param x screen or world coordinate used by this calculation.
     * @param y screen or world coordinate used by this calculation.
     * @param level level value used by this operation.
     */
    private void drawLevelBadge(GuiGraphics g, int x, int y, int level) {
        int bgCol;
        Font font = this.font;
        String text = "Lv." + level;
        float badgeTextScale = Math.max(0.55f, this.fontScale);
        int badgeW = this.getScaledTextWidth(font, text, badgeTextScale) + (int)(this.fontScale * 16.0f);
        int badgeH = Math.max(8, (int)(this.fontScale * 18.0f));
        int padX = Math.max(2, (int)(this.fontScale * 8.0f));
        int padY = Math.max(1, (int)(this.fontScale * 4.0f));
        int borderCol = switch (level) {
            case 5 -> {
                bgCol = -855846067;
                yield -208051;
            }
            case 4 -> {
                bgCol = -1434699027;
                yield -4160260;
            }
            case 3 -> {
                bgCol = -2006945327;
                yield -8286984;
            }
            case 2 -> {
                bgCol = 2000388852;
                yield -10443270;
            }
            case 1 -> {
                bgCol = 1712166016;
                yield -13315175;
            }
            default -> {
                bgCol = 1715160403;
                yield -9735552;
            }
        };
        int a = (int)(this.openAnim * 255.0f);
        int fillCol = a << 24 | bgCol & 0xFFFFFF;
        int bordCol = a << 24 | borderCol & 0xFFFFFF;
        g.fill(x, y, x + badgeW, y + badgeH, fillCol);
        g.fill(x, y, x + badgeW, y + 1, bordCol);
        g.fill(x, y + badgeH - 1, x + badgeW, y + badgeH, bordCol);
        g.fill(x, y, x + 1, y + badgeH, bordCol);
        g.fill(x + badgeW - 1, y, x + badgeW, y + badgeH, bordCol);
        this.drawScaledForegroundText(g, font, text, x + padX, y + padY, -1, badgeTextScale);
    }

    /**
     * Draws xp bar as part of the addon presentation layer.
     * @param g render context used to draw the current frame.
     * @param x screen or world coordinate used by this calculation.
     * @param y screen or world coordinate used by this calculation.
     * @param w screen or world coordinate used by this calculation.
     * @param h screen or world coordinate used by this calculation.
     */
    private void drawXPBar(GuiGraphics g, int x, int y, int w, int h) {
        float progress = (float)this.getXPProgress();
        int a = (int)(this.openAnim * 255.0f);
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, argb((int)(this.openAnim * 92.0f), UI_BLUE));
        this.fillVerticalGradient(g, x, y, x + w, y + h, argb((int)(this.openAnim * 238.0f), 0x0B1427), argb((int)(this.openAnim * 218.0f), 0x050812));
        int fill = (int)((float)w * progress);
        if (fill > 0) {
            this.fillVerticalGradient(g, x, y, x + fill, y + h, argb(a, UI_BLUE), argb(a, 0x0284C7));
            if (fill >= 2) {
                g.fill(x + fill - 2, y, x + fill, y + h, argb(a, 0xE0F2FE));
            }
        }
        g.fill(x, y, x + w, y + 1, argb((int)(this.openAnim * 190.0f), UI_BLUE));
        g.fill(x, y + h - 1, x + w, y + h, argb((int)(this.openAnim * 120.0f), UI_BLUE));
    }

    /**
     * Draws form hint as part of the addon presentation layer. The status text row is
     * positioned from the shared {@link HeaderLayout} (its {@code unlockedStatus} rect) so
     * it stays consistent with the XP bar / form-selector layout (Req 1.8).
     * @param graphics render context used to draw the current frame.
     * @param layout the shared header layout providing the status text row position.
     */
    private void drawFormHint(GuiGraphics graphics, HeaderLayout layout) {
        int color;
        String hint;
        Font font = this.font;
        if (this.masteryMutationLocked) {
            hint = this.masteryMutationLockReason;
            color = 0xEF4444;
        } else if (!this.closedUnlocked) {
            hint = "Only Incomplete is available before Domain Mastery Lv.1";
            color = 9741240;
        } else if (!this.openUnlocked) {
            hint = "Incomplete and Closed are available. Open needs Lv.5 + Open Domain achievement";
            color = 16096779;
        } else {
            hint = "All Domain forms are unlocked";
            color = 2278750;
        }
        int y = layout.unlockedStatus().y();
        float hintScale = this.resolveFittedTextScale(font, hint, this.drawW - Math.max(12, (int)(this.fontScale * 28.0f)), this.fontScale, 0.5f);
        int x = this.panelX + (this.drawW - this.getScaledTextWidth(font, hint, hintScale)) / 2;
        this.drawScaledForegroundText(graphics, font, hint, x, y, argb((int)(this.openAnim * 235.0f), color), hintScale);
    }

    /**
     * Draws form buttons as part of the addon presentation layer. Button geometry is taken
     * from the shared {@link HeaderLayout} so the buttons stay consistent with the XP bar's
     * {@code >= 1px} gap above this row (Req 1.8).
     * @param g render context used to draw the current frame.
     * @param mx screen or world coordinate used by this calculation.
     * @param my screen or world coordinate used by this calculation.
     * @param layout the shared header layout providing the three form-selector rects.
     */
    private void drawFormButtons(GuiGraphics g, int mx, int my, HeaderLayout layout) {
        Font font = this.font;
        int[] formColors = new int[]{4674921, 165063, 1483594};
        String[] formNames = new String[]{"INCOMPLETE", "CLOSED", "OPEN"};
        Rect[] btnRects = new Rect[]{layout.incompleteBtn(), layout.closedBtn(), layout.openBtn()};
        int a = (int)(this.openAnim * 255.0f);
        for (int i = 0; i < 3; ++i) {
            int textAlpha;
            int borderAlpha;
            int bgAlpha;
            int baseColor;
            Rect btnRect = btnRects[i];
            int bx = btnRect.x();
            int btnY = btnRect.y();
            int btnW = btnRect.w();
            int btnH = btnRect.h();
            boolean isSelected = i == this.selectedForm;
            boolean isHovered = i == this.hoveredFormIdx;
            boolean isLocked = i == 1 && !this.closedUnlocked || i == 2 && !this.openUnlocked;
            boolean isDisabled = isLocked || this.masteryMutationLocked;
            int n = baseColor = isDisabled ? 2042167 : formColors[i];
            if (isSelected) {
                bgAlpha = a;
                borderAlpha = a;
                textAlpha = a;
            } else if (isHovered && !isDisabled) {
                bgAlpha = (int)((float)a * 0.7f);
                borderAlpha = (int)((float)a * 0.9f);
                textAlpha = (int)((float)a * 0.9f);
            } else {
                bgAlpha = (int)((float)a * 0.35f);
                borderAlpha = (int)((float)a * 0.5f);
                textAlpha = (int)((float)a * 0.6f);
            }
            int borderCol = argb(borderAlpha, baseColor);
            int textCol = argb(textAlpha, isSelected && !isDisabled ? UI_TEXT : (isDisabled ? UI_TEXT_DIM : UI_TEXT_MID));
            g.fill(bx - 1, btnY - 1, bx + btnW + 1, btnY + btnH + 1, argb((int)(borderAlpha * 0.42f), baseColor));
            this.fillVerticalGradient(g, bx, btnY, bx + btnW, btnY + btnH, argb(bgAlpha, blend(baseColor, UI_ROW_HOVER, isSelected ? 0.22f : 0.12f)), argb(Math.max(70, (int)(bgAlpha * 0.78f)), UI_ROW));
            if (isSelected) {
                g.fill(bx, btnY, bx + Math.max(3, (int)(this.fontScale * 4.0f)), btnY + btnH, argb(a, baseColor));
                g.fill(bx, btnY, bx + btnW, btnY + 1, argb((int)(a * 0.72f), baseColor));
            }
            g.fill(bx, btnY, bx + btnW, btnY + 1, borderCol);
            String label = formNames[i];
            int iconSize = Math.max(11, Math.min(14, Math.round((float)btnH * 0.5f)));
            int iconGap = Math.max(4, (int)(this.fontScale * 6.0f));
            int labelMaxW = Math.max(24, btnW - iconSize - iconGap - Math.max(8, (int)(this.fontScale * 10.0f)));
            float labelScale = this.resolveFittedTextScale(font, label, labelMaxW, 1.0f, 0.62f);
            int labelH = this.getScaledTextHeight(font, labelScale);
            int contentH = Math.max(iconSize, labelH);
            int contentW = iconSize + iconGap + this.getScaledTextWidth(font, label, labelScale);
            int iconX = bx + Math.max(4, (btnW - contentW) / 2);
            int contentY = btnY + Math.max(1, (btnH - contentH) / 2);
            int iconY = contentY + (contentH - iconSize) / 2;
            this.drawLayeredItemScaled(g, this.getFormItem(i), iconX, iconY, iconSize, 160.0);
            int labelX = iconX + iconSize + iconGap;
            int labelY = contentY + (contentH - labelH) / 2;
            this.drawScaledForegroundText(g, font, label, labelX, labelY, textCol, labelScale);
            if (!isDisabled) continue;
            int lockCol = argb(a, this.masteryMutationLocked ? UI_GOLD : UI_RED);
            g.fill(bx + btnW - 6, btnY + 4, bx + btnW - 3, btnY + btnH - 4, lockCol);
        }
        int selColor = this.selectedForm == 2 && !this.openUnlocked ? 2042167 : formColors[this.selectedForm];
        int indicatorCol = argb((int)(this.openAnim * 205.0f), selColor);
        Rect selRect = btnRects[this.selectedForm];
        int indicatorY = selRect.y() + selRect.h() + Math.max(1, (int)(this.fontScale * 3.0f));
        g.fill(selRect.x(), indicatorY, selRect.x() + selRect.w(), indicatorY + Math.max(1, (int)(this.fontScale * 2.0f)), indicatorCol);
    }

    // ===== PROPERTY CARD RENDERING =====
    private void drawPropertiesGrid(GuiGraphics g, int mx, int my) {
        Font font = this.font;
        DomainMasteryProperties[] props = DomainMasteryProperties.values();
        int masteryLevel = this.getDomainMasteryLevel();
        int propStartX = this.getPropertyStartX();
        int propStartY = this.getPropertyStartY();
        int a = (int)(this.openAnim * 255.0f);
        this.hoveredPropIdx = -1;
        int pipH = Math.max(2, (int)(this.fontScale * 5.0f));
        int cardHeaderY = Math.max(6, (int)(this.fontScale * 7.0f));
        int iconPad = Math.max(5, (int)(this.fontScale * 8.0f));
        int stripW = Math.max(2, (int)(this.fontScale * 5.0f));
        int cardPad = Math.max(1, (int)(this.fontScale * 2.0f));
        int topStripH = Math.max(1, (int)(this.fontScale * 3.0f));
        int controlLaneW = Math.max(32, (int)(this.fontScale * 42.0f));
        int slotSize = Math.max(12, (int)(18.0f * this.fontScale));
        int textGap = Math.max(7, (int)(this.fontScale * 8.0f));
        int valueGap = Math.max(5, (int)(this.fontScale * 5.0f));
        int headerToBarGap = Math.max(7, (int)(this.fontScale * 8.0f));
        int barToValueGap = Math.max(7, (int)(this.fontScale * 8.0f));
        int valueBottomPad = Math.max(3, (int)(this.fontScale * 4.0f));
        for (int i = 0; i < props.length; ++i) {
            int statColor;
            Object statText;
            String lvlText;
            boolean isHovered;
            int row = i / 2;
            int col = i % 2;
            int px = propStartX + col * (this.drawPropColW + this.drawPropGapX);
            int py = propStartY + row * (this.drawPropRow + this.drawPropGapY);
            DomainMasteryProperties prop = props[i];
            int propLevel = this.getPropertyLevel(prop);
            int effectiveLevel = this.getEffectivePropertyLevel(prop);
            boolean negativeActive = this.isNegativeProperty(i);
            boolean locked = prop.isLocked(masteryLevel);
            int propColor = this.getPropertyColor(i);
            ItemStack propItem = this.getPropertyItem(i);
            boolean bl = isHovered = mx >= px && mx < px + this.drawPropColW && my >= py && my < py + this.drawPropRow;
            if (isHovered) {
                this.hoveredPropIdx = i;
            }
            int cardLeft = px + cardPad;
            int cardTop = py + cardPad;
            int cardRight = px + this.drawPropColW - cardPad;
            int cardBottom = py + this.drawPropRow - cardPad;
            int cardTopColor = locked ? 0x0A0F1A : (isHovered ? blend(propColor, UI_ROW_HOVER, 0.18f) : blend(propColor, UI_ROW_HOVER, 0.08f));
            int cardBottomColor = locked ? 0x050812 : UI_ROW;
            this.fillVerticalGradient(g, cardLeft, cardTop, cardRight, cardBottom, argb((int)(this.openAnim * (isHovered ? 238.0f : 214.0f)), cardTopColor), argb((int)(this.openAnim * (isHovered ? 218.0f : 194.0f)), cardBottomColor));
            int stripCol = argb(locked ? (int)(a * 0.34f) : a, propColor);
            g.fill(cardLeft, cardTop, cardLeft + stripW, cardBottom, stripCol);
            g.fill(cardLeft, cardTop, cardRight, cardTop + 1, argb((int)(this.openAnim * (isHovered ? 150.0f : 82.0f)), propColor));
            if (isHovered && !locked) {
                g.fill(cardLeft + stripW, cardBottom - 1, cardRight, cardBottom, argb((int)(this.openAnim * 76.0f), propColor));
            }
            int[] minusBounds = this.getMinusBtnBounds(i);
            int[] plusBounds = this.getPlusBtnBounds(i);
            int headerTextY = py + cardHeaderY + 2;
            int headerRight = px + this.drawPropColW - controlLaneW - Math.max(5, (int)(this.fontScale * 6.0f));
            int actionTop = minusBounds[1];
            int slotX = px + iconPad - 1;
            int slotY = py + cardHeaderY + 1;
            this.fillVerticalGradient(g, slotX, slotY, slotX + slotSize, slotY + slotSize, argb((int)(this.openAnim * 232.0f), 0x111A2D), argb((int)(this.openAnim * 216.0f), 0x050812));
            g.fill(slotX, slotY, slotX + slotSize, slotY + 1, argb((int)(this.openAnim * 128.0f), propColor));
            g.fill(slotX, slotY + slotSize - 1, slotX + slotSize, slotY + slotSize, argb((int)(this.openAnim * 78.0f), propColor));
            this.drawLayeredItemScaled(g, propItem, slotX + 1, slotY + 1, Math.max(10, slotSize - 2), 160.0);
            int contentLeft = slotX + slotSize + textGap;
            int contentRight = minusBounds[0] - Math.max(6, (int)(this.fontScale * 8.0f));
            int headerMaxW = Math.max(24, headerRight - contentLeft);
            int valueMaxW = Math.max(24, contentRight - (px + iconPad));
            String name = this.getShortName(i);
            int nameCol = locked ? argb((int)(this.openAnim * 96.0f), UI_TEXT_MID) : argb((int)(this.openAnim * 255.0f), UI_TEXT);
            String tagline = this.getPropertyTagline(i);
            float nameScale = this.resolveFittedTextScale(font, name, headerMaxW, 1.0f, 0.7f);
            int nameLineH = this.getScaledTextHeight(font, nameScale);
            float tagScale = this.resolveFittedTextScale(font, tagline, headerMaxW, 0.92f, 0.62f);
            int tagLineH = this.getScaledTextHeight(font, tagScale);
            int taglineY = headerTextY + nameLineH - 1;
            this.drawScaledForegroundText(g, font, name, contentLeft, headerTextY, nameCol, nameScale);
            this.drawScaledForegroundText(g, font, tagline, contentLeft, taglineY, argb((int)(this.openAnim * 176.0f), UI_TEXT_MID), tagScale);
            String string = lvlText = negativeActive ? String.valueOf(effectiveLevel) : propLevel + "/" + prop.getMaxLevel();
            int lvlCol = negativeActive ? argb((int)(this.openAnim * 255.0f), UI_RED) : (propLevel > 0 ? argb((int)(this.openAnim * 255.0f), UI_GOLD) : argb((int)(this.openAnim * 112.0f), UI_TEXT_MID));
            this.drawRightAlignedFittedForegroundText(g, font, lvlText, headerRight, headerTextY, lvlCol, Math.max(22, controlLaneW - Math.max(6, (int)(this.fontScale * 6.0f))), 0.92f, 0.7f);
            if (locked) {
                statText = "Unlock Lv." + prop.unlockLevel();
                statColor = argb((int)(this.openAnim * 255.0f), UI_RED);
            } else if (negativeActive) {
                statText = prop.formatNegativeValue(Math.abs(effectiveLevel));
                statColor = argb((int)(this.openAnim * 255.0f), UI_RED);
            } else if (propLevel > 0) {
                statText = prop.formatLevelValue(propLevel);
                statColor = argb((int)(this.openAnim * 255.0f), propColor);
            } else {
                statText = prop.formatLevelValue(0);
                statColor = argb((int)(this.openAnim * 92.0f), UI_TEXT_DIM);
            }
            float statScale = this.resolveFittedTextScale(font, (String)statText, valueMaxW, 0.78f, 0.5f);
            int statLineH = this.getScaledTextHeight(font, statScale);
            int statTopLimit = taglineY + tagLineH + headerToBarGap;
            int pipX = px + iconPad;
            int barW = Math.max(18, contentRight - pipX);
            int maxPipY = actionTop - statLineH - valueBottomPad - barToValueGap - pipH;
            int pipY = Math.max(statTopLimit, maxPipY);
            int statY = Math.max(statTopLimit + pipH + barToValueGap, pipY + pipH + barToValueGap + Math.max(1, Math.round(this.fontScale)));
            this.fillVerticalGradient(g, pipX, pipY, pipX + barW, pipY + pipH, argb((int)(this.openAnim * 220.0f), 0x0B1427), argb((int)(this.openAnim * 190.0f), 0x050812));
            int maxLevel = prop.getMaxLevel();
            int visibleLevel = negativeActive ? Math.min(maxLevel, Math.max(1, Math.abs(effectiveLevel))) : propLevel;
            int activeBarColor = negativeActive ? 0xFF4444 : propColor;
            for (int p = 0; p < maxLevel; ++p) {
                int logicalIndex = negativeActive ? maxLevel - 1 - p : p;
                int filled = logicalIndex < visibleLevel ? a : (int)((float)a * 0.125f);
                int pipCol = argb(filled, activeBarColor);
                int segEnd = pipX + (p + 1) * barW / maxLevel;
                int segStart = pipX + p * barW / maxLevel;
                if (segEnd - segStart <= 2) {
                    g.fill(segStart, pipY, segEnd, pipY + pipH, pipCol);
                    continue;
                }
                g.fill(segStart + 1, pipY, segEnd - 1, pipY + pipH, pipCol);
            }
            this.drawScaledForegroundText(g, font, (String)statText, px + iconPad, statY, statColor, statScale);
            if (locked) {
                g.fill(px + cardPad, py + cardPad, px + this.drawPropColW - cardPad, py + this.drawPropRow - cardPad, (int)(this.openAnim * 24.0f) << 24 | 0);
            }
            if (locked) continue;
            boolean canUpgrade = !this.masteryMutationLocked && (negativeActive ? this.canNegativeIncreaseProperty(i) : this.canUpgradeProperty(i));
            boolean canRefund = !this.masteryMutationLocked && (this.canRefundProperty(i) || this.canNegativeDecreaseProperty(i));
            int mbx = minusBounds[0];
            int mby = minusBounds[1];
            int mbw = minusBounds[2];
            int mbh = minusBounds[3];
            if (canRefund) {
                int minusBg = argb(a, this.hoveredMinus[i] ? UI_RED : 0xDC2626);
                int minusTextCol = argb(this.hoveredMinus[i] ? a : (int)((float)a * 0.9f), UI_TEXT);
                this.drawPropertyControlButton(g, mbx, mby, mbw, mbh, minusBg, minusTextCol, false);
            } else {
                int disabledBg = argb((int)((float)a * 0.2f), 0x333333);
                this.drawPropertyControlButton(g, mbx, mby, mbw, mbh, disabledBg, argb((int)((float)a * 0.3f), UI_TEXT_DIM), false);
            }
            int pbx = plusBounds[0];
            int pby = plusBounds[1];
            int pbw = plusBounds[2];
            int pbh = plusBounds[3];
            if (canUpgrade) {
                int plusBg = argb(a, this.hoveredPlus[i] ? 0x10B981 : 0x059669);
                int plusTextCol = argb(this.hoveredPlus[i] ? a : (int)((float)a * 0.9f), UI_TEXT);
                this.drawPropertyControlButton(g, pbx, pby, pbw, pbh, plusBg, plusTextCol, true);
                continue;
            }
            int disabledBg = argb((int)((float)a * 0.2f), 0x333333);
            this.drawPropertyControlButton(g, pbx, pby, pbw, pbh, disabledBg, argb((int)((float)a * 0.3f), UI_TEXT_DIM), true);
        }
        this.drawSukunaSureHitOption(g);
    }

    /**
     * Draws the expanded tooltip for the currently hovered property card or control.
     * @param g render context used to draw the current frame.
     * @param mx screen or world coordinate used by this calculation.
     * @param my screen or world coordinate used by this calculation.
     */
    private void drawPropertyTooltip(GuiGraphics g, int mx, int my) {
        Font font = this.font;
        DomainMasteryProperties prop = DomainMasteryProperties.values()[this.hoveredPropIdx];
        int masteryLevel = this.getDomainMasteryLevel();
        boolean locked = prop.isLocked(masteryLevel);
        String name = this.getPropertyDisplayName(prop);
        StringBuilder descBuilder = new StringBuilder((String)(locked ? "Locked until Domain Mastery Lv." + prop.unlockLevel() : this.getPropertyDescription(prop)));
        if (!locked && prop.supportsNegativeModify()) {
            if (this.isNegativeProperty(this.hoveredPropIdx)) {
                descBuilder.append("\nNegative Modify active - current ").append(prop.formatNegativeValue(Math.abs(this.getEffectivePropertyLevel(prop)))).append("\nPress [+] to move back toward 0");
            } else if (this.getPropertyLevel(prop) > 0) {
                descBuilder.append("\nRefund to 0 before applying Negative Modify");
            } else if (this.getDomainMasteryLevel() < 5) {
                descBuilder.append("\nNegative Modify unlocks at Domain Mastery Lv.5");
            } else if (!this.canSetNegativeProperty(prop)) {
                descBuilder.append("\nAnother property is already negative");
            } else {
                descBuilder.append("\nPress [-] to apply Negative Modify - each level grants +1 point");
            }
        }
        ClashPowerPreview preview = this.buildClashPowerPreview(prop);
        int maxDescWidth = Math.max(120, Math.min(220, this.width / 3));
        List<FormattedCharSequence> descLines = font.split((FormattedText)Component.literal((String)descBuilder.toString()), maxDescWidth);
        int maxW = font.width(name);
        if (preview != null) {
            maxW = Math.max(maxW, font.width(preview.prefix) + font.width(preview.delta) + font.width(preview.suffix));
        }
        for (FormattedCharSequence line : descLines) {
            maxW = Math.max(maxW, font.width(line));
        }
        Objects.requireNonNull(font);
        int n = descLines.size();
        Objects.requireNonNull(font);
        int rawTw = maxW + 20;
        int rawTh = 9 + n * 9 + 16 + (preview == null ? 0 : 14);
        float tooltipScale = this.resolveTooltipScale(rawTw, rawTh);
        int tw = Math.round(rawTw * tooltipScale);
        int th = Math.round(rawTh * tooltipScale);
        int tx = mx + 16;
        int ty = my - th - 4;
        if (tx + tw > this.width) {
            tx = mx - tw - 4;
        }
        if (ty < 0) {
            ty = my + 16;
        }
        int propColor = this.getPropertyColor(this.hoveredPropIdx);
        g.pose().pushPose();
        g.pose().translate(0.0, 0.0, 420.0);
        this.fillVerticalGradient(g, tx, ty, tx + tw, ty + th, argb(248, 0x0F1728), argb(244, 0x040711));
        g.fill(tx, ty, tx + tw, ty + 1, argb(230, propColor));
        g.fill(tx, ty + th - 1, tx + tw, ty + th, argb(160, propColor));
        g.fill(tx, ty, tx + 1, ty + th, argb(130, propColor));
        g.fill(tx + tw - 1, ty, tx + tw, ty + th, argb(130, propColor));
        g.pose().pushPose();
        g.pose().scale(tooltipScale, tooltipScale, 1.0f);
        g.drawString(font, name, Math.round((float)(tx + 10) / tooltipScale), Math.round((float)(ty + 7) / tooltipScale), argb(255, propColor), false);
        for (int i = 0; i < descLines.size(); ++i) {
            FormattedCharSequence formattedCharSequence = (FormattedCharSequence)descLines.get(i);
            Objects.requireNonNull(font);
            Objects.requireNonNull(font);
            g.drawString(font, formattedCharSequence, Math.round((float)(tx + 10) / tooltipScale), Math.round((float)(ty + 7 + 9 + i * 9) / tooltipScale), argb(255, UI_TEXT_MID), false);
        }
        if (preview != null) {
            int py = ty + 7 + 9 + descLines.size() * 9 + 4;
            int x = Math.round((float)(tx + 10) / tooltipScale);
            int scaledPy = Math.round((float)py / tooltipScale);
            g.drawString(font, preview.prefix, x, scaledPy, argb(255, UI_TEXT), false);
            x += font.width(preview.prefix);
            g.drawString(font, preview.delta, x, scaledPy, preview.deltaColor, false);
            x += font.width(preview.delta);
            g.drawString(font, preview.suffix, x, scaledPy, argb(255, UI_GOLD), false);
        }
        g.pose().popPose();
        g.pose().popPose();
    }

    private ClashPowerPreview buildClashPowerPreview(DomainMasteryProperties prop) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || prop == null) {
            return null;
        }
        double current = this.estimateRawClashPower(null, 0);
        int direction = this.hoveredPlus[this.hoveredPropIdx] ? 1 : (this.hoveredMinus[this.hoveredPropIdx] ? -1 : 0);
        if (direction == 0) {
            return new ClashPowerPreview("Raw Clash Power ", String.format(java.util.Locale.ROOT, "%.1f", current), "", 0xFFFCD34D);
        }
        double next = this.estimateRawClashPower(prop, direction);
        double delta = next - current;
        String sign = delta >= 0.0 ? "+" : "";
        int color = delta >= 0.0 ? 0xFF34D399 : 0xFFF87171;
        return new ClashPowerPreview(
            String.format(java.util.Locale.ROOT, "Raw Clash Power %.1f ", current),
            String.format(java.util.Locale.ROOT, "%s%.1f", sign, delta),
            String.format(java.util.Locale.ROOT, " = %.1f", next),
            color
        );
    }

    private double estimateRawClashPower(DomainMasteryProperties changedProp, int deltaLevel) {
        int masteryLevel = this.getDomainMasteryLevel();
        int barrierPower = adjustedEffectiveLevel(DomainMasteryProperties.BARRIER_POWER, changedProp, deltaLevel);
        int barrierRef = adjustedEffectiveLevel(DomainMasteryProperties.BARRIER_REFINEMENT, changedProp, deltaLevel);
        int radiusLevel = adjustedEffectiveLevel(DomainMasteryProperties.RADIUS_BOOST, changedProp, deltaLevel);
        double radius = 22.0 * Math.max(0.1, 1.0 + radiusLevel * 0.12);
        double base = 10.0;
        double hp = 1.0;
        double duration = 1.0;
        double form = DomainForm.CLOSED.formFactor;
        double radiusFactor = PowerCalculator.radiusFactor(radius);
        double mastery = (1.0 + masteryLevel * 0.04) * (1.0 + barrierPower * 0.06);
        double flat = masteryLevel;
        double grade = this.estimateClientGradeMultiplier();
        double power = base * hp * duration * form * radiusFactor * mastery * grade + flat;
        double refinement = 1.0 + Math.max(0, barrierRef) * 0.04;
        return Math.max(0.0, power * refinement);
    }

    private int adjustedEffectiveLevel(DomainMasteryProperties prop, DomainMasteryProperties changedProp, int deltaLevel) {
        int level = this.getEffectivePropertyLevel(prop);
        if (prop == changedProp) {
            level += deltaLevel;
        }
        return Math.max(-5, Math.min(prop.getMaxLevel(), level));
    }

    private double estimateClientGradeMultiplier() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return 1.0;
        }
        double level = mc.player.experienceLevel;
        if (level >= 20.0) return 1.45;
        if (level >= 13.0) return 1.32;
        if (level >= 11.0) return 1.24;
        if (level >= 9.0) return 1.16;
        if (level >= 7.0) return 1.10;
        if (level >= 4.0) return 1.05;
        if (level >= 2.0) return 1.02;
        return 1.0;
    }

    private static final class ClashPowerPreview {
        final String prefix;
        final String delta;
        final String suffix;
        final int deltaColor;

        ClashPowerPreview(String prefix, String delta, String suffix, int deltaColor) {
            this.prefix = prefix;
            this.delta = delta;
            this.suffix = suffix;
            this.deltaColor = deltaColor;
        }
    }

    // ===== FOOTER ACTIONS =====
    private void drawFooter(GuiGraphics g) {
        this.drawActionButton(g, this.getResetBtnBounds(), "RESET", this.hoveredReset, UI_BLUE, UI_GOLD, true, !this.masteryMutationLocked);
        this.drawActionButton(g, this.getCloseBtnBounds(), "CLOSE", this.hoveredClose, UI_RED, UI_RED, false, true);
    }

    /**
     * Draws action button as part of the addon presentation layer.
     * @param g render context used to draw the current frame.
     * @param bounds bounds used by this method.
     * @param text text used by this method.
     * @param hovered hovered used by this method.
     * @param bgCol bg col used by this method.
     * @param hoverCol hover col used by this method.
     * @param isReset is reset used by this method.
     * @param enabled enabled used by this method.
     */
    private void drawActionButton(GuiGraphics g, int[] bounds, String text, boolean hovered, int bgCol, int hoverCol, boolean isReset, boolean enabled) {
        int textCol;
        int borderCol;
        int fillCol;
        Font font = this.font;
        int x = bounds[0];
        int y = bounds[1];
        int w = bounds[2];
        int h = bounds[3];
        int a = (int)(this.openAnim * 255.0f);
        int accent = hovered && enabled ? hoverCol : bgCol;
        if (!enabled) {
            fillCol = argb((int)((float)a * 0.22f), 0x333333);
            borderCol = argb((int)((float)a * 0.3f), 0x555555);
            textCol = argb((int)((float)a * 0.42f), UI_TEXT_MID);
        } else {
            fillCol = argb(a, hovered ? blend(accent, 0x070B16, 0.42f) : blend(accent, 0x070B16, 0.22f));
            borderCol = argb(hovered ? a : (int)((float)a * 0.72f), accent);
            textCol = argb(a, UI_TEXT);
        }
        this.fillVerticalGradient(g, x, y, x + w, y + h, fillCol, argb(enabled ? (int)(a * 0.82f) : (int)(a * 0.16f), 0x02040A));
        g.fill(x, y, x + w, y + 1, borderCol);
        g.fill(x, y + h - 1, x + w, y + h, borderCol);
        if (isReset) {
            int stripeCol = argb((int)((float)a * 0.56f), accent);
            g.fill(x + 2, y + 2, x + 4, y + h - 2, stripeCol);
        }
        float textScale = this.resolveFittedTextScale(font, text, w - Math.max(8, (int)(this.fontScale * 10.0f)), 1.0f, 0.72f);
        int textX = x + (w - this.getScaledTextWidth(font, text, textScale)) / 2;
        int textY = y + (h - this.getScaledTextHeight(font, textScale)) / 2;
        this.drawScaledForegroundText(g, font, text, textX, textY, textCol, textScale);
    }

    private void drawSukunaSureHitOption(GuiGraphics g) {
        if (!this.shouldShowSukunaSureHitOption()) {
            return;
        }
        int[] bounds = this.getSukunaSureHitBtnBounds();
        int px = bounds[0];
        int py = bounds[1];
        Font font = this.font;
        boolean unlocked = this.isSukunaSureHitUnlocked();
        boolean canBuy = !this.masteryMutationLocked && this.canBuySukunaSureHit();
        int a = (int)(this.openAnim * 255.0f);
        int propColor = 0xEF4444;
        int cardPad = Math.max(1, (int)(this.fontScale * 2.0f));
        int stripW = Math.max(2, (int)(this.fontScale * 5.0f));
        int iconPad = Math.max(5, (int)(this.fontScale * 8.0f));
        int textGap = Math.max(7, (int)(this.fontScale * 8.0f));
        int slotSize = Math.max(12, (int)(18.0f * this.fontScale));
        int controlLaneW = Math.max(32, (int)(this.fontScale * 42.0f));
        int cardLeft = px + cardPad;
        int cardTop = py + cardPad;
        int cardRight = px + this.drawPropColW - cardPad;
        int cardBottom = py + this.drawPropRow - cardPad;
        this.fillVerticalGradient(g, cardLeft, cardTop, cardRight, cardBottom, argb((int)(this.openAnim * (this.hoveredSukunaSureHit ? 238.0f : 214.0f)), blend(propColor, UI_ROW_HOVER, this.hoveredSukunaSureHit ? 0.18f : 0.08f)), argb((int)(this.openAnim * (this.hoveredSukunaSureHit ? 218.0f : 194.0f)), UI_ROW));
        int stripCol = argb(a, propColor);
        g.fill(cardLeft, cardTop, cardLeft + stripW, cardBottom, stripCol);
        g.fill(cardLeft, cardTop, cardRight, cardTop + 1, argb((int)(this.openAnim * (this.hoveredSukunaSureHit ? 150.0f : 82.0f)), propColor));
        if (this.hoveredSukunaSureHit) {
            g.fill(cardLeft + stripW, cardBottom - 1, cardRight, cardBottom, argb((int)(this.openAnim * 76.0f), propColor));
        }
        int slotX = px + iconPad - 1;
        int slotY = py + Math.max(6, (int)(this.fontScale * 7.0f)) + 1;
        this.fillVerticalGradient(g, slotX, slotY, slotX + slotSize, slotY + slotSize, argb((int)(this.openAnim * 232.0f), 0x111A2D), argb((int)(this.openAnim * 216.0f), 0x050812));
        g.fill(slotX, slotY, slotX + slotSize, slotY + 1, argb((int)(this.openAnim * 128.0f), propColor));
        g.fill(slotX, slotY + slotSize - 1, slotX + slotSize, slotY + slotSize, argb((int)(this.openAnim * 78.0f), propColor));
        this.drawLayeredItemScaled(g, new ItemStack((ItemLike)Items.NETHER_STAR), slotX + 1, slotY + 1, Math.max(10, slotSize - 2), 160.0);
        int contentLeft = slotX + slotSize + textGap;
        int headerRight = px + this.drawPropColW - Math.max(7, (int)(this.fontScale * 8.0f));
        String name = "Cleave Covenant";
        int statusW = Math.max(28, (int)(this.fontScale * 34.0f));
        int headerMaxW = Math.max(24, headerRight - contentLeft - statusW - Math.max(5, (int)(this.fontScale * 6.0f)));
        float nameScale = this.resolveFittedTextScale(font, name, headerMaxW, 0.88f, 0.58f);
        int headerTextY = py + Math.max(6, (int)(this.fontScale * 7.0f)) + 1;
        this.drawScaledForegroundText(g, font, name, contentLeft, headerTextY, argb(a, UI_TEXT), nameScale);
        this.drawRightAlignedFittedForegroundText(g, font, unlocked ? "ON" : "5 PP", headerRight, headerTextY, argb(a, unlocked ? 0xFCA5A5 : UI_GOLD), statusW, 0.82f, 0.58f);
        int pipX = px + iconPad;
        int contentRight = px + this.drawPropColW - Math.max(8, (int)(this.fontScale * 9.0f));
        int barW = Math.max(18, contentRight - pipX);
        int pipH = Math.max(2, (int)(this.fontScale * 5.0f));
        int pipY = py + Math.max(31, (int)(this.fontScale * 34.0f));
        this.fillVerticalGradient(g, pipX, pipY, pipX + barW, pipY + pipH, argb((int)(this.openAnim * 220.0f), 0x0B1427), argb((int)(this.openAnim * 190.0f), 0x050812));
        g.fill(pipX + 1, pipY, pipX + barW - 1, pipY + pipH, unlocked ? argb(a, UI_RED) : argb((int)((float)a * 0.125f), UI_RED));
        String statText = unlocked ? "Sure-hit forged" : "Costs 5 PP";
        float statScale = this.resolveFittedTextScale(font, statText, Math.max(24, contentRight - (px + iconPad)), 0.58f, 0.46f);
        this.drawScaledForegroundText(g, font, statText, px + iconPad, pipY + pipH + Math.max(4, (int)(this.fontScale * 5.0f)), argb(a, unlocked ? UI_RED : UI_TEXT_DIM), statScale);
        this.drawSukunaSureHitTextButton(g, this.getSukunaSureHitSealBtnBounds(), "SEALED", unlocked && !this.masteryMutationLocked, 0xDC2626, UI_RED);
        this.drawSukunaSureHitTextButton(g, this.getSukunaSureHitForgeBtnBounds(), "FORGE", canBuy, 0x059669, 0x10B981);
    }

    private void drawSukunaSureHitTextButton(GuiGraphics g, int[] bounds, String text, boolean enabled, int baseColor, int hoverColor) {
        Font font = this.font;
        int a = (int)(this.openAnim * 255.0f);
        int x = bounds[0];
        int y = bounds[1];
        int w = bounds[2];
        int h = bounds[3];
        int accent = this.hoveredSukunaSureHit ? hoverColor : baseColor;
        int fill = enabled ? argb(a, blend(accent, 0x070B16, this.hoveredSukunaSureHit ? 0.42f : 0.24f)) : argb((int)((float)a * 0.2f), 0x333333);
        int textCol = enabled ? argb(a, UI_TEXT) : argb((int)((float)a * 0.36f), UI_TEXT_MID);
        this.fillVerticalGradient(g, x, y, x + w, y + h, fill, argb(enabled ? (int)(a * 0.82f) : (int)(a * 0.16f), 0x02040A));
        g.fill(x, y, x + w, y + 1, enabled ? argb((int)(a * 0.72f), accent) : argb((int)((float)a * 0.3f), 0x555555));
        g.fill(x, y + h - 1, x + w, y + h, enabled ? argb((int)(a * 0.45f), accent) : argb((int)((float)a * 0.3f), 0x555555));
        float scale = this.resolveFittedTextScale(font, text, w - Math.max(4, (int)(this.fontScale * 6.0f)), 0.72f, 0.5f);
        this.drawScaledForegroundText(g, font, text, x + (w - this.getScaledTextWidth(font, text, scale)) / 2, y + (h - this.getScaledTextHeight(font, scale)) / 2, textCol, scale);
    }

    private void drawSukunaSureHitTooltip(GuiGraphics g, int mx, int my) {
        Font font = this.font;
        String name = "Cleave Covenant";
        String desc = this.isSukunaSureHitUnlocked()
                ? "A binding vow has sealed Malevolent Shrine into its incomplete shell. Your next incomplete Shrine keeps its guaranteed cleave field, then refunds automatically if the vow is broken by changing form or duration."
                : "Forge a ruthless Sukuna-only vow: sacrifice five Domain Property Points to let incomplete Malevolent Shrine inherit the true sure-hit cleave field. The vow appears only while the required Shrine setup is valid and refunds itself if invalidated.";
        int maxDescWidth = Math.max(180, Math.min(320, this.width / 2));
        List<FormattedCharSequence> descLines = font.split((FormattedText)Component.literal((String)desc), maxDescWidth);
        int maxW = font.width(name);
        for (FormattedCharSequence line : descLines) {
            maxW = Math.max(maxW, font.width(line));
        }
        float tooltipScale = this.resolveTooltipScale(maxW + 20, 9 + descLines.size() * 9 + 16);
        int tw = Math.round((maxW + 20) * tooltipScale);
        int th = Math.round((9 + descLines.size() * 9 + 16) * tooltipScale);
        int tx = mx + 16;
        int ty = my - th - 4;
        if (tx + tw > this.width) {
            tx = mx - tw - 4;
        }
        if (ty < 0) {
            ty = my + 16;
        }
        g.pose().pushPose();
        g.pose().translate(0.0, 0.0, 420.0);
        this.fillVerticalGradient(g, tx, ty, tx + tw, ty + th, argb(248, 0x0F1728), argb(244, 0x040711));
        g.fill(tx, ty, tx + tw, ty + 1, argb(230, UI_RED));
        g.fill(tx, ty + th - 1, tx + tw, ty + th, argb(160, UI_RED));
        g.fill(tx, ty, tx + 1, ty + th, argb(130, UI_RED));
        g.fill(tx + tw - 1, ty, tx + tw, ty + th, argb(130, UI_RED));
        g.pose().pushPose();
        g.pose().scale(tooltipScale, tooltipScale, 1.0f);
        g.drawString(font, name, Math.round((float)(tx + 10) / tooltipScale), Math.round((float)(ty + 7) / tooltipScale), argb(255, UI_RED), false);
        for (int i = 0; i < descLines.size(); ++i) {
            g.drawString(font, descLines.get(i), Math.round((float)(tx + 10) / tooltipScale), Math.round((float)(ty + 16 + i * 9) / tooltipScale), argb(255, UI_TEXT_MID), false);
        }
        g.pose().popPose();
        g.pose().popPose();
    }

    // ===== LAYOUT HELPERS =====
    private int[] getFormBtnBounds(int i) {
        // Drive hit-testing from the same HeaderLayout the buttons are rendered from, so
        // the clickable region always matches the drawn button (Req 1.8 consistency).
        HeaderLayout layout = HeaderLayout.compute(this.fontScale, this.panelX, this.panelY, this.drawW, this.drawHeaderH);
        Rect r = switch (i) {
            case 1 -> layout.closedBtn();
            case 2 -> layout.openBtn();
            default -> layout.incompleteBtn();
        };
        return new int[]{r.x(), r.y(), r.w(), r.h()};
    }

    /**
     * Returns plus btn bounds for the current addon state.
     * @param i i used by this method.
     * @return the resolved plus btn bounds.
     */
    private int[] getPlusBtnBounds(int i) {
        int propStartX = this.getPropertyStartX();
        int propStartY = this.getPropertyStartY();
        int row = i / 2;
        int col = i % 2;
        int px = propStartX + col * (this.drawPropColW + this.drawPropGapX);
        int py = propStartY + row * (this.drawPropRow + this.drawPropGapY);
        int btnW = Math.max(12, (int)(this.fontScale * 18.0f));
        int btnH = Math.max(11, (int)(this.fontScale * 16.0f));
        int btnX = px + this.drawPropColW - btnW - Math.max(3, (int)(this.fontScale * 5.0f));
        int btnY = py + this.drawPropRow - btnH - Math.max(3, (int)(this.fontScale * 5.0f));
        return new int[]{btnX, btnY, btnW, btnH};
    }

    /**
     * Returns minus btn bounds for the current addon state.
     * @param i i used by this method.
     * @return the resolved minus btn bounds.
     */
    private int[] getMinusBtnBounds(int i) {
        int propStartX = this.getPropertyStartX();
        int propStartY = this.getPropertyStartY();
        int row = i / 2;
        int col = i % 2;
        int px = propStartX + col * (this.drawPropColW + this.drawPropGapX);
        int py = propStartY + row * (this.drawPropRow + this.drawPropGapY);
        int btnW = Math.max(12, (int)(this.fontScale * 18.0f));
        int btnH = Math.max(11, (int)(this.fontScale * 16.0f));
        int gap = Math.max(4, (int)(this.fontScale * 5.0f));
        int plusBtnX = px + this.drawPropColW - btnW - Math.max(3, (int)(this.fontScale * 5.0f));
        int btnX = plusBtnX - btnW - gap;
        int btnY = py + this.drawPropRow - btnH - Math.max(3, (int)(this.fontScale * 5.0f));
        return new int[]{btnX, btnY, btnW, btnH};
    }

    /**
     * Returns reset btn bounds for the current addon state.
     * @return the resolved reset btn bounds.
     */
    private int[] getResetBtnBounds() {
        return new int[]{this.panelX + Math.max(4, (int)(this.fontScale * 12.0f)), this.panelY + this.drawH - this.drawFooterH + Math.max(2, (int)(this.fontScale * 8.0f)), Math.max(40, (int)(this.fontScale * 110.0f)), Math.max(10, (int)(this.fontScale * 26.0f))};
    }

    private int[] getSukunaSureHitBtnBounds() {
        int propStartX = this.getPropertyStartX();
        int row = 4;
        int col = 1;
        int x = propStartX + col * (this.drawPropColW + this.drawPropGapX);
        int y = this.getPropertyStartY() + row * (this.drawPropRow + this.drawPropGapY);
        return new int[]{x, y, this.drawPropColW, this.drawPropRow};
    }

    private int[] getSukunaSureHitForgeBtnBounds() {
        int[] card = this.getSukunaSureHitBtnBounds();
        int gap = Math.max(4, (int)(this.fontScale * 5.0f));
        int btnW = Math.max(34, (int)(this.fontScale * 46.0f));
        int btnH = Math.max(11, (int)(this.fontScale * 15.0f));
        int btnY = card[1] + card[3] - btnH - Math.max(2, (int)(this.fontScale * 4.0f));
        int btnX = card[0] + card[2] - btnW - Math.max(3, (int)(this.fontScale * 5.0f));
        return new int[]{btnX, btnY, btnW, btnH};
    }

    private int[] getSukunaSureHitSealBtnBounds() {
        int[] forge = this.getSukunaSureHitForgeBtnBounds();
        int gap = Math.max(4, (int)(this.fontScale * 5.0f));
        return new int[]{forge[0] - forge[2] - gap, forge[1], forge[2], forge[3]};
    }

    /**
     * Returns close btn bounds for the current addon state.
     * @return the resolved close btn bounds.
     */
    private int[] getCloseBtnBounds() {
        return new int[]{this.panelX + this.drawW - Math.max(30, (int)(this.fontScale * 82.0f)), this.panelY + this.drawH - this.drawFooterH + Math.max(2, (int)(this.fontScale * 8.0f)), Math.max(30, (int)(this.fontScale * 70.0f)), Math.max(10, (int)(this.fontScale * 26.0f))};
    }

    /**
     * Checks whether is in rect is true for the current addon state.
     * @param px px used by this method.
     * @param py py used by this method.
     * @param r r used by this method.
     * @return true when is in rect succeeds; otherwise false.
     */
    private boolean isInRect(float px, float py, int[] r) {
        return px >= (float)r[0] && px <= (float)(r[0] + r[2]) && py >= (float)r[1] && py <= (float)(r[1] + r[3]);
    }

    /**
     * Returns property color for the current addon state.
     * @param idx identifier used to resolve the requested entry or state.
     * @return the resolved property color.
     */
    private int getPropertyColor(int idx) {
        return switch (idx) {
            case 0 -> 3718648;
            case 1 -> 16096779;
            case 2 -> 2278750;
            case 3 -> 16007006;
            case 4 -> 6333946;
            case 5 -> 16486972;
            case 6 -> 1357990;
            case 7 -> 16478597;
            case 8 -> 5614335;
            default -> 3718648;
        };
    }

    // ===== TEXT AND ITEM HELPERS =====
    private float normalizeReadableTextScale(float scale) {
        float floor = Math.min(1.0f, this.fontScale + 0.16f);
        return Math.max(scale, floor);
    }

    private float resolveFittedTextScale(Font font, String text, int maxWidth, float maxScale, float minScale) {
        maxScale = this.normalizeReadableTextScale(maxScale);
        minScale = Math.min(maxScale, this.normalizeReadableTextScale(minScale));
        if (text == null || text.isEmpty()) {
            return maxScale;
        }
        if (maxWidth <= 0) {
            return minScale;
        }
        int rawWidth = font.width(text);
        if (rawWidth <= 0 || rawWidth <= maxWidth) {
            return maxScale;
        }
        float fittedScale = (float)maxWidth / (float)rawWidth;
        return Math.max(minScale, Math.min(maxScale, fittedScale));
    }

    private float resolveTooltipScale(int rawWidth, int rawHeight) {
        if (rawWidth <= 0 || rawHeight <= 0) {
            return 1.0f;
        }
        float maxW = Math.max(80.0f, (float)this.width - 16.0f);
        float maxH = Math.max(60.0f, (float)this.height - 16.0f);
        float scale = Math.min(1.0f, Math.min(maxW / (float)rawWidth, maxH / (float)rawHeight));
        return Math.max(0.55f, scale);
    }

    /**
     * Returns scaled text width for the current addon state.
     * @param font font used by this method.
     * @param text text used by this method.
     * @param scale scale used by this method.
     * @return the resolved scaled text width.
     */
    private int getScaledTextWidth(Font font, String text, float scale) {
        scale = this.normalizeReadableTextScale(scale);
        return Math.round((float)font.width(text) * scale);
    }

    /**
     * Returns scaled text height for the current addon state.
     * @param font font used by this method.
     * @param scale scale used by this method.
     * @return the resolved scaled text height.
     */
    private int getScaledTextHeight(Font font, float scale) {
        Objects.requireNonNull(font);
        scale = this.normalizeReadableTextScale(scale);
        return Math.max(1, Math.round(9.0f * scale));
    }

    /**
     * Draws scaled foreground text as part of the addon presentation layer.
     * @param graphics render context used to draw the current frame.
     * @param font font used by this method.
     * @param text text used by this method.
     * @param x screen or world coordinate used by this calculation.
     * @param y screen or world coordinate used by this calculation.
     * @param color color used by this method.
     * @param scale scale used by this method.
     */
    private void drawScaledForegroundText(GuiGraphics graphics, Font font, String text, int x, int y, int color, float scale) {
        scale = this.normalizeReadableTextScale(scale);
        graphics.pose().pushPose();
        graphics.pose().translate(0.0, 0.0, 200.0);
        graphics.pose().scale(scale, scale, 1.0f);
        graphics.drawString(font, text, Math.round((float)x / scale), Math.round((float)y / scale), color, false);
        graphics.pose().popPose();
    }

    /**
     * Draws fitted foreground text as part of the addon presentation layer.
     * @param graphics render context used to draw the current frame.
     * @param font font used by this method.
     * @param text text used by this method.
     * @param x screen or world coordinate used by this calculation.
     * @param y screen or world coordinate used by this calculation.
     * @param color color used by this method.
     * @param maxWidth max width used by this method.
     * @param maxScale max scale used by this method.
     * @param minScale min scale used by this method.
     */
    private void drawFittedForegroundText(GuiGraphics graphics, Font font, String text, int x, int y, int color, int maxWidth, float maxScale, float minScale) {
        float scale = this.resolveFittedTextScale(font, text, maxWidth, maxScale, minScale);
        this.drawScaledForegroundText(graphics, font, text, x, y, color, scale);
    }

    /**
     * Draws right aligned fitted foreground text as part of the addon presentation layer.
     * @param graphics render context used to draw the current frame.
     * @param font font used by this method.
     * @param text text used by this method.
     * @param rightX right x used by this method.
     * @param y screen or world coordinate used by this calculation.
     * @param color color used by this method.
     * @param maxWidth max width used by this method.
     * @param maxScale max scale used by this method.
     * @param minScale min scale used by this method.
     */
    private void drawRightAlignedFittedForegroundText(GuiGraphics graphics, Font font, String text, int rightX, int y, int color, int maxWidth, float maxScale, float minScale) {
        float scale = this.resolveFittedTextScale(font, text, maxWidth, maxScale, minScale);
        int drawX = rightX - this.getScaledTextWidth(font, text, scale);
        this.drawScaledForegroundText(graphics, font, text, drawX, y, color, scale);
    }

    /**
     * Draws foreground text as part of the addon presentation layer.
     * @param graphics render context used to draw the current frame.
     * @param font font used by this method.
     * @param text text used by this method.
     * @param x screen or world coordinate used by this calculation.
     * @param y screen or world coordinate used by this calculation.
     * @param color color used by this method.
     */
    private void drawForegroundText(GuiGraphics graphics, Font font, String text, int x, int y, int color) {
        this.drawScaledForegroundText(graphics, font, text, x, y, color, 1.0f);
    }

    /**
     * Draws layered item as part of the addon presentation layer.
     * @param graphics render context used to draw the current frame.
     * @param item item used by this method.
     * @param x screen or world coordinate used by this calculation.
     * @param y screen or world coordinate used by this calculation.
     * @param z screen or world coordinate used by this calculation.
     */
    private void drawLayeredItem(GuiGraphics graphics, ItemStack item, int x, int y, double z) {
        graphics.pose().pushPose();
        graphics.pose().translate(0.0, 0.0, z);
        graphics.renderItem(item, x, y);
        graphics.pose().popPose();
    }

    /**
     * Draws layered item scaled as part of the addon presentation layer.
     * @param graphics render context used to draw the current frame.
     * @param item item used by this method.
     * @param x screen or world coordinate used by this calculation.
     * @param y screen or world coordinate used by this calculation.
     * @param size size used by this method.
     * @param z screen or world coordinate used by this calculation.
     */
    private void drawLayeredItemScaled(GuiGraphics graphics, ItemStack item, int x, int y, int size, double z) {
        float scale = Math.max(0.1f, (float)size / 16.0f);
        graphics.pose().pushPose();
        graphics.pose().translate((double)x, (double)y, z);
        graphics.pose().scale(scale, scale, 1.0f);
        graphics.renderItem(item, 0, 0);
        graphics.pose().popPose();
    }

    /**
     * Draws property control button as part of the addon presentation layer.
     * @param graphics render context used to draw the current frame.
     * @param x screen or world coordinate used by this calculation.
     * @param y screen or world coordinate used by this calculation.
     * @param w screen or world coordinate used by this calculation.
     * @param h screen or world coordinate used by this calculation.
     * @param fillColor fill color used by this method.
     * @param symbolColor symbol color used by this method.
     * @param plus plus used by this method.
     */
    private void drawPropertyControlButton(GuiGraphics graphics, int x, int y, int w, int h, int fillColor, int symbolColor, boolean plus) {
        graphics.pose().pushPose();
        graphics.pose().translate(0.0, 0.0, 150.0);
        int alpha = fillColor >>> 24;
        int rgb = fillColor & 0xFFFFFF;
        this.fillVerticalGradient(graphics, x, y, x + w, y + h, argb(alpha, blend(rgb, 0x070B16, 0.35f)), argb(Math.max(0, (int)(alpha * 0.78f)), 0x02040A));
        graphics.fill(x, y, x + w, y + 1, argb(Math.max(0, (int)(alpha * 0.72f)), rgb));
        graphics.fill(x, y + h - 1, x + w, y + h, argb(Math.max(0, (int)(alpha * 0.45f)), rgb));
        int centerX = x + w / 2;
        int centerY = y + h / 2;
        int arm = Math.max(2, Math.min(w, h) / 3);
        int thickness = Math.max(1, Math.min(2, Math.round(this.fontScale * 1.5f)));
        graphics.fill(centerX - arm, centerY - thickness, centerX + arm + 1, centerY + thickness + 1, symbolColor);
        if (plus) {
            graphics.fill(centerX - thickness, centerY - arm, centerX + thickness + 1, centerY + arm + 1, symbolColor);
        }
        graphics.pose().popPose();
    }

    private void fillVerticalGradient(GuiGraphics g, int x1, int y1, int x2, int y2, int topColor, int bottomColor) {
        int h = y2 - y1;
        if (h <= 0 || x2 <= x1) {
            return;
        }
        int steps = Math.min(28, Math.max(1, h));
        for (int i = 0; i < steps; i++) {
            float t = steps <= 1 ? 0.0f : (float)i / (float)(steps - 1);
            int yStart = y1 + i * h / steps;
            int yEnd = y1 + (i + 1) * h / steps;
            g.fill(x1, yStart, x2, Math.max(yStart + 1, yEnd), lerpArgb(topColor, bottomColor, t));
        }
    }

    private static int lerpArgb(int a, int b, float t) {
        float clamped = Math.max(0.0f, Math.min(1.0f, t));
        int aa = a >>> 24;
        int ar = a >> 16 & 0xFF;
        int ag = a >> 8 & 0xFF;
        int ab = a & 0xFF;
        int ba = b >>> 24;
        int br = b >> 16 & 0xFF;
        int bg = b >> 8 & 0xFF;
        int bb = b & 0xFF;
        int oa = (int)(aa + (ba - aa) * clamped);
        int or = (int)(ar + (br - ar) * clamped);
        int og = (int)(ag + (bg - ag) * clamped);
        int ob = (int)(ab + (bb - ab) * clamped);
        return oa << 24 | or << 16 | og << 8 | ob;
    }

    private static int argb(int alpha, int rgb) {
        int a = Math.max(0, Math.min(255, alpha));
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private static int blend(int foreground, int background, float amount) {
        float clamped = Math.max(0.0f, Math.min(1.0f, amount));
        int fr = foreground >> 16 & 0xFF;
        int fg = foreground >> 8 & 0xFF;
        int fb = foreground & 0xFF;
        int br = background >> 16 & 0xFF;
        int bg = background >> 8 & 0xFF;
        int bb = background & 0xFF;
        int r = (int)(br + (fr - br) * clamped);
        int g = (int)(bg + (fg - bg) * clamped);
        int b = (int)(bb + (fb - bb) * clamped);
        return r << 16 | g << 8 | b;
    }

    // ===== STATIC LABEL HELPERS =====
    private String getPropertyIcon(int idx) {
        return switch (idx) {
            case 0 -> "CE";
            case 1 -> "BF";
            case 2 -> "RCT";
            case 3 -> "BL";
            case 4 -> "SL";
            case 5 -> "DU";
            case 6 -> "RA";
            case 7 -> "CL";
            default -> "??";
        };
    }

    /**
     * Returns short name for the current addon state.
     * @param idx identifier used to resolve the requested entry or state.
     * @return the resolved short name.
     */
    private String getShortName(int idx) {
        return switch (idx) {
            case 0 -> "CE Drain";
            case 1 -> "BF Chance";
            case 2 -> "RCT Heal";
            case 3 -> "Blind";
            case 4 -> "Slow";
            case 5 -> "Duration";
            case 6 -> "Radius";
            case 7 -> "Barrier Power";
            case 8 -> "Barrier Ref";
            default -> "???";
        };
    }

    private String getPropertyDisplayName(DomainMasteryProperties prop) {
        String translated = Component.translatable((String)prop.getNameKey()).getString();
        if (translated == null || translated.isBlank() || translated.equals(prop.getNameKey())) {
            return this.getShortName(prop.ordinal());
        }
        return translated;
    }

    private String getPropertyDescription(DomainMasteryProperties prop) {
        String translated = Component.translatable((String)prop.getDescKey()).getString();
        if (translated != null && !translated.isBlank() && !translated.equals(prop.getDescKey())) {
            return translated;
        }
        return switch (prop) {
            case VICTIM_CE_DRAIN -> "Drains cursed energy from enemy players inside your active domain radius every 0.5 seconds. Higher levels increase CE drained per tick window.";
            case BF_CHANCE_BOOST -> "Raises your addon Black Flash chance while Domain Mastery effects are active. The runtime bonus is stored as a domain Black Flash bonus on the caster.";
            case RCT_HEAL_BOOST -> "Heals the domain owner once per second while alive and below max health. Higher levels increase HP restored per second.";
            case BLIND_EFFECT -> "Applies Blindness to valid enemies inside the active domain radius. The effect refreshes once per second and scales with invested level.";
            case SLOW_EFFECT -> "Applies Movement Slowdown to valid enemies inside the active domain radius. The effect refreshes once per second and scales with invested level.";
            case DURATION_EXTEND -> "Extends domain duration by 5 seconds per level. Negative Modify can shorten duration and grant extra property points.";
            case RADIUS_BOOST -> "Increases the effective domain radius by 12 percent per level for addon-scaled domain checks, startup radius, active range, and clash power.";
            case BARRIER_POWER -> "Improves barrier power and raw clash strength. It also contributes to runtime barrier scaling; Negative Modify weakens this for extra points.";
            case BARRIER_REFINEMENT -> "Improves barrier refinement against open domains and domain clashes. Negative Modify reduces refinement for glass-cannon builds.";
        };
    }

    /**
     * Returns property tagline for the current addon state.
     * @param idx identifier used to resolve the requested entry or state.
     * @return the resolved property tagline.
     */
    private String getPropertyTagline(int idx) {
        return switch (idx) {
            case 0 -> "Drain victim CE";
            case 1 -> "Boost BF odds";
            case 2 -> "Amplify RCT";
            case 3 -> "Blind targets";
            case 4 -> "Slow targets";
            case 5 -> "Longer domain";
            case 6 -> "Wider domain";
            case 7 -> "Reinforce barrier";
            case 8 -> "Barrier resist";
            default -> "";
        };
    }

    /**
     * Returns property item for the current addon state.
     * @param idx identifier used to resolve the requested entry or state.
     * @return the resolved property item.
     */
    private ItemStack getPropertyItem(int idx) {
        return switch (idx) {
            case 0 -> new ItemStack((ItemLike)Items.LIGHTNING_ROD);
            case 1 -> new ItemStack((ItemLike)Items.GOLD_NUGGET);
            case 2 -> new ItemStack((ItemLike)Items.GLISTERING_MELON_SLICE);
            case 3 -> new ItemStack((ItemLike)Items.ENDER_EYE);
            case 4 -> new ItemStack((ItemLike)Items.COBWEB);
            case 5 -> new ItemStack((ItemLike)Items.CLOCK);
            case 6 -> new ItemStack((ItemLike)Items.COMPASS);
            case 7 -> new ItemStack((ItemLike)Items.NETHERITE_SWORD);
            case 8 -> new ItemStack((ItemLike)Items.SHIELD);
            default -> new ItemStack((ItemLike)Items.AMETHYST_SHARD);
        };
    }

    /**
     * Returns form item for the current addon state.
     * @param form form used by this method.
     * @return the resolved form item.
     */
    private ItemStack getFormItem(int form) {
        return switch (form) {
            case 0 -> new ItemStack((ItemLike)Items.GRAY_STAINED_GLASS_PANE);
            case 1 -> new ItemStack((ItemLike)Items.OBSIDIAN);
            case 2 -> new ItemStack((ItemLike)Items.ENDER_EYE);
            default -> new ItemStack((ItemLike)Items.BARRIER);
        };
    }

    // ===== CAPABILITY READ HELPERS =====
    private int getDomainMasteryLevel() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return 0;
        }
        try {
            return mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(data -> data.getDomainMasteryLevel()).orElse(0);
        }
        catch (Exception e) {
            return 0;
        }
    }

    /**
     * Returns domain property points for the current addon state.
     * @return the resolved domain property points.
     */
    private int getDomainPropertyPoints() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return 0;
        }
        try {
            return mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(data -> data.getDomainPropertyPoints()).orElse(0);
        }
        catch (Exception e) {
            return 0;
        }
    }

    private boolean shouldShowSukunaSureHitOption() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return false;
        }
        try {
            return mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(DomainMasteryData::canShowSukunaIncompleteSureHit).orElse(false);
        }
        catch (Exception e) {
            return false;
        }
    }

    private boolean isSukunaSureHitUnlocked() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return false;
        }
        try {
            return mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(DomainMasteryData::isSukunaIncompleteSureHitUnlocked).orElse(false);
        }
        catch (Exception e) {
            return false;
        }
    }

    private boolean canBuySukunaSureHit() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return false;
        }
        try {
            return mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(DomainMasteryData::canPurchaseSukunaIncompleteSureHit).orElse(false);
        }
        catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns domain xp for the current addon state.
     * @return the resolved domain xp.
     */
    private double getDomainXP() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return 0.0;
        }
        try {
            return mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(data -> data.getDomainXP()).orElse(0.0);
        }
        catch (Exception e) {
            return 0.0;
        }
    }

    /**
     * Returns xp to next for the current addon state.
     * @return the resolved xp to next.
     */
    private int getXPToNext() {
        return switch (this.getDomainMasteryLevel()) {
            case 0 -> 300;
            case 1 -> 700;
            case 2 -> 1300;
            case 3 -> 2200;
            case 4 -> 3500;
            default -> 1;
        };
    }

    /**
     * Returns xp progress for the current addon state.
     * @return the resolved xp progress.
     */
    private double getXPProgress() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return 0.0;
        }
        try {
            return mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(data -> data.getXPProgress()).orElse(0.0);
        }
        catch (Exception e) {
            return 0.0;
        }
    }

    /**
     * Returns property level for the current addon state.
     * @param prop property identifier involved in this operation.
     * @return the resolved property level.
     */
    private int getPropertyLevel(DomainMasteryProperties prop) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return 0;
        }
        try {
            return mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(data -> data.getPropertyLevel(prop)).orElse(0);
        }
        catch (Exception e) {
            return 0;
        }
    }

    /**
     * Returns effective property level for the current addon state.
     * @param prop property identifier involved in this operation.
     * @return the resolved effective property level.
     */
    private int getEffectivePropertyLevel(DomainMasteryProperties prop) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return 0;
        }
        try {
            return mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(data -> data.getEffectivePropertyLevel(prop)).orElse(0);
        }
        catch (Exception e) {
            return 0;
        }
    }

    /**
     * Checks whether is negative property is true for the current addon state.
     * @param propIdx identifier used to resolve the requested entry or state.
     * @return true when is negative property succeeds; otherwise false.
     */
    private boolean isNegativeProperty(int propIdx) {
        DomainMasteryProperties prop = DomainMasteryProperties.values()[propIdx];
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return false;
        }
        try {
            return mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(data -> data.isNegativeProperty(prop)).orElse(false);
        }
        catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether can set negative property is true for the current addon state.
     * @param prop property identifier involved in this operation.
     * @return true when can set negative property succeeds; otherwise false.
     */
    private boolean canSetNegativeProperty(DomainMasteryProperties prop) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return false;
        }
        try {
            return mc.player.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).resolve().map(data -> data.canSetNegative(prop)).orElse(false);
        }
        catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether can upgrade property is true for the current addon state.
     * @param propIdx identifier used to resolve the requested entry or state.
     * @return true when can upgrade property succeeds; otherwise false.
     */
    private boolean canUpgradeProperty(int propIdx) {
        DomainMasteryProperties prop = DomainMasteryProperties.values()[propIdx];
        return !prop.isLocked(this.getDomainMasteryLevel()) && !this.isNegativeProperty(propIdx) && this.getPropertyLevel(prop) < prop.getMaxLevel() && this.getDomainPropertyPoints() >= prop.getPointCost();
    }

    /**
     * Checks whether can refund property is true for the current addon state.
     * @param propIdx identifier used to resolve the requested entry or state.
     * @return true when can refund property succeeds; otherwise false.
     */
    private boolean canRefundProperty(int propIdx) {
        DomainMasteryProperties prop = DomainMasteryProperties.values()[propIdx];
        return !prop.isLocked(this.getDomainMasteryLevel()) && !this.isNegativeProperty(propIdx) && this.getPropertyLevel(prop) > 0;
    }

    /**
     * Checks whether can negative decrease property is true for the current addon state.
     * @param propIdx identifier used to resolve the requested entry or state.
     * @return true when can negative decrease property succeeds; otherwise false.
     */
    private boolean canNegativeDecreaseProperty(int propIdx) {
        DomainMasteryProperties prop = DomainMasteryProperties.values()[propIdx];
        int effectiveLevel = this.getEffectivePropertyLevel(prop);
        return prop.supportsNegativeModify() && this.getDomainMasteryLevel() >= 5 && this.getPropertyLevel(prop) <= 0 && this.canSetNegativeProperty(prop) && (!this.isNegativeProperty(propIdx) || effectiveLevel > -5);
    }

    /**
     * Checks whether can negative increase property is true for the current addon state.
     * @param propIdx identifier used to resolve the requested entry or state.
     * @return true when can negative increase property succeeds; otherwise false.
     */
    private boolean canNegativeIncreaseProperty(int propIdx) {
        DomainMasteryProperties prop = DomainMasteryProperties.values()[propIdx];
        return prop.supportsNegativeModify() && this.isNegativeProperty(propIdx) && this.getDomainPropertyPoints() >= prop.getPointCost();
    }

    // ===== NETWORK ACTIONS =====
    private void setForm(int form) {
        ModNetworking.CHANNEL.sendToServer((Object)new ModNetworking.DomainPropertyPacket(3, form));
    }

    /**
     * Performs upgrade property for this addon component.
     * @param propIdx identifier used to resolve the requested entry or state.
     */
    private void upgradeProperty(int propIdx) {
        ModNetworking.CHANNEL.sendToServer((Object)new ModNetworking.DomainPropertyPacket(0, propIdx));
    }

    /**
     * Performs refund property for this addon component.
     * @param propIdx identifier used to resolve the requested entry or state.
     */
    private void refundProperty(int propIdx) {
        ModNetworking.CHANNEL.sendToServer((Object)new ModNetworking.DomainPropertyPacket(1, propIdx));
    }

    /**
     * Performs negative decrease for this addon component.
     * @param propIdx identifier used to resolve the requested entry or state.
     */
    private void negativeDecrease(int propIdx) {
        ModNetworking.CHANNEL.sendToServer((Object)new ModNetworking.DomainPropertyPacket(5, propIdx));
    }

    /**
     * Performs negative increase for this addon component.
     * @param propIdx identifier used to resolve the requested entry or state.
     */
    private void negativeIncrease(int propIdx) {
        ModNetworking.CHANNEL.sendToServer((Object)new ModNetworking.DomainPropertyPacket(6, propIdx));
    }

    private void buySukunaSureHit() {
        int operation = this.isSukunaSureHitUnlocked() ? ModNetworking.DomainPropertyPacket.OP_SUKUNA_INCOMPLETE_SUREHIT_CLEAR : ModNetworking.DomainPropertyPacket.OP_SUKUNA_INCOMPLETE_SUREHIT;
        ModNetworking.CHANNEL.sendToServer((Object)new ModNetworking.DomainPropertyPacket(operation, 0));
    }

    /**
     * Performs reset all for this addon component.
     */
    private void resetAll() {
        ModNetworking.CHANNEL.sendToServer((Object)new ModNetworking.DomainPropertyPacket(2, -1));
    }

    // ===== LOCKED-STATE FEEDBACK =====
    private void drawMutationLockTooltip(GuiGraphics g, int mx, int my) {
        Font font = this.font;
        String name = "Domain Mastery Locked";
        int maxDescWidth = Math.max(140, Math.min(260, this.width / 3));
        List<FormattedCharSequence> descLines = font.split((FormattedText)Component.literal((String)this.masteryMutationLockReason), maxDescWidth);
        int maxW = font.width(name);
        for (FormattedCharSequence line : descLines) {
            maxW = Math.max(maxW, font.width(line));
        }
        int rawTw = maxW + 20;
        Objects.requireNonNull(font);
        int n = descLines.size();
        Objects.requireNonNull(font);
        int rawTh = 9 + n * 9 + 16;
        float tooltipScale = this.resolveTooltipScale(rawTw, rawTh);
        int tw = Math.round(rawTw * tooltipScale);
        int th = Math.round(rawTh * tooltipScale);
        int tx = mx + 16;
        int ty = my - th - 4;
        if (tx + tw > this.width) {
            tx = mx - tw - 4;
        }
        if (ty < 0) {
            ty = my + 16;
        }
        g.pose().pushPose();
        g.pose().translate(0.0, 0.0, 420.0);
        this.fillVerticalGradient(g, tx, ty, tx + tw, ty + th, argb(248, 0x0F1728), argb(244, 0x040711));
        g.fill(tx, ty, tx + tw, ty + 1, argb(230, UI_GOLD));
        g.fill(tx, ty + th - 1, tx + tw, ty + th, argb(160, UI_GOLD));
        g.fill(tx, ty, tx + 1, ty + th, argb(130, UI_GOLD));
        g.fill(tx + tw - 1, ty, tx + tw, ty + th, argb(130, UI_GOLD));
        g.pose().pushPose();
        g.pose().scale(tooltipScale, tooltipScale, 1.0f);
        g.drawString(font, name, Math.round((float)(tx + 10) / tooltipScale), Math.round((float)(ty + 7) / tooltipScale), argb(255, UI_GOLD), false);
        for (int i = 0; i < descLines.size(); ++i) {
            FormattedCharSequence formattedCharSequence = (FormattedCharSequence)descLines.get(i);
            Objects.requireNonNull(font);
            Objects.requireNonNull(font);
            g.drawString(font, formattedCharSequence, Math.round((float)(tx + 10) / tooltipScale), Math.round((float)(ty + 7 + 9 + i * 9) / tooltipScale), argb(255, UI_TEXT_MID), false);
        }
        g.pose().popPose();
        g.pose().popPose();
    }

    /**
     * Performs send form lock message for this addon component.
     * @param form form used by this method.
     */
    private void sendFormLockMessage(int form) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        if (form == 0) {
            return;
        }
        String message = form == 1 ? "Closed Domain requires Domain Mastery Lv.1" : (this.getDomainMasteryLevel() < 5 ? "Open Domain requires Domain Mastery Lv.5" : "Open Domain also requires the Open Domain achievement");
        mc.player.displayClientMessage((Component)Component.literal((String)"\u26a0 ").withStyle(new ChatFormatting[]{ChatFormatting.GOLD, ChatFormatting.BOLD}).append((Component)Component.literal((String)"[Domain Mastery] ").withStyle(ChatFormatting.DARK_AQUA)).append((Component)Component.literal((String)message).withStyle(ChatFormatting.RED)), false);
    }

    /**
     * Performs send mutation lock message for this addon component.
     */
    private void sendMutationLockMessage() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || this.masteryMutationLockReason.isEmpty()) {
            return;
        }
        mc.player.displayClientMessage((Component)Component.literal((String)"\u26a0 ").withStyle(new ChatFormatting[]{ChatFormatting.GOLD, ChatFormatting.BOLD}).append((Component)Component.literal((String)"[Domain Mastery] ").withStyle(ChatFormatting.DARK_AQUA)).append((Component)Component.literal((String)this.masteryMutationLockReason).withStyle(ChatFormatting.RED)), false);
    }

    // ===== SOUND HELPERS =====
    private void playUiHoverSound(int hoveredControl) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getSoundManager() == null) {
            return;
        }
        float pitch = 0.92f + (float)(hoveredControl % 7) * 0.03f;
        mc.getSoundManager().play((SoundInstance)SimpleSoundInstance.forUI((SoundEvent)SoundEvents.BOOK_PAGE_TURN, (float)0.08f, (float)pitch));
    }

    /**
     * Performs play ui open sound for this addon component.
     */
    private void playUiOpenSound() {
        Minecraft mc = Minecraft.getInstance();
        if (this.playedOpenSound || mc.getSoundManager() == null) {
            return;
        }
        this.playedOpenSound = true;
        mc.getSoundManager().play((SoundInstance)SimpleSoundInstance.forUI((SoundEvent)SoundEvents.ENCHANTMENT_TABLE_USE, (float)0.11f, (float)0.92f));
    }

    /**
     * Performs play form select sound for this addon component.
     * @param form form used by this method.
     */
    private void playFormSelectSound(int form) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getSoundManager() == null) {
            return;
        }
        float pitch = switch (form) {
            case 0 -> 0.82f;
            case 1 -> 0.98f;
            case 2 -> 1.14f;
            default -> 1.0f;
        };
        mc.getSoundManager().play((SoundInstance)SimpleSoundInstance.forUI((SoundEvent)SoundEvents.AMETHYST_BLOCK_CHIME, (float)0.18f, (float)pitch));
    }

    /**
     * Performs play upgrade sound for this addon component.
     */
    private void playUpgradeSound() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getSoundManager() == null) {
            return;
        }
        mc.getSoundManager().play((SoundInstance)SimpleSoundInstance.forUI((SoundEvent)SoundEvents.EXPERIENCE_ORB_PICKUP, (float)0.16f, (float)0.92f));
    }

    /**
     * Performs play refund sound for this addon component.
     */
    private void playRefundSound() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getSoundManager() == null) {
            return;
        }
        mc.getSoundManager().play((SoundInstance)SimpleSoundInstance.forUI((SoundEvent)SoundEvents.ITEM_FRAME_REMOVE_ITEM, (float)0.15f, (float)0.86f));
    }

    /**
     * Performs play reset sound for this addon component.
     */
    private void playResetSound() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getSoundManager() == null) {
            return;
        }
        mc.getSoundManager().play((SoundInstance)SimpleSoundInstance.forUI((SoundEvent)SoundEvents.ENCHANTMENT_TABLE_USE, (float)0.14f, (float)0.78f));
    }

    /**
     * Performs play close sound for this addon component.
     */
    private void playCloseSound() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getSoundManager() == null) {
            return;
        }
        mc.getSoundManager().play((SoundInstance)SimpleSoundInstance.forUI((SoundEvent)SoundEvents.CHEST_CLOSE, (float)0.14f, (float)0.96f));
    }

    /**
     * Performs play ui lock sound for this addon component.
     */
    private void playUiLockSound() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getSoundManager() == null) {
            return;
        }
        mc.getSoundManager().play((SoundInstance)SimpleSoundInstance.forUI((SoundEvent)SoundEvents.DISPENSER_FAIL, (float)0.12f, (float)0.82f));
    }

    // ===== MISCELLANEOUS HELPERS =====
    private int getHoveredControlId() {
        if (this.hoveredFormIdx >= 0) {
            return 100 + this.hoveredFormIdx;
        }
        for (int i = 0; i < this.hoveredPlus.length; ++i) {
            if (this.hoveredPlus[i]) {
                return 200 + i;
            }
            if (!this.hoveredMinus[i]) continue;
            return 300 + i;
        }
        if (this.hoveredReset) {
            return 400;
        }
        if (this.hoveredSukunaSureHit) {
            return 402;
        }
        if (this.hoveredClose) {
            return 401;
        }
        return -1;
    }

    /**
     * Returns property area width for the current addon state.
     * @return the resolved property area width.
     */
    private int getPropertyAreaWidth() {
        return this.drawW - Math.max(16, (int)(this.fontScale * 36.0f));
    }

    /**
     * Returns property start x for the current addon state.
     * @return the resolved property start x.
     */
    private int getPropertyStartX() {
        return this.panelX + Math.max(8, (int)(this.fontScale * 18.0f));
    }

    /**
     * Returns property start y for the current addon state.
     * @return the resolved property start y.
     */
    private int getPropertyStartY() {
        return this.panelY + this.drawHeaderH + Math.max(4, (int)(this.fontScale * 10.0f));
    }
}



