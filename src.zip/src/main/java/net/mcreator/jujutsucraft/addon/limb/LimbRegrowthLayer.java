package net.mcreator.jujutsucraft.addon.limb;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Vector3f;
import java.util.List;
import java.util.Random;
/**
 * Tres fases pixel a pixel (TEX_SIZE=128):
 *  0.00-0.25  Hueso custom  (geometría propia, shoulder + shaft + codo + forearm + conector lateral)
 *  0.25-0.75  Carne (cubo arm/leg + textura carne, pixel reveal)
 *  0.75-1.00  Skin  (cubo arm/leg + textura jugador, pixel reveal — código idéntico al que funcionaba)
 */
public class LimbRegrowthLayer
        extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final float PHASE_BONE      = 0.25f;
    private static final float BONE_COLOR_END  = 0.65f; // color change ends before PHASE_FLESH=0.75
    private static final float PHASE_FLESH = 0.75f;
    private static final float SKIN_SCALE  = 1.002f;
    static final         float PIXEL_SCALE = 1.0f / 16.0f;
    private static final int   TEX_SIZE    = 64;
    // ── Geometría del hueso ────────────────────────────────────────────────
    private static final float[][] RIGHT_ARM_BONE = {
        {-2f,  -1.9f,-1.5f,  3f,1.9f,3f},
        {-2f,    0f, -1f,    2f, 5f, 2f},
        {-2.5f,  4f, -1.5f,  3f, 1f, 3f},
        {-2f,    5f, -1f,    2f, 5f, 2f},
        { 0f,  -1.5f,-0.5f,  2.5f,1f,1f},
    };
    private static final float[][] LEFT_ARM_BONE = {
        {-1f,  -1.9f,-1.5f,  3f,1.9f,3f},
        { 0f,    0f, -1f,    2f, 5f, 2f},
        {-0.5f,  4f, -1.5f,  3f, 1f, 3f},
        { 0f,    5f, -1f,    2f, 5f, 2f},
        {-2.5f,-1.5f,-0.5f,  2.5f,1f,1f},
    };
    private static final float[][] LEG_BONE = {
        {-1f,   0f, -1f,   2f, 5f, 2f},
        {-1.5f, 5f, -1.5f, 3f, 1f,  3f},
        {-1f,   6f, -1f,   2f, 6f,  2f},
    };
    private static final float[][] HEAD_BONE = {
        {-3f, -7f, -3f, 6f, 6f, 6f},
    };
    // ── Texturas ──────────────────────────────────────────────────────────
    private static ResourceLocation boneTex;
    private static ResourceLocation fleshTex;
    // ── Reflexión: delega COMPLETAMENTE a LimbRenderHandler ─────────────────
    private static List<ModelPart.Cube> getCubes(ModelPart p)  { return LimbRenderHandler.getCubes(p); }
    private static Object[]  getPolygons(ModelPart.Cube c)     { return LimbRenderHandler.getPolygons(c); }
    private static Object[]  getVertices(Object p)             { return LimbRenderHandler.getVertices(p); }
    private static Vector3f  getNormal(Object p)               { return LimbRenderHandler.getNormal(p); }
    private static Vector3f  getPos(Object v)                  { return LimbRenderHandler.getPos(v); }
    private static float     getU(Object v)                    { return LimbRenderHandler.getU(v); }
    private static float     getV(Object v)                    { return LimbRenderHandler.getV(v); }
    public LimbRegrowthLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
        LimbRenderHandler.ensureModelReflect();
    }
    // ── Render ────────────────────────────────────────────────────────────
    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light,
                       AbstractClientPlayer entity, float lS, float lSA, float pt,
                       float ait, float hY, float hP) {
        ClientLimbCache.EntityLimbSnapshot snap = ClientLimbCache.get(entity.getId());
        if (snap == null) return;
        boolean any = false;
        for (LimbType t : LimbType.values()) if (snap.getState(t) == LimbState.REVERSING) { any = true; break; }
        if (!any) return;
        @SuppressWarnings("unchecked")
        PlayerModel<AbstractClientPlayer> model = (PlayerModel<AbstractClientPlayer>) this.getParentModel();
        for (LimbType type : LimbType.values()) {
            if (snap.getState(type) != LimbState.REVERSING) continue;
            float progress = snap.getRegenProgress(type);
            if (progress <= 0f || progress >= 1.0f) continue;
            ModelPart part    = getModelPart(model, type);
            ModelPart overlay = getOverlayPart(model, type);
            // ── FASE 1: HUESO (0 → 0.25 reveal; 0.25 → BONE_COLOR_END cambio de color) ──
            {
                float sub = Math.min(1f, progress / PHASE_BONE);
                float colorSub = progress <= PHASE_BONE ? 0f :
                    Math.min(1f, (progress - PHASE_BONE) / (BONE_COLOR_END - PHASE_BONE));
                VertexConsumer bVc = buf.getBuffer(RenderType.entityCutoutNoCull(getOrCreateBoneTexture()));
                ps.pushPose();
                part.translateAndRotate(ps);
                renderBoneReveal(type, ps.last(), bVc, light, sub, colorSub);
                ps.popPose();
            }
            // ── FASE 2: CARNE (0.25 → 0.75) ──────────────────────────────────────────────
            if (progress > PHASE_BONE) {
                float sub = Math.min(1f, (progress - PHASE_BONE) / (PHASE_FLESH - PHASE_BONE));
                VertexConsumer fVc = buf.getBuffer(RenderType.entityCutoutNoCull(getOrCreateFleshTexture()));
                boolean isLeg = (type == LimbType.LEFT_LEG || type == LimbType.RIGHT_LEG);
                ps.pushPose();
                part.translateAndRotate(ps);
                if (isLeg) ps.scale(0.90f, 1.0f, 0.90f);
                LimbRenderHandler.ensureModelReflect();
                revealModelPartTiled(part, ps.last(), fVc, light, sub, 8f, isLeg);
                ps.pushPose();
                ps.scale(isLeg ? 0.78f : 0.78f, 1.0f, isLeg ? 0.78f : 0.78f);
                revealModelPartTiled(part, ps.last(), fVc, light, sub, 8f, isLeg);
                ps.popPose();
                ps.popPose();
            }
            // ── FASE 3: SKIN (0.75 → 1.0) ────────────────────────────────────────────────
            if (progress >= PHASE_FLESH) {
                float sub = (progress - PHASE_FLESH) / (1.0f - PHASE_FLESH);
                if (sub > 0f) {
                    ResourceLocation skinTex = entity.getSkinTextureLocation();
                    VertexConsumer sVc = buf.getBuffer(RenderType.entityCutoutNoCull(skinTex));
                    ps.pushPose();
                    part.translateAndRotate(ps);
                    ps.scale(SKIN_SCALE, SKIN_SCALE, SKIN_SCALE);
                    boolean isLegSkin = (type == LimbType.LEFT_LEG || type == LimbType.RIGHT_LEG);
                    revealModelPart(part, ps.last(), sVc, light, sub, isLegSkin);
                    ps.popPose();
                    if (overlay != null) {
                        ps.pushPose();
                        overlay.translateAndRotate(ps);
                        ps.scale(SKIN_SCALE, SKIN_SCALE, SKIN_SCALE);
                        revealModelPart(overlay, ps.last(), sVc, light, sub, isLegSkin);
                        ps.popPose();
                    }
                }
            }
        }
    }
    // ── Pixel reveal para ModelPart (skin y carne) ────────────────────────
    static void revealModelPart(ModelPart part, PoseStack.Pose pose,
                                 VertexConsumer vc, int light, float sub, boolean useYShift) {
        LimbRenderHandler.ensureModelReflect();
        for (ModelPart.Cube cube : getCubes(part)) {
            Object[] polys = getPolygons(cube);
            if (polys.length == 0) continue;
            float yMin = Float.MAX_VALUE, yMax = -Float.MAX_VALUE;
            for (Object p : polys)
                for (Object v : getVertices(p)) { float y = getPos(v).y(); if(y<yMin)yMin=y; if(y>yMax)yMax=y; }
            float yRange = Math.max(0.001f, yMax - yMin);
            for (Object poly : polys) {
                Object[] verts = getVertices(poly);
                if (verts.length != 4) continue;
                Vector3f normal = getNormal(poly);
                float yShift = useYShift && Math.abs(normal.y()) > 0.5f ? normal.y() * 0.1f : 0f;
                Vector3f[] pos = new Vector3f[4]; float[] us = new float[4], vs = new float[4];
                for (int i = 0; i < 4; i++) { pos[i]=getPos(verts[i]); us[i]=getU(verts[i]); vs[i]=getV(verts[i]); }
                float uMin=mn(us), uMax=mx(us), vMin=mn(vs), vMax=mx(vs);
                float w3d = pos[0].distance(pos[1]);
                float h3d = pos[1].distance(pos[2]);
                int nU=Math.max(1,Math.round((w3d/16f)*TEX_SIZE));
                int nV=Math.max(1,Math.round((h3d/16f)*TEX_SIZE));
                float stU=(uMax-uMin)/nU, stV=(vMax-vMin)/nV;
                for (int pi=0; pi<nU; pi++) for (int pj=0; pj<nV; pj++) {
                    float u0=uMin+pi*stU, u1=u0+stU, v0=vMin+pj*stV, v1=v0+stV;
                    float uC=(u0+u1)*.5f, vC=(v0+v1)*.5f;
                    Vector3f c = blerp(pos, us, vs, uC, vC, uMin, uMax, vMin, vMax);
                    float yN  = Math.max(0f, Math.min(1f, (c.y()-yMin)/yRange));
                    float noise = (noise8(pi, pj)+1f)*.5f;
                    if (sub <= yN*.82f + noise*.18f) continue;
                    Vector3f c00=blerp(pos,us,vs,u0,v0,uMin,uMax,vMin,vMax);
                    Vector3f c10=blerp(pos,us,vs,u1,v0,uMin,uMax,vMin,vMax);
                    Vector3f c11=blerp(pos,us,vs,u1,v1,uMin,uMax,vMin,vMax);
                    Vector3f c01=blerp(pos,us,vs,u0,v1,uMin,uMax,vMin,vMax);
                    pxl(pose,vc,c00,u0,v0,normal,light,yShift); pxl(pose,vc,c10,u1,v0,normal,light,yShift);
                    pxl(pose,vc,c11,u1,v1,normal,light,yShift); pxl(pose,vc,c01,u0,v1,normal,light,yShift);
                }
            }
        }
    }
    static void revealModelPartTiled(ModelPart part, PoseStack.Pose pose,
                                       VertexConsumer vc, int light, float sub, float uvTile, boolean useYShift) {
        LimbRenderHandler.ensureModelReflect();
        for (ModelPart.Cube cube : getCubes(part)) {
            Object[] polys = getPolygons(cube);
            if (polys.length == 0) continue;
            float yMin = Float.MAX_VALUE, yMax = -Float.MAX_VALUE;
            for (Object p : polys)
                for (Object v : getVertices(p)) { float y=getPos(v).y(); if(y<yMin)yMin=y; if(y>yMax)yMax=y; }
            float yRange = Math.max(0.001f, yMax - yMin);
            for (Object poly : polys) {
                Object[] verts = getVertices(poly);
                if (verts.length != 4) continue;
                Vector3f normal = getNormal(poly);
                float yShift = useYShift && Math.abs(normal.y()) > 0.5f ? normal.y() * 0.1f : 0f;
                Vector3f[] pos = new Vector3f[4]; float[] us = new float[4], vs = new float[4];
                for (int i=0;i<4;i++){pos[i]=getPos(verts[i]);us[i]=getU(verts[i]);vs[i]=getV(verts[i]);}
                float uMin=mn(us),uMax=mx(us),vMin=mn(vs),vMax=mx(vs);
                float uSpan=Math.max(0.0001f,uMax-uMin), vSpan=Math.max(0.0001f,vMax-vMin);
                float w3d=pos[0].distance(pos[1]), h3d=pos[1].distance(pos[2]);
                int nU=Math.max(1,Math.round((w3d/16f)*TEX_SIZE));
                int nV=Math.max(1,Math.round((h3d/16f)*TEX_SIZE));
                float stU=uSpan/nU, stV=vSpan/nV;
                for (int pi=0;pi<nU;pi++) for (int pj=0;pj<nV;pj++) {
                    float u0=uMin+pi*stU,u1=u0+stU,v0=vMin+pj*stV,v1=v0+stV;
                    float uC=(u0+u1)*.5f, vC=(v0+v1)*.5f;
                    Vector3f c = blerp(pos,us,vs,uC,vC,uMin,uMax,vMin,vMax);
                    float yN = Math.max(0f,Math.min(1f,(c.y()-yMin)/yRange));
                    float noise = (noise8(pi,pj)+1f)*.5f;
                    if (sub <= yN*.82f+noise*.18f) continue;
                    float u0t=(float)pi/nU*(w3d/16f),     u1t=(float)(pi+1)/nU*(w3d/16f);
                    float v0t=(float)pj/nV*(h3d/16f),     v1t=(float)(pj+1)/nV*(h3d/16f);
                    Vector3f c00=blerp(pos,us,vs,u0,v0,uMin,uMax,vMin,vMax);
                    Vector3f c10=blerp(pos,us,vs,u1,v0,uMin,uMax,vMin,vMax);
                    Vector3f c11=blerp(pos,us,vs,u1,v1,uMin,uMax,vMin,vMax);
                    Vector3f c01=blerp(pos,us,vs,u0,v1,uMin,uMax,vMin,vMax);
                    pxl(pose,vc,c00,u0t,v0t,normal,light,yShift); pxl(pose,vc,c10,u1t,v0t,normal,light,yShift);
                    pxl(pose,vc,c11,u1t,v1t,normal,light,yShift); pxl(pose,vc,c01,u0t,v1t,normal,light,yShift);
                }
            }
        }
    }
    private static float mn(float[] a){return Math.min(Math.min(a[0],a[1]),Math.min(a[2],a[3]));}
    private static float mx(float[] a){return Math.max(Math.max(a[0],a[1]),Math.max(a[2],a[3]));}
    private static Vector3f blerp(Vector3f[] pos, float[] us, float[] vs,
                                   float tu, float tv,
                                   float uMin, float uMax, float vMin, float vMax) {
        float uM=(uMin+uMax)*.5f, vM=(vMin+vMax)*.5f;
        Vector3f tl=pos[0],tr=pos[0],bl=pos[0],br=pos[0];
        for (int i=0;i<4;i++){
            boolean L=us[i]<=uM, T=vs[i]<=vM;
            if(L&&T)tl=pos[i]; if(!L&&T)tr=pos[i]; if(L&&!T)bl=pos[i]; if(!L&&!T)br=pos[i];
        }
        float s=(uMax>uMin)?(tu-uMin)/(uMax-uMin):.5f, t=(vMax>vMin)?(tv-vMin)/(vMax-vMin):.5f;
        float is=1f-s, it=1f-t;
        return new Vector3f(tl.x()*is*it+tr.x()*s*it+br.x()*s*t+bl.x()*is*t,
                            tl.y()*is*it+tr.y()*s*it+br.y()*s*t+bl.y()*is*t,
                            tl.z()*is*it+tr.z()*s*it+br.z()*s*t+bl.z()*is*t);
    }
    private static void pxl(PoseStack.Pose pose, VertexConsumer vc,
                              Vector3f p, float u, float v, Vector3f n, int light, float yShift) {
        vc.vertex(pose.pose(), p.x()*PIXEL_SCALE, (p.y()+yShift)*PIXEL_SCALE, p.z()*PIXEL_SCALE)
          .color(1f,1f,1f,1f).uv(u,v).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light)
          .normal(pose.normal(), n.x(), n.y(), n.z()).endVertex();
    }
    private static void pxl(PoseStack.Pose pose, VertexConsumer vc,
                              Vector3f p, float u, float v, Vector3f n, int light) {
        pxl(pose, vc, p, u, v, n, light, 0f);
    }
    // ── Reveal de hueso (geometría custom) ───────────────────────────────
    private static float noise8(int cx, int cy) {
        int h = cx*374761393 ^ cy*1234567891; h^=(h>>>13); h*=1540483477; h^=(h>>>15);
        return (h & 0xFFFF) / 32767.5f - 1f;
    }
    private static float[][] getBoneCubes(LimbType t) {
        return switch (t) {
            case RIGHT_ARM           -> RIGHT_ARM_BONE;
            case LEFT_ARM            -> LEFT_ARM_BONE;
            case RIGHT_LEG, LEFT_LEG -> LEG_BONE;
            case HEAD                -> HEAD_BONE;
        };
    }
    private static float[] getFleshBox(LimbType t) {
        return switch (t) {
            case LEFT_ARM, RIGHT_ARM -> new float[]{-2f, -2f, -2f, 4f, 12f, 4f};
            case LEFT_LEG, RIGHT_LEG -> new float[]{-2f,  0f, -2f, 4f, 12f, 4f};
            case HEAD                -> new float[]{-4f, -8f, -4f, 8f,  8f, 8f};
        };
    }
    private static void renderFleshReveal(LimbType type, PoseStack.Pose pose,
                                           VertexConsumer vc, int light, float sub) {
        float[] arm = getFleshBox(type);
        float x0=arm[0],y0=arm[1],z0=arm[2],w=arm[3],h=arm[4],d=arm[5];
        boneCube(arm, pose, vc, light, sub, y0, h);
        int nY = Math.round(h);
        float sy = h / nY;
        for (int i = 0; i < nY; i++) {
            float yC = y0 + (i + 0.5f) * sy;
            float yN = Math.max(0f, Math.min(1f, (yC - y0) / h));
            float noise = (noise8(i, 17) + 1f) * 0.5f;
            if (sub <= yN * 0.82f + noise * 0.18f) continue;
            float y = yC;
            float u1 = w / 16f, v1 = d / 16f;
            bQ(pose,vc, x0,y,z0,  x0+w,y,z0,  x0+w,y,z0+d, x0,y,z0+d,
               0f,0f,u1,v1, 0f,1f,0f, light);
            bQ(pose,vc, x0+w,y,z0, x0,y,z0, x0,y,z0+d, x0+w,y,z0+d,
               0f,0f,u1,v1, 0f,-1f,0f, light);
        }
    }
    private static void renderFleshSolidFill(LimbType type, PoseStack.Pose pose,
                                              VertexConsumer vc, int light, float sub) {
        float[] arm = getFleshBox(type);
        float x0=arm[0], y0=arm[1], z0=arm[2], w=arm[3], h=arm[4], d=arm[5];
        int nY = Math.round(h);
        float sy = h / nY;
        float u1=w/16f, v1=d/16f;
        for (int i = 0; i < nY; i++) {
            float yC = y0 + (i + 0.5f) * sy;
            float yN = Math.max(0f, Math.min(1f, (yC - y0) / h));
            float noise = (noise8(i, 17) + 1f) * 0.5f;
            if (sub <= yN * 0.82f + noise * 0.18f) continue;
            float y = yC;
            bQ(pose,vc, x0,y,z0,   x0+w,y,z0,   x0+w,y,z0+d, x0,y,z0+d,   0f,0f,u1,v1, 0f, 1f,0f,light);
            bQ(pose,vc, x0+w,y,z0, x0,y,z0,     x0,y,z0+d,   x0+w,y,z0+d, 0f,0f,u1,v1, 0f,-1f,0f,light);
        }
    }
    private static void renderBoneReveal(LimbType type, PoseStack.Pose pose,
                                          VertexConsumer vc, int light, float sub, float colorSub) {
        float[][] defs = getBoneCubes(type);
        float gYMin=Float.MAX_VALUE, gYMax=-Float.MAX_VALUE;
        for (float[] b : defs) { if(b[1]<gYMin)gYMin=b[1]; if(b[1]+b[4]>gYMax)gYMax=b[1]+b[4]; }
        float yR = Math.max(0.001f, gYMax-gYMin);
        for (float[] b : defs) boneCube(b, pose, vc, light, sub, gYMin, yR, colorSub);
    }
    private static float[] boneColor(float yC, float gYMin, float yR, int pi, int pj, float colorSub) {
        if (colorSub <= 0f) return new float[]{1f,1f,1f};
        float yN = Math.max(0f,Math.min(1f,(yC-gYMin)/yR));
        float cn = (noise8(pi+37,pj+53)+1f)*0.5f;
        boolean red = colorSub > yN*0.82f+cn*0.18f;
        return red ? new float[]{1f,0f,0f} : new float[]{1f,1f,1f};
    }
    private static void boneCube(float[] b, PoseStack.Pose pose, VertexConsumer vc,
                                  int light, float sub, float gYMin, float yR, float colorSub) {
        float ox=b[0],oy=b[1],oz=b[2],w=b[3],h=b[4],d=b[5];
        int nW=Math.max(1,Math.round((w/16f)*TEX_SIZE));
        int nH=Math.max(1,Math.round((h/16f)*TEX_SIZE));
        int nD=Math.max(1,Math.round((d/16f)*TEX_SIZE));
        float sW=w/nW,sH=h/nH,sD=d/nD, uW=(w/16f)/nW,uH=(h/16f)/nH,uD=(d/16f)/nD;
        for(int pi=0;pi<nW;pi++)for(int pj=0;pj<nH;pj++){
            float x0=ox+pi*sW,x1=x0+sW,y0=oy+pj*sH,y1=y0+sH;
            if(!bShow((y0+y1)*.5f,gYMin,yR,pi,pj,sub))continue;
            float u0=pi*uW,v0=pj*uH; float[]c=boneColor((y0+y1)*.5f,gYMin,yR,pi,pj,colorSub); bQ(pose,vc,x0,y0,oz+d,x1,y0,oz+d,x1,y1,oz+d,x0,y1,oz+d,u0,v0,u0+uW,v0+uH,0,0,1,light,c[0],c[1],c[2]);}
        for(int pi=0;pi<nW;pi++)for(int pj=0;pj<nH;pj++){
            float x0=ox+pi*sW,x1=x0+sW,y0=oy+pj*sH,y1=y0+sH;
            if(!bShow((y0+y1)*.5f,gYMin,yR,pi,pj,sub))continue;
            float u0=pi*uW,v0=pj*uH; float[]c=boneColor((y0+y1)*.5f,gYMin,yR,pi,pj,colorSub); bQ(pose,vc,x1,y0,oz,x0,y0,oz,x0,y1,oz,x1,y1,oz,u0,v0,u0+uW,v0+uH,0,0,-1,light,c[0],c[1],c[2]);}
        for(int pi=0;pi<nD;pi++)for(int pj=0;pj<nH;pj++){
            float z0=oz+pi*sD,z1=z0+sD,y0=oy+pj*sH,y1=y0+sH;
            if(!bShow((y0+y1)*.5f,gYMin,yR,pi,pj,sub))continue;
            float u0=pi*uD,v0=pj*uH; float[]c=boneColor((y0+y1)*.5f,gYMin,yR,pi,pj,colorSub); bQ(pose,vc,ox,y0,z1,ox,y0,z0,ox,y1,z0,ox,y1,z1,u0,v0,u0+uD,v0+uH,-1,0,0,light,c[0],c[1],c[2]);}
        for(int pi=0;pi<nD;pi++)for(int pj=0;pj<nH;pj++){
            float z0=oz+pi*sD,z1=z0+sD,y0=oy+pj*sH,y1=y0+sH;
            if(!bShow((y0+y1)*.5f,gYMin,yR,pi,pj,sub))continue;
            float u0=pi*uD,v0=pj*uH; float[]c=boneColor((y0+y1)*.5f,gYMin,yR,pi,pj,colorSub); bQ(pose,vc,ox+w,y0,z0,ox+w,y0,z1,ox+w,y1,z1,ox+w,y1,z0,u0,v0,u0+uD,v0+uH,1,0,0,light,c[0],c[1],c[2]);}
        for(int pi=0;pi<nW;pi++)for(int pj=0;pj<nD;pj++){
            float x0=ox+pi*sW,x1=x0+sW,z0=oz+pj*sD,z1=z0+sD;
            if(!bShow(oy,gYMin,yR,pi,pj,sub))continue;
            float u0=pi*uW,v0=pj*uD; float[]c=boneColor(oy,gYMin,yR,pi,pj,colorSub); bQ(pose,vc,x0,oy,z0,x1,oy,z0,x1,oy,z1,x0,oy,z1,u0,v0,u0+uW,v0+uD,0,-1,0,light,c[0],c[1],c[2]);}
        for(int pi=0;pi<nW;pi++)for(int pj=0;pj<nD;pj++){
            float x0=ox+pi*sW,x1=x0+sW,z0=oz+pj*sD,z1=z0+sD;
            if(!bShow(oy+h,gYMin,yR,pi,pj,sub))continue;
            float u0=pi*uW,v0=pj*uD; float[]c=boneColor(oy+h,gYMin,yR,pi,pj,colorSub); bQ(pose,vc,x0,oy+h,z1,x1,oy+h,z1,x1,oy+h,z0,x0,oy+h,z0,u0,v0,u0+uW,v0+uD,0,1,0,light,c[0],c[1],c[2]);}
    }
    private static void boneCube(float[] b, PoseStack.Pose pose, VertexConsumer vc,
                                  int light, float sub, float gYMin, float yR) {
        boneCube(b, pose, vc, light, sub, gYMin, yR, 0f);
    }
    private static boolean bShow(float yC, float gYMin, float yR, int pi, int pj, float sub) {
        float yN = Math.max(0f,Math.min(1f,(yC-gYMin)/yR));
        float noise = (noise8(pi,pj)+1f)*.5f;
        return sub > yN*.82f + noise*.18f;
    }
    private static void bQ(PoseStack.Pose pose, VertexConsumer vc,
                            float x0,float y0,float z0, float x1,float y1,float z1,
                            float x2,float y2,float z2, float x3,float y3,float z3,
                            float u0,float v0, float u1,float v1,
                            float nx,float ny,float nz, int light,
                            float r,float g,float b) {
        bV(pose,vc,x0,y0,z0,u0,v0,nx,ny,nz,light,r,g,b); bV(pose,vc,x1,y1,z1,u1,v0,nx,ny,nz,light,r,g,b);
        bV(pose,vc,x2,y2,z2,u1,v1,nx,ny,nz,light,r,g,b); bV(pose,vc,x3,y3,z3,u0,v1,nx,ny,nz,light,r,g,b);
    }
    private static void bQ(PoseStack.Pose pose, VertexConsumer vc,
                            float x0,float y0,float z0, float x1,float y1,float z1,
                            float x2,float y2,float z2, float x3,float y3,float z3,
                            float u0,float v0, float u1,float v1,
                            float nx,float ny,float nz, int light) {
        bQ(pose,vc,x0,y0,z0,x1,y1,z1,x2,y2,z2,x3,y3,z3,u0,v0,u1,v1,nx,ny,nz,light,1f,1f,1f);
    }
    private static void bV(PoseStack.Pose pose, VertexConsumer vc,
                            float x,float y,float z,float u,float v,
                            float nx,float ny,float nz,int light,
                            float r,float g,float b) {
        vc.vertex(pose.pose(),x*PIXEL_SCALE,y*PIXEL_SCALE,z*PIXEL_SCALE)
          .color(r,g,b,1f).uv(u,v).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light)
          .normal(pose.normal(),nx,ny,nz).endVertex();
    }
    private static void bV(PoseStack.Pose pose, VertexConsumer vc,
                            float x,float y,float z,float u,float v,
                            float nx,float ny,float nz,int light) {
        bV(pose,vc,x,y,z,u,v,nx,ny,nz,light,1f,1f,1f);
    }
    // ── Primera persona ───────────────────────────────────────────────────
    public static void renderForFirstPerson(ModelPart armPart, ModelPart overlayPart,
                                      PoseStack ps, MultiBufferSource buf, int light,
                                      AbstractClientPlayer entity, LimbType type, float progress) {
        if (progress <= 0f || progress >= 1.0f) return;
        LimbRenderHandler.ensureModelReflect();
        armPart.xRot = 0.0f;
        {
            float sub = Math.min(1f, progress / PHASE_BONE);
            float colorSub = progress <= PHASE_BONE ? 0f
                : Math.min(1f, (progress - PHASE_BONE) / (BONE_COLOR_END - PHASE_BONE));
            VertexConsumer bVc = buf.getBuffer(RenderType.entityCutoutNoCull(getOrCreateBoneTexture()));
            ps.pushPose();
            armPart.translateAndRotate(ps);
            renderBoneReveal(type, ps.last(), bVc, light, sub, colorSub);
            ps.popPose();
        }
        if (progress > PHASE_BONE) {
            float sub = Math.min(1f, (progress - PHASE_BONE) / (PHASE_FLESH - PHASE_BONE));
            VertexConsumer fVc = buf.getBuffer(RenderType.entityCutoutNoCull(getOrCreateFleshTexture()));
            boolean isLeg = (type == LimbType.LEFT_LEG || type == LimbType.RIGHT_LEG);
            ps.pushPose();
            armPart.translateAndRotate(ps);
            if (isLeg) ps.scale(0.90f, 1.0f, 0.90f);
            revealModelPartTiled(armPart, ps.last(), fVc, light, sub, 8f, isLeg);
            ps.pushPose();
            ps.scale(0.78f, 1.0f, 0.78f);
            revealModelPartTiled(armPart, ps.last(), fVc, light, sub, 8f, isLeg);
            ps.popPose();
            ps.popPose();
        }
        if (progress >= PHASE_FLESH) {
            float sub = (progress - PHASE_FLESH) / (1.0f - PHASE_FLESH);
            if (sub > 0f) {
                ResourceLocation skinTex = entity.getSkinTextureLocation();
                VertexConsumer sVc = buf.getBuffer(RenderType.entityCutoutNoCull(skinTex));
                boolean isLegSkin = (type == LimbType.LEFT_LEG || type == LimbType.RIGHT_LEG);
                ps.pushPose();
                armPart.translateAndRotate(ps);
                ps.scale(SKIN_SCALE, SKIN_SCALE, SKIN_SCALE);
                revealModelPart(armPart, ps.last(), sVc, light, sub, isLegSkin);
                ps.popPose();
                if (overlayPart != null) {
                    ps.pushPose();
                    overlayPart.translateAndRotate(ps);
                    ps.scale(SKIN_SCALE, SKIN_SCALE, SKIN_SCALE);
                    revealModelPart(overlayPart, ps.last(), sVc, light, sub, isLegSkin);
                    ps.popPose();
                }
            }
        }
    }
    private static ModelPart getModelPart(PlayerModel<?> m, LimbType t){
        return switch(t){case LEFT_ARM->m.leftArm;case RIGHT_ARM->m.rightArm;
            case LEFT_LEG->m.leftLeg;case RIGHT_LEG->m.rightLeg;case HEAD->m.head;};}
    private static ModelPart getOverlayPart(PlayerModel<?> m, LimbType t){
        return switch(t){case LEFT_ARM->m.leftSleeve;case RIGHT_ARM->m.rightSleeve;
            case LEFT_LEG->m.leftPants;case RIGHT_LEG->m.rightPants;case HEAD->null;};}
    // ── Texturas procedurales ─────────────────────────────────────────────
    private static ResourceLocation getOrCreateBoneTexture() {
        if (boneTex==null){boneTex=new ResourceLocation("jjkblueredpurple","dynamic/bone");
            NativeImage img=new NativeImage(NativeImage.Format.RGBA,16,16,false);
            Random r=new Random(45214L);
            for(int y=0;y<16;y++)for(int x=0;x<16;x++){
                int b=210+r.nextInt(30),g=b-5-r.nextInt(10),bl=b-20-r.nextInt(15);
                if(r.nextInt(8)==0||y%5==0&&r.nextInt(3)==0){b-=50+r.nextInt(30);g-=40;bl-=30;}
                if(x%4==0&&r.nextInt(4)==0){b-=25;g-=20;}
                img.setPixelRGBA(x,y,pk(255,clamp(b),clamp(g),clamp(bl)));}
            Minecraft.getInstance().getTextureManager().register(boneTex,(AbstractTexture)new DynamicTexture(img));}
        return boneTex;
    }
    private static ResourceLocation getOrCreateFleshTexture() {
        if (fleshTex==null){fleshTex=new ResourceLocation("jjkblueredpurple","dynamic/flesh");
            NativeImage img=new NativeImage(NativeImage.Format.RGBA,16,16,false);
            Random r=new Random(61925L);
            for(int y=0;y<16;y++)for(int x=0;x<16;x++){
                int rr=185+r.nextInt(25),g=80+r.nextInt(30),b=75+r.nextInt(25);
                double d=Math.sqrt(Math.pow((x-8)+r.nextGaussian()*2,2)+Math.pow((y-8)+r.nextGaussian()*2,2));
                if(d<3+r.nextDouble()*2){rr-=25;g-=10;}
                if(r.nextInt(12)==0){rr=160+r.nextInt(20);g=20+r.nextInt(15);b=20+r.nextInt(15);}
                if((x+y)%5==0&&r.nextInt(2)==0){rr-=10;g+=5;b+=5;}
                img.setPixelRGBA(x,y,pk(255,clamp(rr),clamp(g),clamp(b)));}
            Minecraft.getInstance().getTextureManager().register(fleshTex,(AbstractTexture)new DynamicTexture(img));}
        return fleshTex;
    }
    private static int pk(int a,int r,int g,int b){return(a&0xFF)<<24|(b&0xFF)<<16|(g&0xFF)<<8|r&0xFF;}
    private static int clamp(int v){return Math.max(0,Math.min(255,v));}
}
