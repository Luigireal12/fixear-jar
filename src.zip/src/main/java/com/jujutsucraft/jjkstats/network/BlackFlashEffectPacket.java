package com.jujutsucraft.jjkstats.network;

import com.jujutsucraft.jjkstats.client.BlackFlashClientHandler;
import com.jujutsucraft.jjkstats.config.StatsConfig;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Paquete servidor → cliente para activar la vibración del título de Black Flash.
 */
public class BlackFlashEffectPacket {

    private final int intensity;
    private final int durationTicks;
    private final int frequency;

    public BlackFlashEffectPacket() {
        this.intensity     = StatsConfig.BLACK_FLASH_SHAKE_INTENSITY.get();
        this.durationTicks = StatsConfig.BLACK_FLASH_SHAKE_DURATION.get();
        this.frequency     = StatsConfig.BLACK_FLASH_SHAKE_FREQUENCY.get();
    }

    public BlackFlashEffectPacket(FriendlyByteBuf buf) {
        this.intensity     = buf.readInt();
        this.durationTicks = buf.readInt();
        this.frequency     = buf.readInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(intensity);
        buf.writeInt(durationTicks);
        buf.writeInt(frequency);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                BlackFlashClientHandler.activateShake(intensity, durationTicks, frequency)
            )
        );
        ctx.get().setPacketHandled(true);
    }
}
