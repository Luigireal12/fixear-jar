package com.jujutsucraft.jjkstats.network;

import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Clase auxiliar que agrupa TODA la lógica de paquetes que toca clases
 * exclusivas del cliente (Minecraft, LocalPlayer, ClientLevel, etc.).
 *
 * Al estar en un archivo separado, la JVM del servidor nunca la carga durante
 * la fase de verificación de StatsNetwork, eliminando el
 * NoClassDefFoundError: net/minecraft/client/player/LocalPlayer.
 *
 * Los métodos se invocan desde StatsNetwork únicamente a través de:
 *   DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandlers.handleXxx(...))
 * lo que garantiza que la clase no se referencia en el servidor.
 */
@OnlyIn(Dist.CLIENT)
public final class ClientPacketHandlers {

    private ClientPacketHandlers() {}

    // ── SyncStatsPacket ──────────────────────────────────────────────────────

    public static void handleSyncStats(StatsNetwork.SyncStatsPacket msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        PlayerStatsCapability.get(mc.player).ifPresent(stats -> {
            stats.strengthLevel     = msg.strengthLevel;
            stats.resistanceLevel   = msg.resistanceLevel;
            stats.speedLevel        = msg.speedLevel;
            stats.cursedEnergyLevel = msg.cursedEnergyLevel;
            stats.healthLevel       = msg.healthLevel;
            stats.statPoints        = msg.statPoints;
            stats.currentExp        = msg.currentExp;
            stats.expToNextFill     = msg.expToNextFill;
            stats.fillCount         = msg.fillCount;
            stats.hudX              = msg.hudX;
            stats.hudY              = msg.hudY;
            stats.playerLevel       = msg.playerLevel;
            stats.blackFlashMasteryPercent    = msg.blackFlashMasteryPercent;
            stats.blackFlashMasteryCapPercent = msg.blackFlashMasteryCapPercent;
            stats.outputPercent     = msg.outputPercent;
            stats.turboActive       = msg.turboActive;
            stats.output120Active   = msg.output120Active;
            stats.output120ProgressCount    = msg.output120ProgressCount;
            stats.output120ProgressRequired = msg.output120ProgressRequired;
        });
    }

    // ── AuraParticlePacket ───────────────────────────────────────────────────

    public static void handleAuraParticle(StatsNetwork.AuraParticlePacket msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;

        boolean isOwner = mc.player != null && mc.player.getUUID().equals(msg.ownerId);
        boolean ownerInFirstPerson = isOwner && mc.options.getCameraType().isFirstPerson();
        if (ownerInFirstPerson) return;

        net.minecraft.core.particles.ParticleOptions options = resolveParticle(msg.colorId);

        java.util.Random rnd = new java.util.Random();
        for (int i = 0; i < Math.max(1, msg.count); i++) {
            double ox = (rnd.nextDouble() - 0.5) * msg.spreadXZ * 2;
            double oy = (rnd.nextDouble() - 0.5) * msg.spreadY  * 2;
            double oz = (rnd.nextDouble() - 0.5) * msg.spreadXZ * 2;
            mc.level.addParticle(options, msg.x + ox, msg.y + oy, msg.z + oz, 0.0, 0.02, 0.0);
        }
    }

    private static net.minecraft.core.particles.ParticleOptions resolveParticle(int colorId) {
        return switch (colorId) {
            case 1  -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_CURSE_POWER_BLUE.get();
            case 2  -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_CURSE_POWER_ORANGE.get();
            case 3  -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_CURSE_POWER_RED.get();
            case 4  -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_CURSE_POWER_GREEN.get();
            case 5  -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_CURSE_POWER_PURPLE.get();
            case 6  -> jjkblueredpurpleV("particle_curse_power_yellow");
            case 7  -> jjkblueredpurpleV("particle_curse_power_deep_red");
            case 8  -> jjkblueredpurpleV("particle_curse_power_deep_blue");
            case 9  -> jjkblueredpurpleV("particle_curse_power_deep_green");
            case 10 -> jjkblueredpurpleV("particle_curse_power_black");
            case 11 -> jjkblueredpurpleV("particle_curse_power_white");
            case 12 -> jjkblueredpurpleV("particle_curse_power_rainbow");
            case 13 -> jjkblueredpurpleV("particle_thunder_red");
            case 14 -> jjkblueredpurpleV("particle_curse_power_orange_to_purple");
            case 15 -> (new java.util.Random().nextInt(5) + 1) <= 2
                ? net.minecraft.core.particles.ParticleTypes.FLAME
                : jjkblueredpurpleV("particle_curse_power_black");
            case 16 -> jjkblueredpurpleV("particle_zawazawa");
            case 17 -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_THUNDER_BLUE.get();
            case 18 -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_WATER_2.get();
            case 19 -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_ICE.get();
            case 20 -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_MAGMA.get();
            case 21 -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_BLOOD_RED.get();
            case 22 -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_COCKROACH.get();
            case 23 -> net.minecraft.core.particles.ParticleTypes.FLAME;
            case 24 -> net.minecraft.core.particles.ParticleTypes.FLAME;
            case 25 -> jjkblueredpurpleV("particle_rice");
            case 26 -> jjkblueredpurpleV("particle_light_medium");
            case 27 -> net.mcreator.jujutsucraft.init.JujutsucraftModParticleTypes.PARTICLE_FLOWER.get();
            default -> net.minecraft.core.particles.ParticleTypes.FLAME;
        };
    }

    private static net.minecraft.core.particles.ParticleOptions jjkblueredpurpleV(String registryName) {
        var particleType = net.minecraftforge.registries.ForgeRegistries.PARTICLE_TYPES.getValue(
            new net.minecraft.resources.ResourceLocation("jujutsucraftv", registryName)
        );
        return particleType instanceof net.minecraft.core.particles.ParticleOptions options
            ? options
            : net.minecraft.core.particles.ParticleTypes.FLAME;
    }
}
