package com.jujutsucraft.jjkstats.network;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability.PlayerStats;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability.StatType;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public class StatsNetwork {

    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(JJKStatsMod.MOD_ID, "main"),
        () -> PROTOCOL,
        PROTOCOL::equals,
        PROTOCOL::equals
    );

    private static int id = 0;

    public static void register() {
        CHANNEL.messageBuilder(SyncStatsPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
            .encoder(SyncStatsPacket::encode)
            .decoder(SyncStatsPacket::new)
            .consumerMainThread((msg, ctx) -> msg.handle(ctx))
            .add();

        CHANNEL.messageBuilder(UpgradeStatPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
            .encoder(UpgradeStatPacket::encode)
            .decoder(UpgradeStatPacket::new)
            .consumerMainThread((msg, ctx) -> msg.handle(ctx))
            .add();

        CHANNEL.messageBuilder(SaveHudPositionPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
            .encoder(SaveHudPositionPacket::encode)
            .decoder(SaveHudPositionPacket::new)
            .consumerMainThread((msg, ctx) -> msg.handle(ctx))
            .add();

        CHANNEL.messageBuilder(com.jujutsucraft.jjkstats.network.BlackFlashEffectPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
            .encoder(com.jujutsucraft.jjkstats.network.BlackFlashEffectPacket::encode)
            .decoder(com.jujutsucraft.jjkstats.network.BlackFlashEffectPacket::new)
            .consumerMainThread((msg, ctx) -> msg.handle(ctx))
            .add();

        CHANNEL.messageBuilder(OutputChargePacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
            .encoder(OutputChargePacket::encode)
            .decoder(OutputChargePacket::new)
            .consumerMainThread((msg, ctx) -> msg.handle(ctx))
            .add();

        CHANNEL.messageBuilder(TurboTogglePacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
            .encoder(TurboTogglePacket::encode)
            .decoder(TurboTogglePacket::new)
            .consumerMainThread((msg, ctx) -> msg.handle(ctx))
            .add();

        CHANNEL.messageBuilder(SaveOutputHudPositionPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
            .encoder(SaveOutputHudPositionPacket::encode)
            .decoder(SaveOutputHudPositionPacket::new)
            .consumerMainThread((msg, ctx) -> msg.handle(ctx))
            .add();

        CHANNEL.messageBuilder(AuraParticlePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
            .encoder(AuraParticlePacket::encode)
            .decoder(AuraParticlePacket::new)
            .consumerMainThread((msg, ctx) -> msg.handle(ctx))
            .add();
    }

    public static void sendBlackFlashEffect(ServerPlayer player) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new com.jujutsucraft.jjkstats.network.BlackFlashEffectPacket());
    }

    public static void syncToClient(ServerPlayer player) {
        PlayerStatsCapability.get(player).ifPresent(stats -> {
            var mastery = com.jujutsucraft.jjkstats.mastery.JoquMasteryReader.readFor(player);
            CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new SyncStatsPacket(player, stats, mastery));
        });
    }

    // ── SyncStatsPacket ──────────────────────────────────────────────────────
    public static class SyncStatsPacket {
        public int strengthLevel, resistanceLevel, speedLevel, cursedEnergyLevel, healthLevel;
        public int statPoints;
        public long currentExp, expToNextFill;
        public int fillCount;
        public int hudX, hudY;
        public double playerLevel;
        public double blackFlashMasteryPercent;
        public double blackFlashMasteryCapPercent;
        public int outputPercent;
        public boolean turboActive;
        public boolean output120Active;
        public int output120ProgressCount;
        public int output120ProgressRequired;

        public SyncStatsPacket(ServerPlayer player, PlayerStats s, com.jujutsucraft.jjkstats.mastery.JoquMasteryReader.MasteryInfo mastery) {
            this.strengthLevel     = s.strengthLevel;
            this.resistanceLevel   = s.resistanceLevel;
            this.speedLevel        = s.speedLevel;
            this.cursedEnergyLevel = s.cursedEnergyLevel;
            this.healthLevel       = s.healthLevel;
            this.statPoints        = s.statPoints;
            this.currentExp        = s.currentExp;
            this.expToNextFill     = s.expToNextFill;
            this.fillCount         = s.fillCount;
            this.hudX              = s.hudX;
            this.hudY              = s.hudY;
            this.playerLevel       = s.playerLevel;
            this.blackFlashMasteryPercent    = mastery.totalPercent();
            this.blackFlashMasteryCapPercent = mastery.capPercent();
            this.outputPercent = s.outputPercent;
            this.turboActive   = s.turboActive;
            // Output 120% vive en JoQu (Output120Handler); se lee directo del
            // NBT compartido del jugador, sin dependencia de compilación.
            long activeUntilTick = player.getPersistentData().getLong("jjkbrp_output120_active_until_tick");
            this.output120Active = player.level().getGameTime() < activeUntilTick;
            this.output120ProgressCount = player.getPersistentData().getInt("jjkbrp_output120_progress_count");
            this.output120ProgressRequired = player.getPersistentData().contains("jjkbrp_output120_procs_required_mirror")
                ? player.getPersistentData().getInt("jjkbrp_output120_procs_required_mirror")
                : 3;
        }

        public SyncStatsPacket(FriendlyByteBuf buf) {
            this.strengthLevel     = buf.readInt();
            this.resistanceLevel   = buf.readInt();
            this.speedLevel        = buf.readInt();
            this.cursedEnergyLevel = buf.readInt();
            this.healthLevel       = buf.readInt();
            this.statPoints        = buf.readInt();
            this.currentExp        = buf.readLong();
            this.expToNextFill     = buf.readLong();
            this.fillCount         = buf.readInt();
            this.hudX              = buf.readInt();
            this.hudY              = buf.readInt();
            this.playerLevel       = buf.readDouble();
            this.blackFlashMasteryPercent    = buf.readDouble();
            this.blackFlashMasteryCapPercent = buf.readDouble();
            this.outputPercent = buf.readInt();
            this.turboActive   = buf.readBoolean();
            this.output120Active = buf.readBoolean();
            this.output120ProgressCount = buf.readVarInt();
            this.output120ProgressRequired = buf.readVarInt();
        }

        public void encode(FriendlyByteBuf buf) {
            buf.writeInt(strengthLevel);
            buf.writeInt(resistanceLevel);
            buf.writeInt(speedLevel);
            buf.writeInt(cursedEnergyLevel);
            buf.writeInt(healthLevel);
            buf.writeInt(statPoints);
            buf.writeLong(currentExp);
            buf.writeLong(expToNextFill);
            buf.writeInt(fillCount);
            buf.writeInt(hudX);
            buf.writeInt(hudY);
            buf.writeDouble(playerLevel);
            buf.writeDouble(blackFlashMasteryPercent);
            buf.writeDouble(blackFlashMasteryCapPercent);
            buf.writeInt(outputPercent);
            buf.writeBoolean(turboActive);
            buf.writeBoolean(output120Active);
            buf.writeVarInt(output120ProgressCount);
            buf.writeVarInt(output120ProgressRequired);
        }

        // FIX: la lógica cliente se delega a ClientPacketHandlers via DistExecutor
        // para que la JVM del servidor nunca cargue LocalPlayer/Minecraft al
        // verificar los bytecodes de este método.
        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                    ClientPacketHandlers.handleSyncStats(this)
                )
            );
            ctx.get().setPacketHandled(true);
        }
    }

    // ── UpgradeStatPacket ────────────────────────────────────────────────────
    public static class UpgradeStatPacket {
        public final StatType stat;
        public final int count; // 1-5 niveles por clic

        public UpgradeStatPacket(StatType stat, int count) {
            this.stat  = stat;
            this.count = Math.max(1, Math.min(5, count));
        }

        public UpgradeStatPacket(FriendlyByteBuf buf) {
            this.stat  = StatType.values()[buf.readByte()];
            this.count = buf.readByte();
        }

        public void encode(FriendlyByteBuf buf) {
            buf.writeByte(stat.ordinal());
            buf.writeByte(count);
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player == null) return;
                double playerLevel = getJJKPlayerLevel(player);
                PlayerStatsCapability.get(player).ifPresent(stats -> {
                    boolean anyUpgraded = false;
                    for (int i = 0; i < count; i++) {
                        if (!stats.upgradeStat(stat, playerLevel)) break;
                        anyUpgraded = true;
                    }
                    if (anyUpgraded) {
                        com.jujutsucraft.jjkstats.event.StatsApplyHandler.applyAll(player, stats);
                        syncToClient(player);
                    }
                });
            });
            ctx.get().setPacketHandled(true);
        }
    }

    // ── SaveHudPositionPacket ────────────────────────────────────────────────
    public static class SaveHudPositionPacket {
        public final int x, y;

        public SaveHudPositionPacket(int x, int y) { this.x = x; this.y = y; }

        public SaveHudPositionPacket(FriendlyByteBuf buf) {
            this.x = buf.readInt();
            this.y = buf.readInt();
        }

        public void encode(FriendlyByteBuf buf) {
            buf.writeInt(x);
            buf.writeInt(y);
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player == null) return;
                PlayerStatsCapability.get(player).ifPresent(stats -> {
                    stats.hudX = x;
                    stats.hudY = y;
                });
            });
            ctx.get().setPacketHandled(true);
        }
    }

    public static double getJJKPlayerLevel(net.minecraft.world.entity.player.Player player) {
        try {
            var cap = player.getCapability(
                net.mcreator.jujutsucraft.network.JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null
            ).orElse(null);
            if (cap == null) return 2.0;
            return cap.PlayerLevel;
        } catch (Exception e) {
            return 2.0;
        }
    }

    // ── OutputChargePacket ───────────────────────────────────────────────────
    //
    // El cliente manda este packet en CADA tick mientras la tecla de output
    // está apretada (no un solo clic), con el flag de si Shift está apretado
    // también. El servidor es la única fuente de verdad del timing real (5%
    // cada ~300ms = 6s de 5% a 100%), usando un timestamp guardado en el NBT
    // del jugador para no depender del tickrate del cliente.
    public static class OutputChargePacket {
        public final boolean shiftHeld;

        public OutputChargePacket(boolean shiftHeld) {
            this.shiftHeld = shiftHeld;
        }

        public OutputChargePacket(FriendlyByteBuf buf) {
            this.shiftHeld = buf.readBoolean();
        }

        public void encode(FriendlyByteBuf buf) {
            buf.writeBoolean(shiftHeld);
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player == null) return;
                com.jujutsucraft.jjkstats.event.OutputHandler.onChargeInput(player, shiftHeld);
            });
            ctx.get().setPacketHandled(true);
        }
    }

    // ── TurboTogglePacket ────────────────────────────────────────────────────
    public static class TurboTogglePacket {
        public TurboTogglePacket() {}

        public TurboTogglePacket(FriendlyByteBuf buf) {}

        public void encode(FriendlyByteBuf buf) {}

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player == null) return;
                com.jujutsucraft.jjkstats.event.OutputHandler.onTurboToggle(player);
            });
            ctx.get().setPacketHandled(true);
        }
    }

    // ── SaveOutputHudPositionPacket ──────────────────────────────────────────
    public static class SaveOutputHudPositionPacket {
        public final int x, y;

        public SaveOutputHudPositionPacket(int x, int y) { this.x = x; this.y = y; }

        public SaveOutputHudPositionPacket(FriendlyByteBuf buf) {
            this.x = buf.readInt();
            this.y = buf.readInt();
        }

        public void encode(FriendlyByteBuf buf) {
            buf.writeInt(x);
            buf.writeInt(y);
        }

        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer player = ctx.get().getSender();
                if (player == null) return;
                PlayerStatsCapability.get(player).ifPresent(stats -> {
                    stats.outputHudX = x;
                    stats.outputHudY = y;
                });
            });
            ctx.get().setPacketHandled(true);
        }
    }

    // ── AuraParticlePacket ───────────────────────────────────────────────────
    //
    // ServerLevel#sendParticles, aún pasándole un ServerPlayer como primer
    // argumento, NO excluye a ese jugador de ver la partícula (la firma
    // sugiere lo contrario, pero no es así en la práctica). Este packet
    // propio se manda con exclusión real desde OutputHandler via
    // PacketDistributor.NEAR + TargetPoint(excluded, ...), y el cliente que
    // lo recibe simplemente spawnea la partícula localmente.
    public static class AuraParticlePacket {
        public final java.util.UUID ownerId;
        public final int colorId; // 0=default del mod base, 1=blue, 2=orange, 3=red, 4=green, 5=purple
        public final double x, y, z;
        public final double spreadXZ;
        public final double spreadY;
        public final int count;

        public AuraParticlePacket(java.util.UUID ownerId, int colorId, double x, double y, double z, double spreadXZ, double spreadY, int count) {
            this.ownerId = ownerId;
            this.colorId = colorId;
            this.x = x; this.y = y; this.z = z;
            this.spreadXZ = spreadXZ;
            this.spreadY = spreadY;
            this.count = count;
        }

        public AuraParticlePacket(FriendlyByteBuf buf) {
            this.ownerId = buf.readUUID();
            this.colorId = buf.readVarInt();
            this.x = buf.readDouble();
            this.y = buf.readDouble();
            this.z = buf.readDouble();
            this.spreadXZ = buf.readDouble();
            this.spreadY = buf.readDouble();
            this.count = buf.readVarInt();
        }

        public void encode(FriendlyByteBuf buf) {
            buf.writeUUID(ownerId);
            buf.writeVarInt(colorId);
            buf.writeDouble(x);
            buf.writeDouble(y);
            buf.writeDouble(z);
            buf.writeDouble(spreadXZ);
            buf.writeDouble(spreadY);
            buf.writeVarInt(count);
        }

        // FIX: la lógica cliente (Minecraft, addParticle, etc.) se delega a
        // ClientPacketHandlers via DistExecutor igual que SyncStatsPacket arriba.
        public void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                    ClientPacketHandlers.handleAuraParticle(this)
                )
            );
            ctx.get().setPacketHandled(true);
        }
    }
}
