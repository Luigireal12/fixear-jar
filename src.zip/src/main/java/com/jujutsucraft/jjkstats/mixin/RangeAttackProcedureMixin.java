package com.jujutsucraft.jjkstats.mixin;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.config.StatsConfig;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Mixin(targets = "net.mcreator.jujutsucraft.procedures.RangeAttackProcedure", remap = false)
public class RangeAttackProcedureMixin {

    private static final long COOLDOWN_TICKS = 5 * 60 * 20L; // 5 minutos en ticks de servidor, no milisegundos: el reloj de pared sigue corriendo durante la pausa en singleplayer, haciendo que el cooldown "ya pasara" solo por tener el juego pausado
    private static final Map<UUID, Long> lastPlayed = new ConcurrentHashMap<>();

    // Ventana de dedupe: RangeAttackProcedure.execute() itera sobre todas las
    // entidades cercanas en un mismo golpe, y este inject se dispara una vez
    // por cada lectura del campo ENTITY_BLACK_FLASH dentro de ese loop. Esta
    // ventana asegura que chat/title/música salgan una sola vez por golpe,
    // sin importar cuántos enemigos conecten Black Flash a la vez.
    private static final long HIT_DEDUPE_WINDOW_MS = 250L;
    private static final Map<UUID, Long> lastNotified = new ConcurrentHashMap<>();

    @Inject(
        method  = "execute",
        at      = @At(
            value  = "FIELD",
            target = "Lnet/mcreator/jujutsucraft/init/JujutsucraftModEntities;" +
                     "ENTITY_BLACK_FLASH:Lnet/minecraftforge/registries/RegistryObject;",
            opcode = Opcodes.GETSTATIC,
            remap  = false
        ),
        require = 0
    )
    private static void onBlackFlash(LevelAccessor world, double x, double y, double z,
                                      Entity entity, CallbackInfo ci) {
        if (!(entity instanceof ServerPlayer player)) return;
        if (!(world instanceof ServerLevel serverLevel)) return;

        // ── Dedupe por golpe ────────────────────────────────────────────────
        long nowHit = System.currentTimeMillis();
        Long lastHit = lastNotified.get(player.getUUID());
        if (lastHit != null && (nowHit - lastHit) < HIT_DEDUPE_WINDOW_MS) {
            return; // ya se notificó este mismo golpe, ignorar repeticiones del loop
        }
        lastNotified.put(player.getUUID(), nowHit);

        String nombre = player.getName().getString();

        // ── Música con cooldown ───────────────────────────────────────────────
        UUID id  = player.getUUID();
        long nowTick = player.level().getGameTime();
        Long last = lastPlayed.get(id);
        if (last == null || (nowTick - last) >= COOLDOWN_TICKS) {
            player.playNotifySound(
                JJKStatsMod.BLACK_FLASH_MUSIC.get(),
                SoundSource.AMBIENT,
                1.0f, 1.0f
            );
            lastPlayed.put(id, nowTick);
        }

        // ── Notificaciones a jugadores en radio configurable ──────────────────
        double radius = StatsConfig.BLACK_FLASH_CHAT_RADIUS.get();
        double r2     = radius * radius;

        String chatTemplate = StatsConfig.BLACK_FLASH_CHAT_MESSAGE.get();
        boolean titleEnabled = StatsConfig.BLACK_FLASH_TITLE_ENABLED.get();

        // Construir los componentes una sola vez
        Component chatMsg     = chatTemplate.isEmpty() ? null
            : Component.literal(StatsConfig.formatMessage(chatTemplate, nombre));

        Component titleComp   = null;
        Component subComp     = null;
        if (titleEnabled) {
            String titleText = StatsConfig.BLACK_FLASH_TITLE_TEXT.get();
            String subText   = StatsConfig.BLACK_FLASH_SUBTITLE_TEXT.get();
            if (!titleText.isEmpty())
                titleComp = Component.literal(StatsConfig.formatMessage(titleText, nombre));
            if (!subText.isEmpty())
                subComp   = Component.literal(StatsConfig.formatMessage(subText, nombre));
        }

        int fadeIn  = StatsConfig.BLACK_FLASH_TITLE_FADE_IN.get();
        int stay    = StatsConfig.BLACK_FLASH_TITLE_STAY.get();
        int fadeOut = StatsConfig.BLACK_FLASH_TITLE_FADE_OUT.get();

        final Component finalChat     = chatMsg;
        final Component finalTitle    = titleComp;
        final Component finalSubtitle = subComp;

        boolean shake = StatsConfig.BLACK_FLASH_TITLE_SHAKE.get();

        serverLevel.getPlayers(p ->
            p.distanceToSqr(player.getX(), player.getY(), player.getZ()) <= r2
        ).forEach(p -> {
            if (finalChat != null)
                p.sendSystemMessage(finalChat);

            if (titleEnabled && finalTitle != null) {
                p.connection.send(new ClientboundSetTitlesAnimationPacket(fadeIn, stay, fadeOut));
                p.connection.send(new ClientboundSetTitleTextPacket(finalTitle));
                if (finalSubtitle != null)
                    p.connection.send(new ClientboundSetSubtitleTextPacket(finalSubtitle));
            }

            // Vibrar el titulo en el cliente via paquete
            if (shake) {
                com.jujutsucraft.jjkstats.network.StatsNetwork.sendBlackFlashEffect(p);
            }
        });

        JJKStatsMod.LOGGER.info("[JJKStats] Black Flash de {}", nombre);
    }
}
