package com.jujutsucraft.jjkstats.mixin;

import net.minecraft.world.entity.Entity;
import net.minecraftforge.eventbus.api.Event;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cancela completamente PlayerPhysicalAbilityProcedure de JujutsuCraft.
 *
 * JJCraft aplicaba strength/resistance/health/speed/CE-max en este procedure
 * basado en PlayerLevel (el grado). Nuestro mod reemplaza todo ese sistema:
 *
 *   - StatsApplyHandler  → aplica los stats físicos farmeados (fuerza, resistencia, vida, velocidad)
 *   - CursedEnergyTickHandler → sobreescribe PlayerCursePowerMAX con el CE farmeado
 *
 * El Mixin solo cancela. La aplicación ocurre de forma independiente via eventos Forge.
 */
@Mixin(
    targets = "net.mcreator.jujutsucraft.procedures.PlayerPhysicalAbilityProcedure",
    remap = false
)
public class PlayerPhysicalAbilityMixin {

    @Inject(
        at = @At("HEAD"),
        method = "execute(Lnet/minecraftforge/eventbus/api/Event;Lnet/minecraft/world/entity/Entity;)V",
        remap = false,
        cancellable = true
    )
    private static void cancelPhysicalAbility(Event event, Entity entity, CallbackInfo ci) {
        ci.cancel();
    }
}
