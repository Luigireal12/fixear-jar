package com.jujutsucraft.jjkstats;

import com.jujutsucraft.jjkstats.config.StatsConfig;
import com.jujutsucraft.jjkstats.network.StatsNetwork;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(JJKStatsMod.MOD_ID)
public class JJKStatsMod {

    public static final String MOD_ID = "jjkstats";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    /** Referencia al ModConfig activo para poder recargarlo via comando. */
    public static ModConfig activeConfig;

    // ── Registro de sonidos ───────────────────────────────────────────────────
    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
        DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MOD_ID);

    /**
     * Música de Black Flash. El archivo OGG va en:
     * src/main/resources/assets/jjkstats/sounds/black_flash_music.ogg
     */
    public static final RegistryObject<SoundEvent> BLACK_FLASH_MUSIC =
        SOUND_EVENTS.register("black_flash_music",
            () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(MOD_ID, "black_flash_music")));

    public JJKStatsMod(FMLJavaModLoadingContext context) {
        context.registerConfig(ModConfig.Type.COMMON, StatsConfig.SPEC, "jjkstats-server.toml");
        context.getModEventBus().addListener(this::onCommonSetup);
        SOUND_EVENTS.register(context.getModEventBus());
        context.getModEventBus().addListener(this::onConfigLoad);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void onConfigLoad(ModConfigEvent event) {
        if (event.getConfig().getSpec() == StatsConfig.SPEC) {
            activeConfig = event.getConfig();
        }
    }

    private void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(StatsNetwork::register);
        LOGGER.info("[JJKStats] Mod inicializado.");
    }
}
