package com.jujutsucraft.jjkstats.capability;

import com.jujutsucraft.jjkstats.config.StatsConfig;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.*;
import net.minecraftforge.common.util.INBTSerializable;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlayerStatsCapability {

    public static final Capability<PlayerStats> CAPABILITY = CapabilityManager.get(new CapabilityToken<>(){});

    public static class PlayerStats implements INBTSerializable<CompoundTag> {

        public int strengthLevel     = 0;
        public int resistanceLevel   = 0;
        public int speedLevel        = 0;
        public int cursedEnergyLevel = 0;
        public int healthLevel       = 0;

        public int  statPoints    = 0;
        public long currentExp    = 0;
        public int  fillCount     = 0;   // nivel (cuántas veces se llenó la barra)
        public long expToNextFill = 0;

        // Sincronizado desde el servidor para el HUD cliente
        public double playerLevel = 1.0;

        // Sincronizado desde el servidor: maestría de Black Flash (leída del NBT
        // de JoQu, addon separado sin dependencia de compilación con stats — ver
        // MasteryNetworkBridge en el lado servidor). No se persiste en el NBT
        // propio de stats; siempre se resincroniza desde JoQu en cada tick/login.
        public double blackFlashMasteryPercent = -1.0; // -1 = JoQu no presente / sin datos aún
        public double blackFlashMasteryCapPercent = 0.0;
        public String blackFlashMasteryCtName = "";

        public int hudX = -1;
        public int hudY = -1;

        // Sistema de output (0-100%, multiplica fuerza/resistencia/velocidad ya
        // calculadas). Persiste entre sesiones, arranca en 5% para un jugador
        // nuevo. Turbo NO persiste (estado de combate momentáneo).
        public int outputPercent = 5;
        public int outputHudX = -1;
        public int outputHudY = -1;
        public boolean turboActive = false;

        // Sincronizado desde el servidor: estado del bono de Output 120%
        // (vive en JoQu, leído vía NBT — ver Output120Handler). No persiste
        // en el NBT propio de stats.
        public boolean output120Active = false;
        public int output120ProgressCount = 0;
        public int output120ProgressRequired = 3;

        public PlayerStats() {
            recalcExpToNextFill();
        }

        public void recalcExpToNextFill() {
            int base    = StatsConfig.EXP_BASE.get();
            double scale = StatsConfig.EXP_SCALE_FACTOR.get();
            expToNextFill = (long) Math.ceil(base * Math.pow(scale, fillCount));
        }

        /** Añade EXP. Devuelve cuántas veces se llenó la barra. */
        public int addExp(long amount) {
            currentExp += amount;
            int fills = 0;
            while (currentExp >= expToNextFill) {
                currentExp -= expToNextFill;
                fillCount++;
                statPoints += StatsConfig.POINTS_PER_FILL.get();
                recalcExpToNextFill();
                fills++;
            }
            return fills;
        }

        public boolean upgradeStat(StatType stat, double pLevel) {
            int cap = (stat == StatType.HEALTH)
                ? Math.max(1, StatsConfig.getHealthCap(pLevel))
                : Math.max(1, StatsConfig.getCumulativeCap(pLevel));
            int current = getStatLevel(stat);
            if (current >= cap) return false;
            int cost = getUpgradeCost(stat, current);
            if (statPoints < cost) return false;
            statPoints -= cost;
            setStatLevel(stat, current + 1);
            return true;
        }

        public int getUpgradeCost(StatType stat, int currentLevel) {
            return switch (stat) {
                case STRENGTH      -> StatsConfig.getCost(StatsConfig.STRENGTH_BASE_COST.get(),      StatsConfig.STRENGTH_SCALE.get(),      StatsConfig.STRENGTH_TIER_INC.get(),      currentLevel);
                case RESISTANCE    -> StatsConfig.getCost(StatsConfig.RESISTANCE_BASE_COST.get(),    StatsConfig.RESISTANCE_SCALE.get(),    StatsConfig.RESISTANCE_TIER_INC.get(),    currentLevel);
                case SPEED         -> StatsConfig.getCost(StatsConfig.SPEED_BASE_COST.get(),         StatsConfig.SPEED_SCALE.get(),         StatsConfig.SPEED_TIER_INC.get(),         currentLevel);
                case CURSED_ENERGY -> StatsConfig.getCost(StatsConfig.CURSED_ENERGY_BASE_COST.get(), StatsConfig.CURSED_ENERGY_SCALE.get(), StatsConfig.CURSED_ENERGY_TIER_INC.get(), currentLevel);
                case HEALTH        -> StatsConfig.getCost(StatsConfig.HEALTH_BASE_COST.get(),        StatsConfig.HEALTH_SCALE.get(),        StatsConfig.HEALTH_TIER_INC.get(),        currentLevel);
            };
        }

        public int getStatLevel(StatType stat) {
            return switch (stat) {
                case STRENGTH      -> strengthLevel;
                case RESISTANCE    -> resistanceLevel;
                case SPEED         -> speedLevel;
                case CURSED_ENERGY -> cursedEnergyLevel;
                case HEALTH        -> healthLevel;
            };
        }

        public void setStatLevel(StatType stat, int value) {
            switch (stat) {
                case STRENGTH      -> strengthLevel     = value;
                case RESISTANCE    -> resistanceLevel   = value;
                case SPEED         -> speedLevel        = value;
                case CURSED_ENERGY -> cursedEnergyLevel = value;
                case HEALTH        -> healthLevel       = value;
            }
        }

        public void reset() {
            strengthLevel = resistanceLevel = speedLevel = cursedEnergyLevel = healthLevel = 0;
            statPoints = 0; currentExp = 0; fillCount = 0;
            recalcExpToNextFill();
        }

        @Override
        public CompoundTag serializeNBT() {
            CompoundTag tag = new CompoundTag();
            tag.putInt("strength",     strengthLevel);
            tag.putInt("resistance",   resistanceLevel);
            tag.putInt("speed",        speedLevel);
            tag.putInt("cursedEnergy", cursedEnergyLevel);
            tag.putInt("health",       healthLevel);
            tag.putInt("statPoints",   statPoints);
            tag.putLong("currentExp",  currentExp);
            tag.putInt("fillCount",    fillCount);
            tag.putLong("expToNext",   expToNextFill);
            tag.putDouble("playerLevel", playerLevel);
            tag.putInt("hudX", hudX);
            tag.putInt("hudY", hudY);
            tag.putInt("outputPercent", outputPercent);
            tag.putInt("outputHudX", outputHudX);
            tag.putInt("outputHudY", outputHudY);
            return tag;
        }

        @Override
        public void deserializeNBT(CompoundTag tag) {
            strengthLevel     = tag.getInt("strength");
            resistanceLevel   = tag.getInt("resistance");
            speedLevel        = tag.getInt("speed");
            cursedEnergyLevel = tag.getInt("cursedEnergy");
            healthLevel       = tag.getInt("health");
            statPoints        = tag.getInt("statPoints");
            currentExp        = tag.getLong("currentExp");
            fillCount         = tag.getInt("fillCount");
            expToNextFill     = tag.getLong("expToNext");
            playerLevel       = tag.contains("playerLevel") ? tag.getDouble("playerLevel") : 1.0;
            hudX              = tag.contains("hudX") ? tag.getInt("hudX") : -1;
            hudY              = tag.contains("hudY") ? tag.getInt("hudY") : -1;
            outputPercent     = tag.contains("outputPercent") ? tag.getInt("outputPercent") : 5;
            outputHudX        = tag.contains("outputHudX") ? tag.getInt("outputHudX") : -1;
            outputHudY        = tag.contains("outputHudY") ? tag.getInt("outputHudY") : -1;
            if (expToNextFill <= 0) recalcExpToNextFill();
        }
    }

    public static class Provider implements ICapabilitySerializable<CompoundTag> {
        private final PlayerStats data = new PlayerStats();
        private final LazyOptional<PlayerStats> optional = LazyOptional.of(() -> data);

        @Override
        public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable net.minecraft.core.Direction side) {
            return CAPABILITY.orEmpty(cap, optional);
        }

        @Override public CompoundTag serializeNBT()          { return data.serializeNBT(); }
        @Override public void deserializeNBT(CompoundTag nbt){ data.deserializeNBT(nbt);   }
        public void invalidate() { optional.invalidate(); }
    }

    public static LazyOptional<PlayerStats> get(Player player) {
        return player.getCapability(CAPABILITY);
    }

    public enum StatType {
        STRENGTH, RESISTANCE, SPEED, CURSED_ENERGY, HEALTH
    }
}
