package com.jujutsucraft.jjkstats.command;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability.StatType;
import com.jujutsucraft.jjkstats.event.StatsApplyHandler;
import com.jujutsucraft.jjkstats.network.StatsNetwork;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class StatsCommand {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        register(event.getDispatcher());
        registerOutputHud(event.getDispatcher());
    }

    /** /jjkoutputhud <x> <y> — cualquier jugador puede mover su propia barra de output, sin requerir OP. */
    private static void registerOutputHud(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("jjkoutputhud")
            .then(Commands.argument("x", IntegerArgumentType.integer(0))
                .then(Commands.argument("y", IntegerArgumentType.integer(0))
                    .executes(ctx -> {
                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                        int x = IntegerArgumentType.getInteger(ctx, "x");
                        int y = IntegerArgumentType.getInteger(ctx, "y");
                        PlayerStatsCapability.get(player).ifPresent(stats -> {
                            stats.outputHudX = x;
                            stats.outputHudY = y;
                        });
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "Barra de output movida a (" + x + ", " + y + ")."
                        ), false);
                        return 1;
                    }))));
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("jjkstats")
            .requires(src -> src.hasPermission(2))

            // /jjkstats addexp <player> <amount>
            .then(Commands.literal("addexp")
                .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("amount", LongArgumentType.longArg(1))
                        .executes(ctx -> {
                            ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                            long amount = LongArgumentType.getLong(ctx, "amount");
                            PlayerStatsCapability.get(target).ifPresent(stats -> {
                                int fills = stats.addExp(amount);
                                StatsNetwork.syncToClient(target);
                                if (fills > 0) {
                                    // Notificar al jugador que ganó puntos
                                    target.sendSystemMessage(Component.literal(
                                        "§6[JJKStats] §eBarra llena! Ganaste §a" +
                                        com.jujutsucraft.jjkstats.config.StatsConfig.POINTS_PER_FILL.get() +
                                        " §epuntos de estadística."
                                    ));
                                }
                            });
                            ctx.getSource().sendSuccess(
                                () -> Component.literal("Se añadieron " + amount + " EXP a " + target.getName().getString()),
                                true
                            );
                            return 1;
                        })
                    )
                )
            )

            // /jjkstats addpoints <player> <amount>
            .then(Commands.literal("addpoints")
                .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.argument("amount", IntegerArgumentType.integer(1))
                        .executes(ctx -> {
                            ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                            int amount = IntegerArgumentType.getInteger(ctx, "amount");
                            PlayerStatsCapability.get(target).ifPresent(stats -> {
                                stats.statPoints += amount;
                                StatsNetwork.syncToClient(target);
                                target.sendSystemMessage(Component.literal(
                                    "§6[JJKStats] §eRecibiste §a" + amount + " §epuntos de estadística."
                                ));
                            });
                            ctx.getSource().sendSuccess(
                                () -> Component.literal("Se añadieron " + amount + " puntos a " + target.getName().getString()),
                                true
                            );
                            return 1;
                        })
                    )
                )
            )

            // /jjkstats reset <player>
            .then(Commands.literal("reset")
                .then(Commands.argument("player", EntityArgument.player())
                    .executes(ctx -> {
                        ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                        PlayerStatsCapability.get(target).ifPresent(stats -> {
                            stats.reset();
                            StatsApplyHandler.applyAll(target, stats);
                            StatsNetwork.syncToClient(target);
                        });
                        ctx.getSource().sendSuccess(
                            () -> Component.literal("Stats de " + target.getName().getString() + " reiniciadas"),
                            true
                        );
                        return 1;
                    })
                )
            )

            // /jjkstats setstat <player> <stat> <level>  (para ajustes de admin)
            .then(Commands.literal("setstat")
                .then(Commands.argument("player", EntityArgument.player())
                    .then(Commands.literal("strength")
                        .then(Commands.argument("level", IntegerArgumentType.integer(0))
                            .executes(ctx -> setStatLevel(ctx, StatType.STRENGTH))))
                    .then(Commands.literal("resistance")
                        .then(Commands.argument("level", IntegerArgumentType.integer(0))
                            .executes(ctx -> setStatLevel(ctx, StatType.RESISTANCE))))
                    .then(Commands.literal("speed")
                        .then(Commands.argument("level", IntegerArgumentType.integer(0))
                            .executes(ctx -> setStatLevel(ctx, StatType.SPEED))))
                    .then(Commands.literal("cursed_energy")
                        .then(Commands.argument("level", IntegerArgumentType.integer(0))
                            .executes(ctx -> setStatLevel(ctx, StatType.CURSED_ENERGY))))
                    .then(Commands.literal("health")
                        .then(Commands.argument("level", IntegerArgumentType.integer(0))
                            .executes(ctx -> setStatLevel(ctx, StatType.HEALTH))))
                )
            )

            // /jjkstats info <player>
            .then(Commands.literal("info")
                .then(Commands.argument("player", EntityArgument.player())
                    .executes(ctx -> {
                        ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
                        PlayerStatsCapability.get(target).ifPresent(stats -> {
                            double jjkLevel = StatsNetwork.getJJKPlayerLevel(target);
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                "§6[JJKStats] §e" + target.getName().getString() +
                                " §7(Grade Level: " + jjkLevel + ")\n" +
                                "  §aFuerza: §f" + stats.strengthLevel +
                                " §aRes: §f" + stats.resistanceLevel +
                                " §aVel: §f" + stats.speedLevel +
                                " §aCE: §f" + stats.cursedEnergyLevel +
                                " §aVida: §f" + stats.healthLevel + "\n" +
                                "  §ePuntos: §f" + stats.statPoints +
                                " §eEXP: §f" + stats.currentExp + "/" + stats.expToNextFill +
                                " §e(llenados: " + stats.fillCount + ")"
                            ), false);
                        });
                        return 1;
                    })
                )
            )
        );
    }

    private static int setStatLevel(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx, StatType stat) {
        try {
            ServerPlayer target = EntityArgument.getPlayer(ctx, "player");
            int level = IntegerArgumentType.getInteger(ctx, "level");
            PlayerStatsCapability.get(target).ifPresent(stats -> {
                stats.setStatLevel(stat, level);
                StatsApplyHandler.applyAll(target, stats);
                StatsNetwork.syncToClient(target);
            });
            ctx.getSource().sendSuccess(
                () -> Component.literal("Stat " + stat.name() + " de " + target.getName().getString() + " → " + level),
                true
            );
            return 1;
        } catch (Exception e) {
            return 0;
        }
    }
}
