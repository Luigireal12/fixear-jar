package com.jujutsucraft.jjkstats.client.keybind;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public class StatsKeyBinding {

    public static final KeyMapping OPEN_STATS_GUI = new KeyMapping(
        "key.jjkstats.open_gui",
        InputConstants.Type.KEYSYM,
        GLFW.GLFW_KEY_L,
        "key.categories.jjkstats"
    );

    /**
     * Mantenida + Shift = baja el output de a 5%; mantenida sin Shift = sube
     * de a 5%. Soltarla deja el % fijo donde esté (no sigue subiendo/bajando
     * solo). El chequeo de Shift se hace en ClientEventHandler, esta tecla
     * solo marca "el jugador está cargando/descargando output ahora".
     */
    public static final KeyMapping OUTPUT_CHARGE = new KeyMapping(
        "key.jjkstats.output_charge",
        InputConstants.Type.KEYSYM,
        GLFW.GLFW_KEY_O,
        "key.categories.jjkstats"
    );

    /** Toggle de turbo mode (+25% velocidad, consume CE/s, independiente del output). */
    public static final KeyMapping TURBO_TOGGLE = new KeyMapping(
        "key.jjkstats.turbo_toggle",
        InputConstants.Type.KEYSYM,
        GLFW.GLFW_KEY_R,
        "key.categories.jjkstats"
    );

    @SubscribeEvent
    public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(OPEN_STATS_GUI);
        event.register(OUTPUT_CHARGE);
        event.register(TURBO_TOGGLE);
    }
}
