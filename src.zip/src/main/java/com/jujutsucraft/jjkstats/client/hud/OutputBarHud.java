package com.jujutsucraft.jjkstats.client.hud;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class OutputBarHud {

    private static final int BAR_W = 140;
    private static final int BAR_H = 14;
    private static final int LABEL_H = 11;
    private static final int DEFAULT_X = 8;
    private static final int DEFAULT_Y = 8;

    // Tramo extra que se agrega a la barra cuando el bono de 120% está
    // activo (la barra "se hace más grande", como pediste).
    private static final int EXTRA_W = 28;
    private static final int EXPAND_ANIM_TICKS = 8; // ~0.4s, la animación de expansión

    private static final int COLOR_OUTER_BORDER = 0xFF000000;
    private static final int COLOR_INNER_BORDER = 0xFF1A5566;
    private static final int COLOR_BG           = 0xE60A1A20;
    private static final int COLOR_TICK         = 0x33FFFFFF;

    private static final int COLOR_FILL   = 0xFF29C5E8; // celeste
    private static final int COLOR_TURBO  = 0xFF7FF0FF; // celeste más claro/brillante
    private static final int COLOR_120_BORDER = 0xFFAA1111;
    private static final int COLOR_SEG_GLOW = 0xFFFF7A7A; // rojo pálido brillante, simula glow alrededor del segmento
    private static final int COLOR_SEG_FILL = 0xFFB01818; // rojo sólido, relleno principal del segmento
    private static final int COLOR_SEG_HIGHLIGHT = 0xFFFFC0C0; // destello superior, casi blanco-rosado
    private static final int COLOR_120_FILL = 0xFF1A0606; // negro con tinte rojizo
    private static final int COLOR_120_FILL_EDGE = 0xFFCC2222; // brillo superior rojizo

    private static final int COLOR_LABEL_BG = 0xCC000000;
    private static final int COLOR_LABEL_TXT = 0xFFEFEFEF;
    private static final int COLOR_PCT_TXT   = 0xFFFFFFFF;
    private static final int COLOR_TURBO_TXT = 0xFF7FF0FF;
    private static final int COLOR_120_TXT   = 0xFFFF3A3A;
    private static final int COLOR_120_TXT_DARK = 0xFF801010;

    private static final Map<UUID, Float> expandAnim = new HashMap<>();

    @SubscribeEvent
    public static void onRenderGuiOverlay(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.POTION_ICONS.type()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        PlayerStatsCapability.get(mc.player).ifPresent(stats -> {
            int barX = stats.outputHudX >= 0 ? stats.outputHudX : DEFAULT_X;
            int barY = stats.outputHudY >= 0 ? stats.outputHudY : DEFAULT_Y;

            var gfx = event.getGuiGraphics();
            int pct = Math.max(5, Math.min(100, stats.outputPercent));
            boolean turbo = stats.turboActive;
            boolean output120 = stats.output120Active;

            // ── Animación de expansión: interpola suavemente hacia el ancho
            // extra cuando se activa, y de vuelta al ancho normal cuando se
            // pierde/expira.
            UUID id = mc.player.getUUID();
            float targetExpand = output120 ? 1.0f : 0.0f;
            float currentExpand = expandAnim.getOrDefault(id, 0.0f);
            float step = 1.0f / EXPAND_ANIM_TICKS;
            if (currentExpand < targetExpand) currentExpand = Math.min(targetExpand, currentExpand + step);
            else if (currentExpand > targetExpand) currentExpand = Math.max(targetExpand, currentExpand - step);
            expandAnim.put(id, currentExpand);

            int extraW = (int) (EXTRA_W * currentExpand);
            int totalBarW = BAR_W + extraW;

            // ── Latido real: dos golpes asimétricos por ciclo (el primero
            // fuerte y corto, el segundo más chico, seguidos de una pausa
            // larga sin movimiento) — no un seno simple, que se sentía como
            // respiración pareja en vez de un "tum-tum" real.
            int pulseExtraW = 0;
            int pulseExtraH = 0;
            float pulse = 0f; // 0.0 a 1.0, reusado también para pulsar el color del texto "120%"
            if (output120) {
                int cycleTicks = 24; // ~1.2s por ciclo completo de latido
                int t = mc.player.tickCount % cycleTicks;
                pulse = heartbeatCurve(t, cycleTicks);
                pulseExtraW = Math.round(pulse * 5f); // hasta +5px de ancho en el golpe más fuerte
                pulseExtraH = Math.round(pulse * 3f); // hasta +3px de alto
            }
            int pulsedBarW = totalBarW + pulseExtraW;
            int pulsedBarH = BAR_H + pulseExtraH;
            int pulseOffsetX = pulseExtraW / 2; // centra el crecimiento, no lo desplaza solo a la derecha
            int pulseOffsetY = pulseExtraH / 2;

            // ── Etiqueta superior (no pulsa, solo la barra en sí abajo) ──────
            String label;
            int labelColor;
            if (output120) {
                label = "OUTPUT 120%" + (turbo ? " [TURBO]" : "");
                labelColor = COLOR_120_TXT;
            } else if (turbo) {
                label = "OUTPUT  [TURBO]";
                labelColor = COLOR_TURBO_TXT;
            } else {
                label = "OUTPUT";
                labelColor = COLOR_LABEL_TXT;
            }
            gfx.fill(barX, barY, barX + totalBarW, barY + LABEL_H, COLOR_LABEL_BG);
            gfx.drawString(mc.font, label, barX + 3, barY + 2, labelColor, false);

            int barTop = barY + LABEL_H + 2;
            int borderColor = output120 ? COLOR_120_BORDER : COLOR_INNER_BORDER;

            // Coordenadas con el pulso aplicado, centrado respecto al
            // rectángulo original (crece/decrece hacia ambos lados, no
            // desplaza la barra entera).
            int pBarX = barX - pulseOffsetX;
            int pBarTop = barTop - pulseOffsetY;
            int pBarW = pulsedBarW;
            int pBarH = pulsedBarH;

            // ── Marco doble ───────────────────────────────────────────────
            gfx.fill(pBarX - 2, pBarTop - 2, pBarX + pBarW + 2, pBarTop + pBarH + 2, COLOR_OUTER_BORDER);
            gfx.fill(pBarX - 1, pBarTop - 1, pBarX + pBarW + 1, pBarTop + pBarH + 1, borderColor);
            gfx.fill(pBarX, pBarTop, pBarX + pBarW, pBarTop + pBarH, COLOR_BG);

            // ── Relleno: la barra "real" llena hasta pct%, y si está
            // extendida, el tramo extra se llena completo mientras el bono
            // está activo (representa el +20% adicional). En 120%, el
            // relleno cambia de celeste a negro con bordes rojizos.
            int fillColorBase = output120 ? COLOR_120_FILL : (turbo ? COLOR_TURBO : COLOR_FILL);
            int filled = (int) (pBarW * (pct / 100.0));
            if (filled > 0) {
                gfx.fill(pBarX, pBarTop, pBarX + filled, pBarTop + pBarH, fillColorBase);
                int hi = output120 ? COLOR_120_FILL_EDGE : blendWithWhite(fillColorBase, 0.35f);
                gfx.fill(pBarX, pBarTop, pBarX + filled, pBarTop + 2, hi);
            }

            // ── Marcas cada 25%, recalculadas sobre el ANCHO actual con pulso
            for (int t = 25; t < 100; t += 25) {
                int tx = pBarX + (pBarW * t) / 100;
                gfx.fill(tx, pBarTop, tx + 1, pBarTop + pBarH, COLOR_TICK);
            }

            // ── Barra secundaria de progreso de Black Flash hacia el 120%,
            // pegada justo debajo, alineada al borde izquierdo de la barra
            // de output, con 1/3 de su ancho. Se dibuja ANTES que los rayos
            // (más abajo) para que estos, si caen en su zona, queden
            // siempre por encima — no tapados por esta barra.
            int progressBarW = BAR_W / 3; // ancho FIJO (base, sin expansión ni latido), no debe cambiar cuando la barra de output se expande/late
            int progressBarTop = pBarTop + pBarH + 3;
            int progressBarH = 6;
            int required = Math.max(1, stats.output120ProgressRequired);
            int progressCount = output120 ? 0 : Math.min(stats.output120ProgressCount, required);

            gfx.fill(pBarX - 2, progressBarTop - 2, pBarX + progressBarW + 2, progressBarTop + progressBarH + 2, COLOR_OUTER_BORDER);
            gfx.fill(pBarX - 1, progressBarTop - 1, pBarX + progressBarW + 1, progressBarTop + progressBarH + 1, borderColor);
            gfx.fill(pBarX, progressBarTop, pBarX + progressBarW, progressBarTop + progressBarH, COLOR_BG);

            if (progressCount > 0) {
                int segGap = 1;
                int totalGapW = segGap * (required - 1);
                int segW = Math.max(1, (progressBarW - totalGapW) / required);
                for (int i = 0; i < progressCount; i++) {
                    int segX = pBarX + i * (segW + segGap);
                    // Borde brillante (rojo pálido, simula un glow alrededor
                    // del segmento) + relleno sólido más oscuro adentro +
                    // destello superior fino para dar sensación de volumen.
                    gfx.fill(segX - 1, progressBarTop - 1, segX + segW + 1, progressBarTop + progressBarH + 1, COLOR_SEG_GLOW);
                    gfx.fill(segX, progressBarTop, segX + segW, progressBarTop + progressBarH, COLOR_SEG_FILL);
                    gfx.fill(segX, progressBarTop, segX + segW, progressBarTop + 1, COLOR_SEG_HIGHLIGHT);
                }
            }

            // ── Animación de rayos negro/rojo sobre toda la barra mientras
            // el bono de 120% está activo ──────────────────────────────────
            if (output120) {
                drawLightningOverlay(gfx, pBarX, pBarTop, pBarW, pBarH, mc.player.tickCount);
            }

            // ── Número grande centrado ───────────────────────────────────────
            String pctTxt = output120 ? "120%" : (pct + "%");
            int textW = mc.font.width(pctTxt);
            int tx = pBarX + (pBarW - textW) / 2;
            int ty = pBarTop + (pBarH - 8) / 2;
            int pctColor = output120
                ? blendColors(COLOR_120_TXT_DARK, COLOR_120_TXT, pulse)
                : COLOR_PCT_TXT;
            gfx.drawString(mc.font, pctTxt, tx + 1, ty + 1, 0xFF000000, false);
            gfx.drawString(mc.font, pctTxt, tx, ty, pctColor, false);
        });
    }

    /**
     * Usa exclusivamente las 13 texturas reales de particle_black_flash_1
     * (el override de JJKU dentro de JoQu, 512x512 cada frame) — sin Kokusen3,
     * por pedido explícito.
     */
    private static final int BF1_FRAME_COUNT = 13;
    private static final int BF1_TEX_SIZE = 512;
    private static final int BF1_DISPLAY_SIZE = 30; // reducido a la mitad (era 60)
    private static final int BF1_LIFETIME = 10;
    private static final net.minecraft.resources.ResourceLocation[] BF1_FRAMES = buildFrames("black_flash_1_", BF1_FRAME_COUNT);

    private static net.minecraft.resources.ResourceLocation[] buildFrames(String prefix, int count) {
        net.minecraft.resources.ResourceLocation[] frames = new net.minecraft.resources.ResourceLocation[count];
        for (int i = 0; i < count; i++) {
            frames[i] = new net.minecraft.resources.ResourceLocation("jjkstats", "textures/particle/" + prefix + (i + 1) + ".png");
        }
        return frames;
    }

    private record ActiveBolt(int spawnTick, int x, int y) {
    }

    private static final java.util.List<ActiveBolt> activeBolts = new java.util.ArrayList<>();

    /**
     * BUG REAL ENCONTRADO Y CORREGIDO: activeBolts es un campo static, sin
     * ningún manejo de limpieza al morir/respawnear. Cada rayito guarda su
     * tickCount de spawn (bolt.spawnTick()) como referencia; tras un
     * respawn, el tickCount del cliente puede quedar desincronizado
     * respecto a esos valores viejos, haciendo que
     * age = tickCount - bolt.spawnTick() se vuelva NEGATIVO. En Java, % con
     * dividendo negativo da resultado negativo (no el resto matemático
     * real), así que spriteIndex = age % BF1_FRAME_COUNT termina siendo
     * negativo — de ahí el ArrayIndexOutOfBoundsException con índices
     * negativos (-1, -2... -12) que aparecía repetidamente en el log justo
     * después de cada muerte, confirmado real. Se limpia la lista entera
     * al respawnear, así los rayos arrancan de cero con el tickCount nuevo.
     */
    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        if (event.isWasDeath()) {
            activeBolts.clear();
        }
    }

    private static final int MIN_BOLTS_SIMULTANEOUS = 3;
    private static final int MAX_BOLTS_SIMULTANEOUS = 4;

    private static void drawLightningOverlay(net.minecraft.client.gui.GuiGraphics gfx, int barX, int barTop, int barW, int barH, int tickCount) {
        java.util.Random spawnRng = new java.util.Random(tickCount * 7919L);

        // Mantiene siempre entre 3 y 4 rayos simultáneos (no un máximo que a
        // veces cae a menos): si hay menos del mínimo, repone; el objetivo
        // exacto (3 o 4) se decide al azar cada vez que toca reponer.
        int target = MIN_BOLTS_SIMULTANEOUS + spawnRng.nextInt(MAX_BOLTS_SIMULTANEOUS - MIN_BOLTS_SIMULTANEOUS + 1);
        if (activeBolts.size() < target) {
            // Margen reducido (antes 0.35) para que el punto de generación
            // caiga un poco más adentro de la barra, no tan cerca del borde.
            int margin = (int) (BF1_DISPLAY_SIZE * 0.22);
            int x = barX - margin + spawnRng.nextInt(barW + margin * 2);
            int y = barTop - margin + spawnRng.nextInt(barH + margin * 2);
            activeBolts.add(new ActiveBolt(tickCount, x, y));
        }

        activeBolts.removeIf(b -> (tickCount - b.spawnTick()) >= BF1_LIFETIME);

        for (ActiveBolt bolt : activeBolts) {
            drawBlackFlash1(gfx, bolt, tickCount);
        }
    }

    private static void drawBlackFlash1(net.minecraft.client.gui.GuiGraphics gfx, ActiveBolt bolt, int tickCount) {
        int age = tickCount - bolt.spawnTick();
        int spriteIndex = age % BF1_FRAME_COUNT;
        int half = BF1_DISPLAY_SIZE / 2;
        gfx.blit(BF1_FRAMES[spriteIndex], bolt.x() - half, bolt.y() - half, BF1_DISPLAY_SIZE, BF1_DISPLAY_SIZE,
            0f, 0f, BF1_TEX_SIZE, BF1_TEX_SIZE, BF1_TEX_SIZE, BF1_TEX_SIZE);
    }

    /**
     * Curva de latido real (no un seno simple): dentro de un ciclo de
     * cycleTicks, hay dos golpes cortos y rápidos (el primero más fuerte,
     * el segundo más chico, como sístole/diástole), cada uno con ataque
     * instantáneo y caída exponencial, seguidos de una pausa larga sin
     * movimiento — el patrón "tum-tum ...... tum-tum ......" real de un
     * pulso cardíaco, en vez de una oscilación pareja tipo respiración.
     */
    private static float heartbeatCurve(int t, int cycleTicks) {
        // Primer golpe: ataque en el tick 0, cae exponencialmente, dura ~6 ticks.
        int beat1Start = 0, beat1Duration = 6;
        // Segundo golpe: más chico, empieza poco después del primero.
        int beat2Start = 7, beat2Duration = 5;

        float v1 = beatPulse(t - beat1Start, beat1Duration, 1.0f);
        float v2 = beatPulse(t - beat2Start, beat2Duration, 0.55f);
        return Math.max(v1, v2);
    }

    /** Un solo golpe: 0 si está fuera de [0, duration), si no decae exponencialmente desde peakHeight. */
    private static float beatPulse(int localT, int duration, float peakHeight) {
        if (localT < 0 || localT >= duration) return 0f;
        float progress = localT / (float) duration; // 0.0 a 1.0
        return peakHeight * (float) Math.exp(-progress * 5.0); // caída exponencial rápida
    }

    /** Interpola linealmente entre dos colores ARGB, t=0 da colorA, t=1 da colorB. */
    private static int blendColors(int colorA, int colorB, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aA = (colorA >>> 24) & 0xFF, rA = (colorA >>> 16) & 0xFF, gA = (colorA >>> 8) & 0xFF, bA = colorA & 0xFF;
        int aB = (colorB >>> 24) & 0xFF, rB = (colorB >>> 16) & 0xFF, gB = (colorB >>> 8) & 0xFF, bB = colorB & 0xFF;
        int a = (int) (aA + (aB - aA) * t);
        int r = (int) (rA + (rB - rA) * t);
        int g = (int) (gA + (gB - gA) * t);
        int b = (int) (bA + (bB - bA) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int blendWithWhite(int argb, float amount) {
        int a = (argb >>> 24) & 0xFF;
        int r = (argb >>> 16) & 0xFF;
        int g = (argb >>> 8)  & 0xFF;
        int b = argb & 0xFF;
        r = (int) (r + (255 - r) * amount);
        g = (int) (g + (255 - g) * amount);
        b = (int) (b + (255 - b) * amount);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
