package com.jujutsucraft.jjkstats.client;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.client.gui.StatsScreen;
import com.jujutsucraft.jjkstats.client.keybind.StatsKeyBinding;
import com.jujutsucraft.jjkstats.network.StatsNetwork;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientEventHandler {

    @SubscribeEvent
    public static void onKeyInput(InputEvent.Key event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != null) return; // No abrir si ya hay otra pantalla
        if (StatsKeyBinding.OPEN_STATS_GUI.consumeClick()) {
            mc.setScreen(new StatsScreen());
        }
        if (StatsKeyBinding.TURBO_TOGGLE.consumeClick()) {
            StatsNetwork.CHANNEL.sendToServer(new StatsNetwork.TurboTogglePacket());
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        // isDown() refleja el estado real de la tecla independientemente de
        // si hay una Screen abierta o no (a diferencia de consumeClick, que
        // sí se ve afectado). No filtramos por mc.screen aquí a propósito:
        // sostener la tecla de output debe funcionar incluso con el
        // inventario u otro GUI no-bloqueante abierto, igual que sprintear.
        boolean held = StatsKeyBinding.OUTPUT_CHARGE.isDown();
        if (held) {
            boolean shiftHeld = mc.options.keyShift.isDown();
            StatsNetwork.CHANNEL.sendToServer(new StatsNetwork.OutputChargePacket(shiftHeld));
        }
    }
}
