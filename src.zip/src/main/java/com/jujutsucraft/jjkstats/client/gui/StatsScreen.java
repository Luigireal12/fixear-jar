package com.jujutsucraft.jjkstats.client.gui;

import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability.PlayerStats;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability.StatType;
import com.jujutsucraft.jjkstats.config.StatsConfig;
import com.jujutsucraft.jjkstats.network.StatsNetwork;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

public class StatsScreen extends Screen {

    private static final int PANEL_W  = 260;
    private static final int PANEL_H  = 356;
    private static final int FACE_SZ  = 28;
    private static final int HEADER_H = 74;
    private static final int ROW_H    = 36;
    private static final int MASTERY_ROW_H = 30;

    private static final int C_BG       = 0xF2080A10;
    private static final int C_HEADER   = 0xFF04060C;
    private static final int C_BORDER   = 0x33FFFFFF;
    private static final int C_DIVIDER  = 0x22FFFFFF;
    private static final int C_NAME     = 0xFFEEEEEE;
    private static final int C_GRADE    = 0xFFCC1111;
    private static final int C_LEVEL    = 0xFF7799BB;
    private static final int C_POINTS   = 0xFFFFBB00;
    private static final int C_STAT     = 0xFFCCCCCC;
    private static final int C_LVL      = 0xFF4488CC;
    private static final int C_MAXED    = 0xFFCC3333;
    private static final int C_COST     = 0xFF5588AA;
    private static final int C_CANT     = 0xFFBB3333;
    private static final int C_BONUS    = 0xFF5599AA;
    private static final int C_EXP_BG   = 0xFF0D1020;
    private static final int C_EXP_FILL = 0xFF1144AA;
    private static final int C_EXP_EDGE = 0xFF2266DD;
    private static final int C_EXP_TXT  = 0xFF6688BB;
    private static final int C_BAR_BG   = 0xFF0D1020;
    private static final int C_BAR_FILL = 0xFF1D3E7A;
    private static final int C_BAR_EDGE = 0xFF2255AA;
    private static final int C_MULT     = 0xFF886622;
    private static final int C_MULT_ACT = 0xFFFFAA00;
    private static final int C_MASTERY_TITLE = 0xFFEE6666;
    private static final int C_MASTERY_BAR_BG   = 0xFF200D0D;
    private static final int C_MASTERY_BAR_FILL = 0xFFAA1111;
    private static final int C_MASTERY_BAR_EDGE = 0xFFDD2222;
    private static final int C_MASTERY_TXT      = 0xFFCC8888;

    private PlayerStats stats;
    private double      jjkPlayerLevel;
    private boolean     hudMoveMode = false;
    private int         hudPreviewX, hudPreviewY;
    private int         multiplier  = 1; // 1-5 niveles por clic

    private Button btnStrUp, btnResUp, btnSpdUp, btnCEUp, btnHpUp;
    private Button btnMoveHud, btnConfirmHud, btnMultiplier;

    public StatsScreen() {
        super(Component.translatable("jjkstats.gui.title"));
    }

    @Override
    protected void init() {
        refreshStats();
        int px = (width - PANEL_W) / 2, py = (height - PANEL_H) / 2;
        int bx = px + PANEL_W - 28;
        int y0 = py + HEADER_H + 10;

        btnStrUp = addRenderableWidget(Button.builder(Component.literal("+"), b -> upgradeStat(StatType.STRENGTH))     .bounds(bx, y0,         22, 16).build());
        btnResUp = addRenderableWidget(Button.builder(Component.literal("+"), b -> upgradeStat(StatType.RESISTANCE))   .bounds(bx, y0+ROW_H,   22, 16).build());
        btnSpdUp = addRenderableWidget(Button.builder(Component.literal("+"), b -> upgradeStat(StatType.SPEED))        .bounds(bx, y0+ROW_H*2, 22, 16).build());
        btnCEUp  = addRenderableWidget(Button.builder(Component.literal("+"), b -> upgradeStat(StatType.CURSED_ENERGY)).bounds(bx, y0+ROW_H*3, 22, 16).build());
        btnHpUp  = addRenderableWidget(Button.builder(Component.literal("+"), b -> upgradeStat(StatType.HEALTH))       .bounds(bx, y0+ROW_H*4, 22, 16).build());

        btnMultiplier = addRenderableWidget(Button.builder(
            Component.literal("x" + multiplier),
            b -> { multiplier = (multiplier % 5) + 1; b.setMessage(Component.literal("x" + multiplier)); updateButtonStates(); }
        ).bounds(px + PANEL_W - 56, py + PANEL_H - 28, 40, 18).build());

        btnMoveHud = addRenderableWidget(Button.builder(Component.literal("Mover HUD"), b -> enterHudMoveMode())
            .bounds(px + 8, py + PANEL_H - 28, 110, 18).build());
        btnConfirmHud = addRenderableWidget(Button.builder(Component.literal("Confirmar"), b -> confirmHudPosition())
            .bounds(px + PANEL_W - 118, py + PANEL_H - 28, 110, 18).build());
        btnConfirmHud.visible = false;
        updateButtonStates();
    }

    private void refreshStats() {
        if (minecraft == null || minecraft.player == null) return;
        stats          = PlayerStatsCapability.get(minecraft.player).orElse(new PlayerStats());
        jjkPlayerLevel = Math.max(1.0, stats.playerLevel);
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float pt) {
        renderBackground(gfx);
        refreshStats();
        int px = (width - PANEL_W) / 2, py = (height - PANEL_H) / 2;
        drawPanel (gfx, px, py);
        drawHeader(gfx, px, py);
        drawLine  (gfx, px, py + HEADER_H, PANEL_W);
        drawStats (gfx, px, py);
        drawLine  (gfx, px, py + PANEL_H - 34, PANEL_W);
        if (hudMoveMode) {
            drawHudPreview(gfx);
            gfx.drawCenteredString(font, Component.literal("\u00a7eClic para colocar el HUD"), width/2, py-14, 0xFFFFFFFF);
        }
        super.render(gfx, mouseX, mouseY, pt);
    }

    private void drawPanel(GuiGraphics gfx, int px, int py) {
        gfx.fill(px, py, px+PANEL_W, py+PANEL_H, C_BG);
        gfx.fill(px, py, px+PANEL_W, py+1, C_BORDER);
        gfx.fill(px, py+PANEL_H-1, px+PANEL_W, py+PANEL_H, C_BORDER);
        gfx.fill(px, py, px+1, py+PANEL_H, C_BORDER);
        gfx.fill(px+PANEL_W-1, py, px+PANEL_W, py+PANEL_H, C_BORDER);
    }

    private void drawLine(GuiGraphics gfx, int px, int y, int w) {
        gfx.fill(px+8, y, px+w-8, y+1, C_DIVIDER);
    }

    private void drawHeader(GuiGraphics gfx, int px, int py) {
        gfx.fill(px+1, py+1, px+PANEL_W-1, py+HEADER_H, C_HEADER);
        if (minecraft != null && minecraft.player != null) {
            var skin = minecraft.player.getSkinTextureLocation();
            int fx = px+10, fy = py+10;
            RenderSystem.enableBlend();
            gfx.blit(skin, fx, fy, FACE_SZ, FACE_SZ,  8f, 8f, 8, 8, 64, 64);
            gfx.blit(skin, fx, fy, FACE_SZ, FACE_SZ, 40f, 8f, 8, 8, 64, 64);
            RenderSystem.disableBlend();
        }
        int tx = px+10+FACE_SZ+10, ty = py+10;
        String name = (minecraft != null && minecraft.player != null)
            ? minecraft.player.getGameProfile().getName() : "?";
        gfx.drawString(font, name, tx, ty,      C_NAME,   false);
        gfx.drawString(font, StatsConfig.getGradeName(jjkPlayerLevel), tx, ty+11, C_GRADE,  false);
        gfx.drawString(font, "Nv. " + (stats != null ? stats.fillCount : 0), tx, ty+22, C_LEVEL,  false);
        String pts = "Puntos: " + (stats != null ? stats.statPoints : 0);
        gfx.drawString(font, pts, px+PANEL_W-font.width(pts)-10, ty+22, C_POINTS, false);

        int barX = px+10, barY = py+HEADER_H-14, barW = PANEL_W-20, barH = 6;
        float pct = (stats != null && stats.expToNextFill > 0)
            ? Mth.clamp((float)stats.currentExp/stats.expToNextFill, 0f, 1f) : 0f;
        gfx.fill(barX, barY, barX+barW, barY+barH, C_EXP_BG);
        int filled = (int)(barW*pct);
        if (filled > 0) {
            gfx.fill(barX, barY, barX+filled, barY+1, C_EXP_EDGE);
            gfx.fill(barX, barY+1, barX+filled, barY+barH, C_EXP_FILL);
        }
        String expTxt = stats != null
            ? fmt(stats.currentExp) + " / " + fmt(stats.expToNextFill) + " EXP" : "0 / 0 EXP";
        gfx.drawCenteredString(font, Component.literal(expTxt), px+PANEL_W/2, barY-9, C_EXP_TXT);
    }

    private void drawStats(GuiGraphics gfx, int px, int py) {
        int y0    = py + HEADER_H + 10;
        int cap   = Math.max(1, StatsConfig.getCumulativeCap(jjkPlayerLevel));
        int hpCap = Math.max(1, StatsConfig.getHealthCap(jjkPlayerLevel));
        drawStatRow(gfx, "Fuerza Fisica",   stats != null ? stats.strengthLevel     : 0, StatType.STRENGTH,      px, y0,         cap);
        drawStatRow(gfx, "Resistencia",     stats != null ? stats.resistanceLevel   : 0, StatType.RESISTANCE,    px, y0+ROW_H,   cap);
        drawStatRow(gfx, "Velocidad",       stats != null ? stats.speedLevel        : 0, StatType.SPEED,         px, y0+ROW_H*2, cap);
        drawStatRow(gfx, "Energia Maldita", stats != null ? stats.cursedEnergyLevel : 0, StatType.CURSED_ENERGY, px, y0+ROW_H*3, cap);
        drawStatRow(gfx, "Vida Maxima",     stats != null ? stats.healthLevel       : 0, StatType.HEALTH,        px, y0+ROW_H*4, hpCap);
        drawMasteryRow(gfx, px, y0+ROW_H*5);
    }

    private void drawMasteryRow(GuiGraphics gfx, int px, int y) {
        int left  = px + 10, right = px + PANEL_W - 32;
        double pct = stats != null ? stats.blackFlashMasteryPercent : -1.0;
        double cap = stats != null ? stats.blackFlashMasteryCapPercent : 0.0;

        gfx.drawString(font, "Maestria Black Flash", left, y+2, C_MASTERY_TITLE, false);
        if (pct >= 0.0) {
            String pctStr = String.format("%.2f%% / %.2f%%", pct, cap);
            gfx.drawString(font, pctStr, right - font.width(pctStr), y+2, C_MASTERY_TXT, false);
        }

        int barX = left, barY = y+13, barW = PANEL_W-46, barH = 4;
        gfx.fill(barX, barY, barX+barW, barY+barH, C_MASTERY_BAR_BG);
        if (pct > 0.0 && cap > 0.0) {
            int fp = (int)(barW * Mth.clamp((float)(pct / cap), 0f, 1f));
            if (fp > 0) {
                gfx.fill(barX, barY, barX+fp, barY+1, C_MASTERY_BAR_EDGE);
                gfx.fill(barX, barY+1, barX+fp, barY+barH, C_MASTERY_BAR_FILL);
            }
        }
    }

    private void drawStatRow(GuiGraphics gfx, String name, int level, StatType type, int px, int y, int rowCap) {
        boolean maxed = level >= rowCap;
        int left  = px + 10, right = px + PANEL_W - 32;

        gfx.drawString(font, name, left, y+2, maxed ? C_MAXED : C_STAT, false);
        String lvl = level + " / " + rowCap;
        gfx.drawString(font, lvl, right - font.width(lvl), y+2, C_LVL, false);

        if (maxed) {
            gfx.drawString(font, "Maximo alcanzado", left, y+13, C_MAXED, false);
        } else if (stats != null) {
            int cost = stats.getUpgradeCost(type, level);
            // Mostrar costo total si multiplier > 1
            int totalCost = 0;
            int tempLevel = level;
            for (int i = 0; i < multiplier && tempLevel < rowCap; i++) {
                totalCost += stats.getUpgradeCost(type, tempLevel);
                tempLevel++;
            }
            boolean afford = stats.statPoints >= totalCost;
            String costStr = multiplier > 1
                ? "Subir x" + Math.min(multiplier, rowCap - level) + ": " + totalCost + " pts"
                : "Subir nivel: " + cost + " pts";
            gfx.drawString(font, costStr, left, y+13, afford ? C_COST : C_CANT, false);
        }

        String bonus = bonusText(type, level);
        if (bonus != null)
            gfx.drawString(font, bonus, right - font.width(bonus), y+13, C_BONUS, false);

        int barX = left, barY = y+26, barW = PANEL_W-46, barH = 4;
        gfx.fill(barX, barY, barX+barW, barY+barH, C_BAR_BG);
        if (rowCap > 0 && level > 0) {
            int fp = (int)(barW * ((float)level / rowCap));
            if (fp > 0) {
                gfx.fill(barX, barY, barX+fp, barY+1, C_BAR_EDGE);
                gfx.fill(barX, barY+1, barX+fp, barY+barH, maxed ? C_MAXED : C_BAR_FILL);
            }
        }
    }

    private String bonusText(StatType type, int level) {
        if (level <= 0) return null;
        return switch (type) {
            case STRENGTH   -> String.format("+%.1f dmg", StatsConfig.computeStrengthDamage(level));
            case RESISTANCE -> String.format("-%.1f%% da\u00f1o", StatsConfig.computeResistancePct(level));
            default         -> null;
        };
    }

    private void drawHudPreview(GuiGraphics gfx) {
        int bw = StatsConfig.HUD_EXP_BAR_WIDTH.get(), bh = StatsConfig.HUD_EXP_BAR_HEIGHT.get();
        float pct = (stats != null && stats.expToNextFill > 0)
            ? Mth.clamp((float)stats.currentExp/stats.expToNextFill, 0f, 1f) : 0.4f;
        gfx.fill(hudPreviewX-1, hudPreviewY-1, hudPreviewX+bw+1, hudPreviewY+bh+1, C_BORDER);
        gfx.fill(hudPreviewX, hudPreviewY, hudPreviewX+bw, hudPreviewY+bh, C_EXP_BG);
        gfx.fill(hudPreviewX, hudPreviewY, hudPreviewX+(int)(bw*pct), hudPreviewY+bh, C_EXP_FILL);
    }

    private void enterHudMoveMode() {
        hudMoveMode = true;
        hudPreviewX = stats != null && stats.hudX >= 0 ? stats.hudX : (width - StatsConfig.HUD_EXP_BAR_WIDTH.get())/2;
        hudPreviewY = stats != null && stats.hudY >= 0 ? stats.hudY : StatsConfig.HUD_EXP_BAR_Y.get();
        btnMoveHud.visible = false; btnConfirmHud.visible = true; btnMultiplier.visible = false;
    }

    private void confirmHudPosition() {
        hudMoveMode = false;
        btnMoveHud.visible = true; btnConfirmHud.visible = false; btnMultiplier.visible = true;
        StatsNetwork.CHANNEL.sendToServer(new StatsNetwork.SaveHudPositionPacket(hudPreviewX, hudPreviewY));
        if (stats != null) { stats.hudX = hudPreviewX; stats.hudY = hudPreviewY; }
    }

    @Override
    public void mouseMoved(double mx, double my) {
        if (hudMoveMode) {
            int bw = StatsConfig.HUD_EXP_BAR_WIDTH.get(), bh = StatsConfig.HUD_EXP_BAR_HEIGHT.get();
            hudPreviewX = Mth.clamp((int)mx-bw/2, 0, width-bw);
            hudPreviewY = Mth.clamp((int)my-bh/2, 0, height-20);
        }
        super.mouseMoved(mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (hudMoveMode && button == 0) { confirmHudPosition(); return true; }
        return super.mouseClicked(mx, my, button);
    }

    private void upgradeStat(StatType stat) {
        StatsNetwork.CHANNEL.sendToServer(new StatsNetwork.UpgradeStatPacket(stat, multiplier));
    }

    private void updateButtonStates() {
        if (stats == null) return;
        btnStrUp.active = canUpgrade(StatType.STRENGTH);
        btnResUp.active = canUpgrade(StatType.RESISTANCE);
        btnSpdUp.active = canUpgrade(StatType.SPEED);
        btnCEUp.active  = canUpgrade(StatType.CURSED_ENERGY);
        btnHpUp.active  = canUpgrade(StatType.HEALTH);
    }

    private boolean canUpgrade(StatType stat) {
        if (stats == null) return false;
        int cap   = (stat == StatType.HEALTH)
            ? Math.max(1, StatsConfig.getHealthCap(jjkPlayerLevel))
            : Math.max(1, StatsConfig.getCumulativeCap(jjkPlayerLevel));
        int level = stats.getStatLevel(stat);
        if (level >= cap) return false;
        // Verificar si puede pagar al menos 1 nivel
        return stats.statPoints >= stats.getUpgradeCost(stat, level);
    }

    @Override public void tick()             { super.tick(); updateButtonStates(); }
    @Override public boolean isPauseScreen() { return false; }

    private static String fmt(long v) {
        if (v >= 1_000_000) return String.format("%.1fM", v/1_000_000.0);
        if (v >= 1_000)     return String.format("%.1fk", v/1_000.0);
        return String.valueOf(v);
    }
}
