package com.jujutsucraft.jjkstats.client.hud;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability;
import com.jujutsucraft.jjkstats.config.StatsConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ExpBarHud {

    private static final int COLOR_BG      = 0xAA0D0D1A;
    private static final int COLOR_FILL    = 0xFF5A3AFF;
    private static final int COLOR_FILL_HI = 0xFF8A6AFF;
    private static final int COLOR_BORDER  = 0xFF333355;
    private static final int COLOR_TEXT    = 0xFFBBBBFF;

    @SubscribeEvent
    public static void onRenderGuiOverlay(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.EXPERIENCE_BAR.type()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;

        PlayerStatsCapability.get(mc.player).ifPresent(stats -> {
            int screenW = event.getWindow().getGuiScaledWidth();

            int barW = StatsConfig.HUD_EXP_BAR_WIDTH.get();
            int barH = StatsConfig.HUD_EXP_BAR_HEIGHT.get();

            int barX = stats.hudX >= 0
                ? stats.hudX
                : (StatsConfig.HUD_EXP_BAR_X.get() >= 0
                    ? StatsConfig.HUD_EXP_BAR_X.get()
                    : (screenW - barW) / 2);
            int barY = stats.hudY >= 0
                ? stats.hudY
                : StatsConfig.HUD_EXP_BAR_Y.get();

            float pct = stats.expToNextFill > 0
                ? (float) stats.currentExp / stats.expToNextFill : 0f;
            pct = Mth.clamp(pct, 0f, 1f);

            var gfx = event.getGuiGraphics();

            gfx.fill(barX - 1, barY - 1, barX + barW + 1, barY + barH + 1, COLOR_BORDER);
            gfx.fill(barX, barY, barX + barW, barY + barH, COLOR_BG);

            int filled = (int)(barW * pct);
            if (filled > 0) {
                gfx.fill(barX, barY,     barX + filled, barY + 1,    COLOR_FILL_HI);
                gfx.fill(barX, barY + 1, barX + filled, barY + barH, COLOR_FILL);
            }

            if (barH >= 7) {
                String txt = "Nv." + stats.fillCount + "  " + stats.currentExp + "/" + stats.expToNextFill;
                int tx = barX + barW / 2 - mc.font.width(txt) / 2;
                gfx.drawString(mc.font, txt, tx, barY + 1, COLOR_TEXT, true);
            }
        });
    }
}
