package com.jujutsucraft.jjkstats.client;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Maneja la vibración del título de Black Flash en el cliente.
 * Intercepta el render del overlay de título y aplica un offset
 * oscilante usando seno/coseno para crear el efecto de vibración.
 */
@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class BlackFlashClientHandler {

    private static long   shakeStartMs  = 0;
    private static int    shakeDurationMs = 0;
    private static float  shakeAmplitude  = 0;
    private static float  shakeFrequency  = 0;

    /** Llamado desde BlackFlashEffectPacket al recibir el paquete del servidor. */
    public static void activateShake(int intensity, int durationTicks, int frequency) {
        shakeStartMs    = System.currentTimeMillis();
        shakeDurationMs = durationTicks * 50; // ticks → ms (1 tick = 50ms)
        shakeAmplitude  = intensity;
        shakeFrequency  = frequency;
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onTitleRenderPre(RenderGuiOverlayEvent.Pre event) {
        if (event.getOverlay() != VanillaGuiOverlay.TITLE_TEXT.type()) return;
        if (shakeDurationMs <= 0) return;

        long elapsed = System.currentTimeMillis() - shakeStartMs;
        if (elapsed >= shakeDurationMs) {
            shakeDurationMs = 0;
            return;
        }

        // Progreso de 0→1 a medida que pasa el tiempo (la amplitud decrece)
        float progress  = elapsed / (float) shakeDurationMs;
        float amplitude = shakeAmplitude * (1f - progress); // decrece suavemente

        // Oscilación en X e Y con frecuencias ligeramente distintas
        double t = elapsed / 1000.0 * shakeFrequency;
        float offsetX = (float)(Math.sin(t * Math.PI * 2)          * amplitude);
        float offsetY = (float)(Math.sin(t * Math.PI * 2 * 1.37)   * amplitude * 0.5f);

        // Aplicar transform al PoseStack del GuiGraphics
        PoseStack pose = event.getGuiGraphics().pose();
        pose.pushPose();
        pose.translate(offsetX, offsetY, 0);
    }

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onTitleRenderPost(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.TITLE_TEXT.type()) return;
        if (shakeDurationMs <= 0) return;

        long elapsed = System.currentTimeMillis() - shakeStartMs;
        if (elapsed < shakeDurationMs) {
            event.getGuiGraphics().pose().popPose();
        }
    }
}
