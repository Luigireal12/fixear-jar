package com.jujutsucraft.jjkstats.mastery;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.network.StatsNetwork;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * La maestría de Black Flash vive en JoQu, un addon externo sin dependencia
 * de compilación con stats (ver JoquMasteryReader). stats solo sincroniza su
 * propio estado al cliente cuando algo del PROPIO stats cambia (subir un
 * stat, abrir el HUD, comandos) — nunca cuando cambia algo de JoQu (farmear
 * maestría peleando, usar /blackflashchance, cambiar de Curse Technique).
 *
 * Esto hace polling cada 20 ticks (1s, mismo intervalo que
 * Jjsk4BlackFlashChanceBridge del lado JoQu) comparando la maestría actual
 * contra la última sincronizada; si cambió, dispara una resincronización al
 * cliente sin que el jugador tenga que salir y volver a entrar al mundo.
 */
@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class MasteryTickSync {

    private MasteryTickSync() {
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (event.player.level().isClientSide()) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.tickCount % 20 != 0) return;

        var mastery = JoquMasteryReader.readFor(player);

        var data = player.getPersistentData();
        String lastKey = "jjkstats_last_synced_mastery";
        String currentSignature = mastery.ctId() + ":" + mastery.totalPercent() + ":" + mastery.capPercent();
        String lastSignature = data.getString(lastKey);

        if (!currentSignature.equals(lastSignature)) {
            data.putString(lastKey, currentSignature);
            StatsNetwork.syncToClient(player);
        }

        // Asegura que el espejo de outputPercent en NBT plano (que JoQu lee
        // para el sistema de Output 120%) esté siempre al día, incluso recién
        // logueado, antes de que el jugador toque la tecla de carga por
        // primera vez en esta sesión.
        com.jujutsucraft.jjkstats.capability.PlayerStatsCapability.get(player).ifPresent(stats -> {
            int mirrored = data.getInt("jjkstats_output_percent_mirror");
            if (mirrored != stats.outputPercent) {
                data.putInt("jjkstats_output_percent_mirror", stats.outputPercent);
            }
        });

        // Resincroniza al cliente si el estado de Output 120% (que vive en
        // JoQu y cambia con cada Black Flash, fuera de cualquier evento
        // propio de stats) cambió desde la última vez que se notó.
        long activeUntilTick = data.getLong("jjkbrp_output120_active_until_tick");
        boolean output120ActiveNow = player.level().getGameTime() < activeUntilTick;
        int progressNow = data.getInt("jjkbrp_output120_progress_count");
        String output120Signature = output120ActiveNow + ":" + progressNow;
        String lastOutput120Signature = data.getString("jjkstats_last_synced_output120");
        if (!output120Signature.equals(lastOutput120Signature)) {
            data.putString("jjkstats_last_synced_output120", output120Signature);
            StatsNetwork.syncToClient(player);
        }
    }
}
