package com.jujutsucraft.jjkstats.mastery;

import net.mcreator.jujutsucraft.network.JujutsucraftModVariables;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Lee el % de maestría de Black Flash del jugador combinando dos fuentes,
 * sin que stats dependa de JoQu como librería (JoQu no está en el classpath
 * de compilación de este addon):
 *
 *   1. El % base y el límite (cap) por Curse Technique, leídos directamente
 *      del archivo config/jjkblueredpurple-mastery.toml de JoQu. Si JoQu
 *      cambia esos NÚMEROS (editando el .toml a mano), stats los lee tal
 *      cual, sin necesitar ningún cambio de código.
 *   2. El % farmeado actual del jugador, leído de su NBT persistente
 *      (jjkbrp_mastery_ct_<id>), que es donde JoQu lo guarda — el NBT del
 *      jugador es estándar de Minecraft, visible para cualquier mod sin
 *      necesitar dependencia de compilación.
 *
 * Si el .toml de JoQu no existe (JoQu no instalado) este lector usa el %
 * base genérico (0.2%) y el límite global default (35%) como fallback, para
 * que la barra siga mostrando algo razonable en vez de romperse.
 */
public final class JoquMasteryReader {

    private JoquMasteryReader() {
    }

    private static final String TOML_FILE = "jjkblueredpurple-mastery.toml";
    private static final double FALLBACK_BASE = 0.2;
    private static final double FALLBACK_GLOBAL_CAP = 35.0;

    private static long lastLoadAttemptMs = 0;
    private static long cachedFileLastModified = -1;
    private static Map<Integer, double[]> cachedCtTable = null; // ctId -> [basePercent, capPercent(-1=global)]
    private static double cachedGlobalCap = FALLBACK_GLOBAL_CAP;
    private static String cachedTomlPath = null;

    public record MasteryInfo(double totalPercent, double capPercent, int ctId) {
    }

    public static MasteryInfo readFor(ServerPlayer player) {
        int ctId = activeCtId(player);
        reloadIfStale();

        double base = FALLBACK_BASE;
        double cap = cachedGlobalCap;
        if (cachedCtTable != null && cachedCtTable.containsKey(ctId)) {
            double[] entry = cachedCtTable.get(ctId);
            base = entry[0];
            cap = entry[1] >= 0.0 ? entry[1] : cachedGlobalCap;
        }

        double farmed = player.getPersistentData().getDouble("jjkbrp_mastery_ct_" + ctId);
        double total = Math.min(base + farmed, Math.max(base, cap));
        return new MasteryInfo(total, cap, ctId);
    }

    private static int activeCtId(ServerPlayer player) {
        JujutsucraftModVariables.PlayerVariables vars = player
            .getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null)
            .orElse(new JujutsucraftModVariables.PlayerVariables());
        double activeTech = vars.SecondTechnique ? vars.PlayerCurseTechnique2 : vars.PlayerCurseTechnique;
        return (int) Math.round(activeTech);
    }

    // ── Lectura del .toml de JoQu ───────────────────────────────────────────

    private static void reloadIfStale() {
        long now = System.currentTimeMillis();
        if (now - lastLoadAttemptMs < 5000 && cachedCtTable != null) {
            return; // no re-intentar más de una vez cada 5s
        }
        lastLoadAttemptMs = now;

        Path configPath = resolveConfigPath();
        if (configPath == null || !Files.exists(configPath)) {
            cachedCtTable = null;
            return;
        }

        try {
            long modified = Files.getLastModifiedTime(configPath).toMillis();
            if (cachedCtTable != null && modified == cachedFileLastModified) {
                return; // sin cambios desde la última lectura
            }
            cachedFileLastModified = modified;
            parseToml(configPath);
        } catch (IOException ignored) {
            cachedCtTable = null;
        }
    }

    private static Path resolveConfigPath() {
        if (cachedTomlPath != null) {
            return Path.of(cachedTomlPath);
        }
        Path candidate = net.minecraftforge.fml.loading.FMLPaths.CONFIGDIR.get().resolve(TOML_FILE);
        cachedTomlPath = candidate.toString();
        return candidate;
    }

    // Parser TOML minimalista: solo necesita "key = value" dentro de secciones
    // [ct_<id>_xxx], que es exactamente lo que MasteryConfig.java de JoQu
    // genera. No es un parser TOML general, es deliberadamente simple porque
    // solo necesita leer ESTE archivo con ESTE formato conocido.
    private static final Pattern SECTION = Pattern.compile("^\\s*\\[curse_techniques\\.ct_(\\d+)_[a-z0-9_]*]\\s*$");
    private static final Pattern BASE_KV = Pattern.compile("^\\s*base_percent\\s*=\\s*([0-9.]+)\\s*$");
    private static final Pattern CAP_KV = Pattern.compile("^\\s*cap_percent\\s*=\\s*(-?[0-9.]+)\\s*$");
    private static final Pattern GLOBAL_CAP_KV = Pattern.compile("^\\s*global_cap_percent\\s*=\\s*([0-9.]+)\\s*$");

    private static void parseToml(Path path) throws IOException {
        Map<Integer, double[]> table = new HashMap<>();
        double globalCap = FALLBACK_GLOBAL_CAP;

        int currentCt = -1;
        double currentBase = FALLBACK_BASE;
        double currentCap = -1.0;

        for (String line : Files.readAllLines(path)) {
            Matcher sectionMatch = SECTION.matcher(line);
            if (sectionMatch.matches()) {
                if (currentCt >= 0) {
                    table.put(currentCt, new double[]{currentBase, currentCap});
                }
                currentCt = Integer.parseInt(sectionMatch.group(1));
                currentBase = FALLBACK_BASE;
                currentCap = -1.0;
                continue;
            }
            Matcher baseMatch = BASE_KV.matcher(line);
            if (baseMatch.matches()) {
                currentBase = Double.parseDouble(baseMatch.group(1));
                continue;
            }
            Matcher capMatch = CAP_KV.matcher(line);
            if (capMatch.matches()) {
                currentCap = Double.parseDouble(capMatch.group(1));
                continue;
            }
            Matcher globalMatch = GLOBAL_CAP_KV.matcher(line);
            if (globalMatch.matches()) {
                globalCap = Double.parseDouble(globalMatch.group(1));
            }
        }
        if (currentCt >= 0) {
            table.put(currentCt, new double[]{currentBase, currentCap});
        }

        cachedCtTable = table;
        cachedGlobalCap = globalCap;
    }
}
