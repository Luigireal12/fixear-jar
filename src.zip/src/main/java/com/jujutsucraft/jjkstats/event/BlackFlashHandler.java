package com.jujutsucraft.jjkstats.event;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import net.minecraftforge.fml.common.Mod;

/** Lógica de Black Flash manejada por RangeAttackProcedureMixin. */
@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class BlackFlashHandler { }
