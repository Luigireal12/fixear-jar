package com.jujutsucraft.jjkstats.event;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability;
import com.jujutsucraft.jjkstats.config.StatsConfig;
import net.mcreator.jujutsucraft.init.JujutsucraftModMobEffects;
import net.mcreator.jujutsucraft.network.JujutsucraftModVariables;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Aplica fuerza y resistencia directamente sobre el daño (LivingHurtEvent),
 * sin depender de pociones ni atributos — decisión explícita del addon para
 * que el sistema sea controlable vía código.
 *
 * El NÚMERO resultante (bono de daño, % de reducción) replica exactamente lo
 * que PlayerPhysicalAbilityProcedure (mod base) daría a través de los efectos
 * vanilla reales (Strength, Resistance), incluyendo los bonos de Curse
 * Technique (Itadori, Sukuna) que ese procedure aplica sobre el "level" antes
 * de derivar esos efectos.
 *
 * El stat farmeado en este addon (0 hasta el cap de cada grado) NO es la
 * misma escala que el PlayerLevel real del mod base (0-20). Se traduce con
 * StatsConfig.statLevelToEffectivePlayerLevel: tener el stat al tope de tu
 * grado actual equivale exactamente al PlayerLevel real de ese grado.
 */
@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class DamageHandler {

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onLivingHurt(LivingHurtEvent event) {
        try {
            if (event.getEntity() instanceof ServerPlayer defender) {
                applyResistance(event, defender);
            }

            if (event.getSource().getEntity() instanceof ServerPlayer attacker) {
                applyStrength(event, attacker);
            }
        } catch (Exception e) {
            JJKStatsMod.LOGGER.warn("[JJKStats] Error en DamageHandler: {}", e.getMessage());
        }
    }

    private static void applyStrength(LivingHurtEvent event, ServerPlayer player) {
        PlayerStatsCapability.get(player).ifPresent(stats -> {
            if (stats.strengthLevel <= 0) return;

            double effectiveLevel = jjkblueredpurple$applyCtLevelBonus(player, stats.strengthLevel);
            double bonus = StatsConfig.computeStrengthDamage(effectiveLevel);
            if (bonus <= 0.0) return;

            // El % de output (5-100%, ver OutputHandler) escala el bono real de
            // fuerza: con output al 100% se comporta igual que antes de existir
            // este sistema; por debajo de eso, el jugador deliberadamente está
            // usando menos de su fuerza farmeada.
            bonus *= com.jujutsucraft.jjkstats.event.OutputHandler.outputFactor(stats);

            // Bono de Output 120% (vive en JoQu, leído vía espejo en NBT plano:
            // ver net.mcreator.jujutsucraft.addon.mastery.Output120Handler).
            // Medido en ticks del mundo (level.getGameTime()), no milisegundos ni player.tickCount.
            long activeUntilTick = player.getPersistentData().getLong("jjkbrp_output120_active_until_tick");
            if (player.level().getGameTime() < activeUntilTick) {
                double output120DamageBonus = player.getPersistentData().contains("jjkbrp_output120_damage_bonus_mirror")
                    ? player.getPersistentData().getDouble("jjkbrp_output120_damage_bonus_mirror")
                    : 0.20;
                bonus *= (1.0 + output120DamageBonus);
            }

            float cooldownScale = player.getAttackStrengthScale(0.5f);
            event.setAmount((float) (event.getAmount() + bonus * cooldownScale));
        });
    }

    private static void applyResistance(LivingHurtEvent event, ServerPlayer player) {
        PlayerStatsCapability.get(player).ifPresent(stats -> {
            if (stats.resistanceLevel <= 0) return;

            double effectiveLevel = jjkblueredpurple$applyCtLevelBonus(player, stats.resistanceLevel);
            double reduction = StatsConfig.computeResistancePct(effectiveLevel) / 100.0;
            if (reduction <= 0.0) return;

            reduction *= com.jujutsucraft.jjkstats.event.OutputHandler.outputFactor(stats);

            float newAmount = (float) (event.getAmount() * (1.0 - reduction));
            event.setAmount(Math.max(0f, newAmount));
        });
    }

    static double jjkblueredpurple$applyCtLevelBonus(ServerPlayer player, int farmedStatLevel) {
        double level = StatsConfig.statLevelToEffectivePlayerLevel(farmedStatLevel);

        var jjkCap = player.getCapability(
            JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, (Direction) null
        ).orElse(null);

        if (jjkblueredpurple$isItadori(jjkCap)) {
            level = Math.max(level + 3.0D, level * 1.2D);
        }

        double sukunaLevel = jjkblueredpurple$sukunaEffectiveLevel(player);
        if (sukunaLevel > 0.0) {
            level = Math.max(level, sukunaLevel);
        }

        return level;
    }

    static boolean jjkblueredpurple$isItadori(JujutsucraftModVariables.PlayerVariables jjkCap) {
        if (jjkCap == null) return false;
        return jjkCap.PlayerCurseTechnique == 21.0D || jjkCap.PlayerCurseTechnique2 == 21.0D;
    }

    static double jjkblueredpurple$sukunaEffectiveLevel(ServerPlayer player) {
        MobEffect sukunaEffect = (MobEffect) JujutsucraftModMobEffects.SUKUNA_EFFECT.get();
        if (!player.hasEffect(sukunaEffect)) return 0.0;

        double levelSukuna = Math.min(player.getEffect(sukunaEffect).getAmplifier() + 1, 20);
        if (levelSukuna <= 10.0D) {
            return 15.0D + Math.round(Math.floor(levelSukuna * 0.5D));
        } else if (levelSukuna <= 19.0D) {
            return 10.0D + Math.round(Math.floor(levelSukuna * 1.0D));
        } else {
            return 35.0D;
        }
    }
}
