package com.jujutsucraft.jjkstats.event;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability;
import com.jujutsucraft.jjkstats.network.StatsNetwork;
import net.mcreator.jujutsucraft.network.JujutsucraftModVariables;
import net.mcreator.jujutsucraft.procedures.ChargeParticleProcedure;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Sistema de "output": un % (5-100) que multiplica la fuerza/resistencia/
 * velocidad ya calculadas por DamageHandler/StatsApplyHandler (ver esos dos
 * archivos para dónde se aplica el multiplicador). Arranca en 5% — hace
 * falta cargarlo activamente hasta 100% para usar toda la fuerza farmeada.
 *
 * Mantener la tecla de output (sin Shift) sube de a 5% cada ~300ms (6s de
 * 5% a 100%); mantenerla CON Shift baja de a 5% al mismo ritmo. Soltarla
 * deja el % fijo donde esté.
 *
 * El modo turbo (+25% velocidad) es independiente del output: multiplica
 * sobre lo que el jugador tenga en ese momento, consume 50 CE/s mientras
 * está activo, y se desactiva solo si la CE llega a 0.
 *
 * Ambos modos muestran la partícula de aura del jugador (ChargeParticleProcedure,
 * mode=10.0 — la misma que ya usa el mod base para "cargar Attack al 100%",
 * con el color que el jugador tenga asignado o el default si no asignó nada).
 */
@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class OutputHandler {

    private static final int CHARGE_STEP_PERCENT = 5;
    private static final int CHARGE_STEP_MS = 300; // 5% cada 300ms -> 6s de 5% a 100%
    private static final double TURBO_CE_PER_SECOND = 50.0;
    private static final double TURBO_SPEED_BONUS = 0.25; // +25%

    private static final String KEY_LAST_CHARGE_MS = "jjkstats_output_last_charge_ms";

    /** Llamado desde OutputChargePacket cada tick mientras el jugador sostiene la tecla. */
    public static void onChargeInput(ServerPlayer player, boolean shiftHeld) {
        PlayerStatsCapability.get(player).ifPresent(stats -> {
            long now = System.currentTimeMillis();
            long lastCharge = player.getPersistentData().getLong(KEY_LAST_CHARGE_MS);
            long elapsed = now - lastCharge;

            if (elapsed < CHARGE_STEP_MS) {
                return;
            }
            player.getPersistentData().putLong(KEY_LAST_CHARGE_MS, now);

            int delta = shiftHeld ? -CHARGE_STEP_PERCENT : CHARGE_STEP_PERCENT;
            int newPercent = Math.max(5, Math.min(100, stats.outputPercent + delta));

            // Si el bono de Output 120% está activo y el jugador intenta
            // bajar el output, se cancela de inmediato: vuelve a 100% y
            // entra en cooldown (ver Output120Handler en JoQu, que lee/escribe
            // las mismas keys de NBT compartidas — no hay dependencia de
            // compilación entre los dos addons, solo el NBT del jugador).
            // Medido en TICKS de servidor, no milisegundos: el reloj de
            // pared sigue corriendo durante la pausa en singleplayer, lo
            // que hacía expirar el bono solo por tener el juego pausado.
            long output120ActiveUntilTick = player.getPersistentData().getLong("jjkbrp_output120_active_until_tick");
            boolean output120WasActive = player.level().getGameTime() < output120ActiveUntilTick;
            if (output120WasActive && shiftHeld) {
                player.getPersistentData().putLong("jjkbrp_output120_active_until_tick", 0L);
                long cooldownSeconds = player.getPersistentData().contains("jjkbrp_output120_cooldown_seconds_mirror")
                    ? player.getPersistentData().getLong("jjkbrp_output120_cooldown_seconds_mirror")
                    : 60L;
                player.getPersistentData().putLong("jjkbrp_output120_cooldown_until_tick",
                    player.level().getGameTime() + cooldownSeconds * 20L);
                newPercent = 100;
                player.displayClientMessage(
                    net.minecraft.network.chat.Component.literal("§7Output 120% perdido."), true
                );
                player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                    net.minecraft.sounds.SoundEvents.LAVA_EXTINGUISH, net.minecraft.sounds.SoundSource.PLAYERS,
                    0.8f, 1.1f);
                // BUG REAL ENCONTRADO Y CORREGIDO: esta rama maneja la
                // cancelación del 120% DIRECTAMENTE (escribiendo las mismas
                // keys NBT que Output120Handler de JoQu lee/escribe), sin
                // pasar nunca por Output120Handler.cancelIfActiveAndForceTo100
                // — por eso ese método, aunque correcto en sí mismo, nunca
                // llegaba a ejecutarse para este camino real, y el
                // MobEffect visual (output_120_active) se quedaba activo
                // aunque el bono real ya se hubiera cancelado. Se quita
                // acá también, sin import directo de la clase Java de JoQu
                // (mismo patrón sin dependencia de compilación que el resto
                // de este archivo usa para leer/escribir NBT compartido).
                net.minecraft.world.effect.MobEffect output120ActiveEffect = net.minecraftforge.registries.ForgeRegistries.MOB_EFFECTS
                    .getValue(new net.minecraft.resources.ResourceLocation("jjkblueredpurple", "output_120_active"));
                if (output120ActiveEffect != null) {
                    player.removeEffect(output120ActiveEffect);
                }
                // Avisa al cliente para que corte el fade/.ogg de música del
                // 120% (Output120MusicHandler, en JoQu). Se hace por
                // reflexión sobre un método estático simple (sin genéricos
                // de red complicados), para mantener la independencia de
                // compilación entre los dos addons (mismo patrón que
                // ForgeRegistries.MOB_EFFECTS.getValue arriba).
                try {
                    Class.forName("net.mcreator.jujutsucraft.addon.mastery.Output120Handler")
                        .getMethod("notifyMusicCancelled", ServerPlayer.class)
                        .invoke(null, player);
                } catch (Exception ignored) {
                    // JoQu no está instalado, o cambió de versión sin este método — no romper el flujo de output por esto.
                }
            }

            if (newPercent != stats.outputPercent) {
                stats.outputPercent = newPercent;
                // Espejo en NBT plano (fuera de la capability propia de stats),
                // para que otros addons (JoQu) puedan leer el output actual sin
                // depender de la clase Java de esta capability — mismo patrón
                // que Jjsk4BlackFlashChanceBridge usa para leer JJSK4.
                player.getPersistentData().putInt("jjkstats_output_percent_mirror", newPercent);
                StatsNetwork.syncToClient(player);
                // Sonido de "tic" de carga, una sola vez por escalón de 5%.
                player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                    net.minecraft.sounds.SoundEvents.BEACON_POWER_SELECT, net.minecraft.sounds.SoundSource.PLAYERS,
                    0.6f, shiftHeld ? 0.8f : 1.2f);
            }

            jjkblueredpurple$showAuraParticle(player, 4.0);
        });
    }

    /** Llamado desde TurboTogglePacket al apretar la tecla de turbo. */
    public static void onTurboToggle(ServerPlayer player) {
        PlayerStatsCapability.get(player).ifPresent(stats -> {
            if (!stats.turboActive) {
                var jjkCap = player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(null);
                if (jjkCap != null && jjkCap.PlayerCursePower <= 0.0) {
                    return;
                }
            }
            stats.turboActive = !stats.turboActive;
            StatsNetwork.syncToClient(player);
        });
    }

    /** Tickea el consumo de CE del turbo, y lo apaga solo si la CE se agota. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (event.player.level().isClientSide()) return;
        if (!(event.player instanceof ServerPlayer player)) return;

        PlayerStatsCapability.get(player).ifPresent(stats -> {
            if (!stats.turboActive) return;

            // BEACON_AMBIENT dura varios segundos; como playSound con
            // coordenadas fijas NO sigue al jugador mientras se mueve (no es
            // un MovingSound), un sonido largo se queda sonando atrás cuando
            // el jugador avanza. Repetirlo cada 20 ticks (1s) en la posición
            // ACTUAL del jugador reancla el sonido seguido, así nunca llega a
            // sentirse muy desfasado aunque técnicamente no "siga" en tiempo real.
            if (player.tickCount % 20 == 0) {
                player.level().playSound(null, player.getX(), player.getY(), player.getZ(),
                    net.minecraft.sounds.SoundEvents.BEACON_AMBIENT, net.minecraft.sounds.SoundSource.PLAYERS,
                    0.4f, 1.4f);
            }

            var jjkCap = player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(null);
            if (jjkCap == null) return;

            double drainPerTick = TURBO_CE_PER_SECOND / 20.0;
            double newCe = jjkCap.PlayerCursePower - drainPerTick;
            if (newCe <= 0.0) {
                jjkCap.PlayerCursePower = 0.0;
                jjkCap.syncPlayerVariables(player);
                stats.turboActive = false;
                StatsNetwork.syncToClient(player);
                return;
            }
            jjkCap.PlayerCursePower = newCe;
            jjkCap.syncPlayerVariables(player);

            jjkblueredpurple$showAuraParticle(player, 1.0);
        });
    }

    /** El multiplicador de velocidad que el turbo aporta, +25% sobre lo que ya tenga el jugador en ese momento. Solo se aplica si turboActive. */
    public static double turboSpeedMultiplier(PlayerStatsCapability.PlayerStats stats) {
        return stats.turboActive ? (1.0 + TURBO_SPEED_BONUS) : 1.0;
    }

    /** El factor de output (0.05 a 1.0) que multiplica fuerza/resistencia/velocidad ya calculadas. */
    public static double outputFactor(PlayerStatsCapability.PlayerStats stats) {
        return Math.max(5, Math.min(100, stats.outputPercent)) / 100.0;
    }

    /**
     * Reimplementa el modo 10.0 de ChargeParticleProcedure (mod base), con
     * dos diferencias respecto al original: usa el color real elegido en el
     * changer de JujutsuCraftV (1-27, no solo 1-5) y oculta la partícula en
     * primera persona para el propio jugador.
     *
     * El packet se manda a TODOS los jugadores cercanos sin excluir a nadie
     * (ver StatsNetwork.AuraParticlePacket) — la exclusión de primera
     * persona se decide en cada CLIENTE comparando su propia cámara y UUID,
     * no a nivel de red. Esto es necesario porque el jugador sí debe ver su
     * propia aura cuando está en tercera persona (F5), así que no se puede
     * resolver con una exclusión de red fija.
     */
    private static void jjkblueredpurple$showAuraParticle(ServerPlayer player, double countMultiplier) {
        try {
            double selectColor = net.mcreator.jujutsucraft.procedures.ReturnEnergyColorProcedure.execute(player);
            double entitySize = net.mcreator.jujutsucraft.procedures.ReturnEntitySizeProcedure.execute(player);
            int colorId = (int) selectColor;
            int count = (int) (countMultiplier * entitySize);

            double x = player.getX();
            double y = player.getY() + player.getBbHeight() * 0.5;
            double z = player.getZ();
            double spreadXZ = player.getBbWidth() * 0.5;
            double spreadY = player.getBbHeight() * 0.5;

            StatsNetwork.CHANNEL.send(
                net.minecraftforge.network.PacketDistributor.NEAR.with(
                    () -> new net.minecraftforge.network.PacketDistributor.TargetPoint(
                        x, y, z, 32.0, player.level().dimension()
                    )
                ),
                new StatsNetwork.AuraParticlePacket(player.getUUID(), colorId, x, y, z, spreadXZ, spreadY, count)
            );
        } catch (Exception e) {
            JJKStatsMod.LOGGER.warn("[JJKStats] Error mostrando particula de aura: {}", e.getMessage());
        }
    }
}
