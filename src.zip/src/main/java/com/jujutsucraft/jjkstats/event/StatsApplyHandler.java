package com.jujutsucraft.jjkstats.event;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability.PlayerStats;
import com.jujutsucraft.jjkstats.config.StatsConfig;
import com.jujutsucraft.jjkstats.network.StatsNetwork;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.resources.ResourceLocation;

@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class StatsApplyHandler {

    private static final UUID UUID_HEALTH = UUID.fromString("3a3a3a3a-bbbb-cccc-dddd-eeeeeeeeeeee");

    /** Backup de stats guardado al morir, para restaurar en Clone event. */
    private static final Map<UUID, CompoundTag> deathBackup = new ConcurrentHashMap<>();

    /** Rampa de velocidad por jugador. */
    private static final Map<UUID, Integer> speedRamps = new ConcurrentHashMap<>();

    /**
     * Último world conocido por jugador (ResourceLocation del dimension key).
     * Se usa para detectar cambios de world hechos por plugins de Bukkit
     * (PhantomWorlds, CMI, etc.) que NO disparan PlayerEvent.Clone ni
     * PlayerChangedDimensionEvent de Forge.
     */
    private static final Map<UUID, ResourceLocation> lastKnownWorld = new ConcurrentHashMap<>();

    // ── Muerte y respawn ──────────────────────────────────────────────────────

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onPlayerDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PlayerStatsCapability.get(player).ifPresent(stats -> {
            deathBackup.put(player.getUUID(), stats.serializeNBT());
            JJKStatsMod.LOGGER.info("[JJKStats] Backup guardado para {}", player.getName().getString());
        });
    }

    @SubscribeEvent
    public static void onPlayerClone(PlayerEvent.Clone event) {
        if (!event.isWasDeath()) return;
        UUID id = event.getOriginal().getUUID();

        // Restaurar desde backup guardado en LivingDeathEvent
        CompoundTag backup = deathBackup.remove(id);
        if (backup != null) {
            PlayerStatsCapability.get(event.getEntity()).ifPresent(newStats -> {
                newStats.deserializeNBT(backup);
                JJKStatsMod.LOGGER.info("[JJKStats] Stats restauradas tras muerte para {}", id);
            });
        } else {
            // Fallback: intentar copiar desde capability original
            event.getOriginal().reviveCaps();
            try {
                PlayerStatsCapability.get(event.getOriginal()).ifPresent(old -> {
                    CompoundTag tag = old.serializeNBT();
                    PlayerStatsCapability.get(event.getEntity()).ifPresent(n -> n.deserializeNBT(tag));
                });
            } catch (Exception e) {
                JJKStatsMod.LOGGER.error("[JJKStats] Error en clone fallback: {}", e.getMessage());
            } finally {
                event.getOriginal().invalidateCaps();
            }
        }
        speedRamps.remove(id);
    }

    @SubscribeEvent
    public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        lastKnownWorld.remove(event.getEntity().getUUID());
        speedRamps.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PlayerStatsCapability.get(player).ifPresent(stats -> {
            applyAll(player, stats);
            StatsNetwork.syncToClient(player);
        });
    }

    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        PlayerStatsCapability.get(player).ifPresent(stats -> {
            double playerLevel = getPlayerLevel(player);
            enforceGradeCaps(player, stats, playerLevel);
            stats.playerLevel = playerLevel;
            applyAll(player, stats);
            StatsNetwork.syncToClient(player);
        });
    }

    // ── Tick ─────────────────────────────────────────────────────────────────

    @SubscribeEvent
    public static void onPlayerTick(net.minecraftforge.event.TickEvent.PlayerTickEvent event) {
        if (event.phase != net.minecraftforge.event.TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;

        // ── Detección de cambio de world por plugin de Bukkit ─────────────────
        // PhantomWorlds, CMI, /tpworld y similares teleportean al jugador entre
        // worlds usando la API de Bukkit. Esto NO dispara PlayerEvent.Clone ni
        // PlayerChangedDimensionEvent de Forge: el objeto ServerPlayer es el
        // mismo, pero player.level() cambia. Comparando el dimension key entre
        // ticks detectamos el cambio sin depender de ningún evento ni de Bukkit.
        ResourceLocation currentWorld = player.level().dimension().location();
        UUID pid = player.getUUID();
        ResourceLocation prevWorld = lastKnownWorld.put(pid, currentWorld);
        if (prevWorld != null && !prevWorld.equals(currentWorld)) {
            // El jugador acaba de cambiar de world. Re-aplicar todo y sincronizar.
            // getPlayerLevel() ya es correcto porque el player object no se recreó.
            PlayerStatsCapability.get(player).ifPresent(stats -> {
                double lvl = getPlayerLevel(player);
                stats.playerLevel = lvl;
                enforceGradeCaps(player, stats, lvl);
                applyAll(player, stats);
                StatsNetwork.syncToClient(player);
                JJKStatsMod.LOGGER.info("[JJKStats] World cambiado ({} → {}), stats re-aplicadas para {}",
                    prevWorld.getPath(), currentWorld.getPath(), player.getName().getString());
            });
            speedRamps.remove(pid);
            return;
        }

        PlayerStatsCapability.get(player).ifPresent(stats -> {
            double playerLevel = getPlayerLevel(player);

            // Detectar degradación de grado
            if (stats.playerLevel > 0 && playerLevel < stats.playerLevel) {
                enforceGradeCaps(player, stats, playerLevel);
            }
            if (stats.playerLevel != playerLevel) {
                stats.playerLevel = playerLevel;
                StatsNetwork.syncToClient(player);
            }

            // Velocidad: rampa cada 2 ticks
            if (player.tickCount % 2 == 0) {
                updateSpeed(player, stats);
            }
        });
    }

    // ── enforceGradeCaps ─────────────────────────────────────────────────────

    private static void enforceGradeCaps(ServerPlayer player, PlayerStats stats, double newLevel) {
        int cap    = Math.max(1, StatsConfig.getCumulativeCap(newLevel));
        int hpCap  = Math.max(1, StatsConfig.getHealthCap(newLevel));
        boolean changed = false;
        if (stats.strengthLevel     > cap)   { stats.strengthLevel     = cap;   changed = true; }
        if (stats.resistanceLevel   > cap)   { stats.resistanceLevel   = cap;   changed = true; }
        if (stats.speedLevel        > cap)   { stats.speedLevel        = cap;   changed = true; }
        if (stats.cursedEnergyLevel > cap)   { stats.cursedEnergyLevel = cap;   changed = true; }
        if (stats.healthLevel       > hpCap) { stats.healthLevel       = hpCap; changed = true; }
        if (changed) {
            applyAll(player, stats);
            StatsNetwork.syncToClient(player);
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                "\u00a7c[JJKStats] Stats ajustadas al limite del grado actual."));
        }
    }

    // ── applyAll ─────────────────────────────────────────────────────────────

    public static void applyAll(ServerPlayer player, PlayerStats stats) {
        applyHealth(player, stats.healthLevel);
        applyArmor(player, stats);
        updateSpeed(player, stats);
        // Fuerza y Resistencia: manejadas por DamageHandler (LivingHurtEvent)
        // NO se aplican como pociones aqui
    }

    // ── Vida ─────────────────────────────────────────────────────────────────
    //
    // Replica PlayerPhysicalAbilityProcedure: level_health = round(level>=19 ?
    // 9 : min(level/3,4)), con piso 14 si el jugador tiene Sukuna activo.
    // Health Boost real da +4 HP por nivel (amplifier+1). No se da el efecto
    // en sí (decisión del addon: todo vía atributo), solo el HP equivalente.

    private static void applyHealth(ServerPlayer player, int statLevel) {
        AttributeInstance attr = player.getAttribute(Attributes.MAX_HEALTH);
        if (attr == null) return;
        attr.removeModifier(UUID_HEALTH);
        if (statLevel <= 0) return;

        double bonus = StatsConfig.computeHealthBonus(statLevel);
        if (bonus <= 0) return;
        attr.addPermanentModifier(new AttributeModifier(
            UUID_HEALTH, "jjkstats.health", bonus, AttributeModifier.Operation.ADDITION
        ));
    }

    // ── Armadura plana ────────────────────────────────────────────────────────
    //
    // Replica la armadura/toughness de PlayerPhysicalAbilityProcedure: por
    // grado, level*1.0 de armor y level*0.15 de toughness, con +4.0/+0.5 si
    // el jugador es Itadori. El original solo SUBE estos atributos, nunca
    // los baja (no compite con equipamiento real); replicamos lo mismo acá.

    private static final UUID UUID_ARMOR     = UUID.fromString("3a3a3a3a-bbbb-cccc-dddd-eeeeeeeeeeef");
    private static final UUID UUID_TOUGHNESS  = UUID.fromString("3a3a3a3a-bbbb-cccc-dddd-eeeeeeeeeef0");

    private static void applyArmor(ServerPlayer player, PlayerStats stats) {
        double effectiveLevel = DamageHandler.jjkblueredpurple$applyCtLevelBonus(player, stats.strengthLevel);
        var jjkCap = player.getCapability(
            net.mcreator.jujutsucraft.network.JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null
        ).orElse(null);
        boolean itadori = DamageHandler.jjkblueredpurple$isItadori(jjkCap);

        double armorBonus     = StatsConfig.computeArmorBonus(effectiveLevel, itadori);
        double toughnessBonus = StatsConfig.computeArmorToughnessBonus(effectiveLevel, itadori);

        AttributeInstance armorAttr = player.getAttribute(Attributes.ARMOR);
        if (armorAttr != null) {
            armorAttr.removeModifier(UUID_ARMOR);
            if (armorBonus > 0) {
                armorAttr.addPermanentModifier(new AttributeModifier(
                    UUID_ARMOR, "jjkstats.armor", armorBonus, AttributeModifier.Operation.ADDITION
                ));
            }
        }

        AttributeInstance toughnessAttr = player.getAttribute(Attributes.ARMOR_TOUGHNESS);
        if (toughnessAttr != null) {
            toughnessAttr.removeModifier(UUID_TOUGHNESS);
            if (toughnessBonus > 0) {
                toughnessAttr.addPermanentModifier(new AttributeModifier(
                    UUID_TOUGHNESS, "jjkstats.armor_toughness", toughnessBonus, AttributeModifier.Operation.ADDITION
                ));
            }
        }
    }

    // ── Velocidad ─────────────────────────────────────────────────────────────

    private static final UUID UUID_SPEED = UUID.fromString("3a3a3a3a-bbbb-cccc-dddd-eeeeeeeeeef1");
    private static final Map<UUID, Double> speedRampPct = new ConcurrentHashMap<>();

    /**
     * Reemplaza el viejo sistema basado en el efecto MOVEMENT_SPEED (niveles
     * enteros, +20% por nivel) por el atributo Attributes.MOVEMENT_SPEED
     * directo, igual que ya se hizo con fuerza/resistencia en DamageHandler:
     * el efecto de poción no admite valores fraccionarios, lo que hacía que
     * el % de output (continuo) y el turbo (+25%, no un múltiplo de 20%) se
     * sintieran "a saltos" o no se notaran en absoluto.
     *
     * El % final (cuánto más rápido corrés) es matemáticamente equivalente
     * al original: rawMaxRamp (mismos niveles posibles que antes, vía
     * computeSpeedMaxAmp) × 20% por nivel × output × turbo, pero aplicado
     * como MULTIPLY_TOTAL sobre el atributo real, sin redondear a entero en
     * ningún punto del cálculo.
     */
    private static void updateSpeed(ServerPlayer player, PlayerStats stats) {
        AttributeInstance speedAttr = player.getAttribute(Attributes.MOVEMENT_SPEED);
        UUID id = player.getUUID();

        boolean output120Active = player.level().getGameTime() < player.getPersistentData().getLong("jjkbrp_output120_active_until_tick");

        if (stats.speedLevel <= 0 && !stats.turboActive && !output120Active) {
            if (speedAttr != null) speedAttr.removeModifier(UUID_SPEED);
            speedRamps.remove(id);
            speedRampPct.remove(id);
            return;
        }
        if (speedAttr == null) return;

        double rawMaxRamp = Math.max(0, StatsConfig.computeSpeedMaxAmp(stats.speedLevel));
        // % máximo alcanzable por rampa normal (sin turbo), ya escalado por
        // output. 20% por "nivel equivalente", igual que el efecto Speed real.
        double maxRampPct = rawMaxRamp * 0.20 * com.jujutsucraft.jjkstats.event.OutputHandler.outputFactor(stats);

        // El turbo (+25%) aplica SIEMPRE mientras esté activo, sin importar
        // si el jugador está corriendo, caminando, o quieto — a diferencia
        // de la rampa normal de velocidad farmeada, que solo crece al
        // sprintar (igual que el sistema viejo de efecto de poción).
        double turboBonusPct = stats.turboActive ? 0.25 : 0.0;

        // Bono de Output 120% (vive en JoQu, leído vía espejo en NBT plano).
        double output120SpeedBonus = 0.0;
        if (output120Active) {
            output120SpeedBonus = player.getPersistentData().contains("jjkbrp_output120_speed_bonus_mirror")
                ? player.getPersistentData().getDouble("jjkbrp_output120_speed_bonus_mirror")
                : 0.20;
        }

        double currentRampPct;

        boolean sprinting = player.onGround() && player.isSprinting();
        if (!sprinting) {
            speedRamps.remove(id);
            speedRampPct.remove(id);
            currentRampPct = 0.0;
        } else if (stats.speedLevel <= 0) {
            currentRampPct = 0.0;
        } else {
            currentRampPct = speedRampPct.getOrDefault(id, 0.0);
            if (currentRampPct < maxRampPct) {
                // Mismo rampeo gradual que antes (avanza un escalón cada 10
                // ticks), pero en porcentaje continuo en vez de niveles
                // enteros. El paso por escalón replica 1 nivel de Speed
                // (20%) repartido en los mismos 10 ticks que ya usaba el
                // sistema viejo.
                int ramp = speedRamps.merge(id, 0, (old, z) -> old);
                if (ramp <= 0) {
                    currentRampPct = Math.min(currentRampPct + 0.20, maxRampPct);
                    speedRampPct.put(id, currentRampPct);
                    speedRamps.put(id, 10);
                } else {
                    speedRamps.put(id, ramp - 1);
                }
            } else {
                currentRampPct = maxRampPct;
                speedRampPct.put(id, currentRampPct);
            }
        }

        double totalPct = currentRampPct + turboBonusPct + output120SpeedBonus;
        speedAttr.removeModifier(UUID_SPEED);
        if (totalPct > 0.0) {
            speedAttr.addPermanentModifier(new AttributeModifier(
                UUID_SPEED, "jjkstats.speed", totalPct, AttributeModifier.Operation.MULTIPLY_TOTAL
            ));
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    static double getPlayerLevel(ServerPlayer player) {
        try {
            var caps = player.getCapability(
                net.mcreator.jujutsucraft.network.JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null
            ).orElse(null);
            return (caps != null) ? caps.PlayerLevel : 1.0;
        } catch (Exception e) {
            return 1.0;
        }
    }
}
