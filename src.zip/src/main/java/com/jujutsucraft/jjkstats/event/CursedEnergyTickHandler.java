package com.jujutsucraft.jjkstats.event;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability;
import com.jujutsucraft.jjkstats.config.StatsConfig;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Aplica el CE Max farmeado con LOWEST priority para correr DESPUÉS de cualquier
 * otro mod (JJCraft, JRB) que escriba PlayerCursePowerMAX en el mismo tick.
 * Así sobreescribimos siempre el último valor con el nuestro.
 *
 * CE Max = cursedEnergyLevel * CURSED_ENERGY_PER_LEVEL (default 200)
 * Esto replica exactamente la fórmula de JJCraft:
 *   CE_Max = Former(200) × round((PlayerLevel + 2.0) / 1.1)
 * donde round((PlayerLevel + 2.0) / 1.1) es el cap de niveles del grado.
 */
@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class CursedEnergyTickHandler {

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onPlayerTickLowest(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;
        if (player.level().isClientSide()) return;

        try {
            var jjkCap = player.getCapability(
                net.mcreator.jujutsucraft.network.JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null
            ).orElse(null);
            if (jjkCap == null) return;

            PlayerStatsCapability.get(player).ifPresent(stats -> {
                // computeCEMax da el valor exacto de JJCraft al llegar al cap de cada grado
                double ceMax = StatsConfig.computeCEMax(stats.cursedEnergyLevel);
                jjkCap.PlayerCursePowerMAX = ceMax;

                // Si la CE actual supera el nuevo máximo, la clampea para no quedar con CE > MAX
                if (jjkCap.PlayerCursePower > ceMax) {
                    jjkCap.PlayerCursePower = ceMax;
                }
            });
        } catch (Exception e) {
            JJKStatsMod.LOGGER.warn("[JJKStats] Error aplicando CE max: {}", e.getMessage());
        }
    }
}
