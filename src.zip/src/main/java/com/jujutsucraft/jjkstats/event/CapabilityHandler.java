package com.jujutsucraft.jjkstats.event;

import com.jujutsucraft.jjkstats.JJKStatsMod;
import com.jujutsucraft.jjkstats.capability.PlayerStatsCapability;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class CapabilityHandler {

    @SubscribeEvent
    public static void onRegisterCapabilities(RegisterCapabilitiesEvent event) {
        event.register(PlayerStatsCapability.PlayerStats.class);
    }
}

@Mod.EventBusSubscriber(modid = JJKStatsMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
class CapabilityAttacher {

    @SubscribeEvent
    public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (!(event.getObject() instanceof Player)) return;
        var provider = new PlayerStatsCapability.Provider();
        event.addCapability(new ResourceLocation(JJKStatsMod.MOD_ID, "player_stats"), provider);
        event.addListener(provider::invalidate);
    }
}
