package com.jujutsucraft.jjkstats.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class StatsConfig {

    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue    EXP_BASE;
    public static final ForgeConfigSpec.DoubleValue EXP_SCALE_FACTOR;
    public static final ForgeConfigSpec.IntValue    POINTS_PER_FILL;

    // Costos por tramos: costo_nivel_N = base_cost + floor(N / tier_size) * tier_increase
    public static final ForgeConfigSpec.IntValue STRENGTH_BASE_COST;
    public static final ForgeConfigSpec.IntValue STRENGTH_SCALE;
    public static final ForgeConfigSpec.IntValue STRENGTH_TIER_INC;
    public static final ForgeConfigSpec.IntValue RESISTANCE_BASE_COST;
    public static final ForgeConfigSpec.IntValue RESISTANCE_SCALE;
    public static final ForgeConfigSpec.IntValue RESISTANCE_TIER_INC;
    public static final ForgeConfigSpec.IntValue SPEED_BASE_COST;
    public static final ForgeConfigSpec.IntValue SPEED_SCALE;
    public static final ForgeConfigSpec.IntValue SPEED_TIER_INC;
    public static final ForgeConfigSpec.IntValue CURSED_ENERGY_BASE_COST;
    public static final ForgeConfigSpec.IntValue CURSED_ENERGY_SCALE;
    public static final ForgeConfigSpec.IntValue CURSED_ENERGY_TIER_INC;
    public static final ForgeConfigSpec.IntValue HEALTH_BASE_COST;
    public static final ForgeConfigSpec.IntValue HEALTH_SCALE;
    public static final ForgeConfigSpec.IntValue HEALTH_TIER_INC;

    public static final ForgeConfigSpec.IntValue CAP_UNGRADED;
    public static final ForgeConfigSpec.IntValue CAP_GRADE4;
    public static final ForgeConfigSpec.IntValue CAP_GRADE3;
    public static final ForgeConfigSpec.IntValue CAP_SEMI_GRADE2;
    public static final ForgeConfigSpec.IntValue CAP_GRADE2;
    public static final ForgeConfigSpec.IntValue CAP_SEMI_GRADE1;
    public static final ForgeConfigSpec.IntValue CAP_GRADE1;
    public static final ForgeConfigSpec.IntValue CAP_SPECIAL_GRADE;

    public static final ForgeConfigSpec.IntValue HUD_EXP_BAR_X;
    public static final ForgeConfigSpec.IntValue HUD_EXP_BAR_Y;
    public static final ForgeConfigSpec.IntValue HUD_EXP_BAR_WIDTH;
    public static final ForgeConfigSpec.IntValue HUD_EXP_BAR_HEIGHT;

    public static final ForgeConfigSpec.ConfigValue<String> BLACK_FLASH_CHAT_MESSAGE;
    public static final ForgeConfigSpec.IntValue            BLACK_FLASH_CHAT_RADIUS;
    public static final ForgeConfigSpec.BooleanValue        BLACK_FLASH_TITLE_ENABLED;
    public static final ForgeConfigSpec.ConfigValue<String> BLACK_FLASH_TITLE_TEXT;
    public static final ForgeConfigSpec.ConfigValue<String> BLACK_FLASH_SUBTITLE_TEXT;
    public static final ForgeConfigSpec.IntValue            BLACK_FLASH_TITLE_FADE_IN;
    public static final ForgeConfigSpec.IntValue            BLACK_FLASH_TITLE_STAY;
    public static final ForgeConfigSpec.IntValue            BLACK_FLASH_TITLE_FADE_OUT;
    public static final ForgeConfigSpec.BooleanValue        BLACK_FLASH_TITLE_SHAKE;
    public static final ForgeConfigSpec.IntValue            BLACK_FLASH_SHAKE_INTENSITY;
    public static final ForgeConfigSpec.IntValue            BLACK_FLASH_SHAKE_DURATION;
    public static final ForgeConfigSpec.IntValue            BLACK_FLASH_SHAKE_FREQUENCY;

    static {
        BUILDER.push("experience");
        EXP_BASE         = BUILDER.comment("EXP base").defineInRange("exp_base", 1000, 1, Integer.MAX_VALUE);
        EXP_SCALE_FACTOR = BUILDER.comment("Factor de escala").defineInRange("exp_scale_factor", 1.3, 1.0, 10.0);
        POINTS_PER_FILL  = BUILDER.comment("Puntos por nivel").defineInRange("points_per_fill", 3, 1, 100);
        BUILDER.pop();

        BUILDER.push("stat_costs");
        BUILDER.comment("costo_nivel_N = base_cost + floor(N / tier_size) * tier_increase");
        BUILDER.push("strength");
        STRENGTH_BASE_COST = BUILDER.comment("Costo del nivel 1").defineInRange("base_cost", 1, 1, 1000);
        STRENGTH_SCALE     = BUILDER.comment("Cada cuantos niveles sube el costo").defineInRange("tier_size", 5, 1, 100);
        STRENGTH_TIER_INC  = BUILDER.comment("Cuanto sube el costo por tramo").defineInRange("tier_increase", 2, 0, 1000);
        BUILDER.pop();
        BUILDER.push("resistance");
        RESISTANCE_BASE_COST = BUILDER.defineInRange("base_cost", 1, 1, 1000);
        RESISTANCE_SCALE     = BUILDER.defineInRange("tier_size", 5, 1, 100);
        RESISTANCE_TIER_INC  = BUILDER.defineInRange("tier_increase", 2, 0, 1000);
        BUILDER.pop();
        BUILDER.push("speed");
        SPEED_BASE_COST = BUILDER.defineInRange("base_cost", 1, 1, 1000);
        SPEED_SCALE     = BUILDER.defineInRange("tier_size", 5, 1, 100);
        SPEED_TIER_INC  = BUILDER.defineInRange("tier_increase", 2, 0, 1000);
        BUILDER.pop();
        BUILDER.push("cursed_energy");
        CURSED_ENERGY_BASE_COST = BUILDER.defineInRange("base_cost", 1, 1, 1000);
        CURSED_ENERGY_SCALE     = BUILDER.defineInRange("tier_size", 5, 1, 100);
        CURSED_ENERGY_TIER_INC  = BUILDER.defineInRange("tier_increase", 2, 0, 1000);
        BUILDER.pop();
        BUILDER.push("health");
        HEALTH_BASE_COST = BUILDER.defineInRange("base_cost", 2, 1, 1000);
        HEALTH_SCALE     = BUILDER.defineInRange("tier_size", 5, 1, 100);
        HEALTH_TIER_INC  = BUILDER.defineInRange("tier_increase", 2, 0, 1000);
        BUILDER.pop();
        BUILDER.pop();

        BUILDER.push("grade_caps");
        CAP_UNGRADED      = BUILDER.defineInRange("ungraded",       20, 0, 1000);
        CAP_GRADE4        = BUILDER.defineInRange("grade4",         40, 0, 1000);
        CAP_GRADE3        = BUILDER.defineInRange("grade3",         60, 0, 1000);
        CAP_SEMI_GRADE2   = BUILDER.defineInRange("semi_grade2",    80, 0, 1000);
        CAP_GRADE2        = BUILDER.defineInRange("grade2",        100, 0, 1000);
        CAP_SEMI_GRADE1   = BUILDER.defineInRange("semi_grade1",   120, 0, 1000);
        CAP_GRADE1        = BUILDER.defineInRange("grade1",        140, 0, 1000);
        CAP_SPECIAL_GRADE = BUILDER.defineInRange("special_grade", 160, 0, 1000);
        BUILDER.pop();

        BUILDER.push("hud");
        HUD_EXP_BAR_X      = BUILDER.defineInRange("hud_x", -1, -1, 10000);
        HUD_EXP_BAR_Y      = BUILDER.defineInRange("hud_y", 10, 0, 10000);
        HUD_EXP_BAR_WIDTH  = BUILDER.defineInRange("hud_width", 160, 80, 500);
        HUD_EXP_BAR_HEIGHT = BUILDER.defineInRange("hud_height", 8, 4, 30);
        BUILDER.pop();

        BUILDER.push("black_flash_notification");
        BUILDER.comment("Colores: &0-&f, &l negrita, &o italica, &r reset. {player} = nombre.");
        BLACK_FLASH_CHAT_MESSAGE    = BUILDER.comment("Mensaje chat. Vacio = deshabilitado.").define("chat_message", "&4&l{player} : !Kokusen!");
        BLACK_FLASH_CHAT_RADIUS     = BUILDER.comment("Radio en bloques").defineInRange("chat_radius", 100, 0, 10000);
        BLACK_FLASH_TITLE_ENABLED   = BUILDER.comment("Mostrar titulo").define("title_enabled", true);
        BLACK_FLASH_TITLE_TEXT      = BUILDER.comment("Texto del titulo").define("title_text", "&4&l!Kokusen!");
        BLACK_FLASH_SUBTITLE_TEXT   = BUILDER.comment("Subtitulo. Vacio = sin subtitulo.").define("subtitle_text", "&c{player}");
        BLACK_FLASH_TITLE_FADE_IN   = BUILDER.comment("Ticks fade in").defineInRange("title_fade_in", 5, 0, 100);
        BLACK_FLASH_TITLE_STAY      = BUILDER.comment("Ticks duracion").defineInRange("title_stay", 50, 1, 200);
        BLACK_FLASH_TITLE_FADE_OUT  = BUILDER.comment("Ticks fade out").defineInRange("title_fade_out", 15, 0, 100);
        BLACK_FLASH_TITLE_SHAKE     = BUILDER.comment("Vibrar titulo").define("title_shake", true);
        BLACK_FLASH_SHAKE_INTENSITY = BUILDER.comment("Amplitud vibracion en pixeles").defineInRange("shake_intensity", 3, 1, 20);
        BLACK_FLASH_SHAKE_DURATION  = BUILDER.comment("Duracion vibracion en ticks").defineInRange("shake_duration", 20, 1, 100);
        BLACK_FLASH_SHAKE_FREQUENCY = BUILDER.comment("Frecuencia oscilaciones/segundo").defineInRange("shake_frequency", 20, 1, 60);
        BUILDER.pop();

        SPEC = BUILDER.build();
    }

    // ── Caps ──────────────────────────────────────────────────────────────────

    public static int getCapForPlayerLevel(double playerLevel) {
        return getCumulativeCap(playerLevel);
    }

    public static int getCumulativeCap(double playerLevel) {
        if (playerLevel >= 20.0) return CAP_SPECIAL_GRADE.get();
        if (playerLevel >= 13.0) return CAP_GRADE1.get();
        if (playerLevel >= 11.0) return CAP_SEMI_GRADE1.get();
        if (playerLevel >=  9.0) return CAP_GRADE2.get();
        if (playerLevel >=  7.0) return CAP_SEMI_GRADE2.get();
        if (playerLevel >=  4.0) return CAP_GRADE3.get();
        if (playerLevel >=  2.0) return CAP_GRADE4.get();
        return CAP_UNGRADED.get();
    }

    // ── Traducción stat farmeado -> PlayerLevel equivalente (original) ────────
    //
    // Las fórmulas reales de JujutsuCraft (fuerza, resistencia, vida, armadura
    // en PlayerPhysicalAbilityProcedure) toman como entrada el PlayerLevel real
    // del grado (0-20), no el stat 0-160 que este addon usa para farmear dentro
    // de cada grado. Para que el resultado final sea equivalente al original,
    // interpolamos: tener la barra llena en tu grado actual equivale exactamente
    // al PlayerLevel real de ese grado (p. ej. Grado 3 al 100% = PlayerLevel 4,
    // Grado Especial al 100% = PlayerLevel 20). Dentro de cada grado, el valor
    // escala linealmente entre el PlayerLevel del grado anterior y el de este.
    private static final double[] GRADE_PLAYER_LEVELS = {0.0, 0.0, 2.0, 4.0, 7.0, 9.0, 11.0, 13.0, 20.0};

    public static double statLevelToEffectivePlayerLevel(double statLevel) {
        // Mismos breakpoints/orden que getCumulativeCap, de menor a mayor.
        double[] caps = {
            0.0,
            CAP_UNGRADED.get(),
            CAP_GRADE4.get(),
            CAP_GRADE3.get(),
            CAP_SEMI_GRADE2.get(),
            CAP_GRADE2.get(),
            CAP_SEMI_GRADE1.get(),
            CAP_GRADE1.get(),
            CAP_SPECIAL_GRADE.get()
        };

        if (statLevel <= 0.0) return 0.0;

        for (int i = 1; i < caps.length; i++) {
            if (statLevel <= caps[i]) {
                double prevCap = caps[i - 1];
                double curCap  = caps[i];
                double prevPl  = GRADE_PLAYER_LEVELS[i - 1];
                double curPl   = GRADE_PLAYER_LEVELS[i];
                if (curCap <= prevCap) return prevPl;
                double frac = (statLevel - prevCap) / (curCap - prevCap);
                return prevPl + frac * (curPl - prevPl);
            }
        }
        return 20.0;
    }

    public static int getHealthCap(double playerLevel) {
        if (playerLevel >= 20.0) return 70;
        if (playerLevel >= 13.0) return 60;
        if (playerLevel >= 11.0) return 50;
        if (playerLevel >=  9.0) return 45;
        if (playerLevel >=  7.0) return 35;
        if (playerLevel >=  4.0) return 30;
        if (playerLevel >=  2.0) return 20;
        return 10;
    }

    public static String getGradeName(double playerLevel) {
        if (playerLevel >= 20.0) return "Grado Especial";
        if (playerLevel >= 13.0) return "Grado 1";
        if (playerLevel >= 11.0) return "Semi Grado 1";
        if (playerLevel >=  9.0) return "Grado 2";
        if (playerLevel >=  7.0) return "Semi Grado 2";
        if (playerLevel >=  4.0) return "Grado 3";
        if (playerLevel >=  2.0) return "Grado 4";
        return "Sin Grado";
    }

    // ── Formulas (replican PlayerPhysicalAbilityProcedure del mod base) ───────
    //
    // El mod base calcula un "level" (PlayerLevel + bonos de CT como Itadori o
    // Sukuna) y de ahí deriva amplifiers de efectos vanilla reales. Acá NO se
    // dan esos efectos (decisión explícita: todo vía código, sin pociones),
    // pero el NÚMERO resultante (daño extra, % de reducción, HP extra) tiene
    // que ser el mismo que ese efecto real habría dado a ese nivel.

    /**
     * Bono de daño por fuerza, LINEAL Y CONTINUO en función del nivel
     * efectivo (0 a 20, el tope real de PlayerLevel). El original
     * (PlayerPhysicalAbilityProcedure vía el efecto Strength real) avanza en
     * escalones discretos de a 3 niveles de daño por nivel de PlayerLevel,
     * lo cual en un sistema de farmeo continuo (este addon) se sentía como
     * "varios puntos farmeados sin dar nada" antes de cruzar cada escalón.
     * Esta versión interpola linealmente entre 0 (nivel 0) y el mismo techo
     * que el original daba en el tope absoluto (nivel 20 -> 60.0 de daño,
     * verificado contra una medición real de Itadori en Grado Especial:
     * 1 base + 60 bono = 73 de daño total con puño), así que cada punto de
     * stat farmeado suma algo, sin tramos muertos, sin cambiar el techo
     * final.
     */
    public static double computeStrengthDamage(double effectivePlayerLevel) {
        double level = Math.max(0.0, effectivePlayerLevel); // sin clamp superior: un bono (ej. Itadori) puede superar el techo genérico, igual que en el original
        double maxBonusAtCap = 60.0; // el mismo techo que ya daba la fórmula original en nivel 20 (sin bonos)
        return maxBonusAtCap * (level / 20.0);
    }

    // Overload de compatibilidad con el llamador existente (int totalLevels = stat farmeado)
    public static double computeStrengthDamage(int totalLevels) {
        return computeStrengthDamage(statLevelToEffectivePlayerLevel(totalLevels));
    }

    /**
     * % de reducción de daño por resistencia, LINEAL Y CONTINUO, mismo
     * criterio que computeStrengthDamage: el original avanzaba en escalones
     * de Resistance I/II/III/IV (0%, 40%, 60%, 80%), dejando tramos enteros
     * sin ninguna reducción. Esta versión interpola linealmente entre 0%
     * (nivel 0) y 80% (nivel 20, el mismo techo que ya daba el original en
     * el tope absoluto), así que cada punto farmeado reduce un poco más.
     * Sí se clampea a 80% real (Resistance no puede pasar de ahí en el
     * juego, a diferencia del daño que no tiene techo natural).
     */
    public static double computeResistancePct(double effectivePlayerLevel) {
        double level = Math.max(0.0, effectivePlayerLevel);
        double maxPctAtCap = 80.0;
        return Math.min(maxPctAtCap * (level / 20.0), maxPctAtCap);
    }

    public static double computeResistancePct(int totalLevels) {
        return computeResistancePct(statLevelToEffectivePlayerLevel(totalLevels));
    }

    /**
     * 0.5 HP por nivel farmeado, plano. Decisión final tomada en sesión
     * anterior (ver historial): el Health Boost amplifier real del mod base
     * (level>=19?9:min(level/3,4)) daba saltos demasiado grandes y poco
     * intuitivos para un sistema de farmeo gradual — se descartó a favor de
     * esta fórmula simple y directa, sin bonos de CT ni piso de Sukuna.
     */
    public static double computeHealthBonus(int totalLevels) {
        return totalLevels * 0.5;
    }

    /**
     * Replica la armadura plana de PlayerPhysicalAbilityProcedure:
     *   level_armor = level * 1.0 (+4.0 si Itadori), tope 30.
     */
    public static double computeArmorBonus(double effectivePlayerLevel, boolean itadori) {
        double armor = effectivePlayerLevel * 1.0;
        if (itadori) armor += 4.0;
        return Math.min(armor, 30.0);
    }

    /**
     * Replica: level_armorToughness = level * 0.15 (+0.5 si Itadori), tope 20.
     */
    public static double computeArmorToughnessBonus(double effectivePlayerLevel, boolean itadori) {
        double toughness = effectivePlayerLevel * 0.15;
        if (itadori) toughness += 0.5;
        return Math.min(toughness, 20.0);
    }

    public static double computeCEMax(int totalLevels) {
        double[] maxCE = {600, 800, 1000, 1600, 2000, 2400, 2800, 4000};
        double ce = 0, prevMax = 0;
        int remaining = totalLevels;
        for (double max : maxCE) {
            double inc = (max - prevMax) / 20.0;
            int used = Math.min(remaining, 20);
            ce += used * inc;
            remaining -= used;
            prevMax = max;
            if (remaining <= 0) break;
        }
        return ce;
    }

    public static double computeSpeedMaxAmp(int totalLevels) {
        double[] maxAmps = {0, 1, 2, 3, 4, 5, 6, 10};
        double amp = -1, prevMax = -1;
        int remaining = totalLevels;
        for (double max : maxAmps) {
            double inc = (max - prevMax) / 20.0;
            int used = Math.min(remaining, 20);
            if (remaining > 0) amp = prevMax + inc * used;
            remaining -= used;
            prevMax = max;
            if (remaining <= 0) break;
        }
        return amp;
    }

    // ── Costo por tramos ──────────────────────────────────────────────────────

    public static int getCost(int baseCost, int tierSize, int tierIncrease, int currentLevel) {
        return baseCost + (currentLevel / Math.max(1, tierSize)) * tierIncrease;
    }

    // ── Helpers de color ──────────────────────────────────────────────────────

    public static String colorize(String text) {
        return text.replace('&', '\u00A7');
    }

    public static String formatMessage(String template, String playerName) {
        return colorize(template.replace("{player}", playerName));
    }
}
