package net.mcreator.jujutsucraft.addon;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import net.mcreator.jujutsucraft.addon.ClientPacketHandler;
import net.mcreator.jujutsucraft.addon.DomainMasteryCapabilityProvider;
import net.mcreator.jujutsucraft.addon.DomainMasteryData;
import net.mcreator.jujutsucraft.addon.DomainMasteryProperties;
import net.mcreator.jujutsucraft.addon.clash.net.DomainClashHudSnapshotPacket;
import net.mcreator.jujutsucraft.addon.limb.LimbSyncPacket;
import net.mcreator.jujutsucraft.addon.limb.NearDeathPacket;
import net.mcreator.jujutsucraft.addon.limb.RCTLevel3Handler;
import net.mcreator.jujutsucraft.addon.logic.DustOverlayFormat;
import net.mcreator.jujutsucraft.addon.logic.FugaCooldownClear;
import net.mcreator.jujutsucraft.addon.logic.FugaDustLogic;
import net.mcreator.jujutsucraft.addon.util.DomainAddonUtils;
import net.mcreator.jujutsucraft.addon.yuta.YutaCopyStore;
import net.mcreator.jujutsucraft.addon.util.DomainCostUtils;
import net.mcreator.jujutsucraft.init.JujutsucraftModItems;
import net.mcreator.jujutsucraft.init.JujutsucraftModMobEffects;
import net.mcreator.jujutsucraft.network.JujutsucraftModVariables;
import net.mcreator.jujutsucraft.procedures.ChangeTechniqueTestProcedure;
import net.mcreator.jujutsucraft.procedures.KeyChangeTechniqueOnKeyPressedProcedure;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Central networking hub for addon packets. It registers every packet type, builds technique wheel payloads, synchronizes cooldown and mastery data, and processes domain mastery mutations on the server.
 */
public class ModNetworking {
    // Shared network protocol version string used when establishing the addon channel.
    private static final String PROTOCOL_VERSION = "2";
    // Persistent data key used to remember the peak value of the current technique cooldown cycle.
    private static final String DATA_KEY_TECHNIQUE_CD_MAX = "jjkbrp_technique_cd_max";
    // Persistent data key used to remember the peak value of the current combat cooldown cycle.
    private static final String DATA_KEY_COMBAT_CD_MAX = "jjkbrp_combat_cd_max";
    // SimpleChannel used for every addon packet exchanged between client and server.
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel((ResourceLocation)new ResourceLocation("jjkblueredpurple", "main"), () -> PROTOCOL_VERSION, PROTOCOL_VERSION::equals, PROTOCOL_VERSION::equals);
    // Monotonically increasing discriminator assigned as packet types are registered.
    private static int packetId = 0;
    private static final int MAX_WHEEL_PAGE_SIZE = 10;
    public static final int YUTA_COPY_ENTRY_BASE = 10000;
    public static final int YUTA_SUREHIT_ENTRY_BASE = 2000000;
    public static final int YUTA_SUREHIT_CLEAR_ENTRY_ID = -2000000;

    // ===== CHANNEL REGISTRATION =====
    public static void register() {
        CHANNEL.registerMessage(packetId++, SelectTechniquePacket.class, SelectTechniquePacket::encode, SelectTechniquePacket::decode, SelectTechniquePacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(packetId++, RequestWheelPacket.class, RequestWheelPacket::encode, RequestWheelPacket::decode, RequestWheelPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(packetId++, OpenWheelPacket.class, OpenWheelPacket::encode, OpenWheelPacket::decode, OpenWheelPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, CooldownSyncPacket.class, CooldownSyncPacket::encode, CooldownSyncPacket::decode, CooldownSyncPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, BlackFlashSyncPacket.class, BlackFlashSyncPacket::encode, BlackFlashSyncPacket::decode, BlackFlashSyncPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, BlackFlashReleasePacket.class, BlackFlashReleasePacket::encode, BlackFlashReleasePacket::decode, BlackFlashReleasePacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(packetId++, BlackFlashFeedbackPacket.class, BlackFlashFeedbackPacket::encode, BlackFlashFeedbackPacket::decode, BlackFlashFeedbackPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, GojoShiftTapPacket.class, GojoShiftTapPacket::encode, GojoShiftTapPacket::decode, GojoShiftTapPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(packetId++, SelectSpiritPacket.class, SelectSpiritPacket::encode, SelectSpiritPacket::decode, SelectSpiritPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(packetId++, SelectYutaCopyPacket.class, SelectYutaCopyPacket::encode, SelectYutaCopyPacket::decode, SelectYutaCopyPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(packetId++, LimbSyncPacket.class, LimbSyncPacket::encode, LimbSyncPacket::decode, LimbSyncPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, NearDeathPacket.class, NearDeathPacket::encode, NearDeathPacket::decode, NearDeathPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, NearDeathCdSyncPacket.class, NearDeathCdSyncPacket::encode, NearDeathCdSyncPacket::decode, NearDeathCdSyncPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, DomainPropertyPacket.class, DomainPropertyPacket::encode, DomainPropertyPacket::decode, DomainPropertyPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(packetId++, DomainMasteryOpenPacket.class, DomainMasteryOpenPacket::encode, DomainMasteryOpenPacket::decode, DomainMasteryOpenPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(packetId++, DomainMasteryOpenScreenPacket.class, DomainMasteryOpenScreenPacket::encode, DomainMasteryOpenScreenPacket::decode, DomainMasteryOpenScreenPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, DomainMasterySyncPacket.class, DomainMasterySyncPacket::encode, DomainMasterySyncPacket::decode, DomainMasterySyncPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, GojoTeleportGhostPacket.class, GojoTeleportGhostPacket::encode, GojoTeleportGhostPacket::decode, GojoTeleportGhostPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, DomainClashHudSnapshotPacket.class, DomainClashHudSnapshotPacket::encode, DomainClashHudSnapshotPacket::decode, DomainClashHudSnapshotPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, RequestAddonGameRulesPacket.class, RequestAddonGameRulesPacket::encode, RequestAddonGameRulesPacket::decode, RequestAddonGameRulesPacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(packetId++, OpenAddonGameRulesPacket.class, OpenAddonGameRulesPacket::encode, OpenAddonGameRulesPacket::decode, OpenAddonGameRulesPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, SyncAddonGameRulesPacket.class, SyncAddonGameRulesPacket::encode, SyncAddonGameRulesPacket::decode, SyncAddonGameRulesPacket::handle, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(packetId++, SetAddonGameRulePacket.class, SetAddonGameRulePacket::encode, SetAddonGameRulePacket::decode, SetAddonGameRulePacket::handle, Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }

    // ===== TECHNIQUE SELECTION HELPERS =====
    private static boolean isTechniqueLocked(ServerPlayer player, int charId, double selectId) {
        if (ModNetworking.isSpecialIncompleteFugaOverride(player, charId, selectId)) {
            return false;
        }
        return ChangeTechniqueTestProcedure.execute((LevelAccessor)player.level(), (double)player.getX(), (double)player.getY(), (double)player.getZ(), (Entity)player, (double)charId, (double)selectId);
    }

    public static boolean canUseSukunaIncompleteFugaOverride(ServerPlayer player, int charId, double selectId) {
        if (player == null || charId != 1 || Math.round(selectId) != 7L) {
            return false;
        }
        if (!AddonGameRules.enabled(player, AddonGameRules.SUKUNA_FUGA_REWARD_ENABLED)) {
            return false;
        }
        if (ModNetworking.hasSukunaFugaDustReward(player, charId, selectId)) {
            return true;
        }
        return ModNetworking.canUseActiveSukunaIncompleteFugaOverride(player, charId, selectId);
    }

    public static boolean canUseActiveSukunaIncompleteFugaOverride(ServerPlayer player, int charId, double selectId) {
        if (player == null || charId != 1 || Math.round(selectId) != 7L) {
            return false;
        }
        if (!AddonGameRules.enabled(player, AddonGameRules.SUKUNA_FUGA_COOLDOWN_BYPASS_ENABLED)) {
            return false;
        }
        CompoundTag data = player.getPersistentData();
        boolean specialDomainActive = !data.getBoolean("jjkbrp_sukuna_incomplete_fuga_used")
                && DomainAddonUtils.isActiveSukunaIncompleteShrine(player);
        if (specialDomainActive) {
            data.putBoolean("jjkbrp_sukuna_incomplete_surehit_active", true);
            data.putBoolean("jjkbrp_sukuna_incomplete_surehit_had_domain", true);
            ModNetworking.fillSukunaFugaDust(player);
        }
        return specialDomainActive;
    }

    public static boolean hasSukunaFugaDustReward(ServerPlayer player, int charId, double selectId) {
        if (player == null || charId != 1 || Math.round(selectId) != 7L) {
            return false;
        }
        if (!AddonGameRules.sukunaFugaReward(player)) {
            return false;
        }
        CompoundTag data = player.getPersistentData();
        return data.getBoolean("jjkbrp_sukuna_fuga_dust_locked_full");
    }

    public static boolean applySukunaFugaDustReward(ServerPlayer player, Entity flameArrow) {
        if (player == null || flameArrow == null) {
            return false;
        }
        if (!AddonGameRules.sukunaFugaReward(player)) {
            return false;
        }
        CompoundTag ownerData = player.getPersistentData();
        if (!ownerData.getBoolean("jjkbrp_sukuna_fuga_dust_locked_full")) {
            return false;
        }
        double storedDust = ownerData.getDouble("dust_amount");
        CompoundTag projectileData = flameArrow.getPersistentData();
        double existingCnt6 = projectileData.getDouble("cnt6");
        projectileData.putDouble("cnt6", FugaDustLogic.resolveTransferDust(storedDust, existingCnt6));
        projectileData.putBoolean("jjkbrp_sukuna_fuga_dust_applied", true);
        ownerData.remove("jjkbrp_sukuna_fuga_dust_locked_full");
        ownerData.remove("jjkbrp_sukuna_incomplete_fuga_used");
        ModNetworking.clearSukunaFugaCooldown(player);
        // clearSukunaFugaDustOverlay sets dust_amount = 0 and clears OVERLAY1/OVERLAY2.
        ModNetworking.clearSukunaFugaDustOverlay(player);
        ModNetworking.sendCooldownSync(player);
        return true;
    }

    private static boolean isSpecialIncompleteFugaOverride(ServerPlayer player, int charId, double selectId) {
        return ModNetworking.canUseSukunaIncompleteFugaOverride(player, charId, selectId);
    }

    /**
     * Applies original technique selection to the current addon state.
     * @param player player instance involved in this operation.
     * @param selectId identifier used to resolve the requested entry or state.
     */
    private static void applyOriginalTechniqueSelection(ServerPlayer player, double selectId) {
        player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(cap -> {
            boolean previousNoChange = cap.noChangeTechnique;
            cap.noChangeTechnique = true;
            cap.PlayerSelectCurseTechnique = selectId;
            cap.syncPlayerVariables((Entity)player);
            KeyChangeTechniqueOnKeyPressedProcedure.execute((LevelAccessor)player.level(), (double)player.getX(), (double)player.getY(), (double)player.getZ(), (Entity)player);
            cap.noChangeTechnique = previousNoChange;
            cap.syncPlayerVariables((Entity)player);
        });
    }

    /**
     * Returns active character id for the current addon state.
     * @param vars vars used by this method.
     * @return the resolved active character id.
     */
    private static int getActiveCharacterId(JujutsucraftModVariables.PlayerVariables vars) {
        double activeTechnique = vars.SecondTechnique ? vars.PlayerCurseTechnique2 : vars.PlayerCurseTechnique;
        return (int)Math.round(activeTechnique);
    }

    /**
     * Checks whether is valid select id is true for the current addon state.
     * @param selectId identifier used to resolve the requested entry or state.
     * @return true when is valid select id succeeds; otherwise false.
     */
    private static boolean isValidSelectId(double selectId) {
        return selectId >= 0.0 && selectId <= 21.0;
    }

    /**
     * Performs as select id for this addon component.
     * @param selectId identifier used to resolve the requested entry or state.
     * @return the resulting as select id value.
     */
    private static int asSelectId(double selectId) {
        return (int)Math.round(selectId);
    }

    private static boolean isBlockedPlayerYutaHardcodedCopy(ServerPlayer player, int charId, double selectId) {
        return charId == 5 && YutaCopyStore.isVanillaHardcodedCopySelect(selectId);
    }

    private static boolean hasUnusedLoudspeakerEquipped(ServerPlayer player) {
        return ModNetworking.isUnusedLoudspeaker(player.getMainHandItem()) || ModNetworking.isUnusedLoudspeaker(player.getOffhandItem());
    }

    private static boolean isUnusedLoudspeaker(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.is(JujutsucraftModItems.LOUDSPEAKER.get()) && !stack.getOrCreateTag().getBoolean("Used");
    }

    private static boolean isLoudspeakerCursedSpeechEntry(double selectId, String displayName) {
        int sid = (int)Math.round(selectId);
        if (sid >= 5 && sid <= 12) {
            return true;
        }
        String normalized = displayName == null ? "" : displayName.toLowerCase(Locale.ROOT).replace('’', '\'').replace("'", "");
        return normalized.contains("cursed speech")
            || normalized.contains("curse speech")
            || normalized.contains("loudspeaker")
            || normalized.contains("blast away")
            || normalized.contains("dont move")
            || normalized.contains("dont get close")
            || normalized.contains("get crushed")
            || normalized.contains("explode")
            || normalized.contains("sleep")
            || normalized.contains("stop")
            || normalized.contains("plummet")
            || normalized.contains("twist")
            || normalized.contains("return");
    }

    private static boolean shouldHideLoudspeakerEntriesFromYutaCopyWheel(ServerPlayer player, int charId) {
        return ModNetworking.shouldHideLoudspeakerEntriesForActiveYuta(player, charId);
    }

    private static boolean shouldHideLoudspeakerEntriesForActiveYuta(ServerPlayer player, int charId) {
        return charId == 5 && YutaCopyStore.isActiveYuta(player) && ModNetworking.hasUnusedLoudspeakerEquipped(player);
    }

    private static void removeLoudspeakerEntriesForActiveYuta(ServerPlayer player, int charId, List<WheelTechniqueEntry> entries) {
        if (ModNetworking.shouldHideLoudspeakerEntriesForActiveYuta(player, charId)) {
            entries.removeIf(entry -> ModNetworking.isLoudspeakerCursedSpeechEntry(entry.selectId(), entry.displayName()));
        }
    }

    private static boolean shouldRejectPlayerYutaSelection(ServerPlayer player, int charId, double selectId) {
        return charId == 5 && YutaCopyStore.isActiveYuta(player) && YutaCopyStore.isVanillaHardcodedCopySelect(selectId);
    }

    private static boolean isBlockedPlayerYutaHardcodedCopyEntry(ServerPlayer player, int charId, double requestedId, JujutsucraftModVariables.PlayerVariables after) {
        return charId == 5
            && YutaCopyStore.isActiveYuta(player)
            && (YutaCopyStore.isVanillaHardcodedCopySelect(requestedId) || YutaCopyStore.isVanillaHardcodedCopySelect(after.PlayerSelectCurseTechnique));
    }

    // ===== COOLDOWN HELPERS =====
    public static int getTechniqueCooldownTicks(ServerPlayer player) {
        return player.hasEffect((MobEffect)JujutsucraftModMobEffects.COOLDOWN_TIME.get()) ? player.getEffect((MobEffect)JujutsucraftModMobEffects.COOLDOWN_TIME.get()).getDuration() : 0;
    }

    /**
     * Returns combat cooldown ticks for the current addon state.
     * @param player player instance involved in this operation.
     * @return the resolved combat cooldown ticks.
     */
    public static int getCombatCooldownTicks(ServerPlayer player) {
        return player.hasEffect((MobEffect)JujutsucraftModMobEffects.COOLDOWN_TIME_COMBAT.get()) ? player.getEffect((MobEffect)JujutsucraftModMobEffects.COOLDOWN_TIME_COMBAT.get()).getDuration() : 0;
    }

    /**
     * Returns cooldown ticks for the current addon state.
     * @param player player instance involved in this operation.
     * @return the resolved cooldown ticks.
     */
    public static int getCooldownTicks(ServerPlayer player) {
        return Math.max(ModNetworking.getTechniqueCooldownTicks(player), ModNetworking.getCombatCooldownTicks(player));
    }

    public static void clearSukunaFugaCooldown(ServerPlayer player) {
        if (player == null) {
            return;
        }
        // Remove the three Fuga cooldown effects (existence-checked) so neither the
        // base-mod skill UI nor the addon HUD shows Fuga on cooldown. The effect keys
        // are sourced from FugaCooldownClear.REMOVED_EFFECT_KEYS.
        // - jujutsucraft_acerycd:extension_cooldown_7 and jujutsucraft_plus:fuga are
        //   addon/plus mob effects resolved through ForgeRegistries.MOB_EFFECTS.
        // - COOLDOWN_TIME is the base-mod technique cooldown effect, resolved through
        //   the JujutsucraftModMobEffects registry object (its symbolic name, not a
        //   namespaced ResourceLocation).
        ModNetworking.removeCooldownEffectByKey(player, FugaCooldownClear.EXTENSION_COOLDOWN_7);
        ModNetworking.removeCooldownEffectByKey(player, FugaCooldownClear.FUGA_COOLDOWN);
        MobEffect techniqueCooldown = (MobEffect)JujutsucraftModMobEffects.COOLDOWN_TIME.get();
        if (techniqueCooldown != null && player.hasEffect(techniqueCooldown)) {
            player.removeEffect(techniqueCooldown);
        }
        // NOTE: we intentionally do NOT remove the UNSTABLE effect here. UNSTABLE is a real
        // base-mod post-domain debuff; removing it every tick (a previous attempt) made it
        // vanish entirely, which was wrong. The OG skill UI does derive its Fuga cooldown
        // readout partly from UNSTABLE, so while UNSTABLE is on the player the OG UI may still
        // show a Fuga cooldown number; that is handled separately and must not be "fixed" by
        // deleting the Unstable effect.
        // Zero the three cooldown-max NBT values that drive the UI cooldown ring fill,
        // so no stale "full-but-stuck" ring is rendered after the effects are gone.
        // The zeroing is driven by FugaCooldownClear.clear over a snapshot of the
        // currently-present cd-max values: keys absent from the snapshot stay absent,
        // present keys are set to 0. This leaves every other technique's state untouched
        // and is idempotent under the per-tick (Unstable-window) re-clear.
        ModNetworking.zeroFugaCooldownMaxValues(player);
        ModNetworking.sendCooldownSync(player);
    }

    /**
     * Removes a Fuga cooldown mob effect identified by a {@code namespace:path} key
     * (one of {@link FugaCooldownClear#REMOVED_EFFECT_KEYS}). The effect is resolved
     * through {@link ForgeRegistries#MOB_EFFECTS} and removed only when present.
     */
    private static void removeCooldownEffectByKey(ServerPlayer player, String key) {
        ResourceLocation id = ResourceLocation.tryParse(key);
        if (id == null) {
            return;
        }
        MobEffect effect = (MobEffect)ForgeRegistries.MOB_EFFECTS.getValue(id);
        if (effect != null && player.hasEffect(effect)) {
            player.removeEffect(effect);
        }
    }

    /**
     * Zeroes the {@code jjkbrp_technique_cd_max}, {@code jjkbrp_combat_cd_max}, and
     * {@code jjkbrp_cd_max_1_7} NBT values that are currently present, driven by
     * {@link FugaCooldownClear#clear(Map)}. Only present keys are zeroed (matching the
     * "zeroes only the present ones" contract), and the original storage type is
     * preserved on write-back: the two technique/combat maxima are stored as doubles
     * (read by {@link #sendCooldownSync}) while the per-skill {@code jjkbrp_cd_max_1_7}
     * is stored as an int (read by the wheel builder).
     */
    private static void zeroFugaCooldownMaxValues(ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        Map<String, Integer> snapshot = new LinkedHashMap<>();
        for (String key : FugaCooldownClear.ZEROED_CD_MAX_KEYS) {
            if (data.contains(key)) {
                snapshot.put(key, (int)data.getDouble(key));
            }
        }
        Map<String, Integer> cleared = FugaCooldownClear.clear(snapshot);
        for (Map.Entry<String, Integer> entry : cleared.entrySet()) {
            String key = entry.getKey();
            if (DATA_KEY_TECHNIQUE_CD_MAX.equals(key) || DATA_KEY_COMBAT_CD_MAX.equals(key)) {
                data.putDouble(key, (double)(int)entry.getValue());
            } else {
                data.putInt(key, entry.getValue());
            }
        }
    }

    public static void fillSukunaFugaDust(ServerPlayer player) {
        if (player == null) {
            return;
        }
        if (!AddonGameRules.sukunaFugaReward(player)) {
            return;
        }
        CompoundTag data = player.getPersistentData();
        data.putDouble("dust_amount", DustOverlayFormat.DUST_MAX * AddonGameRules.percent(player, AddonGameRules.SUKUNA_FUGA_DUST_REWARD_PERCENT, 100));
        ModNetworking.syncDustOverlayFromAmount(player);
    }

    /**
     * Pushes the dust overlay to the client from the caster's current {@code dust_amount},
     * so the rendered bar reflects the real stored dust instead of a fixed/spoofed value.
     *
     * <p>The overlay is only shown while a confirmed reward is present: either the
     * {@code jjkbrp_sukuna_fuga_dust_locked_full} flag is set or the Incomplete Domain
     * Shrine is active. When neither holds, this clears the overlay so no unconfirmed
     * overlay appears. All writes stay server-side and are propagated to the client only
     * through {@code syncPlayerVariables}.
     *
     * @param player player whose dust overlay should be synced.
     */
    public static void syncDustOverlayFromAmount(ServerPlayer player) {
        if (player == null) {
            return;
        }
        CompoundTag data = player.getPersistentData();
        boolean rewardPresent = data.getBoolean("jjkbrp_sukuna_fuga_dust_locked_full")
                || DomainAddonUtils.isActiveSukunaIncompleteShrine(player);
        if (!rewardPresent) {
            ModNetworking.clearSukunaFugaDustOverlay(player);
            return;
        }
        double dust = data.getDouble("dust_amount");
        player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(cap -> {
            cap.OVERLAY1 = DustOverlayFormat.OVERLAY1_LABEL;
            cap.OVERLAY2 = DustOverlayFormat.buildBar(dust);
            cap.syncPlayerVariables((Entity)player);
        });
    }

    public static void clearSukunaFugaDustOverlay(ServerPlayer player) {
        if (player == null) {
            return;
        }
        player.getPersistentData().putDouble("dust_amount", 0.0);
        player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(cap -> {
            if (DustOverlayFormat.OVERLAY1_LABEL.equals(cap.OVERLAY1)) {
                cap.OVERLAY1 = "";
                cap.OVERLAY2 = "";
                cap.syncPlayerVariables((Entity)player);
            }
        });
    }

    /**
     * Performs capture active skill cooldown for this addon component.
     * @param player player instance involved in this operation.
     * @param vars vars used by this method.
     */
    public static void captureActiveSkillCooldown(ServerPlayer player, JujutsucraftModVariables.PlayerVariables vars) {
    }

    /**
     * Performs send cooldown sync for this addon component.
     * @param player player instance involved in this operation.
     */
    public static void sendCooldownSync(ServerPlayer player) {
        if (player == null) {
            return;
        }
        if (!AddonGameRules.enabled(player, AddonGameRules.HUD_OVERLAYS_ENABLED, AddonGameRules.COOLDOWN_HUD_ENABLED)) {
            CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new CooldownSyncPacket(0, 0, 0, 0));
            return;
        }
        CompoundTag data = player.getPersistentData();
        int techRemaining = ModNetworking.getTechniqueCooldownTicks(player);
        int combatRemaining = ModNetworking.getCombatCooldownTicks(player);
        int techMax = (int)data.getDouble(DATA_KEY_TECHNIQUE_CD_MAX);
        int combatMax = (int)data.getDouble(DATA_KEY_COMBAT_CD_MAX);
        if (techRemaining > techMax) {
            techMax = techRemaining;
            data.putDouble(DATA_KEY_TECHNIQUE_CD_MAX, (double)techMax);
        }
        if (techRemaining <= 0) {
            techMax = 0;
            data.putDouble(DATA_KEY_TECHNIQUE_CD_MAX, 0.0);
        }
        if (combatRemaining > combatMax) {
            combatMax = combatRemaining;
            data.putDouble(DATA_KEY_COMBAT_CD_MAX, (double)combatMax);
        }
        if (combatRemaining <= 0) {
            combatMax = 0;
            data.putDouble(DATA_KEY_COMBAT_CD_MAX, 0.0);
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new CooldownSyncPacket(techRemaining, techMax, combatRemaining, combatMax));
    }

    public static void sendGojoTeleportGhost(ServerPlayer player, double x, double y, double z, float yaw, int lifetime) {
        if (player == null) {
            return;
        }
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player), (Object)new GojoTeleportGhostPacket(x, y, z, yaw, lifetime));
    }
 
    // ===== WHEEL DISPLAY HELPERS =====
    private static int computeTechniqueColor(String displayName, boolean passive, boolean physical, double selectId) {
        String n = displayName == null ? "" : displayName.toLowerCase(Locale.ROOT);
        String string = n;
        if (n.contains("purple") || n.contains("hollow")) {
            return 11032055;
        }
        if (n.contains("blue") || n.contains("ice") || n.contains("water") || n.contains("frost")) {
            return 3900150;
        }
        if (n.contains("red") || n.contains("blood") || n.contains("fire") || n.contains("flame") || n.contains("meteor")) {
            return 0xEF4444;
        }
        if (n.contains("electric") || n.contains("lightning") || n.contains("thunder") || n.contains("kirin")) {
            return 16436245;
        }
        if (n.contains("shadow") || n.contains("shikigami") || n.contains("dog") || n.contains("serpent") || n.contains("rabbit") || n.contains("deer") || n.contains("ox") || n.contains("tiger") || n.contains("mahoraga")) {
            return 2278750;
        }
        if (n.contains("soul") || n.contains("idle transfiguration") || n.contains("mahito")) {
            return 1357990;
        }
        if (n.contains("domain") || n.contains("void") || n.contains("shrine")) {
            return 16096779;
        }
        if (n.contains("copy") || n.contains("rika")) {
            return 15485081;
        }
        if (physical) {
            return 16486972;
        }
        if (passive) {
            return 3462041;
        }
        if (selectId >= 20.0) {
            return 16096779;
        }
        return ModNetworking.generateVibrantColor(displayName, selectId);
    }

    /**
     * Performs generate vibrant color for this addon component.
     * @param displayName display name used by this method.
     * @param selectId identifier used to resolve the requested entry or state.
     * @return the resulting generate vibrant color value.
     */
    private static int generateVibrantColor(String displayName, double selectId) {
        String key = (displayName == null ? "technique" : displayName.toLowerCase(Locale.ROOT)) + "#" + (int)Math.round(selectId);
        int hash = key.hashCode();
        float hue = (hash & Integer.MAX_VALUE) % 360;
        float saturation = 0.72f;
        float value = 0.95f;
        return ModNetworking.hsvToRgb(hue, saturation, value);
    }

    /**
     * Performs hsv to rgb for this addon component.
     * @param hue hue used by this method.
     * @param saturation saturation used by this method.
     * @param value value used by this method.
     * @return the resulting hsv to rgb value.
     */
    private static int hsvToRgb(float hue, float saturation, float value) {
        float bp;
        float gp;
        float rp;
        float c = value * saturation;
        float x = c * (1.0f - Math.abs(hue / 60.0f % 2.0f - 1.0f));
        float m = value - c;
        if (hue < 60.0f) {
            rp = c;
            gp = x;
            bp = 0.0f;
        } else if (hue < 120.0f) {
            rp = x;
            gp = c;
            bp = 0.0f;
        } else if (hue < 180.0f) {
            rp = 0.0f;
            gp = c;
            bp = x;
        } else if (hue < 240.0f) {
            rp = 0.0f;
            gp = x;
            bp = c;
        } else if (hue < 300.0f) {
            rp = x;
            gp = 0.0f;
            bp = c;
        } else {
            rp = c;
            gp = 0.0f;
            bp = x;
        }
        int r = Math.min(255, Math.max(0, Math.round((rp + m) * 255.0f)));
        int g = Math.min(255, Math.max(0, Math.round((gp + m) * 255.0f)));
        int b = Math.min(255, Math.max(0, Math.round((bp + m) * 255.0f)));
        return r << 16 | g << 8 | b;
    }

    // ===== PLAYER STATE SNAPSHOTS =====
    private static PlayerSelectionSnapshot snapshot(JujutsucraftModVariables.PlayerVariables vars) {
        return new PlayerSelectionSnapshot(vars.PlayerSelectCurseTechnique, vars.PlayerSelectCurseTechniqueName, vars.PlayerSelectCurseTechniqueCost, vars.PlayerSelectCurseTechniqueCostOrgin, vars.PassiveTechnique, vars.PhysicalAttack, vars.noChangeTechnique, vars.OverlayCost, vars.OverlayCursePower);
    }

    /**
     * Performs restore for this addon component.
     * @param player player instance involved in this operation.
     * @param snap snap used by this method.
     */
    private static void restore(ServerPlayer player, PlayerSelectionSnapshot snap) {
        player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(cap -> {
            cap.PlayerSelectCurseTechnique = snap.selectId();
            cap.PlayerSelectCurseTechniqueName = snap.name();
            cap.PlayerSelectCurseTechniqueCost = snap.finalCost();
            cap.PlayerSelectCurseTechniqueCostOrgin = snap.baseCost();
            cap.PassiveTechnique = snap.passive();
            cap.PhysicalAttack = snap.physical();
            cap.noChangeTechnique = snap.noChangeTechnique();
            cap.OverlayCost = snap.overlayCost();
            cap.OverlayCursePower = snap.overlayCursePower();
            cap.syncPlayerVariables((Entity)player);
        });
    }

    // ===== PER-SKILL COOLDOWN LOOKUPS =====
    private static int getPerSkillCooldownTicks(ServerPlayer player, int charId, int selectId) {
        String acerycdEffectId = ModNetworking.getAcerycdExtensionCooldownEffectId(selectId);
        if (acerycdEffectId != null) {
            int acerycdCooldown = ModNetworking.getCooldownTicksForEffect(player, "jujutsucraft_acerycd", acerycdEffectId);
            if (acerycdCooldown >= 0) {
                return acerycdCooldown;
            }
        }
        String legacyEffectId = ModNetworking.getLegacyPerSkillEffectId(charId, selectId);
        if (legacyEffectId == null) {
            return -1;
        }
        return ModNetworking.getCooldownTicksForEffect(player, "jujutsucraft_plus", legacyEffectId);
    }

    /**
     * Resolves the per-move cooldown effect used by jujutsucraft_acerycd.
     * acerycd keys this directly from PlayerSelectCurseTechnique: 1 is unsuffixed,
     * then 2..19 use extension_cooldown_N.
     * @param selectId identifier used to resolve the requested entry or state.
     * @return the resolved effect id, or null when acerycd has no matching effect.
     */
    private static String getAcerycdExtensionCooldownEffectId(int selectId) {
        if (selectId < 1 || selectId > 19) {
            return null;
        }
        return selectId == 1 ? "extension_cooldown" : "extension_cooldown_" + selectId;
    }

    private static int getCooldownTicksForEffect(ServerPlayer player, String namespace, String effectId) {
        MobEffect effect = (MobEffect)ForgeRegistries.MOB_EFFECTS.getValue(new ResourceLocation(namespace, effectId));
        if (effect == null) {
            return -1;
        }
        if (!player.hasEffect(effect)) {
            return 0;
        }
        return player.getEffect(effect).getDuration();
    }

    /**
     * Returns the older per-skill effect id for compatibility with legacy separate-cooldown addons.
     * @param charId identifier used to resolve the requested entry or state.
     * @param selectId identifier used to resolve the requested entry or state.
     * @return the resolved per skill effect id.
     */
    private static String getLegacyPerSkillEffectId(int charId, int selectId) {
        if (charId == 2) {
            String gojoEffect = null;
            switch (selectId) {
                case 6: {
                    gojoEffect = "blue";
                    break;
                }
                case 7: {
                    gojoEffect = "red";
                    break;
                }
                case 8: {
                    gojoEffect = "blue_strike";
                    break;
                }
                case 15: {
                    gojoEffect = "purple";
                }
            }
            if (gojoEffect != null) {
                return gojoEffect;
            }
        }
        if (charId == 1) {
            String sukunaEffect = null;
            switch (selectId) {
                case 5: {
                    sukunaEffect = "dismantle";
                    break;
                }
                case 6: {
                    sukunaEffect = "cleave";
                    break;
                }
                case 7: {
                    sukunaEffect = "fuga";
                }
            }
            if (sukunaEffect != null) {
                return sukunaEffect;
            }
        }
        return switch (selectId) {
            case 1 -> "extension_cooldown";
            case 2 -> "extension_cooldown_2";
            case 3 -> "extension_cooldown_3";
            case 4 -> "extension_cooldown_4";
            case 5 -> "extension_cooldown_5";
            case 6 -> "extension_cooldown_6";
            case 7 -> "extension_cooldown_7";
            case 8 -> "extension_cooldown_8";
            case 9 -> "extension_cooldown_9";
            case 10 -> "extension_cooldown_10";
            case 11 -> "extension_cooldown_11";
            case 12 -> "extension_cooldown_12";
            case 13 -> "extension_cooldown_13";
            case 14 -> "extension_cooldown_14";
            case 15 -> "maximum";
            case 16 -> "extension_cooldown_16";
            case 17 -> "extension_cooldown_17";
            case 18 -> "extension_cooldown_18";
            case 19 -> "extension_cooldown_19";
            default -> null;
        };
    }

    // ===== ADVANCEMENT AND LOCK HELPERS =====
    private static boolean hasAdvancement(ServerPlayer player, ResourceLocation id) {
        try {
            Advancement adv = player.server.getAdvancements().getAdvancement(id);
            if (adv == null) {
                return false;
            }
            AdvancementProgress progress = player.getAdvancements().getOrStartProgress(adv);
            return progress.isDone();
        }
        catch (Exception e) {
            return false;
        }
    }

    /**
     * Checks whether has open barrier advancement is true for the current addon state.
     * @param player player instance involved in this operation.
     * @return true when has open barrier advancement succeeds; otherwise false.
     */
    private static boolean hasOpenBarrierAdvancement(ServerPlayer player) {
        return ModNetworking.hasAdvancement(player, new ResourceLocation("jujutsucraft", "mastery_open_barrier_type_domain"));
    }

    /**
     * Checks whether has domain expansion advancement is true for the current addon state.
     * @param player player instance involved in this operation.
     * @return true when has domain expansion advancement succeeds; otherwise false.
     */
    private static boolean hasDomainExpansionAdvancement(ServerPlayer player) {
        return ModNetworking.hasAdvancement(player, new ResourceLocation("jujutsucraft", "mastery_domain_expansion"));
    }

    /**
     * Whether the player has unlocked Black Flash Mastery, via either the addon advancement or the
     * runtime {@code addon_bf_mastery} NBT flag set by {@code CooldownTrackerEvents}.
     * @param player player instance involved in this operation.
     * @return true when Black Flash Mastery is unlocked.
     */
    private static boolean hasBlackFlashMastery(ServerPlayer player) {
        if (player.getPersistentData().getBoolean("addon_bf_mastery")) {
            return true;
        }
        return ModNetworking.hasAdvancement(player, new ResourceLocation("jjkblueredpurple", "black_flash_mastery"));
    }

    /**
     * Awards every remaining criterion of the requested advancement so it is marked complete for the
     * player. Safe to call repeatedly; a fully-completed advancement is left untouched.
     * @param player player instance involved in this operation.
     * @param id advancement identifier to award.
     */
    private static void grantAdvancement(ServerPlayer player, ResourceLocation id) {
        try {
            Advancement adv = player.server.getAdvancements().getAdvancement(id);
            if (adv == null) {
                return;
            }
            AdvancementProgress progress = player.getAdvancements().getOrStartProgress(adv);
            if (!progress.isDone()) {
                for (String criterion : progress.getRemainingCriteria()) {
                    player.getAdvancements().award(adv, criterion);
                }
            }
        }
        catch (Exception ignored) {
            // empty catch block
        }
    }

    /**
     * Checks whether is domain mastery mutation operation is true for the current addon state.
     * @param operation operation used by this method.
     * @return true when is domain mastery mutation operation succeeds; otherwise false.
     */
    private static boolean isDomainMasteryMutationOperation(int operation) {
        return operation == 0 || operation == 1 || operation == 2 || operation == 3 || operation == 4 || operation == 5 || operation == 6 || operation == 7 || operation == 8;
    }

    /**
     * Rejects property mutation packets whenever gameplay state says mastery editing should be locked.
     * @param player player instance involved in this operation.
     * @param operation operation used by this method.
     * @return true when reject locked domain mastery mutation succeeds; otherwise false.
     */
    private static boolean rejectLockedDomainMasteryMutation(ServerPlayer player, int operation) {
        // Only mutation operations are blocked here; informational packets can still pass even when the player is combat locked.
        if (player == null || !ModNetworking.isDomainMasteryMutationOperation(operation)) {
            return false;
        }
        if (!DomainAddonUtils.isDomainMasteryMutationLocked((LivingEntity)player)) {
            return false;
        }
        player.displayClientMessage(ModNetworking.domainMsgError(DomainAddonUtils.getDomainMasteryMutationLockReason((LivingEntity)player)), false);
        return true;
    }

    /**
     * Performs domain msg error for this addon component.
     * @param text text used by this method.
     * @return the resulting domain msg error value.
     */
    private static Component domainMsgError(String text) {
        return Component.literal((String)"\u2716 ").withStyle(new ChatFormatting[]{ChatFormatting.RED, ChatFormatting.BOLD}).append((Component)Component.literal((String)"[Domain Mastery] ").withStyle(ChatFormatting.DARK_RED)).append((Component)Component.literal((String)text).withStyle(ChatFormatting.RED));
    }

    /**
     * Performs domain msg info for this addon component.
     * @param icon icon used by this method.
     * @param iconColor icon color used by this method.
     * @param text text used by this method.
     * @return the resulting domain msg info value.
     */
    private static Component domainMsgInfo(String icon, ChatFormatting iconColor, String text) {
        return Component.literal((String)(icon + " ")).withStyle(new ChatFormatting[]{iconColor, ChatFormatting.BOLD}).append((Component)Component.literal((String)"[Domain Mastery] ").withStyle(ChatFormatting.DARK_AQUA)).append((Component)Component.literal((String)text).withStyle(ChatFormatting.GRAY));
    }

    /**
     * Performs domain msg success for this addon component.
     * @param icon icon used by this method.
     * @param iconColor icon color used by this method.
     * @param text text used by this method.
     * @return the resulting domain msg success value.
     */
    private static Component domainMsgSuccess(String icon, ChatFormatting iconColor, String text) {
        return Component.literal((String)(icon + " ")).withStyle(new ChatFormatting[]{iconColor, ChatFormatting.BOLD}).append((Component)Component.literal((String)"[Domain Mastery] ").withStyle(ChatFormatting.DARK_AQUA)).append((Component)Component.literal((String)text).withStyle(ChatFormatting.WHITE));
    }

    /**
     * Performs domain prop label for this addon component.
     * @param prop property identifier involved in this operation.
     * @return the resulting domain prop label value.
     */
    private static String domainPropLabel(DomainMasteryProperties prop) {
        String[] words = prop.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder label = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty()) continue;
            if (!label.isEmpty()) {
                label.append(' ');
            }
            label.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return label.toString();
    }

    // ===== SKILL WHEEL PAYLOAD BUILDERS =====
    private static List<WheelTechniqueEntry> buildWheelEntries(ServerPlayer player, int charId) {
        JujutsucraftModVariables.PlayerVariables baseVars = player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new JujutsucraftModVariables.PlayerVariables());
        PlayerSelectionSnapshot baseline = ModNetworking.snapshot(baseVars);
        ArrayList<WheelTechniqueEntry> entries = new ArrayList<WheelTechniqueEntry>();
        ArrayList<Double> seenIds = new ArrayList<Double>();
        // Probe every vanilla select id slot so the wheel can discover the actual techniques exposed by the current character without maintaining a second hard-coded list.
        for (int i = 0; i <= 21; ++i) {
            String displayName;
            double selectId = i;
            ModNetworking.restore(player, baseline);
            ModNetworking.applyOriginalTechniqueSelection(player, selectId);
            JujutsucraftModVariables.PlayerVariables after = player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new JujutsucraftModVariables.PlayerVariables());
            double resolvedId = after.PlayerSelectCurseTechnique;
            if (ModNetworking.isBlockedPlayerYutaHardcodedCopyEntry(player, charId, selectId, after)) continue;
            if (!ModNetworking.isValidSelectId(resolvedId) || seenIds.stream().anyMatch(v -> Math.abs(v - resolvedId) < 0.001) || (displayName = after.PlayerSelectCurseTechniqueName) == null || displayName.isBlank() || "-----".equals(displayName)) continue;
            int sid = (int)Math.round(resolvedId);
            int cdRemaining = 0;
            int cdMax = 0;
            int perSkill = ModNetworking.getPerSkillCooldownTicks(player, charId, sid);
            if (perSkill >= 0) {
                cdRemaining = perSkill;
            } else if (after.PhysicalAttack && sid <= 2) {
                cdRemaining = ModNetworking.getCombatCooldownTicks(player);
            } else {
                cdRemaining = after.PhysicalAttack ? ModNetworking.getCombatCooldownTicks(player) : ModNetworking.getTechniqueCooldownTicks(player);
            }
            if (cdRemaining <= 0 && sid > 2 && !after.PhysicalAttack && player.hasEffect((MobEffect)JujutsucraftModMobEffects.UNSTABLE.get())) {
                cdRemaining = player.getEffect((MobEffect)JujutsucraftModMobEffects.UNSTABLE.get()).getDuration();
            }
            if (ModNetworking.isSpecialIncompleteFugaOverride(player, charId, sid)) {
                cdRemaining = 0;
                cdMax = 0;
            }
            if (cdRemaining > 0) {
                String maxKey = "jjkbrp_cd_max_" + charId + "_" + sid;
                int storedMax = player.getPersistentData().getInt(maxKey);
                if (cdRemaining > storedMax) {
                    storedMax = cdRemaining;
                }
                player.getPersistentData().putInt(maxKey, storedMax);
                cdMax = storedMax;
            }
            double entryFinalCost = after.PlayerSelectCurseTechniqueCost;
            double entryBaseCost = after.PlayerSelectCurseTechniqueCostOrgin;
            int domainForm = -1;
            double domainMultiplier = 0.0;
            // Domain techniques are displayed with their effective form-adjusted costs instead of the raw base value shown by the original selection state.
            if (DomainCostUtils.isDomainTechniqueSelected(after)) {
                domainForm = DomainCostUtils.resolveEffectiveForm((Player)player);
                domainMultiplier = DomainCostUtils.formMultiplier((Player)player, domainForm);
                entryBaseCost = DomainCostUtils.resolveTechniqueBaseCost((Player)player, after);
                entryFinalCost = DomainCostUtils.resolveExpectedDomainCastCost((Player)player, after);
            }
            entries.add(new WheelTechniqueEntry(resolvedId, displayName, entryFinalCost, entryBaseCost, ModNetworking.computeTechniqueColor(displayName, after.PassiveTechnique, after.PhysicalAttack, resolvedId), after.PassiveTechnique, after.PhysicalAttack, domainForm, domainMultiplier, cdRemaining, cdMax));
            seenIds.add(resolvedId);
        }
        ModNetworking.restore(player, baseline);
        entries.sort(Comparator.comparingDouble(WheelTechniqueEntry::selectId));
        if (entries.isEmpty()) {
            entries.add(new WheelTechniqueEntry(baseline.selectId(), baseline.name() == null || baseline.name().isBlank() ? "Technique" : baseline.name(), baseline.finalCost(), baseline.baseCost(), ModNetworking.computeTechniqueColor(baseline.name(), baseline.passive(), baseline.physical(), baseline.selectId()), baseline.passive(), baseline.physical(), -1, 0.0, 0, 0));
        }
        return entries;
    }

    private static void addPaged(List<List<WheelTechniqueEntry>> pages, List<WheelTechniqueEntry> entries) {
        if (entries == null || entries.isEmpty()) {
            return;
        }
        ArrayList<WheelTechniqueEntry> page = new ArrayList<>();
        for (WheelTechniqueEntry entry : entries) {
            page.add(entry);
            if (page.size() >= MAX_WHEEL_PAGE_SIZE) {
                pages.add(page);
                page = new ArrayList<>();
            }
        }
        if (!page.isEmpty()) {
            pages.add(page);
        }
    }

    /**
     * Performs detect spirit grade for this addon component.
     * @param name name used by this method.
     * @return the resulting detect spirit grade value.
     */
    private static int detectSpiritGrade(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.contains("special grade") || lower.contains("grade 0")) {
            return 0;
        }
        if (lower.contains("semi grade 1") || lower.contains("semi-grade 1")) {
            return 1;
        }
        if (lower.contains("grade 1")) {
            return 1;
        }
        if (lower.contains("grade 2")) {
            return 2;
        }
        if (lower.contains("grade 3")) {
            return 3;
        }
        if (lower.contains("grade 4")) {
            return 4;
        }
        return 0;
    }

    /**
     * Returns spirit grade color for the current addon state.
     * @param grade grade used by this method.
     * @return the resolved spirit grade color.
     */
    private static int getSpiritGradeColor(int grade) {
        return switch (grade) {
            case 0 -> 13127872;
            case 1 -> 13934615;
            case 2 -> 4886745;
            default -> 7048811;
        };
    }

    /**
     * Builds the multi-page wheel payload for Geto, separating normal entries from stored cursed spirits by grade.
     * @param player player instance involved in this operation.
     * @param charId identifier used to resolve the requested entry or state.
     * @return the resulting build geto pages value.
     */
    private static List<List<WheelTechniqueEntry>> buildGetoPages(ServerPlayer player, int charId) {
        String displayName;
        ArrayList<WheelTechniqueEntry> page;
        String key;
        double yPos;
        ArrayList<List<WheelTechniqueEntry>> pages = new ArrayList<List<WheelTechniqueEntry>>();
        List<WheelTechniqueEntry> normalEntries = ModNetworking.buildWheelEntries(player, charId);
        normalEntries.removeIf(e -> {
            int sid = (int)Math.round(e.selectId());
            return sid >= 11 && sid <= 13;
        });
        ModNetworking.addPaged(pages, normalEntries);
        CompoundTag data = player.getPersistentData();
        ArrayList<SpiritData> allSpirits = new ArrayList<SpiritData>();
        // Geto spirit pages are rebuilt by walking the stored manipulation slots until the first empty sentinel entry is encountered.
        for (int n = 1; n < 10000 && (yPos = data.getDouble(key = "data_cursed_spirit_manipulation" + n)) != 0.0; ++n) {
            String name = data.getString(key + "_name");
            double count = data.getDouble(key + "_num");
            if (name.isEmpty() || count <= 0.0) continue;
            allSpirits.add(new SpiritData(n, name, (int)Math.round(count), ModNetworking.detectSpiritGrade(name)));
        }
        ArrayList<SpiritData> lowerGrade = new ArrayList<SpiritData>();
        ArrayList<SpiritData> upperGrade = new ArrayList<SpiritData>();
        for (SpiritData s : allSpirits) {
            if (s.grade >= 2) {
                lowerGrade.add(s);
                continue;
            }
            upperGrade.add(s);
        }
        if (!lowerGrade.isEmpty()) {
            page = new ArrayList<WheelTechniqueEntry>();
            for (SpiritData s : lowerGrade) {
                displayName = s.count > 1 ? s.name + " x" + s.count : s.name;
                page.add(new WheelTechniqueEntry(100 + s.slot, displayName, 0.0, 0.0, ModNetworking.getSpiritGradeColor(s.grade), false, false, -1, 0.0, 0, 0));
                if (page.size() < MAX_WHEEL_PAGE_SIZE) continue;
                pages.add(page);
                page = new ArrayList();
            }
            if (!page.isEmpty()) {
                pages.add(page);
            }
        }
        if (!upperGrade.isEmpty()) {
            page = new ArrayList();
            for (SpiritData s : upperGrade) {
                displayName = s.count > 1 ? s.name + " x" + s.count : s.name;
                page.add(new WheelTechniqueEntry(100 + s.slot, displayName, 0.0, 0.0, ModNetworking.getSpiritGradeColor(s.grade), false, false, -1, 0.0, 0, 0));
                if (page.size() < MAX_WHEEL_PAGE_SIZE) continue;
                pages.add(page);
                page = new ArrayList();
            }
            if (!page.isEmpty()) {
                pages.add(page);
            }
        }
        return pages;
    }

    // Returns the wheel color for a Yuta copy record. Cancel-state entries (active Ten Shadows copy toggle)
    // use an orange accent so the "Cancel: …" label is visually distinct, otherwise the color is derived
    // from the underlying technique name via the existing computeTechniqueColor heuristics.
    private static int copyEntryColor(CompoundTag rec, boolean cancelState) {
        if (cancelState) {
            return 0xFB923C;
        }
        int techniqueId = (int)Math.round(rec.getDouble("techniqueId"));
        int moveSelectId = rec.contains("moveSelectId") ? rec.getInt("moveSelectId") : 5;
        if (techniqueId == 2) {
            if (moveSelectId == 7) return 0xEF4444;
            if (moveSelectId == 15) return 0xA855F7;
            return 0x3B82F6;
        }
        return switch (techniqueId) {
            case 1 -> 0xDC2626;
            case 3 -> 0xEC4899;
            case 4 -> 0xF97316;
            case 6 -> 0x22C55E;
            case 7 -> 0x991B1B;
            case 8 -> 0x38BDF8;
            case 9 -> 0x14B8A6;
            case 10 -> 0xFACC15;
            case 11 -> 0x111827;
            case 12, 18 -> 0x7C3AED;
            case 13 -> 0x60A5FA;
            case 14 -> 0xF59E0B;
            case 15 -> 0x94A3B8;
            case 16 -> 0x93C5FD;
            case 17 -> 0xA3E635;
            case 19 -> 0xFDE047;
            default -> ModNetworking.computeTechniqueColor(YutaCopyStore.techniqueName(techniqueId), false, false, techniqueId);
        };
    }

    private static List<List<WheelTechniqueEntry>> buildYutaCopyPages(ServerPlayer player, int charId) {
        ArrayList<List<WheelTechniqueEntry>> pages = new ArrayList<List<WheelTechniqueEntry>>();
        YutaCopyStore.cleanupVanillaPlayerCopy(player);
        YutaCopyStore.clearSureHit(player);
        List<WheelTechniqueEntry> baseEntries = ModNetworking.buildWheelEntries(player, charId);
        ModNetworking.removeLoudspeakerEntriesForActiveYuta(player, charId, baseEntries);
        ModNetworking.addPaged(pages, baseEntries);
        List<CompoundTag> validRecords = YutaCopyStore.validRecords(player);
        ArrayList<WheelTechniqueEntry> copyEntries = new ArrayList<WheelTechniqueEntry>();
        for (int recordIndex = 0; recordIndex < validRecords.size(); ++recordIndex) {
            CompoundTag rec = validRecords.get(recordIndex);
            double entryId = (double)stableYutaCopyEntryId(rec.getString("recordUuid"));
            String suffix = rec.contains("usesRemaining") ? " §b(" + rec.getInt("usesRemaining") + " uses)" : (rec.getBoolean("temporary") ? " §7(Temp)" : " §d(Perm)");
            double cost = YutaCopyStore.effectiveCopyCost(player, rec);
            int moveSelectId = rec.contains("moveSelectId") ? rec.getInt("moveSelectId") : 5;
            int cooldownMax = Math.max(YutaCopyStore.effectiveCopyCooldownTicks(player, rec), (int)Math.round(rec.getDouble("COOLDOWN_TICKS")));
            int cooldownRemaining = YutaCopyStore.cooldownRemainingTicks(player, rec);
            cooldownMax = Math.max(cooldownMax, cooldownRemaining);
            String moveName = rec.getString("moveName");
            if (Math.round(rec.getDouble("techniqueId")) == 6L && rec.contains("moveSelectId")) {
                moveName = YutaCopyStore.tenShadowsWheelMoveName(rec.getInt("moveSelectId"));
            }
            String label = moveName == null || moveName.isBlank() ? rec.getString("displayName") : YutaCopyStore.techniqueName(rec.getDouble("techniqueId")) + ": " + moveName;
            boolean cancelState = Math.round(rec.getDouble("techniqueId")) == 6L
                && rec.contains("moveSelectId")
                && YutaCopyStore.isCopiedTenShadowsMoveActive(player, rec);
            if (cancelState) {
                label = "Cancel: " + moveName;
                cost = 0.0D;
                cooldownRemaining = 0;
            }
            int entryColor = ModNetworking.copyEntryColor(rec, cancelState);
            copyEntries.add(new WheelTechniqueEntry(entryId, "Rika: " + label + suffix, cost, cooldownMax, entryColor, false, false, -1, 0.0D, cooldownRemaining, cooldownMax));
        }
        ModNetworking.addPaged(pages, copyEntries);
        return pages;
    }

    private static int stableYutaCopyEntryId(String recordUuid) {
        int hash = recordUuid == null ? 0 : (recordUuid.hashCode() & 0x7fffffff);
        return YUTA_COPY_ENTRY_BASE + (hash % (YUTA_SUREHIT_ENTRY_BASE - YUTA_COPY_ENTRY_BASE - 1));
    }

    // ===== CLIENT SYNC SENDERS =====
    public static void sendBlackFlashSync(ServerPlayer player) {
        if (player == null) {
            return;
        }
        if (!AddonGameRules.blackFlashHud(player.level())) {
            long serverNowTick = player.serverLevel().getGameTime();
            CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new BlackFlashSyncPacket(0.0F, false, false, 0L, 1.0F, 0.0F, 0.0F, 0L, 0, 0, serverNowTick, Math.max(0, player.latency)));
            return;
        }
        CompoundTag data = player.getPersistentData();
        float pct = (float)data.getDouble("addon_bf_chance");
        boolean mastery = data.getBoolean("addon_bf_mastery");
        boolean charging = data.getBoolean("addon_bf_charging");
        long timingStartTick = data.getLong("addon_bf_timing_start_tick");
        float timingPeriodTicks = (float)data.getDouble("addon_bf_timing_period_ticks");
        float timingRedStart = (float)data.getDouble("addon_bf_timing_red_start");
        float timingRedSize = (float)data.getDouble("addon_bf_timing_red_size");
        long timingNonce = data.getLong("addon_bf_timing_nonce");
        int flow = data.getInt("addon_bf_flow");
        int primaryFlowCooldown = data.getInt("addon_bf_flow_cd");
        int legacyFlowCooldown = data.getInt("addon_bf_flow_cooldown");
        int flowCooldown = primaryFlowCooldown > 0 ? primaryFlowCooldown : legacyFlowCooldown;
        long serverNowTick = player.serverLevel().getGameTime();
        int latencyMs = Math.max(0, player.latency);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new BlackFlashSyncPacket(pct, mastery, charging, timingStartTick, timingPeriodTicks, timingRedStart, timingRedSize, timingNonce, flow, flowCooldown, serverNowTick, latencyMs));
    }

    /**
     * Performs send near death cd sync for this addon component.
     * @param player player instance involved in this operation.
     */
    public static void sendNearDeathCdSync(ServerPlayer player) {
        if (player == null) {
            return;
        }
        if (!AddonGameRules.nearDeathHud(player.level())) {
            CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new NearDeathCdSyncPacket(0, 0, false));
            return;
        }
        CompoundTag data = player.getPersistentData();
        int cd = data.getInt("jjkbrp_near_death_cd");
        boolean rctL3 = RCTLevel3Handler.hasAdvancement(player, "jjkblueredpurple:rct_level_3");
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new NearDeathCdSyncPacket(cd, 6000, rctL3));
    }

    /**
     * Pushes the current domain mastery capability snapshot to the specified client after applying open-barrier unlock state.
     * @param player player instance involved in this operation.
     * @param data data used by this method.
     */
    public static void syncDomainMasteryToClient(ServerPlayer player, DomainMasteryData data) {
        if (player == null || !AddonGameRules.domainMastery(player)) {
            return;
        }
        boolean hasOpenAdvancement = ModNetworking.hasOpenBarrierAdvancement(player);
        data.setOpenBarrierAdvancementUnlocked(hasOpenAdvancement);
        data.setBlackFlashMasteryUnlocked(ModNetworking.hasBlackFlashMastery(player));
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new DomainMasterySyncPacket(data, hasOpenAdvancement));
    }

    /**
     * Server-bound packet that requests a specific technique selection from the skill wheel.
     */
    // ===== PACKET TYPES =====
    public static class SelectTechniquePacket {
        // Requested technique select id carried by this packet.
        private final double selectId;

        /**
         * Creates a new select technique packet instance and initializes its addon state.
         * @param selectId identifier used to resolve the requested entry or state.
         */
        public SelectTechniquePacket(double selectId) {
            this.selectId = selectId;
        }

        /**
         * Writes this packet payload into the provided network buffer.
         * @param pkt pkt used by this method.
         * @param buf serialized data container used by this operation.
         */
        public static void encode(SelectTechniquePacket pkt, FriendlyByteBuf buf) {
            buf.writeDouble(pkt.selectId);
        }

        /**
         * Reads this packet payload from the provided network buffer and rebuilds the packet instance.
         * @param buf serialized data container used by this operation.
         * @return the resulting decode value.
         */
        public static SelectTechniquePacket decode(FriendlyByteBuf buf) {
            return new SelectTechniquePacket(buf.readDouble());
        }

        /**
         * Handles  for the addon system.
         * @param pkt pkt used by this method.
         * @param ctxSupplier context data supplied by the current callback or network pipeline.
         */
        public static void handle(SelectTechniquePacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer player = ctx.getSender();
                if (player == null) {
                    return;
                }
                if (!AddonGameRules.enabled(player, AddonGameRules.SKILL_WHEEL_ENABLED)) {
                    return;
                }
                syncAddonGameRulesCache(player);
                JujutsucraftModVariables.PlayerVariables vars = player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new JujutsucraftModVariables.PlayerVariables());
                if (vars.noChangeTechnique) {
                    return;
                }
                int charId = ModNetworking.getActiveCharacterId(vars);
                if (ModNetworking.shouldRejectPlayerYutaSelection(player, charId, pkt.selectId)) {
                    YutaCopyStore.cleanupVanillaPlayerCopy(player);
                    return;
                }
                if (ModNetworking.isTechniqueLocked(player, charId, pkt.selectId)) {
                    return;
                }
                ModNetworking.applyOriginalTechniqueSelection(player, pkt.selectId);
                YutaCopyStore.cleanupVanillaPlayerCopy(player);
            });
            ctx.setPacketHandled(true);
        }
    }

    /**
     * Server-bound packet asking the server to build and send the current skill wheel payload.
     */
    public static class RequestWheelPacket {
        /**
         * Writes this packet payload into the provided network buffer.
         * @param pkt pkt used by this method.
         * @param buf serialized data container used by this operation.
         */
        public static void encode(RequestWheelPacket pkt, FriendlyByteBuf buf) {
        }

        /**
         * Reads this packet payload from the provided network buffer and rebuilds the packet instance.
         * @param buf serialized data container used by this operation.
         * @return the resulting decode value.
         */
        public static RequestWheelPacket decode(FriendlyByteBuf buf) {
            return new RequestWheelPacket();
        }

        /**
         * Handles  for the addon system.
         * @param pkt pkt used by this method.
         * @param ctxSupplier context data supplied by the current callback or network pipeline.
         */
        public static void handle(RequestWheelPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer player = ctx.getSender();
                if (player == null) {
                    return;
                }
                if (!AddonGameRules.enabled(player, AddonGameRules.SKILL_WHEEL_ENABLED)) {
                    return;
                }
                JujutsucraftModVariables.PlayerVariables vars = player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new JujutsucraftModVariables.PlayerVariables());
                if (vars.noChangeTechnique) {
                    player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(cap -> {
                        cap.noChangeTechnique = false;
                        cap.syncPlayerVariables((Entity)player);
                    });
                    vars = player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new JujutsucraftModVariables.PlayerVariables());
                }
                int charId = ModNetworking.getActiveCharacterId(vars);
                if (charId == 5) {
                    YutaCopyStore.cleanupVanillaPlayerCopy(player);
                } else {
                    YutaCopyStore.clearTransientYutaRuntimeState(player);
                }
                double currentSelect = vars.PlayerSelectCurseTechnique;
                if (ModNetworking.isBlockedPlayerYutaHardcodedCopy(player, charId, currentSelect)) {
                    currentSelect = 0.0D;
                }
                if (charId == 18) {
                    List<List<WheelTechniqueEntry>> pages = ModNetworking.buildGetoPages(player, charId);
                    CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new OpenWheelPacket(pages, currentSelect));
                } else if (charId == 5 && YutaCopyStore.hasValidRikaOrDomain(player)) {
                    List<List<WheelTechniqueEntry>> pages = ModNetworking.buildYutaCopyPages(player, charId);
                    CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new OpenWheelPacket(pages, currentSelect));
                } else {
                    List<WheelTechniqueEntry> entries = ModNetworking.buildWheelEntries(player, charId);
                    ModNetworking.removeLoudspeakerEntriesForActiveYuta(player, charId, entries);
                    ArrayList<List<WheelTechniqueEntry>> singlePage = new ArrayList<List<WheelTechniqueEntry>>();
                    ModNetworking.addPaged(singlePage, entries);
                    CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new OpenWheelPacket(singlePage, currentSelect));
                }
            });
            ctx.setPacketHandled(true);
        }
    }

    /**
     * Client-bound packet containing one or more wheel pages plus the currently selected technique id.
     */
    public static class OpenWheelPacket {
        final List<List<WheelTechniqueEntry>> pages;
        // Currently selected technique id shown when the skill wheel opens.
        private final double currentSelect;

        /**
         * Creates a new open wheel packet instance and initializes its addon state.
         * @param pages pages used by this method.
         * @param currentSelect current select used by this method.
         */
        public OpenWheelPacket(List<List<WheelTechniqueEntry>> pages, double currentSelect) {
            this.pages = pages;
            this.currentSelect = currentSelect;
        }

        /**
         * Writes this packet payload into the provided network buffer.
         * @param pkt pkt used by this method.
         * @param buf serialized data container used by this operation.
         */
        public static void encode(OpenWheelPacket pkt, FriendlyByteBuf buf) {
            buf.writeInt(pkt.pages.size());
            for (List<WheelTechniqueEntry> page : pkt.pages) {
                buf.writeInt(page.size());
                for (WheelTechniqueEntry entry : page) {
                    buf.writeDouble(entry.selectId());
                    buf.writeUtf(entry.displayName(), 256);
                    buf.writeDouble(entry.finalCost());
                    buf.writeDouble(entry.baseCost());
                    buf.writeInt(entry.color());
                    buf.writeBoolean(entry.passive());
                    buf.writeBoolean(entry.physical());
                    buf.writeInt(entry.domainForm());
                    buf.writeDouble(entry.domainMultiplier());
                    buf.writeInt(entry.cooldownRemainingTicks());
                    buf.writeInt(entry.cooldownMaxTicks());
                }
            }
            buf.writeDouble(pkt.currentSelect);
        }

        /**
         * Reads this packet payload from the provided network buffer and rebuilds the packet instance.
         * @param buf serialized data container used by this operation.
         * @return the resulting decode value.
         */
        public static OpenWheelPacket decode(FriendlyByteBuf buf) {
            int numPages = buf.readInt();
            ArrayList<List<WheelTechniqueEntry>> pages = new ArrayList<List<WheelTechniqueEntry>>();
            for (int p = 0; p < numPages; ++p) {
                int size = buf.readInt();
                ArrayList<WheelTechniqueEntry> page = new ArrayList<WheelTechniqueEntry>();
                for (int i = 0; i < size; ++i) {
                    page.add(new WheelTechniqueEntry(buf.readDouble(), buf.readUtf(256), buf.readDouble(), buf.readDouble(), buf.readInt(), buf.readBoolean(), buf.readBoolean(), buf.readInt(), buf.readDouble(), buf.readInt(), buf.readInt()));
                }
                pages.add(page);
            }
            return new OpenWheelPacket(pages, buf.readDouble());
        }

        /**
         * Handles  for the addon system.
         * @param pkt pkt used by this method.
         * @param ctxSupplier context data supplied by the current callback or network pipeline.
         */
        public static void handle(OpenWheelPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> ClientPacketHandler.openSkillWheel(pkt.pages, pkt.currentSelect)));
            ctx.setPacketHandled(true);
        }
    }

    /**
     * Client-bound packet that synchronizes technique and combat cooldown progress.
     */
    public static class CooldownSyncPacket {
        // Remaining technique cooldown ticks sent to the client.
        private final int techRemaining;
        // Maximum technique cooldown ticks used to render normalized client progress.
        private final int techMax;
        // Remaining combat cooldown ticks sent to the client.
        private final int combatRemaining;
        // Maximum combat cooldown ticks used to render normalized client progress.
        private final int combatMax;

        /**
         * Creates a new cooldown sync packet instance and initializes its addon state.
         * @param techRemaining tech remaining used by this method.
         * @param techMax tech max used by this method.
         * @param combatRemaining combat remaining used by this method.
         * @param combatMax combat max used by this method.
         */
        public CooldownSyncPacket(int techRemaining, int techMax, int combatRemaining, int combatMax) {
            this.techRemaining = techRemaining;
            this.techMax = techMax;
            this.combatRemaining = combatRemaining;
            this.combatMax = combatMax;
        }

        /**
         * Writes this packet payload into the provided network buffer.
         * @param pkt pkt used by this method.
         * @param buf serialized data container used by this operation.
         */
        public static void encode(CooldownSyncPacket pkt, FriendlyByteBuf buf) {
            buf.writeInt(pkt.techRemaining);
            buf.writeInt(pkt.techMax);
            buf.writeInt(pkt.combatRemaining);
            buf.writeInt(pkt.combatMax);
        }

        /**
         * Reads this packet payload from the provided network buffer and rebuilds the packet instance.
         * @param buf serialized data container used by this operation.
         * @return the resulting decode value.
         */
        public static CooldownSyncPacket decode(FriendlyByteBuf buf) {
            return new CooldownSyncPacket(buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt());
        }

        /**
         * Handles  for the addon system.
         * @param pkt pkt used by this method.
         * @param ctxSupplier context data supplied by the current callback or network pipeline.
         */
        public static void handle(CooldownSyncPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> ClientPacketHandler.updateCooldowns(pkt.techRemaining, pkt.techMax, pkt.combatRemaining, pkt.combatMax)));
            ctx.setPacketHandled(true);
        }
    }

    /**
     * Client-bound packet that synchronizes Black Flash HUD values.
     */
    public static class BlackFlashSyncPacket {
        private final float bfPercent;
        private final boolean mastery;
        private final boolean charging;
        private final long timingStartTick;
        private final float timingPeriodTicks;
        private final float timingRedStart;
        private final float timingRedSize;
        private final long timingNonce;
        private final int flow;
        private final int flowCooldown;
        private final long serverNowTick;
        private final int latencyMs;

        public BlackFlashSyncPacket(float bfPercent, boolean mastery, boolean charging, long timingStartTick, float timingPeriodTicks, float timingRedStart, float timingRedSize, long timingNonce, int flow, int flowCooldown, long serverNowTick, int latencyMs) {
            this.bfPercent = bfPercent;
            this.mastery = mastery;
            this.charging = charging;
            this.timingStartTick = timingStartTick;
            this.timingPeriodTicks = timingPeriodTicks;
            this.timingRedStart = timingRedStart;
            this.timingRedSize = timingRedSize;
            this.timingNonce = timingNonce;
            this.flow = flow;
            this.flowCooldown = flowCooldown;
            this.serverNowTick = serverNowTick;
            this.latencyMs = latencyMs;
        }

        public static void encode(BlackFlashSyncPacket pkt, FriendlyByteBuf buf) {
            buf.writeFloat(pkt.bfPercent);
            buf.writeBoolean(pkt.mastery);
            buf.writeBoolean(pkt.charging);
            buf.writeLong(pkt.timingStartTick);
            buf.writeFloat(pkt.timingPeriodTicks);
            buf.writeFloat(pkt.timingRedStart);
            buf.writeFloat(pkt.timingRedSize);
            buf.writeLong(pkt.timingNonce);
            buf.writeInt(pkt.flow);
            buf.writeInt(pkt.flowCooldown);
            buf.writeLong(pkt.serverNowTick);
            buf.writeInt(pkt.latencyMs);
        }

        public static BlackFlashSyncPacket decode(FriendlyByteBuf buf) {
            return new BlackFlashSyncPacket(buf.readFloat(), buf.readBoolean(), buf.readBoolean(), buf.readLong(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readLong(), buf.readInt(), buf.readInt(), buf.readLong(), buf.readInt());
        }

        public static void handle(BlackFlashSyncPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> ClientPacketHandler.updateBlackFlash(pkt.bfPercent, pkt.mastery, pkt.charging, pkt.timingStartTick, pkt.timingPeriodTicks, pkt.timingRedStart, pkt.timingRedSize, pkt.timingNonce, pkt.flow, pkt.flowCooldown, pkt.serverNowTick, pkt.latencyMs)));
            ctx.setPacketHandled(true);
        }
    }

    public static class GojoShiftTapPacket {
        public GojoShiftTapPacket() {
        }

        public static void encode(GojoShiftTapPacket pkt, FriendlyByteBuf buf) {
        }

        public static GojoShiftTapPacket decode(FriendlyByteBuf buf) {
            return new GojoShiftTapPacket();
        }

        public static void handle(GojoShiftTapPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer player = ctx.getSender();
                if (player == null) {
                    return;
                }
                if (!AddonGameRules.gojoTeleport(player)) {
                    return;
                }
                BlueRedPurpleNukeMod.handleGojoShiftTapPacket(player);
            });
            ctx.setPacketHandled(true);
        }
    }

    /**
     * Server-bound packet used when the skill wheel selects a stored cursed spirit instead of a normal technique.
     */
    public static class SelectSpiritPacket {
        // Stored cursed spirit slot selected from the multi-page Geto wheel.
        private final int spiritSlot;

        /**
         * Creates a new select spirit packet instance and initializes its addon state.
         * @param spiritSlot spirit slot used by this method.
         */
        public SelectSpiritPacket(int spiritSlot) {
            this.spiritSlot = spiritSlot;
        }

        /**
         * Writes this packet payload into the provided network buffer.
         * @param pkt pkt used by this method.
         * @param buf serialized data container used by this operation.
         */
        public static void encode(SelectSpiritPacket pkt, FriendlyByteBuf buf) {
            buf.writeInt(pkt.spiritSlot);
        }

        /**
         * Reads this packet payload from the provided network buffer and rebuilds the packet instance.
         * @param buf serialized data container used by this operation.
         * @return the resulting decode value.
         */
        public static SelectSpiritPacket decode(FriendlyByteBuf buf) {
            return new SelectSpiritPacket(buf.readInt());
        }

        /**
         * Handles  for the addon system.
         * @param pkt pkt used by this method.
         * @param ctxSupplier context data supplied by the current callback or network pipeline.
         */
        public static void handle(SelectSpiritPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> {
                String key;
                ServerPlayer player = ctx.getSender();
                if (player == null) {
                    return;
                }
                CompoundTag data = player.getPersistentData();
                if (data.getDouble(key = "data_cursed_spirit_manipulation" + pkt.spiritSlot) == 0.0) {
                    return;
                }
                String name = data.getString(key + "_name");
                double count = data.getDouble(key + "_num");
                String displayName = name + " \u00d7" + (int)Math.round(count);
                player.getCapability(JujutsucraftModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(cap -> {
                    cap.PlayerSelectCurseTechnique = 12.0;
                    cap.PlayerSelectCurseTechniqueName = displayName;
                    cap.syncPlayerVariables((Entity)player);
                });
            });
            ctx.setPacketHandled(true);
        }
    }

    public static class SelectYutaCopyPacket {
        private final double entryId;
        private final boolean activate;

        public SelectYutaCopyPacket(double entryId, boolean activate) {
            this.entryId = entryId;
            this.activate = activate;
        }

        public static void encode(SelectYutaCopyPacket pkt, FriendlyByteBuf buf) {
            buf.writeDouble(pkt.entryId);
            buf.writeBoolean(pkt.activate);
        }

        public static SelectYutaCopyPacket decode(FriendlyByteBuf buf) {
            return new SelectYutaCopyPacket(buf.readDouble(), buf.readBoolean());
        }

        public static void handle(SelectYutaCopyPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer player = ctx.getSender();
                if (player == null || !AddonGameRules.yutaCopy(player) || !YutaCopyStore.isActiveYuta(player) || !YutaCopyStore.hasValidRikaOrDomain(player)) {
                    return;
                }
                if (Math.abs(pkt.entryId - (double)YUTA_SUREHIT_CLEAR_ENTRY_ID) <= 0.001D) {
                    YutaCopyStore.clearSureHit(player);
                    return;
                }
                List<CompoundTag> validRecords = YutaCopyStore.validRecords(player);
                if (validRecords.isEmpty()) {
                    player.displayClientMessage(Component.literal("§e[Rika] No valid copied techniques are available."), true);
                    return;
                }
                int entryId = (int)Math.round(pkt.entryId);
                if (Math.abs(pkt.entryId - (double)entryId) > 0.001D) {
                    player.displayClientMessage(Component.literal("§e[Rika] Selected copy is no longer valid."), true);
                    return;
                }
                if (entryId >= YUTA_SUREHIT_ENTRY_BASE) {
                    YutaCopyStore.clearSureHit(player);
                    return;
                }
                if (entryId >= YUTA_COPY_ENTRY_BASE && entryId < YUTA_SUREHIT_ENTRY_BASE) {
                    CompoundTag rec = null;
                    for (CompoundTag candidate : validRecords) {
                        if (stableYutaCopyEntryId(candidate.getString("recordUuid")) == entryId) {
                            rec = candidate;
                            break;
                        }
                    }
                    if (rec == null) {
                        player.displayClientMessage(Component.literal("§e[Rika] Selected copy is no longer valid."), true);
                        return;
                    }
                    if (YutaCopyStore.selectRecord(player, rec.getString("recordUuid")) && pkt.activate) {
                        YutaCopyStore.activateSelected(player);
                    }
                    return;
                }
                player.displayClientMessage(Component.literal("§e[Rika] Selected copy is no longer valid."), true);
            });
            ctx.setPacketHandled(true);
        }
    }

    /**
     * Client-bound packet that synchronizes near-death cooldown progress and unlock state.
     */
    public record NearDeathCdSyncPacket(int cdRemaining, int cdMax, boolean rctLevel3Unlocked) {
        /**
         * Writes this packet payload into the provided network buffer.
         * @param pkt pkt used by this method.
         * @param buf serialized data container used by this operation.
         */
        public static void encode(NearDeathCdSyncPacket pkt, FriendlyByteBuf buf) {
            buf.writeInt(pkt.cdRemaining);
            buf.writeInt(pkt.cdMax);
            buf.writeBoolean(pkt.rctLevel3Unlocked);
        }

        /**
         * Reads this packet payload from the provided network buffer and rebuilds the packet instance.
         * @param buf serialized data container used by this operation.
         * @return the resulting decode value.
         */
        public static NearDeathCdSyncPacket decode(FriendlyByteBuf buf) {
            return new NearDeathCdSyncPacket(buf.readInt(), buf.readInt(), buf.readBoolean());
        }

        /**
         * Handles  for the addon system.
         * @param pkt pkt used by this method.
         * @param ctxSupplier context data supplied by the current callback or network pipeline.
         */
        public static void handle(NearDeathCdSyncPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> ClientPacketHandler.updateNearDeathCooldown(pkt.cdRemaining, pkt.cdMax, pkt.rctLevel3Unlocked)));
            ctx.setPacketHandled(true);
        }
    }

    /**
     * Server-bound packet that upgrades, refunds, resets, or changes domain mastery properties and forms.
     */
    public static class DomainPropertyPacket {
        // Named addon constant for op upgrade.
        public static final int OP_UPGRADE = 0;
        // Named addon constant for op refund.
        public static final int OP_REFUND = 1;
        // Named addon constant for op reset all.
        public static final int OP_RESET_ALL = 2;
        // Named addon constant for op set form.
        public static final int OP_SET_FORM = 3;
        // Named addon constant for op cycle form.
        public static final int OP_CYCLE_FORM = 4;
        // Named addon constant for op negative decrease.
        public static final int OP_NEGATIVE_DECREASE = 5;
        // Named addon constant for op negative increase.
        public static final int OP_NEGATIVE_INCREASE = 6;
        public static final int OP_SUKUNA_INCOMPLETE_SUREHIT = 7;
        public static final int OP_SUKUNA_INCOMPLETE_SUREHIT_CLEAR = 8;
        // Encoded domain mastery mutation operation handled by the server packet.
        private final int operation;
        // Runtime index used for property index.
        private final int propertyIndex;

        /**
         * Creates a new domain property packet instance and initializes its addon state.
         * @param operation operation used by this method.
         * @param propertyIndex property index used by this method.
         */
        public DomainPropertyPacket(int operation, int propertyIndex) {
            this.operation = operation;
            this.propertyIndex = propertyIndex;
        }

        /**
         * Writes this packet payload into the provided network buffer.
         * @param pkt pkt used by this method.
         * @param buf serialized data container used by this operation.
         */
        public static void encode(DomainPropertyPacket pkt, FriendlyByteBuf buf) {
            buf.writeByte(pkt.operation);
            buf.writeByte(pkt.propertyIndex);
        }

        /**
         * Reads this packet payload from the provided network buffer and rebuilds the packet instance.
         * @param buf serialized data container used by this operation.
         * @return the resulting decode value.
         */
        public static DomainPropertyPacket decode(FriendlyByteBuf buf) {
            return new DomainPropertyPacket(buf.readByte(), buf.readByte());
        }

        /**
         * Handles  for the addon system.
         * @param pkt pkt used by this method.
         * @param ctx context data supplied by the current callback or network pipeline.
         */
        public static void handle(DomainPropertyPacket pkt, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer sender = ((NetworkEvent.Context)ctx.get()).getSender();
                if (sender == null) {
                    return;
                }
                if (!AddonGameRules.domainMastery(sender)) {
                    return;
                }
                if (ModNetworking.rejectLockedDomainMasteryMutation(sender, pkt.operation)) {
                    return;
                }
                sender.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY, null).ifPresent(data -> {
                    boolean hasOpenAdvancement = ModNetworking.hasOpenBarrierAdvancement(sender);
                    data.setOpenBarrierAdvancementUnlocked(hasOpenAdvancement);
                    data.setBlackFlashMasteryUnlocked(ModNetworking.hasBlackFlashMastery(sender));
                    switch (pkt.operation) {
                        case 0: {
                            if (pkt.propertyIndex < 0 || pkt.propertyIndex >= DomainMasteryProperties.values().length) break;
                            DomainMasteryProperties prop = DomainMasteryProperties.values()[pkt.propertyIndex];
                            if (data.getDomainMasteryLevel() < prop.unlockLevel()) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Property locked \u2022 Reach Domain Mastery Lv." + prop.unlockLevel()), false);
                                return;
                            }
                            if (!data.upgradeProperty(prop)) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Not enough Property Points or property is currently negative"), false);
                                return;
                            }
                            sender.displayClientMessage(ModNetworking.domainMsgSuccess("\u25b2", ChatFormatting.GREEN, ModNetworking.domainPropLabel(prop) + " -> Lv." + data.getPropertyLevel(prop) + " (" + prop.formatLevelValue(data.getPropertyLevel(prop)) + ")"), false);
                            break;
                        }
                        case 1: {
                            if (pkt.propertyIndex < 0 || pkt.propertyIndex >= DomainMasteryProperties.values().length) break;
                            DomainMasteryProperties prop = DomainMasteryProperties.values()[pkt.propertyIndex];
                            if (!data.downgradeProperty(prop)) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Property already at Lv.0 or currently negative"), false);
                                return;
                            }
                            sender.displayClientMessage(ModNetworking.domainMsgInfo("\u21ba", ChatFormatting.GOLD, ModNetworking.domainPropLabel(prop) + " refunded \u2022 +" + prop.getPointCost() + " Point(s)"), false);
                            break;
                        }
                        case 2: {
                            int refunded = data.getDomainPropertyPoints();
                            data.refundAllProperties();
                            int gained = data.getDomainPropertyPoints();
                            sender.displayClientMessage(ModNetworking.domainMsgInfo("\u2727", ChatFormatting.AQUA, "All properties and negative modify reset \u2022 +" + (gained - refunded) + " Property Points restored"), false);
                            break;
                        }
                        case 3: {
                            if (!ModNetworking.hasDomainExpansionAdvancement(sender)) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Requires the Domain Expansion achievement"), false);
                                break;
                            }
                            int form = Math.max(0, Math.min(2, pkt.propertyIndex));
                            int level = data.getDomainMasteryLevel();
                            if (form == 1 && !DomainMasteryData.isClosedFormUnlocked(level)) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Closed Domain requires Domain Mastery Lv.1"), false);
                                break;
                            }
                            if (form == 2 && !DomainMasteryData.isOpenFormUnlocked(level, hasOpenAdvancement)) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Open Domain requires Domain Mastery Lv.5 and the Open Domain achievement"), false);
                                break;
                            }
                            data.setDomainTypeSelected(form, hasOpenAdvancement);
                            sender.displayClientMessage(ModNetworking.domainMsgSuccess("\u25c8", ChatFormatting.LIGHT_PURPLE, "Domain Form -> " + data.getDomainFormName()), false);
                            break;
                        }
                        case 4: {
                            int next;
                            if (!ModNetworking.hasDomainExpansionAdvancement(sender)) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Requires the Domain Expansion achievement"), false);
                                break;
                            }
                            int level = data.getDomainMasteryLevel();
                            boolean hasOpen = DomainMasteryData.isOpenFormUnlocked(level, hasOpenAdvancement);
                            int current = DomainMasteryData.sanitizeFormSelection(data.getDomainTypeSelected(), level, hasOpenAdvancement);
                            if (!DomainMasteryData.isClosedFormUnlocked(level)) {
                                next = 0;
                            } else if (hasOpen) {
                                next = switch (current) {
                                    case 0 -> 1;
                                    case 1 -> 2;
                                    default -> 0;
                                };
                            } else {
                                next = current == 0 ? 1 : 0;
                            }
                            data.setDomainTypeSelected(next, hasOpenAdvancement);
                            sender.displayClientMessage(ModNetworking.domainMsgSuccess("\u25c8", ChatFormatting.LIGHT_PURPLE, "Domain Form -> " + data.getDomainFormName()), false);
                            break;
                        }
                        case 5: {
                            if (pkt.propertyIndex < 0 || pkt.propertyIndex >= DomainMasteryProperties.values().length) break;
                            DomainMasteryProperties prop = DomainMasteryProperties.values()[pkt.propertyIndex];
                            if (data.getDomainMasteryLevel() < 5) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Negative Modify unlocks at Domain Mastery Lv.5"), false);
                                return;
                            }
                            if (!prop.supportsNegativeModify()) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Only Duration, Radius, and Clash Power can become negative"), false);
                                return;
                            }
                            if (!data.canSetNegative(prop)) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Another property is already negative"), false);
                                return;
                            }
                            if (data.getPropertyLevel(prop) > 0) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Refund this property to Lv.0 before applying Negative Modify"), false);
                                return;
                            }
                            if (!data.decreaseNegative(prop)) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Negative Modify is already at minimum Lv.-5"), false);
                                return;
                            }
                            int negativeLevel = data.getNegativeLevel();
                            sender.displayClientMessage(ModNetworking.domainMsgInfo("\u2212", ChatFormatting.RED, ModNetworking.domainPropLabel(prop) + " -> Lv." + negativeLevel + " \u2022 " + prop.formatNegativeValue(Math.abs(negativeLevel)) + " \u2022 +1 Property Point"), false);
                            break;
                        }
                        case 6: {
                            if (pkt.propertyIndex < 0 || pkt.propertyIndex >= DomainMasteryProperties.values().length) break;
                            DomainMasteryProperties prop = DomainMasteryProperties.values()[pkt.propertyIndex];
                            if (!data.increaseNegative(prop)) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Not enough Property Points to reduce negative modify"), false);
                                return;
                            }
                            if (data.isNegativeProperty(prop)) {
                                int negativeLevel = data.getNegativeLevel();
                                sender.displayClientMessage(ModNetworking.domainMsgSuccess("+", ChatFormatting.GREEN, ModNetworking.domainPropLabel(prop) + " -> Lv." + negativeLevel + " \u2022 " + prop.formatNegativeValue(Math.abs(negativeLevel))), false);
                                break;
                            }
                            sender.displayClientMessage(ModNetworking.domainMsgSuccess("+", ChatFormatting.GREEN, ModNetworking.domainPropLabel(prop) + " negative modify cleared"), false);
                            break;
                        }
                        case 7: {
                            if (!ModNetworking.hasDomainExpansionAdvancement(sender)) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Requires the Domain Expansion achievement"), false);
                                break;
                            }
                            if (!data.isBlackFlashMasteryUnlocked()) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Cleave Covenant requires Black Flash Mastery first"), false);
                                break;
                            }
                            if (data.isSukunaIncompleteSureHitUnlocked()) {
                                sender.displayClientMessage(ModNetworking.domainMsgInfo("◈", ChatFormatting.GOLD, "Cleave Covenant is already sealed into your Incomplete Shrine"), false);
                                break;
                            }
                            if (!data.purchaseSukunaIncompleteSureHit()) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Cleave Covenant cannot be forged with the current Shrine Setup or Property Point pool"), false);
                                break;
                            }
                            ModNetworking.grantAdvancement(sender, new ResourceLocation("jjkblueredpurple", "cleave_covenant"));
                            sender.displayClientMessage(ModNetworking.domainMsgSuccess("◈", ChatFormatting.RED, "Cleave Covenant Forged • Incomplete Malevolent Shrine will carry True Sure-Hit"), false);
                            break;
                        }
                        case 8: {
                            if (!data.isSukunaIncompleteSureHitUnlocked()) {
                                sender.displayClientMessage(ModNetworking.domainMsgError("Cleave Covenant is not currently sealed"), false);
                                break;
                            }
                            data.clearSukunaIncompleteSureHit();
                            sender.displayClientMessage(ModNetworking.domainMsgInfo("↺", ChatFormatting.GOLD, "Cleave Covenant Released • 5 Property Points returned"), false);
                            break;
                        }
                    }
                    data.syncToClient(sender);
                });
            });
            ctx.get().setPacketHandled(true);
        }
    }

    /**
     * Server-bound packet requesting that the server validate and open the domain mastery screen.
     */
    public static class DomainMasteryOpenPacket {
        /**
         * Writes this packet payload into the provided network buffer.
         * @param pkt pkt used by this method.
         * @param buf serialized data container used by this operation.
         */
        public static void encode(DomainMasteryOpenPacket pkt, FriendlyByteBuf buf) {
        }

        /**
         * Reads this packet payload from the provided network buffer and rebuilds the packet instance.
         * @param buf serialized data container used by this operation.
         * @return the resulting decode value.
         */
        public static DomainMasteryOpenPacket decode(FriendlyByteBuf buf) {
            return new DomainMasteryOpenPacket();
        }

        /**
         * Handles  for the addon system.
         * @param pkt pkt used by this method.
         * @param ctx context data supplied by the current callback or network pipeline.
         */
        public static void handle(DomainMasteryOpenPacket pkt, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                ServerPlayer sender = ((NetworkEvent.Context)ctx.get()).getSender();
                if (sender == null) {
                    return;
                }
                if (!AddonGameRules.domainMastery(sender)) {
                    return;
                }
                if (!ModNetworking.hasDomainExpansionAdvancement(sender)) {
                    sender.displayClientMessage(ModNetworking.domainMsgError("Requires the Domain Expansion achievement"), false);
                    return;
                }
                sender.getCapability(DomainMasteryCapabilityProvider.DOMAIN_MASTERY_CAPABILITY).ifPresent(data -> {
                    data.syncToClient(sender);
                    CHANNEL.send(PacketDistributor.PLAYER.with(() -> sender), (Object)new DomainMasteryOpenScreenPacket());
                });
            });
            ctx.get().setPacketHandled(true);
        }
    }

    /**
     * Client-bound packet that opens the domain mastery screen after server validation succeeds.
     */
    public static class DomainMasteryOpenScreenPacket {
        /**
         * Writes this packet payload into the provided network buffer.
         * @param pkt pkt used by this method.
         * @param buf serialized data container used by this operation.
         */
        public static void encode(DomainMasteryOpenScreenPacket pkt, FriendlyByteBuf buf) {
        }

        /**
         * Reads this packet payload from the provided network buffer and rebuilds the packet instance.
         * @param buf serialized data container used by this operation.
         * @return the resulting decode value.
         */
        public static DomainMasteryOpenScreenPacket decode(FriendlyByteBuf buf) {
            return new DomainMasteryOpenScreenPacket();
        }

        /**
         * Handles  for the addon system.
         * @param pkt pkt used by this method.
         * @param ctx context data supplied by the current callback or network pipeline.
         */
        public static void handle(DomainMasteryOpenScreenPacket pkt, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> ClientPacketHandler.openDomainMasteryScreen()));
            ctx.get().setPacketHandled(true);
        }
    }

    /**
     * Client-bound packet that transfers the full domain mastery capability snapshot.
     */
    public static class DomainMasterySyncPacket {
        // Domain mastery XP value transmitted to the client.
        private final double xp;
        // Domain mastery level transmitted to the client.
        private final int level;
        // Selected domain form transmitted to the client.
        private final int form;
        // Remaining property points transmitted to the client.
        private final int points;
        // Per-property level array transmitted to the client in enum order.
        private final int[] propLevels;
        // Name of the property currently assigned as the negative modify target.
        private final String negativeProperty;
        // Current negative modify level transmitted to the client.
        private final int negativeLevel;
        // Whether the server confirmed the open-barrier advancement for the receiving player.
        private final boolean hasOpenBarrierAdvancement;
        private final boolean sukunaIncompleteSureHitUnlocked;
        // Whether the server confirmed Black Flash Mastery for the receiving player.
        private final boolean blackFlashMasteryUnlocked;

        /**
         * Creates a new domain mastery sync packet instance and initializes its addon state.
         * @param data data used by this method.
         * @param hasOpenBarrierAdvancement has open barrier advancement used by this method.
         */
        public DomainMasterySyncPacket(DomainMasteryData data, boolean hasOpenBarrierAdvancement) {
            this.xp = data.getDomainXP();
            this.level = data.getDomainMasteryLevel();
            this.form = data.getDomainTypeSelected();
            this.points = data.getDomainPropertyPoints();
            this.negativeProperty = data.getNegativeProperty();
            this.negativeLevel = data.getNegativeLevel();
            this.hasOpenBarrierAdvancement = hasOpenBarrierAdvancement;
            this.sukunaIncompleteSureHitUnlocked = data.isSukunaIncompleteSureHitUnlocked();
            this.blackFlashMasteryUnlocked = data.isBlackFlashMasteryUnlocked();
            this.propLevels = new int[DomainMasteryProperties.values().length];
            for (int i = 0; i < this.propLevels.length; ++i) {
                this.propLevels[i] = data.getPropertyLevel(DomainMasteryProperties.values()[i]);
            }
        }

        /**
         * Writes this packet payload into the provided network buffer.
         * @param pkt pkt used by this method.
         * @param buf serialized data container used by this operation.
         */
        public static void encode(DomainMasterySyncPacket pkt, FriendlyByteBuf buf) {
            buf.writeDouble(pkt.xp);
            buf.writeByte(pkt.level);
            buf.writeByte(pkt.form);
            buf.writeVarInt(pkt.points);
            buf.writeUtf(pkt.negativeProperty);
            buf.writeInt(pkt.negativeLevel);
            buf.writeBoolean(pkt.hasOpenBarrierAdvancement);
            buf.writeBoolean(pkt.sukunaIncompleteSureHitUnlocked);
            buf.writeBoolean(pkt.blackFlashMasteryUnlocked);
            buf.writeByte(pkt.propLevels.length);
            for (int lvl : pkt.propLevels) {
                buf.writeByte(lvl);
            }
        }

        /**
         * Reads this packet payload from the provided network buffer and rebuilds the packet instance.
         * @param buf serialized data container used by this operation.
         * @return the resulting decode value.
         */
        public static DomainMasterySyncPacket decode(FriendlyByteBuf buf) {
            double xp = buf.readDouble();
            byte level = buf.readByte();
            byte form = buf.readByte();
            int points = buf.readVarInt();
            String negativeProperty = buf.readUtf();
            int negativeLevel = buf.readInt();
            boolean hasOpenBarrierAdvancement = buf.readBoolean();
            boolean sukunaIncompleteSureHitUnlocked = buf.readBoolean();
            boolean blackFlashMasteryUnlocked = buf.readBoolean();
            int count = buf.readByte();
            int[] levels = new int[count];
            for (int i = 0; i < count; ++i) {
                levels[i] = buf.readByte();
            }
            return new DomainMasterySyncPacket(xp, level, form, points, levels, negativeProperty, negativeLevel, hasOpenBarrierAdvancement, sukunaIncompleteSureHitUnlocked, blackFlashMasteryUnlocked);
        }

        /**
         * Creates a new domain mastery sync packet instance and initializes its addon state.
         * @param xp xp used by this method.
         * @param level level value used by this operation.
         * @param form form used by this method.
         * @param points points used by this method.
         * @param levels levels used by this method.
         * @param negativeProperty property identifier involved in this operation.
         * @param negativeLevel level value used by this operation.
         * @param hasOpenBarrierAdvancement has open barrier advancement used by this method.
         */
        private DomainMasterySyncPacket(double xp, int level, int form, int points, int[] levels, String negativeProperty, int negativeLevel, boolean hasOpenBarrierAdvancement, boolean sukunaIncompleteSureHitUnlocked, boolean blackFlashMasteryUnlocked) {
            this.xp = xp;
            this.level = level;
            this.form = form;
            this.points = points;
            this.propLevels = levels;
            this.negativeProperty = negativeProperty;
            this.negativeLevel = negativeLevel;
            this.hasOpenBarrierAdvancement = hasOpenBarrierAdvancement;
            this.sukunaIncompleteSureHitUnlocked = sukunaIncompleteSureHitUnlocked;
            this.blackFlashMasteryUnlocked = blackFlashMasteryUnlocked;
        }

        /**
         * Handles  for the addon system.
         * @param pkt pkt used by this method.
         * @param ctx context data supplied by the current callback or network pipeline.
         */
        public static void handle(DomainMasterySyncPacket pkt, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> ClientPacketHandler.syncDomainMastery(pkt.xp, pkt.level, pkt.form, pkt.points, pkt.propLevels, pkt.negativeProperty, pkt.negativeLevel, pkt.hasOpenBarrierAdvancement, pkt.sukunaIncompleteSureHitUnlocked, pkt.blackFlashMasteryUnlocked)));
            ctx.get().setPacketHandled(true);
        }
    }


    public static class GojoTeleportGhostPacket {
        private final double x;
        private final double y;
        private final double z;
        private final float yaw;
        private final int lifetime;

        public GojoTeleportGhostPacket(double x, double y, double z, float yaw, int lifetime) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
            this.lifetime = Math.max(1, Math.min(60, lifetime));
        }

        public static void encode(GojoTeleportGhostPacket pkt, FriendlyByteBuf buf) {
            buf.writeDouble(pkt.x);
            buf.writeDouble(pkt.y);
            buf.writeDouble(pkt.z);
            buf.writeFloat(pkt.yaw);
            buf.writeVarInt(pkt.lifetime);
        }

        public static GojoTeleportGhostPacket decode(FriendlyByteBuf buf) {
            return new GojoTeleportGhostPacket(buf.readDouble(), buf.readDouble(), buf.readDouble(), buf.readFloat(), buf.readVarInt());
        }

        public static void handle(GojoTeleportGhostPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> ClientPacketHandler.spawnGojoTeleportGhost(pkt.x, pkt.y, pkt.z, pkt.yaw, pkt.lifetime)));
            ctx.setPacketHandled(true);
        }
    }
 
    private static boolean canManageAddonGameRules(ServerPlayer player) {
        return player != null && player.hasPermissions(2);
    }

    private static void sendAddonGameRulesSnapshot(ServerPlayer player) {
        if (player == null) {
            return;
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new OpenAddonGameRulesPacket(AddonGameRules.snapshots(player.level())));
    }

    private static void syncAddonGameRulesCache(ServerPlayer player) {
        if (player == null) {
            return;
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new SyncAddonGameRulesPacket(AddonGameRules.snapshots(player.level())));
    }

    private static void syncAddonGameRulesCacheToAll(ServerPlayer source) {
        if (source == null || source.server == null) {
            return;
        }
        for (ServerPlayer target : source.server.getPlayerList().getPlayers()) {
            syncAddonGameRulesCache(target);
        }
    }

    private static void encodeRuleSnapshots(List<AddonGameRules.RuleSnapshot> rules, FriendlyByteBuf buf) {
        List<AddonGameRules.RuleSnapshot> safeRules = rules == null ? List.of() : rules;
        buf.writeVarInt(safeRules.size());
        for (AddonGameRules.RuleSnapshot rule : safeRules) {
            buf.writeUtf(rule.id(), 128);
            buf.writeUtf(rule.fieldName(), 96);
            buf.writeUtf(rule.tabId(), 64);
            buf.writeUtf(rule.tabName(), 64);
            buf.writeVarInt(rule.tabOrder());
            buf.writeUtf(rule.label(), 128);
            buf.writeUtf(rule.description(), 220);
            buf.writeVarInt(rule.kind().ordinal());
            buf.writeUtf(rule.value(), 64);
            buf.writeUtf(rule.defaultValue(), 64);
        }
    }

    private static List<AddonGameRules.RuleSnapshot> decodeRuleSnapshots(FriendlyByteBuf buf) {
        int size = buf.readVarInt();
        ArrayList<AddonGameRules.RuleSnapshot> rules = new ArrayList<>();
        AddonGameRules.RuleKind[] kinds = AddonGameRules.RuleKind.values();
        for (int i = 0; i < size; i++) {
            String id = buf.readUtf(128);
            String fieldName = buf.readUtf(96);
            String tabId = buf.readUtf(64);
            String tabName = buf.readUtf(64);
            int tabOrder = buf.readVarInt();
            String label = buf.readUtf(128);
            String description = buf.readUtf(220);
            int kindOrdinal = Math.max(0, Math.min(kinds.length - 1, buf.readVarInt()));
            String value = buf.readUtf(64);
            String defaultValue = buf.readUtf(64);
            rules.add(new AddonGameRules.RuleSnapshot(id, fieldName, tabId, tabName, tabOrder, label, description, kinds[kindOrdinal], value, defaultValue));
        }
        return rules;
    }

    public static class RequestAddonGameRulesPacket {
        public static void encode(RequestAddonGameRulesPacket pkt, FriendlyByteBuf buf) {
        }

        public static RequestAddonGameRulesPacket decode(FriendlyByteBuf buf) {
            return new RequestAddonGameRulesPacket();
        }

        public static void handle(RequestAddonGameRulesPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer player = ctx.getSender();
                if (!canManageAddonGameRules(player)) {
                    if (player != null) {
                        player.displayClientMessage(Component.literal("JoQu's JJC Addon gamerule panel requires operator permission level 2."), true);
                    }
                    return;
                }
                sendAddonGameRulesSnapshot(player);
            });
            ctx.setPacketHandled(true);
        }
    }

    public static class OpenAddonGameRulesPacket {
        private final List<AddonGameRules.RuleSnapshot> rules;

        public OpenAddonGameRulesPacket(List<AddonGameRules.RuleSnapshot> rules) {
            this.rules = rules == null ? List.of() : List.copyOf(rules);
        }

        public static void encode(OpenAddonGameRulesPacket pkt, FriendlyByteBuf buf) {
            encodeRuleSnapshots(pkt.rules, buf);
        }

        public static OpenAddonGameRulesPacket decode(FriendlyByteBuf buf) {
            return new OpenAddonGameRulesPacket(decodeRuleSnapshots(buf));
        }

        public static void handle(OpenAddonGameRulesPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> ClientPacketHandler.openAddonGameRulesScreen(pkt.rules)));
            ctx.setPacketHandled(true);
        }
    }

    public static class SyncAddonGameRulesPacket {
        private final List<AddonGameRules.RuleSnapshot> rules;

        public SyncAddonGameRulesPacket(List<AddonGameRules.RuleSnapshot> rules) {
            this.rules = rules == null ? List.of() : List.copyOf(rules);
        }

        public static void encode(SyncAddonGameRulesPacket pkt, FriendlyByteBuf buf) {
            encodeRuleSnapshots(pkt.rules, buf);
        }

        public static SyncAddonGameRulesPacket decode(FriendlyByteBuf buf) {
            return new SyncAddonGameRulesPacket(decodeRuleSnapshots(buf));
        }

        public static void handle(SyncAddonGameRulesPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> ClientPacketHandler.syncAddonGameRules(pkt.rules)));
            ctx.setPacketHandled(true);
        }
    }

    public static class SetAddonGameRulePacket {
        private final String id;
        private final String value;

        public SetAddonGameRulePacket(String id, String value) {
            this.id = id == null ? "" : id;
            this.value = value == null ? "" : value;
        }

        public static void encode(SetAddonGameRulePacket pkt, FriendlyByteBuf buf) {
            buf.writeUtf(pkt.id, 128);
            buf.writeUtf(pkt.value, 64);
        }

        public static SetAddonGameRulePacket decode(FriendlyByteBuf buf) {
            return new SetAddonGameRulePacket(buf.readUtf(128), buf.readUtf(64));
        }

        public static void handle(SetAddonGameRulePacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer player = ctx.getSender();
                if (!canManageAddonGameRules(player)) {
                    if (player != null) {
                        player.displayClientMessage(Component.literal("You do not have permission to edit JoQu's JJC Addon gamerules."), true);
                    }
                    return;
                }
                boolean changed = AddonGameRules.setRule(player.server, player.level(), pkt.id, pkt.value);
                if (!changed) {
                    player.displayClientMessage(Component.literal("Invalid JoQu's JJC Addon gamerule value: " + pkt.id), true);
                } else {
                    syncAddonGameRulesCacheToAll(player);
                }
                sendAddonGameRulesSnapshot(player);
            });
            ctx.setPacketHandled(true);
        }
    }

    /**
     * Immutable snapshot of vanilla technique selection state used while the server probes wheel entries.
     */
    // ===== PAYLOAD RECORDS =====
    private record PlayerSelectionSnapshot(double selectId, String name, double finalCost, double baseCost, boolean passive, boolean physical, boolean noChangeTechnique, String overlayCost, String overlayCursePower) {
    }

    /**
     * Immutable data row describing a single skill wheel entry, its colors, costs, cooldowns, and optional domain metadata.
     */
    public record WheelTechniqueEntry(double selectId, String displayName, double finalCost, double baseCost, int color, boolean passive, boolean physical, int domainForm, double domainMultiplier, int cooldownRemainingTicks, int cooldownMaxTicks) {
    }

    /**
     * Small helper record describing a stored cursed spirit slot for Geto's paged wheel entries.
     */
    private record SpiritData(int slot, String name, int count, int grade) {
    }

    public record DomainClashOpponentPayload(float power, int form, int domainId, String name) {
        public DomainClashOpponentPayload {
            power = Math.max(0.0f, power);
            name = name == null ? "" : name;
        }
    }

    public static void sendGojoShiftTap() {
        CHANNEL.sendToServer((Object)new GojoShiftTapPacket());
    }

    public static void sendBlackFlashRelease(float clientNeedle, long timingNonce) {
        CHANNEL.sendToServer((Object)new BlackFlashReleasePacket(clientNeedle, Float.NaN, timingNonce, false));
    }

    public static void sendBlackFlashRelease(float clientNeedle, long timingNonce, boolean clientTimingSuccess) {
        CHANNEL.sendToServer((Object)new BlackFlashReleasePacket(clientNeedle, Float.NaN, timingNonce, clientTimingSuccess));
    }

    public static void sendBlackFlashRelease(float clientNeedle, float clientElapsedTicks, long timingNonce, boolean clientTimingSuccess) {
        CHANNEL.sendToServer((Object)new BlackFlashReleasePacket(clientNeedle, clientElapsedTicks, timingNonce, clientTimingSuccess));
    }

    public static void sendBlackFlashFeedback(net.minecraft.server.level.ServerPlayer player, boolean success, boolean confirmedHit) {
        if (player == null || !AddonGameRules.blackFlashHud(player.level())) {
            return;
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), (Object)new BlackFlashFeedbackPacket(success, confirmedHit));
    }

    public static class BlackFlashReleasePacket {
        private final float clientNeedle;
        private final float clientElapsedTicks;
        private final long timingNonce;
        private final boolean clientTimingSuccess;

        public BlackFlashReleasePacket(float clientNeedle, long timingNonce) {
            this(clientNeedle, Float.NaN, timingNonce, false);
        }

        public BlackFlashReleasePacket(float clientNeedle, long timingNonce, boolean clientTimingSuccess) {
            this(clientNeedle, Float.NaN, timingNonce, clientTimingSuccess);
        }

        public BlackFlashReleasePacket(float clientNeedle, float clientElapsedTicks, long timingNonce, boolean clientTimingSuccess) {
            this.clientNeedle = clientNeedle;
            this.clientElapsedTicks = clientElapsedTicks;
            this.timingNonce = timingNonce;
            this.clientTimingSuccess = clientTimingSuccess;
        }

        public static void encode(BlackFlashReleasePacket pkt, FriendlyByteBuf buf) {
            buf.writeFloat(pkt.clientNeedle);
            buf.writeFloat(pkt.clientElapsedTicks);
            buf.writeLong(pkt.timingNonce);
            buf.writeBoolean(pkt.clientTimingSuccess);
        }

        public static BlackFlashReleasePacket decode(FriendlyByteBuf buf) {
            return new BlackFlashReleasePacket(buf.readFloat(), buf.readFloat(), buf.readLong(), buf.readBoolean());
        }

        public static void handle(BlackFlashReleasePacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> {
                ServerPlayer player = ctx.getSender();
                if (player != null && AddonGameRules.blackFlashTiming(player)) {
                    BlueRedPurpleNukeMod.resolveBlackFlashTimingRelease(player, true, pkt.clientNeedle, pkt.clientElapsedTicks, pkt.timingNonce, pkt.clientTimingSuccess);
                }
            });
            ctx.setPacketHandled(true);
        }
    }

    public static class BlackFlashFeedbackPacket {
        private final boolean success;
        private final boolean confirmedHit;

        public BlackFlashFeedbackPacket(boolean success, boolean confirmedHit) {
            this.success = success;
            this.confirmedHit = confirmedHit;
        }

        public static void encode(BlackFlashFeedbackPacket pkt, FriendlyByteBuf buf) {
            buf.writeBoolean(pkt.success);
            buf.writeBoolean(pkt.confirmedHit);
        }

        public static BlackFlashFeedbackPacket decode(FriendlyByteBuf buf) {
            return new BlackFlashFeedbackPacket(buf.readBoolean(), buf.readBoolean());
        }

        public static void handle(BlackFlashFeedbackPacket pkt, Supplier<NetworkEvent.Context> ctxSupplier) {
            NetworkEvent.Context ctx = ctxSupplier.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> ClientPacketHandler.showBlackFlashFeedback(pkt.success, pkt.confirmedHit)));
            ctx.setPacketHandled(true);
        }
    }
}
